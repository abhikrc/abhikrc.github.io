%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Declaration of LSC Charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% here we use the Figure 7 (a) in paper "Symbolic Checking of Behavioral Requirements" as example
%% this shows that our simulator can find the vilotion caused by time constraints

 
allInstanceCount(3).

declareInstance(0, user).
declareInstance(1, host).
declareInstance(2, display).

initInstance(user, [[0, []]]).

initInstance(host, [[0, []]]).

initInstance(display, [[0, []]]).

bindInstanceVars(_).

declareSysVars([]).


allChartCount(1).

 
declareChart(0, example).

declareChartSymbolicInstances(example, [[user, [[0,0]]], [host, [[0,0]]], [display, [[0,0]]]]).


declareMainChart(example, main_example).

declarePreChart(example, pre_example).

declareChartVars(example, [_, _, _]).



 
chartEventCount(pre_example, 3).

chartEventCount(main_example, 5).

declareChartInstances(pre_example, [user, host]).
declareChartInstances(main_example, [host, display]).


declareInstanceLocations(pre_example, user, [0, 2]):- !.
declareInstanceLocations(pre_example, host, [1, 2]):- !.

declareInstanceLocations(main_example, host, [0, 1, 4]):- !.
declareInstanceLocations(main_example, display, [2, 3, 4]):- !.


declareChartActivationCondition(example, example_ac):- !.


example_ac(_, _, _, _).



 %% events, 
declareEvent(pre_example, [0, 1, hot, asend, [user], [[[user, send_const], [host, recv_const]], user, host, asend_p0_0], hot]):- !.
declareEvent(pre_example, [1, 2, hot, arecv, [host], [[[user, send_const], [host, recv_const]], user, host, arecv_p0_0], hot]):- !.
declareEvent(pre_example, [2, 2, hot, end, [user, host], [], cold]):- !.


declareEvent(main_example, [0, 2, hot, time, [host], [[], time_m0_0], hot]):- !.
declareEvent(main_example, [1, 2, hot, asend, [host], [[[host, send_const], [display, recv_const]], host, display, asend_m0_0], hot]):- !.
declareEvent(main_example, [2, 2, hot, arecv, [display], [[[host, send_const], [display, recv_const]], host, display, arecv_m0_0], hot]):- !.
declareEvent(main_example, [3, 2, hot, time, [display], [[], time_m0_1], hot]):- !.
declareEvent(main_example, [4, 2, hot, end, [host, display], [[]], cold]):- !.



send_const(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
    
recv_const(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_p0_0([on], _, _, _, _).
arecv_p0_0([on], _, _, _, _).

asend_m0_0([green], _, _, _, _).
arecv_m0_0([green], _, _, _, _).

time_m0_0(_, _, _, NewTime, _):-
    NewTime #>=2.


time_m0_1(_, _, _, NewTime, _):-
    NewTime #<=1.
   

   
begin:-
    run([[asend, user, [], host, [], [on], hot], [arecv, user, [], host, [], [on], hot]], _, _).
