%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Declaration of LSC Charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% figure 13 on "Multiple Instances and Symbolic Variables in Executable Sequence Charts"
%%   this shows that our simulator can process complex LSC charts. This example involves several charts
%%   here we instantiate every object of class phone, because each of them has a unique property. It cannot be symbolic
%%   1. we change the event Set QResult to an assignment event
%%   2. we change three assignments ID:= Phone.ID, Caller:=Channel.ID, and Receiver:=PhoneDB.Result  to three bind operations
%%   3. after each Allocate(_) message, we add an assignment to set the Channel.Allocated variable
%%   4. change the condition PhoneDBResult= Caller

%% NOTE: channel and channel2 are the same classes, but have different names to differ them in the chart
%%       their values have been binded together



allInstanceCount(6).

declareInstance(0, user).
declareInstance(1, phone).
declareInstance(2, channel).
declareInstance(3, switch).
declareInstance(4, phoneDB).
declareInstance(5, channel2).

initInstance(user, [[0, []]]).

initInstance(phone, InstanceVars):-
    initPhoneVars(InstanceVars, 10).

initInstance(channel, InstanceVars):-
    initChannelVars(InstanceVars, 10).

initInstance(switch, [[0, [0]]]).

initInstance(phoneDB, [[0, [_]]]).   %% [QResult]

initInstance(channel2, InstanceVars):-
    initChannel2Vars(InstanceVars, 10).


initPhoneVars([[1, [1, 4]]], 1):- !.    %%[ID, Display]

initPhoneVars(InstanceVars, X):-
    X2 is X-1,
    initPhoneVars(InstanceVars1, X2),
    X1 is X+4,
    noNullAppend(InstanceVars1, [[X, [X, X1]]], InstanceVars).
    
    
initChannelVars([[1, [1, true]]], 1):- !.     %%[ID, inorder]

initChannelVars(InstanceVars, X):-
    X1 is X-1,
    initChannelVars(InstanceVars1, X1),
    noNullAppend(InstanceVars1, [[X, [X, true]]], InstanceVars).


initChannel2Vars([[1, [1, _]]], 1):- !.

initChannel2Vars(InstanceVars, X):-
    X1 is X-1,
    initChannel2Vars(InstanceVars1, X1),
    noNullAppend(InstanceVars1, [[X, [X, _]]], InstanceVars).


bindInstanceVars(InstanceVarsList):-
    getListofInstance(InstanceVarsList, channel, ChannelVarList),
    getListofInstance(InstanceVarsList, channel2, Channel2VarList),
    ChannelVarList= Channel2VarList.


declareSysVars([_]).                     %% channel.allocated
 


allChartCount(3).

 
declareChart(0, clickCall).
declareChart(1, callChannel).
declareChart(2, getReceiver).

declareChartSymbolicInstances(clickCall, [[user, [[0,0]]], [phone, [[1]]], [channel, [[1]]]]).
declareChartSymbolicInstances(callChannel, [[phone, [[1]]], [channel, [[1]]], [switch, [[0,0]]]]).
declareChartSymbolicInstances(getReceiver, [[channel, [[1]]], [switch, [[0,0]]], [phone, [[1]]], [phoneDB, [[0,0]]], [channel2, [[1]]]]).



declarePreChart(clickCall, pre_clickCall).
declarePreChart(callChannel, pre_callChannel).
declarePreChart(getReceiver, pre_getReceiver).


declareMainChart(clickCall, main_clickCall).
declareMainChart(callChannel, main_callChannel).
declareMainChart(getReceiver, main_getReceiver).


declareChartVars(clickCall, [_, _, _, _]).
declareChartVars(callChannel, [_, _, _]).
declareChartVars(getReceiver, [_, _, _, _]).


 %%%%% declare events

chartEventCount(pre_clickCall, 3).
chartEventCount(main_clickCall, 7).

chartEventCount(pre_callChannel, 3).
chartEventCount(main_callChannel, 9).

chartEventCount(pre_getReceiver, 3).
chartEventCount(main_getReceiver, 39).


declareChartInstances(pre_clickCall, [user, phone]).
declareChartInstances(main_clickCall, [phone, channel]).

declareChartInstances(pre_callChannel, [phone, channel]).
declareChartInstances(main_callChannel, [phone, channel, switch]).

declareChartInstances(pre_getReceiver, [channel, switch]).
declareChartInstances(main_getReceiver, [channel, switch, phone, phoneDB, channel2]).


declareInstanceLocations(pre_clickCall, user, [0, 2]):- !.
declareInstanceLocations(pre_clickCall, phone, [1, 2]):- !.

declareInstanceLocations(main_clickCall, phone, [0, 1, 2, 5, 6]):- !.
declareInstanceLocations(main_clickCall, channel, [3, 4, 6]):- !.

declareInstanceLocations(pre_callChannel, phone, [0, 2]):- !.
declareInstanceLocations(pre_callChannel, channel, [1, 2]):- !.

declareInstanceLocations(main_callChannel, phone, [0, 3, 4, 7, 8]):- !.
declareInstanceLocations(main_callChannel, channel, [0, 1, 2, 4, 5, 7, 8]):- !.
declareInstanceLocations(main_callChannel, switch, [0, 4, 6, 7, 8]):- !.

declareInstanceLocations(pre_getReceiver, channel, [0, 2]):- !.
declareInstanceLocations(pre_getReceiver, switch, [1, 2]):- !.

declareInstanceLocations(main_getReceiver, channel, [0, 1, 2, 3, 6, 7, 8, 10, 11, 12, 13, 14, 17, 22, 23, 24, 25, 30, 31, 33, 36, 37, 38]):- !.
declareInstanceLocations(main_getReceiver, switch, [1, 3, 4, 5, 8, 9, 12, 13, 14, 17, 19, 21, 24, 25, 27, 29, 32, 34, 36, 37, 38]):- !.
declareInstanceLocations(main_getReceiver, phone, [14, 15, 17, 20, 24, 25, 28, 32, 33, 36, 37, 38]):- !.
declareInstanceLocations(main_getReceiver, phoneDB, [14, 16, 17, 18, 24, 25, 26, 32, 33, 36, 37, 38]):- !.
declareInstanceLocations(main_getReceiver, channel2, [17, 24, 25, 32, 33, 35, 36, 37, 38]):- !.







declareChartActivationCondition(clickCall, main_clickCall_ac):- !.
declareChartActivationCondition(callChannel, main_callChannel_ac):- !.
declareChartActivationCondition(getReceiver, main_getReceiver_ac):- !.


main_clickCall_ac(_, _, _, _).
main_callChannel_ac(_, _, _, _).
main_getReceiver_ac(_, _, _, _).


%% events,
declareEvent(pre_clickCall, [0, 1, hot, asend, [user], [[[user, send_const_p0_1], [phone, recv_const_p0_1]], user, phone, asend_p0_1], hot]):- !.
declareEvent(pre_clickCall, [1, 2, hot, arecv, [phone], [[[user, send_const_p0_1], [phone, recv_const_p0_1]], user, phone, arecv_p0_1], hot]):- !.
declareEvent(pre_clickCall, [2, 2, hot, end, [[], user, phone], [], cold]):- !.


%% events,
%% here ect. are function to implement meta-programming
%% paramaters for the same type of event should be the same
%% send(Value, SysVarList, InstanceList, ChartVarList)
%% recv(Value, SysVarList, InstanceList, ChartVarList)
%% assign(SysVarList, InstanceList, ChartVarList, NewSysVarList, NewInstanceList, NewChartVarList)
%% condition(SysVarList, InstanceList, ChartVarList)

declareEvent(main_clickCall, [0, 2, hot, bind, [phone], [[], bind_m0_1], hot]):- !.
declareEvent(main_clickCall, [1, 2, hot, assignment, [phone], [[], assign_m0_2], hot]):- !.
declareEvent(main_clickCall, [2, 2, hot, asend, [phone], [[[phone, send_const_m0_1], [channel, recv_const_m0_1]], phone, channel, asend_m0_1], hot]):- !.
declareEvent(main_clickCall, [3, 2, hot, arecv, [channel], [[[phone, send_const_m0_1], [channel, recv_const_m0_1]], phone, channel, arecv_m0_1], hot]):- !.
declareEvent(main_clickCall, [4, 2, hot, asend, [channel], [[[channel, send_const_m0_2], [phone, recv_const_m0_2]], channel, phone, asend_m0_2], hot]):- !.
declareEvent(main_clickCall, [5, 2, hot, arecv, [phone], [[[channel, send_const_m0_2], [phone, recv_const_m0_2]], channel, phone, arecv_m0_2], hot]):- !.
declareEvent(main_clickCall, [6, 2, hot, end, [phone, channel], [[]], cold]):- !.


%% events
declareEvent(pre_callChannel, [0, 1, hot, asend, [phone], [[[phone, send_const_p1_1], [channel, recv_const_p1_1]], phone, channel, asend_p1_1], hot]):- !.
declareEvent(pre_callChannel, [1, 2, hot, arecv, [channel], [[[phone, send_const_p1_1], [channel, recv_const_p1_1]], phone, channel, arecv_p1_1], hot]):- !.
declareEvent(pre_callChannel, [2, 2, hot, end, [[], phone, channel], [], cold]):- !.

%% events
declareEvent(main_callChannel, [0, 2, hot, subbegin, [phone, channel, switch], [[]], hot]):- !.
declareEvent(main_callChannel, [1, 2, hot, condition, [channel], [[], cond_m1_0, [[[channel, 2]], [[phone, 7], [channel, 5], [switch, 6]]]], cold]):- !.
declareEvent(main_callChannel, [2, 2, hot, asend, [channel], [[[channel, send_const_m1_1], [phone, recv_const_m1_1]], channel, phone, asend_m1_1], hot]):- !.
declareEvent(main_callChannel, [3, 2, hot, arecv, [phone], [[[channel, send_const_m1_1], [phone, recv_const_m1_1]], channel, phone, arecv_m1_1], hot]):- !.
declareEvent(main_callChannel, [4, 2, hot, goto, [phone, channel, switch], [[], [[phone, 7], [channel, 7], [switch, 7]]], hot]):- !.
declareEvent(main_callChannel, [5, 2, hot, asend, [channel], [[[channel, send_const_m1_2], [switch, recv_const_m1_2]], channel, switch, asend_m1_2], hot]):- !.
declareEvent(main_callChannel, [6, 2, hot, arecv, [switch], [[[channel, send_const_m1_2], [switch, recv_const_m1_2]], channel, switch, arecv_m1_2], hot]):- !.
declareEvent(main_callChannel, [7, 2, hot, subend, [phone, channel, switch], [[]], hot]):- !.
declareEvent(main_callChannel, [8, 2, hot, end, [phone, channel, switch], [[]], cold]):- !.

%% events
declareEvent(pre_getReceiver, [0, 1, hot, asend, [channel], [[[channel, send_const_p2_1], [switch, recv_const_p2_1]], channel, switch, asend_p2_1], hot]):- !.
declareEvent(pre_getReceiver, [1, 2, hot, arecv, [switch], [[[channel, send_const_p2_1], [switch, recv_const_p2_1]], channel, switch, arecv_p2_1], hot]):- !.
declareEvent(pre_getReceiver, [2, 2, hot, end, [[], channel, switch], [], cold]):- !.

%% events
declareEvent(main_getReceiver, [0, 2, hot, bind, [channel], [[], bind_m2_1], hot]):- !.
declareEvent(main_getReceiver, [1, 2, hot, subbegin, [channel, switch], [[]], hot]):- !.
declareEvent(main_getReceiver, [2, 2, hot, condition, [channel], [[], cond_m2_0, [[[channel, 3]], [[channel, 12], [switch, 12]]]], cold]):- !.
declareEvent(main_getReceiver, [3, 2, hot, subbegin, [channel, switch], [[]], hot]):- !.
declareEvent(main_getReceiver, [4, 2, hot, condition, [switch], [[], cond_m2_1, [[[switch, 5]], [[channel, 10], [switch, 9]]]], cold]):- !.
declareEvent(main_getReceiver, [5, 2, hot, asend, [switch], [[[switch, send_const_m2_1], [channel, recv_const_m2_1]], switch, channel, asend_m2_1], hot]):- !.
declareEvent(main_getReceiver, [6, 2, hot, arecv, [channel], [[[switch, send_const_m2_1], [channel, recv_const_m2_1]], switch, channel, arecv_m2_1], hot]):- !.
declareEvent(main_getReceiver, [7, 2, hot, assignment, [channel], [[], assign_m2_0], hot]):- !.
declareEvent(main_getReceiver, [8, 2, hot, goto, [channel, switch], [[], [[channel, 12], [switch, 12]]], hot]):- !.
declareEvent(main_getReceiver, [9, 2, hot, asend, [switch], [[[switch, send_const_m2_2], [channel, recv_const_m2_2]], switch, channel, asend_m2_2], hot]):- !.
declareEvent(main_getReceiver, [10, 2, hot, arecv, [channel], [[[switch, send_const_m2_2], [channel, recv_const_m2_2]], switch, channel, arecv_m2_2], hot]):- !.
declareEvent(main_getReceiver, [11, 2, hot, assignment, [channel], [[], assign_m2_1], hot]):- !.
declareEvent(main_getReceiver, [12, 2, hot, subend, [channel, switch], [[]], hot]):- !.
declareEvent(main_getReceiver, [13, 2, hot, subend, [channel, switch], [[]], hot]):- !.
declareEvent(main_getReceiver, [14, 2, hot, condition, [channel, switch, phone, phoneDB], [[], cond_m2_2, []], hot]):- !.
declareEvent(main_getReceiver, [15, 2, hot, assignment, [phone], [[], assign_m2_2], hot]):- !.
declareEvent(main_getReceiver, [16, 2, hot, assignment, [phoneDB], [[], assign_m2_3], hot]):- !.
declareEvent(main_getReceiver, [17, 2, hot, subbegin, [channel, switch, phone, phoneDB, channel2], [[]], hot]):- !.
declareEvent(main_getReceiver, [18, 2, hot, condition, [phoneDB], [[], cond_m2_3, [[[phoneDB, 24]], [[channel, 25], [switch, 25], [phone, 25], [phoneDB, 25], [channel2, 25]]]], cold]):- !.
declareEvent(main_getReceiver, [19, 2, hot, asend, [switch], [[[switch, send_const_m2_3], [phone, recv_const_m2_3]], switch, phone, asend_m2_3], hot]):- !.
declareEvent(main_getReceiver, [20, 2, hot, arecv, [phone], [[[switch, send_const_m2_3], [phone, recv_const_m2_3]], switch, phone, arecv_m2_3], hot]):- !.
declareEvent(main_getReceiver, [21, 2, hot, asend, [switch], [[[switch, send_const_m2_4], [channel, recv_const_m2_4]], switch, channel, asend_m2_4], hot]):- !.
declareEvent(main_getReceiver, [22, 2, hot, arecv, [channel], [[[switch, send_const_m2_4], [channel, recv_const_m2_4]], switch, channel, arecv_m2_4], hot]):- !.
declareEvent(main_getReceiver, [23, 2, hot, assignment, [channel], [[], assign_m2_4], hot]):- !.
declareEvent(main_getReceiver, [24, 2, hot, goto, [channel, switch, phone, phoneDB, channel2], [[], [[channel, 37], [switch, 37], [phone, 37], [phoneDB, 37], [channel2, 37]]], hot]):- !.
declareEvent(main_getReceiver, [25, 2, hot, subbegin, [channel, switch, phone, phoneDB, channel2], [[]], hot]):- !.
declareEvent(main_getReceiver, [26, 2, hot, condition, [phoneDB], [[], cond_m2_4, [[[phoneDB, 32]], [[channel, 36], [switch, 34], [phone, 33], [phoneDB, 33], [channel2, 33]]]], cold]):- !.
declareEvent(main_getReceiver, [27, 2, hot, asend, [switch], [[[switch, send_const_m2_5], [phone, recv_const_m2_5]], switch, phone, asend_m2_5], hot]):- !.
declareEvent(main_getReceiver, [28, 2, hot, arecv, [phone], [[[switch, send_const_m2_5], [phone, recv_const_m2_5]], switch, phone, arecv_m2_5], hot]):- !.
declareEvent(main_getReceiver, [29, 2, hot, asend, [switch], [[[switch, send_const_m2_6], [channel, recv_const_m2_6]], switch, channel, asend_m2_6], hot]):- !.
declareEvent(main_getReceiver, [30, 2, hot, arecv, [channel], [[[switch, send_const_m2_6], [channel, recv_const_m2_6]], switch, channel, arecv_m2_6], hot]):- !.
declareEvent(main_getReceiver, [31, 2, hot, assignment, [channel], [[], assign_m2_5], hot]):- !.
declareEvent(main_getReceiver, [32, 2, hot, goto, [channel, switch, phone, phoneDB, channel2], [[], [[channel, 36], [switch, 36], [phone, 36], [phoneDB, 36], [channel2, 36]]], hot]):- !.
declareEvent(main_getReceiver, [33, 2, hot, bind, [phone, phoneDB, channel2], [[], bind_m2_2], hot]):- !.
declareEvent(main_getReceiver, [34, 2, hot, asend, [switch], [[[switch, send_const_m2_7], [channel2, recv_const_m2_7]], switch, channel2, asend_m2_7], hot]):- !.
declareEvent(main_getReceiver, [35, 2, hot, arecv, [channel2], [[[switch, send_const_m2_7], [channel2, recv_const_m2_7]], switch, channel2, arecv_m2_7], hot]):- !.
declareEvent(main_getReceiver, [36, 2, hot, subend, [channel, switch, phone, phoneDB, channel2], [[]], hot]):- !.
declareEvent(main_getReceiver, [37, 2, hot, subend, [channel, switch, phone, phoneDB, channel2], [[]], hot]):- !.
declareEvent(main_getReceiver, [38, 2, hot, end, [channel, switch, phone, phoneDB, channel2], [[]], cold]):- !.



send_const_p0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_p0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_p0_1([click, call], _, _, _, _).
arecv_p0_1([click, call], _, _, _, _).

bind_m0_1(_, InstanceVarList, _, ChartSymblicInstanceList, NewChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phone, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phone, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[ID|_],
    updateSymbolicInstanceList(ChartSymblicInstanceList, NewChartSymblicInstanceList, channel, [[ID, ID]]).

assign_m0_2(SysVarList, InstanceVarList, ChartVarList, SysVarList, InstanceVarList, NewChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phone, PhoneVarList),
    getListofInstance(ChartSymblicInstanceList, phone, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(PhoneVarList, X, VarList),
    VarList=[ID, Num],
    ChartVarList=[Times, TriggeredTime, ID, Num],
    NewChartVarList= [Times, TriggeredTime, ID, Num].
    

send_const_m0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m0_1(_, _, ChartVarList, _, IntervalList):-
    ChartVarList=[_, _, ID|_],
    IntervalList=[[ID, ID]].
    
    
asend_m0_1([call, Num], _, _, ChartVarList, _):-
    ChartVarList=[_, _, _, Num].


arecv_m0_1([call, Num], _, _, ChartVarList, _):-
    ChartVarList=[_, _, _, Num].


send_const_m0_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m0_2(_, _, ChartVarList, _, IntervalList):-
    ChartVarList=[_, _, ID|_],
    IntervalList=[[ID, ID]].
    
    
asend_m0_2([ack], _, _, _, _).

arecv_m0_2([ack], _, _, _, _).
    
    

send_const_p1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
recv_const_p1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_p1_1([call, Num], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Num].

arecv_p1_1([call, Num], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Num].


cond_m1_0(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, channel, ChannelVarList),
    getListofInstance(ChartSymblicInstanceList, channel, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(ChannelVarList, X, VarList),
    VarList=[false|_].
    
    

send_const_m1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_m1_1([channelError], _, _, _, _).
arecv_m1_1([channelError], _, _, _, _).


send_const_m1_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m1_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_m1_2([call, Num], _, _, ChartVarList,_):- 
    ChartVarList= [_, _, Num|_].
    
arecv_m1_2([call, Num], _, _, ChartVarList,_):-
    ChartVarList= [_, _, Num|_].


send_const_p2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_p2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_p2_1([call, Num], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, Num|_].
    
arecv_p2_1([call, Num], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, Num|_].


bind_m2_1(_, InstanceVarList, _, ChartSymblicInstanceList, NewChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, channel, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, channel, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[ID|_],
    updateSymbolicInstanceList(ChartSymblicInstanceList, NewChartSymblicInstanceList, phone, [[ID, ID]]).
    


cond_m2_0(SysVarList, _, _, _):-
    SysVarList=[0|_].

cond_m2_1(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, switch, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, switch, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[0|_].
    
send_const_m2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    

recv_const_m2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
asend_m2_1([allocate, 1], _, _, _, _).
arecv_m2_1([allocate, 1], _, _, _, _).
    

send_const_m2_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
recv_const_m2_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_m2_2([allocate, 2], _, _, _, _).
arecv_m2_2([allocate, 2], _, _, _, _).


assign_m2_0(SysVarList, InstanceVarList, ChartVarList, NewSysVarList, InstanceVarList, ChartVarList, _):-
    SysVarList=[_|SysVarListTail],
    NewSysVarList=[1|SysVarListTail].

assign_m2_1(SysVarList, InstanceVarList, ChartVarList, NewSysVarList, InstanceVarList, ChartVarList, _):-
    SysVarList=[_|SysVarListTail],
    NewSysVarList=[2|SysVarListTail].


cond_m2_2(SysVarList, _, _, _):-
    SysVarList=[Allocated|_],
    Allocated>0.


assign_m2_2(SysVarList, InstanceVarList, ChartVarList, SysVarList, InstanceVarList, NewChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phone, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phone, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[Number|_],
    ChartVarList=[Times, TriggeredTime, Num, _|ChartVarListTail],
    CallNum= Number, 
    NewChartVarList= [Times, TriggeredTime, Num, CallNum|ChartVarListTail].

    

assign_m2_3(SysVarList, InstanceVarList, ChartVarList, SysVarList, NewInstanceVarList, ChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[_|VarListTail],
    ChartVarList=[_, _, Num|_],    
    retrieveKey(Result, Num),
    NewVarList= [Result|VarListTail],
    updateSymbolicInstanceList(InstanceVars, NewInstanceVars, X, NewVarList),
    updateSymbolicInstanceList(InstanceVarList, NewInstanceVarList, phoneDB, NewInstanceVars).


retrieveKey(7, 7):- !.
retrieveKey(_, _):- !.


send_const_m2_3(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m2_3(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


cond_m2_3(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[QResult|_],
    var(QResult).



asend_m2_3([showerror, illegalNumber], _, _, _, _).
arecv_m2_3([showerror, illegalNumber], _, _, _, _).


send_const_m2_4(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m2_4(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_m2_4([allocate, 0], _, _, _, _).
arecv_m2_4([allocate, 0], _, _, _, _).


assign_m2_4(SysVarList, InstanceVarList, ChartVarList, NewSysVarList, InstanceVarList, ChartVarList, _):-
    SysVarList=[_|SysVarListTail],
    NewSysVarList=[0|SysVarListTail].


cond_m2_4(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[QResult|_],    
    getListofInstance(InstanceVarList, channel, InstanceVars1),
    getListofInstance(ChartSymblicInstanceList, channel, IntervalList1),
    IntervalList1=[InterVal1],
    InterVal1=[X1, X1],
    getInstanceVarList(InstanceVars1, X1, VarList1),
    VarList1=[Caller|_],
    Caller= QResult.
    
send_const_m2_5(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m2_5(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
asend_m2_5([cannotCallYourSelf], _, _, _, _).
arecv_m2_5([cannotCallYourSelf], _, _, _, _).


send_const_m2_6(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m2_6(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
asend_m2_6([allocate, 0], _, _, _, _).
arecv_m2_6([allocate, 0], _, _, _, _).

assign_m2_5(SysVarList, InstanceVarList, ChartVarList, NewSysVarList, InstanceVarList, ChartVarList, _):-
    SysVarList=[_|SysVarListTail],
    NewSysVarList=[0|SysVarListTail].

bind_m2_2(_, InstanceVarList, _, ChartSymblicInstanceList, NewChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[QResult|_],
    updateSymbolicInstanceList(ChartSymblicInstanceList, NewChartSymblicInstanceList, channel2, [[QResult, QResult]]).

send_const_m2_7(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m2_7(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_m2_7([call, CallNum], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, _, CallNum|_].
    
arecv_m2_7([call, CallNum], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, _, CallNum|_].



begin:-
    run([[asend, user, [], phone, [[3, 3]], [click, call], hot], [arecv, user, [], phone, [[3, 3]], [click, call], hot]], _, _).
