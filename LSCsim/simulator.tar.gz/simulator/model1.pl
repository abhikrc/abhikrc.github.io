%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Declaration of LSC Charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% this example shows how our simulator backtrack to find all execution paths

allInstanceCount(4).

declareInstance(0, user).
declareInstance(1, host).
declareInstance(2, display).
declareInstance(3, antenna).

initInstance(user, [[0, []]]).

initInstance(host, [[0, []]]).

initInstance(display, [[0, []]]).

initInstance(antenna, [[0, []]]).

bindInstanceVars(_).

declareSysVars([_]).
                        

allChartCount(2).
 
declareChart(0, left).
declareChart(1, right).

declareChartSymbolicInstances(left, [[user, [[0,0]]], [host, [[0,0]]], [display, [[0,0]]], [antenna, [[0,0]]]]).
declareChartSymbolicInstances(right, [[host, [[0,0]]], [display, [[0,0]]], [antenna, [[0,0]]]]).

declareMainChart(left, main_left).
declareMainChart(right, main_right).

declarePreChart(left, pre_left).
declarePreChart(right, pre_right).

declareChartVars(left, [_, _]).
declareChartVars(right, [_, _]).

 
chartEventCount(pre_left, 3).
chartEventCount(main_left, 9).

chartEventCount(pre_right, 3).
chartEventCount(main_right, 2).

declareChartInstances(pre_left, [user, host]).
declareChartInstances(pre_right, [host, antenna]).
declareChartInstances(main_left, [host, display, antenna]).
declareChartInstances(main_right,[display]).


declareInstanceLocations(pre_left, user, [0, 2]):- !.
declareInstanceLocations(pre_left, host, [1, 2]):- !.

declareInstanceLocations(main_left, host, [0, 3, 5, 8]):- !.
declareInstanceLocations(main_left, display, [1, 2, 6, 7, 8]):- !.
declareInstanceLocations(main_left, antenna, [4, 8]):- !.

declareInstanceLocations(pre_right, host, [0, 2]):- !.
declareInstanceLocations(pre_right, antenna, [1, 2]):- !.

declareInstanceLocations(main_right, display, [0, 1]):- !.


declareChartActivationCondition(left, main_left_ac):- !.
declareChartActivationCondition(right, main_right_ac):- !.


main_left_ac(_, _,_, _).

main_right_ac(_, _,_, _).


declareEvent(pre_left, [0, 1, hot, asend, [user], [[[user, send_const], [host, recv_const]], user, host, asend_p0_1], hot]):- !.
declareEvent(pre_left, [1, 2, hot, arecv, [host], [[[user, send_const], [host, recv_const]], user, host, arecv_p0_1], hot]):- !.
declareEvent(pre_left, [2, 2, hot, end, [[], user, host], [], cold]):- !.


declareEvent(main_left, [0, 2, hot, asend, [host], [[[host, send_const], [display, recv_const]], host, display, asend_m0_1], hot]):- !.
declareEvent(main_left, [1, 2, hot, arecv, [display], [[[host, send_const], [display, recv_const]], host, display, arecv_m0_1], hot]):- !.
declareEvent(main_left, [2, 2, hot, assignment, [display], [[], assign_m0_1], hot]):- !.
declareEvent(main_left, [3, 2, hot, asend, [host], [[[host, send_const], [antenna, recv_const]], host, antenna, asend_m0_2], hot]):- !.
declareEvent(main_left, [4, 2, hot, arecv, [antenna], [[[host, send_const], [antenna, recv_const]], host, antenna, arecv_m0_2], hot]):- !.
declareEvent(main_left, [5, 2, hot, asend, [host], [[[host, send_const], [display, recv_const]], host, display, asend_m0_3], hot]):- !.
declareEvent(main_left, [6, 2, hot, arecv, [display], [[[host, send_const], [display, recv_const]], host, display, arecv_m0_3], hot]):- !.
declareEvent(main_left, [7, 2, hot, assignment, [display], [[], assign_m0_2], hot]):- !.
declareEvent(main_left, [8, 2, hot, end, [host, display, antenna], [[]], cold]):- !.

declareEvent(pre_right, [0, 1, hot, asend, [host], [[[host, send_const], [antenna, recv_const]], host, antenna, asend_p1_1], hot]):- !.
declareEvent(pre_right, [1, 2, hot, arecv, [antenna], [[[host, send_const], [antenna, recv_const]], host, antenna, arecv_p1_1], hot]):- !.
declareEvent(pre_right, [2, 2, hot, end, [[], host, antenna], [], cold]):- !.


%% events, for main_right
declareEvent(main_right, [0, 2, hot, condition, [display], [[], cond_m1_1, []], hot]):- !.
declareEvent(main_right, [1, 2, hot, end, [display], [], cold]):- !.


send_const(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
    
recv_const(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
    
asend_p0_1([on], _, _, _, _).
arecv_p0_1([on], _, _, _, _).

asend_m0_1([green], _, _, _, _).
arecv_m0_1([green], _, _, _, _).

asend_m0_2([open], _, _, _, _).
arecv_m0_2([open], _, _, _, _).

asend_m0_3([red], _, _, _, _).
arecv_m0_3([red], _, _, _, _).

assign_m0_1(SysVarList, InstanceVarList, ChartVarList, NewSysVarList, InstanceVarList, ChartVarList, _):-
    SysVarList=[_|SysVarListTail],
    NewSysVarList=[green|SysVarListTail].

assign_m0_2(SysVarList, InstanceVarList, ChartVarList, NewSysVarList, InstanceVarList, ChartVarList, _):-
    SysVarList=[_|SysVarListTail],
    NewSysVarList=[red|SysVarListTail].
    
asend_p1_1([open], _, _, _, _).
arecv_p1_1([open], _, _, _, _).


cond_m1_1(SysVarList, _, _, _):-
    SysVarList= [Bg|_],
    not(var(Bg)),
    Bg= green.

    
begin:-
    run([[asend, user, [], host, [], [on], hot], [arecv, user, [], host, [], [on], hot]],_, _).
