%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Declaration of LSC Charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% here we use the figure 4 in paper "Symbolic Checking of Behavioral Requirements" as example
%% this example shows how our simulator descroy and create new live copies, and that our simulator
%% can deal with symblic variables in messages
%% in order to see the result  of this example, please remove the % at line 190 and 213 in engine.pl
%%  then the live copies will be printed at each step
%%  please note the ChartSymbolicInstanctList output


allInstanceCount(3).

declareInstance(0, user).
declareInstance(1, controller).
declareInstance(2, lift).

initInstance(user, []).

initInstance(controller, []).

initInstance(lift, []).

bindInstanceVars(_).

declareSysVars([]).                    
 
                        

allChartCount(1).


 %%%%% declare the left lsc chart
 
declareChart(0, example).

declareChartSymbolicInstances(example, [[user, [[0,0]]], [controller, [[0,0]]], [lift, [[1]]]]).


declarePreChart(example, pre_example).


declareMainChart(example, main_example).


declareChartVars(example, [_, _, _]).

chartEventCount(pre_example, 3).
chartEventCount(main_example, 5).



declareChartInstances(pre_example, [user, controller]).
declareChartInstances(main_example, [controller, lift]).



declareInstanceLocations(pre_example, user, [0, 2]):- !.
declareInstanceLocations(pre_example, controller, [1, 2]):- !.

declareInstanceLocations(main_example, controller, [0, 3, 4]):- !.
declareInstanceLocations(main_example, lift, [1, 2, 4]):- !.


declareChartActivationCondition(example, main_example_ac):- !.


main_example_ac(_, _, _, _).


declareEvent(pre_example, [0, 1, hot, asend, [user], [[[user, send_const_p0_1], [controller, recv_const_p0_1]], user, controller, asend_p0_1], hot]):- !.
declareEvent(pre_example, [1, 2, hot, arecv, [controller], [[[user, send_const_p0_1], [controller, recv_const_p0_1]], user, controller, arecv_p0_1], hot]):- !.
declareEvent(pre_example, [2, 2, hot, end, [[], user, controller], [], cold]):- !.


declareEvent(main_example, [0, 2, hot, asend, [controller], [[[controller, send_const_m0_1], [lift, recv_const_m0_1]], controller, lift, asend_m0_1], hot]):- !.
declareEvent(main_example, [1, 2, hot, arecv, [lift], [[[controller, send_const_m0_1], [lift, recv_const_m0_1]], controller, lift, arecv_m0_1], hot]):- !.
declareEvent(main_example, [2, 2, hot, asend, [lift], [[[lift, send_const_m0_2], [controller, recv_const_m0_2]], lift, controller, asend_m0_2], hot]):- !.
declareEvent(main_example, [3, 2, hot, arecv, [controller], [[[lift, send_const_m0_2], [controller, recv_const_m0_2]], lift, controller, arecv_m0_2], hot]):- !.
declareEvent(main_example, [4, 2, hot, end, [controller, lift], [[]], cold]):- !.



send_const_p0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_p0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_p0_1([req, Direction], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Direction|_].
    
arecv_p0_1([req, Direction], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Direction|_].
    

send_const_m0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m0_1(_, _, _, _, IntervalList):-
    IntervalList= [[3]].
    
    
asend_m0_1([req, Direction], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Direction|_].


arecv_m0_1([req, Direction], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Direction|_].


send_const_m0_2(_, _, _, _, IntervalList):-
    IntervalList= [[3, 3]].

recv_const_m0_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
    
asend_m0_2([alloc, Direction], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Direction|_].


arecv_m0_2([alloc, Direction], _, _, ChartVarList, _):-
    ChartVarList=[_, _, Direction|_].


begin:-
    run([[asend, user, [], controller, [], [req, Direction], hot], [arecv, user, [], controller, [], [req, Direction], hot]], _, _).

