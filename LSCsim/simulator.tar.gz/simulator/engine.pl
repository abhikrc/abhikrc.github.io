%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% wangtao's engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% cut= [Tempture, LocationList]
%%      Location=[Instance, CurrentLocation]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- lib(fd).
:- lib(apply).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% initialization of the system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% initialization of instances.

initInstances(InstanceList) :- 
    allInstanceCount(InstanceCount),
    getInstanceList(InstanceList, 0, InstanceCount),
    bindInstanceVars(InstanceList).
    
getInstanceList([], InstanceCount, InstanceCount) :- !.

getInstanceList([[Instance, VarList]|InstanceListTail], Index, InstanceCount) :-
    declareInstance(Index, Instance), 
    initInstance(Instance, VarList),
    NextIndex is Index+1,
    getInstanceList(InstanceListTail, NextIndex, InstanceCount).
  
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% initialization of charts
%% Each element in the ChartList is 
%% [ChartName, MainChart, PreChart, MinimalEventList, ChartVarList]
%% MainChart= [ MainChartName, EventList, InstanceLocationList], 
%%         InstanceLocation= [Instance, LocationList]
%%         where Event=[Id, Position, PosiTemp, EventType, InstanceList, EventBody, EventTemp]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% initCharts(ChartList): get all the charts, 
initCharts(ChartList) :-
    allChartCount(ChartCount),
    getCharts(ChartList, 0, ChartCount).

%% getCharts(ChartList, Index, ChartCount): get the chart with the Index. There are ChartCount charts.
getCharts([], ChartCount, ChartCount) :- !.


getCharts([Chart|ChartListTail], Index, ChartCount) :-
    Chart= [ChartName, MainChart, PreChart, MinimalEventList, ChartSymbolicInstanceList, ActivationCondition, ChartVarList],
    declareChart(Index, ChartName),
    declareChartVars(ChartName, ChartVarList),
    declareChartSymbolicInstances(ChartName, ChartSymbolicInstanceList),
        
    %% get the event list of the main chart
    declareMainChart(ChartName, MainChartName),
    initChartEvent(MainChartName, MainChart),
    
    %% get the event list of the pre chart
    declarePreChart(ChartName, PreChartName),
    initChartEvent(PreChartName, PreChart),
    getMinimalEvents(PreChart, MinimalEventList),
    
    declareChartActivationCondition(ChartName, ActivationCondition),    
    NextIndex is Index+1,
    getCharts(ChartListTail, NextIndex, ChartCount).
    
    
    
%% getMinimalEvents(PreChart, MinimalEventList), get mimila events from the prechart
%%        MinimalEventList is a list of Event, not Event id
getMinimalEvents([_, [], _], []) :- !.

getMinimalEvents([_, [Event|EventListTail], _], [MinimalEvent|MinimalEventListTail] ) :-
    Event= [_, 1 | _],
    !,
    Event= MinimalEvent,
    getMinimalEvents([_, EventListTail, _], MinimalEventListTail).
    
getMinimalEvents([_, [_|EventListTail], _], MinimalEventList):-
    getMinimalEvents([_, EventListTail, _], MinimalEventList).
    
    
%% initChartEvent(Chart, [ChartName, EventList, InstanceLocationList]): get all events of the Chart, put them in the Event List    
initChartEvent(Chart, [Chart, EventList, InstanceLocationList]) :-
    chartEventCount(Chart, EventCount),
    getEvents(Chart, EventList, 0, EventCount),    
    declareChartInstances(Chart, InstanceList),
    getLocations(Chart, InstanceLocationList, InstanceList).
    

%% getEvents(ChartName, Event, Index, EventCount): get the Index event in the Chart
getEvents(_, [], EventCount, EventCount) :- !.

getEvents(Chart, [[Index|EventTail]|EventListTail], Index, EventCount) :-
    declareEvent(Chart, [Index|EventTail]),
    NextIndex is Index+1,
    getEvents(Chart, EventListTail, NextIndex, EventCount).
    
%%getLocations(Chart, InstanceLocationList, InstanceList): get instance locations for Chart
getLocations(_, [], []):- !.

getLocations(Chart, [InstanceLocation|InstanceLocationListTail], [Instance|InstanceListTail]):- 
    InstanceLocation= [Instance, LocationList],
    declareInstanceLocations(Chart, Instance, LocationList),
    getLocations(Chart, InstanceLocationListTail, InstanceListTail).
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% initialization of system variable
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

initSysVars(SysVarList):-
    declareSysVars(SysVarList).

    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% run, execute the system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

run(SysEventList, MaxLiveCopies, MaxSteps):-
    initSysVars(SysVarList),
    initInstances(InstanceList),
    initCharts(ChartList),
    ( SysEventList=[SysEvent|SysEventListTail] ->
          execute([SysEvent], SysVarList, InstanceList, ChartList, [], [], [], [], SysEventListTail, 0, MaxLiveCopies, 0, Steps, 0, MaxSteps)
          ;
          execute([], SysVarList, InstanceList, ChartList, [], [], [], [], [], 0, MaxLiveCopies, 0, Steps, 0, MaxSteps)
    ).
    
    
%% execute(MessageList, SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps): execute a event,
%%      SysEventList: remaining system events, triggered by environment or user

execute(MessageList, SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps):-
    %% ensure that MessageList contains at least one message
    MessageList=[_|_],
    getMessage(MessageList, Message),
    executeMessage(Message, SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps).

execute(MessageList, SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps):-
    MessageList=[],
    not (SysEventList=[]),
    !,
    SysEventList=[SysEvent|SysEventListTail],
    ( OldSteps>OldMaxSteps ->
          NewMaxSteps1 is OldSteps
          ;
          NewMaxSteps1 is OldMaxSteps
    ),
    execute([SysEvent], SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventListTail, OldMaxLiveCopies, NewMaxLiveCopies, -1, NewSteps, NewMaxSteps1, NewMaxSteps).

execute(MessageList, SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps):-    
    MessageList=[],
    checkActivationConditions(SysVarList, InstanceVarList, ChartList),    
    !,
    executeMessage([], SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps).

execute(MessageList, _, _, _, ActiveSet, _, _, Trace, _, OldMaxLiveCopies, OldMaxLiveCopies, OldSteps, OldSteps, OldMaxSteps, NewMaxSteps):-    
    MessageList=[],    
    
    ( OldSteps>OldMaxSteps ->
          NewMaxSteps is OldSteps
          ;
          NewMaxSteps is OldMaxSteps
    ),
    print("*********************************************************************************\n"),
    cputime(CurrentTime),    
    debugPrint("CurrentTime", CurrentTime),
    debugPrint("SuperStep", NewMaxSteps),
    debugPrint("MaxLiveCopies", OldMaxLiveCopies),
    outputTrace(Trace),
    
    print("*********************************************************************************\n"),
    print(ActiveSet),
    print("\n"),
    ( ActiveSet=[]->
          print("succeed\n")
          ;
          print("fail\n")
    ).

executeMessage(Message, SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps):-
%    print("*********************************************** Next Iteration ***********************************************\n"),
    formatMessage(Message, Message1),
    updateMessageSet(Message1, ActiveMessageSet, ActiveMessageSet1),
    
    ( Message1\= []->
          noNullAppend(Trace, [Message1], NewTrace1),
          NewSteps1 is OldSteps+1
          ;
          NewTrace1= Trace,
          NewSteps1 is OldSteps
    ),
    checkMinimal(Message1, SysVarList, InstanceVarList, ChartList, EnabledCharts),
    length(EnabledCharts, EnabledChartsNum),
    
    NewMaxLiveCopies1 is OldMaxLiveCopies+EnabledChartsNum,    
    append(PreActiveSet, EnabledCharts, PreActiveSet1),    
    checkPreActive(Message1, SysVarList, InstanceVarList, SysVarList1, InstanceVarList1, PreActiveSet1, PreActiveSet2, ReadyActiveSet, NewTrace1, NewMaxLiveCopies1, NewMaxLiveCopies2),
    
    executeLocalOperations(SysVarList1, InstanceVarList1, SysVarList2, InstanceVarList2, ReadyActiveSet, ReadyActiveSet1, NewTrace1, NewTrace2, NewSteps1, NewSteps2, NewMaxLiveCopies2),
    append(ActiveSet, ReadyActiveSet1, ActiveSet1),
    
    checkActive(Message1, SysVarList2, InstanceVarList2, SysVarList3, InstanceVarList3, ActiveSet1, ActiveSet2, NewTrace2, NewMaxLiveCopies2, NewMaxLiveCopies3),
    executeLocalOperations(SysVarList3, InstanceVarList3, SysVarList4, InstanceVarList4, ActiveSet2, ActiveSet3, NewTrace2, NewTrace3, NewSteps2, NewSteps3, NewMaxLiveCopies3),
%    outputCharts(ActiveSet3),

    getNewMessages(SysVarList4, InstanceVarList4, NewMessages, ActiveMessageSet1, ActiveSet3, ActiveSet3),
    execute(NewMessages, SysVarList4, InstanceVarList4, ChartList, ActiveSet3, PreActiveSet2, ActiveMessageSet1, NewTrace3, SysEventList, NewMaxLiveCopies3, NewMaxLiveCopies, NewSteps3, NewSteps, OldMaxSteps, NewMaxSteps).
    

%% for code messages, it can be either receiverd or lost, here we simulate that it is lost
%%   i.e. after send this message, do not put it into the messageSet

executeMessage(Message, SysVarList, InstanceVarList, ChartList, ActiveSet, PreActiveSet, ActiveMessageSet, Trace, SysEventList, OldMaxLiveCopies, NewMaxLiveCopies, OldSteps, NewSteps, OldMaxSteps, NewMaxSteps):-
%    print("*********************************************** cold message ***********************************************\n"),
    Message1= [asend, _, _, _, _, _, cold],
    formatMessage(Message, Message1),
    ( Message1\= []->
          noNullAppend(Trace, [Message1], NewTrace1),
          NewSteps1 is OldSteps+1
          ;
          NewTrace1= Trace,
          NewSteps1 is OldSteps
    ),
   
    checkMinimal(Message1, SysVarList, InstanceVarList, ChartList, EnabledCharts),
    length(EnabledCharts, EnabledChartsNum),
    
    checkMinimal(Message1, SysVarList, InstanceVarList, ChartList, EnabledCharts),
    length(EnabledCharts, EnabledChartsNum),
    
    NewMaxLiveCopies1 is OldMaxLiveCopies+EnabledChartsNum,
    append(PreActiveSet, EnabledCharts, PreActiveSet1),
    checkPreActive(Message1, SysVarList, InstanceVarList, SysVarList1, InstanceVarList1, PreActiveSet1, PreActiveSet2, ReadyActiveSet, NewTrace1, NewMaxLiveCopies1, NewMaxLiveCopies2),
    executeLocalOperations(SysVarList1, InstanceVarList1, SysVarList2, InstanceVarList2, ReadyActiveSet, ReadyActiveSet1, NewTrace1, NewTrace2, NewSteps1, NewSteps2, NewMaxLiveCopies2),
    append(ActiveSet, ReadyActiveSet1, ActiveSet1),
    checkActive(Message1, SysVarList2, InstanceVarList2, SysVarList3, InstanceVarList3, ActiveSet1, ActiveSet2, NewTrace2, NewMaxLiveCopies2, NewMaxLiveCopies3),
    executeLocalOperations(SysVarList3, InstanceVarList3, SysVarList4, InstanceVarList4, ActiveSet2, ActiveSet3, NewTrace2, NewTrace3, NewSteps2, NewSteps3, NewMaxLiveCopies3),
    getNewMessages(SysVarList4, InstanceVarList4, NewMessages, ActiveMessageSet, ActiveSet3, ActiveSet3),
    execute(NewMessages, SysVarList4, InstanceVarList4, ChartList, ActiveSet3, PreActiveSet2, ActiveMessageSet, NewTrace3, SysEventList, NewMaxLiveCopies3, NewMaxLiveCopies, NewSteps3, NewSteps, OldMaxSteps, NewMaxSteps).


%% getMessage(MessageList, Message), get a message form the MessageList,  It will get all messages by executing many times
%% Message= [Sender, Receiver, [MessageBody], Tempture]

getMessage([Message], Message):- !.

getMessage([Message|_], Message).

getMessage([_|MessagesListTail], Message) :-
    getMessage(MessagesListTail, Message).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  predicates to update the message set, which acts as message channels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% updateMessageSet, if Message is a send event, insert the message to the set
%%                   if Message is a recv event, delete the message from the set

updateMessageSet([], ActiveMessageSet, ActiveMessageSet):- !.

updateMessageSet([asend|MessageTail], ActiveMessageSet, NewActiveMessageSet):-
    NewActiveMessageSet=[MessageTail|ActiveMessageSet], 
    !.

updateMessageSet([arecv|MessageTail], ActiveMessageSet, NewActiveMessageSet):-
    deleteElementFromList(MessageTail, ActiveMessageSet, NewActiveMessageSet),
    !.
    
updateMessageSet([assignment|_], ActiveMessageSet, ActiveMessageSet).

%% formatMessage(Message, NewMessage)

formatMessage([], []):- !.

formatMessage(Message, NewMessage):-
    Message= [Type, Sender, SenderIntervalList, Receiver, RecvIntervalList, Value, Temperature],
    !,
    ( SenderIntervalList =[] ->
          NewSenderIntervalList= [[0,0]]
          ;
          NewSenderIntervalList= SenderIntervalList
    ),
    ( RecvIntervalList =[] ->
          NewRecvIntervalList= [[0,0]]
          ;
          NewRecvIntervalList= RecvIntervalList
    ),
    NewMessage= [Type, Sender, NewSenderIntervalList, Receiver, NewRecvIntervalList, Value, Temperature].
    
formatMessage(Message, Message).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% predicates for messages
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
%% getNewMessages(SysVarList, InstanceVarList, NewMessages, ActiveMessageSet, ActiveSet, AllActiveSet)
%%     get the NewMessages which can be triggered from ActiveSet, and update relevant message channels (ActiveMessageSet)    
%%     NewMessages includes all messages in OldMessages

getNewMessages(_, _, [], _, [], _) :- !.

getNewMessages(SysVarList, InstanceVarList, NewMessages, ActiveMessageSet, ActiveSet, AllActiveSet):-
    ActiveSet=[ActiveChart|OtherActiveCharts],
    getNewMessagesFromAChart(SysVarList, InstanceVarList, NewMessages1, ActiveMessageSet, ActiveChart, AllActiveSet),
    getNewMessages(SysVarList, InstanceVarList, NewMessages2, ActiveMessageSet, OtherActiveCharts, AllActiveSet),    
    noNullAppend(NewMessages1, NewMessages2, NewMessages).
    

%% getNewMessagesFromAChart(SysVarList, InstanceVarList, NewMessages, ActiveMessageSet, ActiveChart, ActiveSet)
%%     get the NewMessages which can be triggered from ActiveSet, 

getNewMessagesFromAChart(SysVarList, InstanceVarList, NewMessages, ActiveMessageSet, ActiveChart, ActiveSet):-
    ActiveChart=[_, MainChart, _, ChartSymbolicInstanceList, ChartVarList, Cut],
    MainChart=[_, EventList, _],
    Cut=[_, LocationList],
    getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, [], NewMessages, ActiveMessageSet, EventList, LocationList, ActiveSet).


%% getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, TriggedMessages, NewMessages, ActiveMessageSet, EventList, LocationList, ActiveSet)
%%     get the NewMessages which can be triggered from events, 

getNewMessagesFromEvents(_, _, _, _, TriggedMessages, TriggedMessages, _, [], _, _):-  !.

%% deal with send events

getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, TriggedMessages, NewMessages, ActiveMessageSet, [Event|EventListTail], LocationList, ActiveSet):-
       Event=[_, _, _, assignment, _, [_, Method], _],
       enabledEvent(Event, LocationList),
       !,
       noNullAppend(TriggedMessages, [[assignment, Method]], NewTriggedMessages),
       getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, NewTriggedMessages, NewMessages, ActiveMessageSet, EventListTail, LocationList, ActiveSet).


getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, TriggedMessages, NewMessages, ActiveMessageSet, [Event|EventListTail], LocationList, ActiveSet):-
       Event=[_, _, _, asend, _, [EventConstraints, Sender, Receiver, Method], EventTemp],
       enabledEvent(Event, LocationList),
       
       getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
       getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
       apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
       noVarInInterval(ConstraintSenderInterval),
       minusIntervalLists(CurrentSenderInterval, ConstraintSenderInterval, EnabledSenderInterval),
       EnabledSenderInterval \=[],
       
       getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
       getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
       apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
       noVarInInterval(ConstraintReceiverInterval),
       minusIntervalLists(CurrentReceiverInterval, ConstraintReceiverInterval, EnabledReceiverInterval),
       EnabledReceiverInterval\= [],
       
       updateSymbolicInstanceList(ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval),
       
       apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, NewChartSymbolicInstanceList]),
       
       Message= [asend, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value, EventTemp],

       not(memberOfMessageSet(Message, TriggedMessages)),
       
       %% we will try to issue several messages together
       checkEnabledActiveCharts(SysVarList, InstanceVarList, Message, ActiveSet, ActiveSet1),       
       
       ifViolationMessage(SysVarList, InstanceVarList, Message, _, ActiveSet1),
       !,
       noNullAppend(TriggedMessages, [Message], NewTriggedMessages),
       getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, NewTriggedMessages, NewMessages, ActiveMessageSet, EventListTail, LocationList, ActiveSet).
       


%% deal with receive events
getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, TriggedMessages, NewMessages, ActiveMessageSet, [Event|EventListTail], LocationList, ActiveSet):-
       Event=[_, _, _, arecv, _, [EventConstraints, Sender, Receiver, Method], EventTemp],

       enabledEvent(Event, LocationList),

       getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
       getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
       apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
       noVarInInterval(ConstraintSenderInterval),
       minusIntervalLists(CurrentSenderInterval, ConstraintSenderInterval, EnabledSenderInterval),
       EnabledSenderInterval \=[],
       
       getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
       getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
       apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
       noVarInInterval(ConstraintReceiverInterval),
       minusIntervalLists(CurrentReceiverInterval, ConstraintReceiverInterval, EnabledReceiverInterval),
       EnabledReceiverInterval \=[],
       
       updateSymbolicInstanceList(ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval),


       apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, NewChartSymbolicInstanceList]),
       
       Message= [arecv, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value, EventTemp],
       
       not(memberOfMessageSet(Message, TriggedMessages)),
       
       memberOfMessageSet2([Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value, EventTemp], ActiveMessageSet),       
       
       !,
       noNullAppend(TriggedMessages, [Message], TriggedMessages1),
       getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, TriggedMessages1, NewMessages, ActiveMessageSet, EventListTail, LocationList, ActiveSet).


%% other events
getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, TriggedMessages, NewMessages, ActiveMessageSet, [_|EventListTail], LocationList, ActiveSet):-
    getNewMessagesFromEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, TriggedMessages, NewMessages, ActiveMessageSet, EventListTail, LocationList, ActiveSet).


%% checkEnabledActiveCharts(SysVarList, InstanceVarList, Message, ActiveSet, NewActiveSet)
%%   check if this event is enabled in other active charts, then these copies do not need to be checked

checkEnabledActiveCharts(_, _, _, [], []):- !.

checkEnabledActiveCharts(SysVarList, InstanceVarList, Message, ActiveSet, NewActiveSet):-
    ActiveSet=[ActiveChart|OtherActiveCharts],    
    checkEnabledActiveCharts(SysVarList, InstanceVarList, Message, OtherActiveCharts, NewActiveSet1),
    ActiveChart=[_, MainChart, _, ChartSymbolicInstanceList, ChartVarList, [_, LocationList]],
    MainChart=[_, EventList, _],
    ( checkEnabledEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, LocationList, EventList, Message)->
          NewActiveSet2= [ActiveChart]
          ;
          NewActiveSet2= []
    ),    
    noNullAppend(NewActiveSet2, NewActiveSet1, NewActiveSet).


%% haveNotProcess(Event, LocationList), check whether the event has been handled

haveNotProcess(Event, LocationList):-
    Event=[Id, _, _, _, InstanceList, _, _],
    checkProcess(Id, InstanceList, LocationList).
    
checkProcess(_, [], _):- !.

checkProcess(Id, [Instance|InstanceListTail], LocationList):-
    getInstanceVarList(LocationList, Instance, Location),    
    Location =< Id,
    checkProcess(Id, InstanceListTail, LocationList).


%% checkEnabledEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, LocationList, EventList, Message)

checkEnabledEvents(_, _, _, _, _, [], _):- fail, !.

checkEnabledEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, LocationList, EventList, Message):-
    EventList=[Event|EventListTail],
    enabledEvent(Event, LocationList),
    !,
    Event=[_, _, _, Type, _, [EventConstraints, Sender, Receiver, Method], EventTemp],
    
    getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
    getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
    apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
    noVarInInterval(ConstraintSenderInterval),
    minusIntervalLists(CurrentSenderInterval, ConstraintSenderInterval, EnabledSenderInterval),
       
    getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
    getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
    apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
    noVarInInterval(ConstraintReceiverInterval),
    minusIntervalLists(CurrentReceiverInterval, ConstraintReceiverInterval, EnabledReceiverInterval),
     
    updateSymbolicInstanceList(ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval),


    apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, NewChartSymbolicInstanceList]),

    ( Message= [Type, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value, EventTemp] ->
          true
          ;
          checkEnabledEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, LocationList, EventListTail, Message)
    ).


checkEnabledEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, LocationList, EventList, Message):-
    EventList=[_|EventListTail],
    checkEnabledEvents(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, LocationList, EventListTail, Message).
  


%% ifViolationMessage(SysVarList, InstanceVarList, Message, NewMessage, ActiveSet)
%%    check  if message violate other active copies

ifViolationMessage(_, _, [], [], _):- !.

ifViolationMessage(_, _, Message, Message, []):- !.

ifViolationMessage(SysVarList, InstanceVarList, Message, NewMessage, ActiveSet):-
    ActiveSet=[ActiveChart|OtherActiveChart],
    ActiveChart=[_, MainChart, _, ChartSymbolicInstanceList, ChartVarList, Cut],
    MainChart=[_, EventList, _],
    Cut=[Tempture, _],
    ( Tempture= hot->
          ifViolateEvent(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, Message, Message1, EventList, Cut),
          ifViolationMessage(SysVarList, InstanceVarList, Message1, NewMessage, OtherActiveChart)
          ;
          ifViolationMessage(SysVarList, InstanceVarList, Message, NewMessage, OtherActiveChart)
    ).


%% ifViolateEvent(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, Message, NewMessages, EventList, Cut)

ifViolateEvent(_, _, _, _, [], [], _, _):- !.

ifViolateEvent(_, _, _, _, Message, [Message], [], _):- !.

ifViolateEvent(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, Message, NewMessage, [Event|_], Cut):-
    Cut=[hot, LocationList],
    Event=[_, _, _, Type, _, [EventConstraints, Sender, Receiver, Method], EventTemp],
    
    not(enabledEvent(Event, LocationList)),
    
    apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]),
    freeList(Value),
    
    Message= [Type, Sender, SenderInterval, Receiver, ReceiverInterval, MessageValue, EventTemp],
    
    copyList(Value, Value1),
    copyList(MessageValue, MessageValue1),
    Value1= MessageValue1,
    
    
    getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
    getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
    apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
    minusIntervalLists(CurrentSenderInterval, ConstraintSenderInterval, EnabledSenderInterval),
    minusIntervalLists(SenderInterval, EnabledSenderInterval, []),
       
    getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
    getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
    apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
    minusIntervalLists(CurrentReceiverInterval, ConstraintReceiverInterval, EnabledReceiverInterval),
    minusIntervalLists(ReceiverInterval, EnabledReceiverInterval, []),
    
    !,
    
    NewMessage= Message.
      
ifViolateEvent(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, Message, NewMessage, [_|EventListTail], Cut):-
    ifViolateEvent(SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, Message, NewMessage, EventListTail, Cut).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% predicates for checking activation conditions
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

checkActivationConditions(_, _, []):- !, fail.

checkActivationConditions(SysVarList, InstanceVarList, [Chart|OtherCharts]):-
    Chart= [_, _, _, MinimalEventList, ChartSymbolicInstanceList, ActivationCondition, ChartVarList],
    ( apply(ActivationCondition, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]) ->
          ( MinimalEventList = [] ->
                true
                ;
                checkActivationConditions(SysVarList, InstanceVarList, OtherCharts)
          )
          ;
          checkActivationConditions(SysVarList, InstanceVarList, OtherCharts)
    ).
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% predicates for checking minimal events
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%  checkMinimal(Message, SysVarList, InstanceVarList,  ChartList, EnabledCharts):-
%%    check whether Minimal events happen to put the chart into the preactive status

checkMinimal(_, _, _, [], []):- !.

checkMinimal([assignment|_], _, _, _, []):- !.

checkMinimal(Message, SysVarList, InstanceVarList, [Chart|ChartListTail], EnabledCharts):-
    Chart= [ChartName, MainChart, PreChart, MinimalEventList, ChartSymbolicInstanceList, ActivationCondition, ChartVarList],
    createList(ChartVarList, NewChartVarList),
    apply(ActivationCondition, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]),
    ( MinimalEventList = [] ->
          NewChartVarList=[Times, []|_],
          PreChart=[PreChartName|_],
          declareChartInstances(PreChartName, PreChartInstanceList),
          initTimes(PreChartInstanceList, PreChartInstanceList, Times),
          EnabledCharts=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, NewChartVarList, _]|EnabledCharts1]
          ;
          unifyMinimal(Message, SysVarList, InstanceVarList, ChartSymbolicInstanceList, NewChartVarList, MinimalEventList),          
          PreChart=[_, _, InstanceLocationList],
          initCutLocations(InstanceLocationList, Locations),
          Cut=[_, Locations],
          NewChartVarList=[Times, []|_],
          PreChart=[PreChartName|_],
          declareChartInstances(PreChartName, PreChartInstanceList),          
          initTimes(PreChartInstanceList, PreChartInstanceList, Times),          
          EnabledCharts=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, NewChartVarList, Cut]|EnabledCharts1]
    ),
    !,
    %% for prechart, the tempture is useless
    checkMinimal(Message, SysVarList, InstanceVarList, ChartListTail, EnabledCharts1).


checkMinimal(Message, SysVarList, InstanceVarList, [_|ChartListTail], EnabledCharts):-
    checkMinimal(Message, SysVarList, InstanceVarList, ChartListTail, EnabledCharts).
    


%% unifyMinimal(Message, SysVarList, InstanceVarList, ChartSymbolicInstanceList, ChartVarList, MinimalEventList)
%%    :try to unify minimal events, if success, the variable is automatically bounded

unifyMinimal(_, _, _, _, _, []):- !, fail.

unifyMinimal(Message, SysVarList, InstanceVarList, ChartSymbolicInstanceList, ChartVarList, [Event|_]):-
    Event=[_, _, _, Type, _, [EventConstraints, Sender, Receiver, Method], _],
    apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]),
    
    Message= [Type, Sender, SenderIntervalList, Receiver, ReceiverIntervalList, Value, _],
    !,
    getListofInstance(ChartSymbolicInstanceList, Sender, ChartSenderIntervalList),
    minusIntervalLists(ChartSenderIntervalList, SenderIntervalList, EnabledSenderIntervalList),
    
    getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
    apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
    minusIntervalLists(EnabledSenderIntervalList, ConstraintSenderInterval, EnabledSenderIntervalList1),
    EnabledSenderIntervalList1 \= [],
    
    getListofInstance(ChartSymbolicInstanceList, Receiver, ChartReceiverIntervalList),
    minusIntervalLists(ChartReceiverIntervalList, ReceiverIntervalList, EnabledReceiverIntervalList),
    getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
    apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
    minusIntervalLists(EnabledReceiverIntervalList, ConstraintSenderInterval, EnabledReceiverIntervalList1),
    EnabledReceiverIntervalList1 \=[].
    
  
unifyMinimal(Message, SysVarList, InstanceVarList, ChartSymbolicInstanceList, ChartVarList, [_|MinimalEventListTail]):-
    unifyMinimal(Message, SysVarList, InstanceVarList, ChartSymbolicInstanceList, ChartVarList, MinimalEventListTail).




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% predicate for PreActive chart copies
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% checkPreActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, PreActiveSet, NewPreActiveSet, ReadyActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies)
%%     advance all preactive chart copies in PreActiveSet, produce the NewPreActiveSet
%%     and ReadyActiveSet contains chart copies which should convert to 

checkPreActive(_, SysVarList, InstanceVarList, SysVarList, InstanceVarList, [], [], [], _, OldMaxLiveCopies, OldMaxLiveCopies):- !.

checkPreActive([assigment|_], SysVarList, InstanceVarList, SysVarList, InstanceVarList, PreActiveSet, PreActiveSet, [], _, OldMaxLiveCopies, OldMaxLiveCopies):- !.


checkPreActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, PreActiveSet, NewPreActiveSet, ReadyActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    PreActiveSet=[PreActiveChart|OtherPreActiveCharts],
    checkPreActiveChart(Message, SysVarList, InstanceVarList, SysVarList1, InstanceVarList1, PreActiveChart, PreActiveSet1, ReadyActiveSet1, Trace, OldMaxLiveCopies, NewMaxLiveCopies1),    
    
    checkPreActive(Message, SysVarList1, InstanceVarList1, NewSysVarList, NewInstanceVarList, OtherPreActiveCharts, PreActiveSet2, ReadyActiveSet2, Trace, NewMaxLiveCopies1, NewMaxLiveCopies),    
    noNullAppend(PreActiveSet1, PreActiveSet2, NewPreActiveSet),
    noNullAppend(ReadyActiveSet1, ReadyActiveSet2, ReadyActiveSet).
    

%% checkPreActiveChart(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, PreActiveChart, PreActiveSet1, ReadyActiveSet1, Trace, OldMaxLiveCopies, NewMaxLiveCopies),
%% check a single preActive chart, and advance it if necessary

checkPreActiveChart(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, PreActiveChart, NewPreActiveSet, ReadyActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    PreActiveChart=[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, _],
    PreChart=[_, EventList, _],
    
    ( EventList \= [] ->
          unifyPreActive(Message, SysVarList, InstanceVarList, EventList, PreActiveChart, NewPreActiveSet, ReadyActiveSet1, Trace, OldMaxLiveCopies, NewMaxLiveCopies)
          ;
          NewPreActiveSet=[],
          ReadyActiveSet1= [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, _]],
          NewMaxLiveCopies= OldMaxLiveCopies
     ),
     
      ( ReadyActiveSet1 \= [] ->
          initActiveCharts(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ReadyActiveSet1, ReadyActiveSet, Trace)
          ;
          ReadyActiveSet= ReadyActiveSet1,
          SysVarList= NewSysVarList,
          InstanceVarList= NewInstanceVarList
    ).

%% initActiveCharts(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ReadyActiveSet, NewReadyActiveSet, Trace)          

initActiveCharts(SysVarList, InstanceVarList, SysVarList, InstanceVarList, [], [], _):- !.

initActiveCharts(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ReadyActiveSet, NewReadyActiveSet, Trace):-

    ReadyActiveSet= [ReadyActiveChart|OtherReadyActiveCharts],
    initActiveCharts(SysVarList, InstanceVarList, NewSysVarList1, NewInstanceVarList1, OtherReadyActiveCharts, NewReadyActiveSet1, Trace),
    
    ReadyActiveChart= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, _],
    ChartVarList= [Times, _|ChartVarListTail],
    MainChart=[MainChartName, _, MainChartInstanceLocationList],    
    
    declareChartInstances(MainChartName, MainChartInstanceList),    
    
    initCutLocations(MainChartInstanceLocationList, NewLocations),
    
    initMainTimes(MainChartInstanceList, MainChartInstanceList, Times, NewTimes),

    ChartVarList1=[NewTimes, []| ChartVarListTail],
          
    getCutTempture(Tempture, MainChartName, NewLocations),    

    ChartCopySet= [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList1, [Tempture, NewLocations]]],
    
    advanceActiveCut(NewSysVarList1, NewInstanceVarList1, NewSysVarList, NewInstanceVarList, ChartCopySet, NewActiveSet1, Trace),
 
    checkEndOfMainCharts(MainChartName, NewActiveSet1, NewReadyActiveSet2),
    
    noNullAppend(NewReadyActiveSet2, NewReadyActiveSet1, NewReadyActiveSet).
    



%% unifyPreActive(Message, SysVarList, InstanceVarList, EventList, PreActiveChart, NewPreActiveSet, ReadyActiveSet, OldMaxLiveCopies, NewMaxLiveCopies).
%% unify events in a preactive chart copy


unifyPreActive(_, _, _, [], PreActiveChart, [PreActiveChart], [], _, OldMaxLiveCopies, OldMaxLiveCopies):- !.


%%  deal with all enabled events
unifyPreActive(Message, SysVarList, InstanceVarList, [Event|EventListTail], PreActiveChart, NewPreActiveSet, ReadyActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    PreActiveChart= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, Cut],
    PreChart= [PreChartName, _, InstanceLocationList],
    Cut= [_, LocationList],
    Event=[_, _, _, Type, InstanceList, [EventConstraints, Sender, Receiver, Method], _],
    haveNotProcess(Event, LocationList),
    enabledEvent(Event, LocationList),
    !,
    getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
    getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
    apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
    minusIntervalLists(CurrentSenderInterval, ConstraintSenderInterval, EnabledSenderInterval),
       
    getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
    getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
    apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
    minusIntervalLists(CurrentReceiverInterval, ConstraintReceiverInterval, EnabledReceiverInterval),
       
    updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList0, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval),

    apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList0]),
    
    ( Message= [Type, Sender, SenderInterval, Receiver, ReceiverInterval, Value, _] ->
           NewMaxLiveCopies0 is OldMaxLiveCopies-1,

           minusIntervalLists(EnabledSenderInterval, SenderInterval, TriggeredSenderInterval),
           minusIntervalLists(EnabledReceiverInterval, ReceiverInterval, TriggeredReceiverInterval),
        
           ( TriggeredSenderInterval= [] ->
                 NewPreActiveSet1=[],
                 ReadyActiveSet1=[],
                 NewMaxLiveCopies1 is NewMaxLiveCopies0
                 ;
                 ( TriggeredReceiverInterval= [] ->
                       NewPreActiveSet1=[],
                       ReadyActiveSet1=[],
                       NewMaxLiveCopies1 is NewMaxLiveCopies0
                       ;
                       
                       ( Type= asend ->
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],                             
                             
                             updateLogicalTime(Sender, Times, Times1),
                             
                             getListofInstance(Times1, Sender, [SendTime|_]),
                             
                             copyTriggeredTime(TriggeredTime, TriggeredTime1),
                             append([[[Sender, Receiver, Value], SendTime]], TriggeredTime1, TriggeredTime11),
                             
                             ChartVarList1=[Times1, TriggeredTime11|ChartVarListTail]
                             ;
                             
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             copyTriggeredTime(TriggeredTime, TriggeredTime1),
                             getMessangeTime(TriggeredTime1, [Sender, Receiver, Value], SendTime),                             
                             
                             updateLogicalTime2(Receiver, SendTime, Times, Times1),
                
                             deleteElementFromList([[Sender, Receiver, Value], SendTime], TriggeredTime1, NewTriggeredTime11),
                             
                             ChartVarList1=[Times1, NewTriggeredTime11|ChartVarListTail]
                       ),                       
                       
                       updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList1),
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList1, Sender, TriggeredSenderInterval, Receiver, TriggeredReceiverInterval),
                       
                       ChartCopySet=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList1, ChartVarList1, [_, LocationList1]]],
                       advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet, NewChartCopySet, Trace),
                       NewMaxLiveCopies1 is NewMaxLiveCopies0+1,
                     
                       checkEndOfPreCharts(PreChartName, NewChartCopySet, NewPreActiveSet1, ReadyActiveSet1)
                 )
           ),

           ( beginOfChart(InstanceLocationList, LocationList)->
                 NewPreActiveSet= NewPreActiveSet1,
                 ReadyActiveSet= ReadyActiveSet1,
                 NewMaxLiveCopies is NewMaxLiveCopies1,
                 true
                 ;
                 
                 removeIntervalList(EnabledSenderInterval, TriggeredSenderInterval, RemainSenderInterval),
                 removeIntervalList(EnabledReceiverInterval, TriggeredReceiverInterval, RemainReceiverInterval),
           
                 ( RemainSenderInterval= [] ->
                       ( RemainReceiverInterval= [] ->
                             NewPreActiveSet2=NewPreActiveSet1,
                             ReadyActiveSet2=ReadyActiveSet1,
                             NewMaxLiveCopies2 is NewMaxLiveCopies1
                             ;
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList2, Sender, EnabledSenderInterval, Receiver, RemainReceiverInterval),
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             copyTriggeredTime(TriggeredTime, TriggeredTime2),    
                             
                             ChartVarList2=[Times, TriggeredTime2|ChartVarListTail],
                             noNullAppend(NewPreActiveSet1, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList2, ChartVarList2, [_, LocationList]]], NewPreActiveSet2),
                             ReadyActiveSet2=ReadyActiveSet1,
                             NewMaxLiveCopies2 is NewMaxLiveCopies1+1
                       )
                       ;
                       ( RemainReceiverInterval= [] ->
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList2, Sender, RemainSenderInterval, Receiver, EnabledReceiverInterval),
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             copyTriggeredTime(TriggeredTime, TriggeredTime2),
                             
                             ChartVarList2=[Times, TriggeredTime2|ChartVarListTail],
                             noNullAppend(NewPreActiveSet1, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList2, ChartVarList2, [_, LocationList]]], NewPreActiveSet2),
                             ReadyActiveSet2=ReadyActiveSet1,
                             NewMaxLiveCopies2 is NewMaxLiveCopies1+1
                             
                             ;
                       
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList21, Sender, TriggeredSenderInterval, Receiver, RemainReceiverInterval),
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList22, Sender, RemainSenderInterval, Receiver, TriggeredReceiverInterval),
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList23, Sender, RemainSenderInterval, Receiver, RemainReceiverInterval),
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             copyTriggeredTime(TriggeredTime, TriggeredTime21),
                             copyTriggeredTime(TriggeredTime, TriggeredTime22),
                             copyTriggeredTime(TriggeredTime, TriggeredTime23),
                             
                             ChartVarList21=[Times, TriggeredTime21|ChartVarListTail],
                             ChartVarList22=[Times, TriggeredTime22|ChartVarListTail],
                             ChartVarList23=[Times, TriggeredTime23|ChartVarListTail],                       
                             
                             noNullAppend(NewPreActiveSet1, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList21, ChartVarList21, [_, LocationList]]], NewPreActiveSet21),
                             noNullAppend(NewPreActiveSet21, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList22, ChartVarList22, [_, LocationList]]], NewPreActiveSet22),
                             noNullAppend(NewPreActiveSet22, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList23, ChartVarList23, [_, LocationList]]], NewPreActiveSet2),
                             ReadyActiveSet2=ReadyActiveSet1,
                             NewMaxLiveCopies2 is NewMaxLiveCopies1+3             
                       )
                 ),
                 
                 removeIntervalList(CurrentSenderInterval, EnabledSenderInterval, OtherSenderInterval),
                 removeIntervalList(CurrentReceiverInterval, EnabledReceiverInterval, OtherReceiverInterval),
                 
                 ( OtherSenderInterval= [] ->
                       ( OtherReceiverInterval= [] ->
                             NewPreActiveSet=NewPreActiveSet2,
                             ReadyActiveSet=ReadyActiveSet2,
                             NewMaxLiveCopies is NewMaxLiveCopies2
                             ;
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList3, Sender, CurrentSenderInterval, Receiver, EnabledReceiverInterval),
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             copyTriggeredTime(TriggeredTime, TriggeredTime3),
                             
                             ChartVarList3=[Times, TriggeredTime3|ChartVarListTail],
                       
                             updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList3),
                       
                             ChartCopySet3=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList3, ChartVarList3, [_, LocationList3]]],
                       
                             advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet3, NewChartCopySet3, Trace),
                       
                             checkEndOfPreCharts(PreChartName, NewChartCopySet3, NewPreActiveSet3, ReadyActiveSet3),
                       
                             noNullAppend(NewPreActiveSet2, NewPreActiveSet3, NewPreActiveSet),
                             noNullAppend(ReadyActiveSet2, ReadyActiveSet3, ReadyActiveSet),
                             NewMaxLiveCopies is NewMaxLiveCopies2+1
                       )
                       ;
                       ( OtherReceiverInterval= [] ->
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList3, Sender, EnabledSenderInterval, Receiver, CurrentReceiverInterval),
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             copyTriggeredTime(TriggeredTime, TriggeredTime3),
                             
                             ChartVarList3=[Times, TriggeredTime3|ChartVarListTail],
                       
                             updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList3),
                                              
                             ChartCopySet3=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList3, ChartVarList3, [_, LocationList3]]],
                       
                             advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet3, NewChartCopySet3, Trace),
                       
                             checkEndOfPreCharts(PreChartName, NewChartCopySet3, NewPreActiveSet3, ReadyActiveSet3),
                       
                             noNullAppend(NewPreActiveSet2, NewPreActiveSet3, NewPreActiveSet),
                             noNullAppend(ReadyActiveSet2, ReadyActiveSet3, ReadyActiveSet),
                             NewMaxLiveCopies is NewMaxLiveCopies2+1
                             ;
                 
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList31, Sender, OtherSenderInterval, Receiver, EnabledReceiverInterval),
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList32, Sender, EnabledSenderInterval, Receiver, OtherReceiverInterval),
                             updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList33, Sender, OtherSenderInterval, Receiver, OtherReceiverInterval),
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             copyTriggeredTime(TriggeredTime, TriggeredTime31),
                             copyTriggeredTime(TriggeredTime, TriggeredTime32),
                             copyTriggeredTime(TriggeredTime, TriggeredTime33),
                             
                             ChartVarList31=[Times, TriggeredTime31|ChartVarListTail],
                             ChartVarList32=[Times, TriggeredTime32|ChartVarListTail],
                             ChartVarList33=[Times, TriggeredTime33|ChartVarListTail],
                       
                             updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList3),
                       
                             ChartCopySet31=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList31, ChartVarList31, [_, LocationList3]]],
                             ChartCopySet32=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList32, ChartVarList32, [_, LocationList3]]],
                             ChartCopySet33=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList33, ChartVarList33, [_, LocationList3]]],
                       
                             advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet31, NewChartCopySet31, Trace),
                             advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet32, NewChartCopySet32, Trace),
                             advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet33, NewChartCopySet33, Trace),
                       
                             noNullAppend(NewChartCopySet31, NewChartCopySet32, NewChartCopySet311),
                             noNullAppend(NewChartCopySet311, NewChartCopySet33, NewChartCopySet3),
                       
                             checkEndOfPreCharts(PreChartName, NewChartCopySet3, NewPreActiveSet3, ReadyActiveSet3),
                       
                             noNullAppend(NewPreActiveSet2, NewPreActiveSet3, NewPreActiveSet),
                             noNullAppend(ReadyActiveSet2, ReadyActiveSet3, ReadyActiveSet),
                             NewMaxLiveCopies is NewMaxLiveCopies2+3
                       )           
                 )
           )
           ;
           unifyPreActive(Message, SysVarList, InstanceVarList, EventListTail, PreActiveChart, NewPreActiveSet, ReadyActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies)
     ).

%%  deal with all not-enabled events
unifyPreActive(Message, SysVarList, InstanceVarList, [Event|_], PreActiveChart, NewPreActiveSet, ReadyActiveSet, _, OldMaxLiveCopies, NewMaxLiveCopies):-
    Event=[_, _, _, Type, _, [EventConstraints, Sender, Receiver, Method], _],
    PreActiveChart= [ChartName, MainChart, PreChart, ChartSymblicInstanceList, ChartVarList, Cut],
    Cut=[_, LocationList],
    haveNotProcess(Event, LocationList),
    apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, ChartSymblicInstanceList]),
    freeList(Value),
    Message= [Type, Sender, SenderInterval, Receiver, ReceiverInterval, Value, _],
    !,
    
    getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
    getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
    apply(SendConstraintMethod, [SysVarList, InstanceVarList,ChartVarList,  ChartSymbolicInstanceList, ConstraintSenderInterval]),
    minusIntervalLists(ConstraintSenderInterval, SenderInterval, ForbiddenSenderInterval),
    removeIntervalList(CurrentSenderInterval, ForbiddenSenderInterval, RemainSenderInterval),
    
    getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
    getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
    apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
    minusIntervalLists(ConstraintReceiverInterval, ReceiverInterval, ForbiddenReceiverInterval),
    removeIntervalList(CurrentReceiverInterval, ForbiddenReceiverInterval, RemainReceiverInterval),
    
   
    ( RemainSenderInterval= [] ->
          ( RemainReceiverInterval= [] ->
                NewPreActiveSet=[],
                ReadyActiveSet=[],
                NewMaxLiveCopies is OldMaxLiveCopies
                ;
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList1, Sender, CurrentReceiverInterval, Receiver, RemainReceiverInterval),
                ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                copyTriggeredTime(TriggeredTime, TriggeredTime1),
                
                ChartVarList1=[Times, TriggeredTime1|ChartVarListTail],
                       
                NewPreActiveSet=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList1, ChartVarList1, Cut]],
                ReadyActiveSet=[],
                NewMaxLiveCopies is OldMaxLiveCopies
          )
          ;
          ( RemainReceiverInterval= [] ->
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList2, Sender, RemainSenderInterval, Receiver, CurrentReceiverInterval),
                ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                copyTriggeredTime(TriggeredTime, TriggeredTime2),
                
                ChartVarList2=[Times, TriggeredTime2|ChartVarListTail],
                       
                NewPreActiveSet=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList2, ChartVarList2, Cut]],
                ReadyActiveSet=[],
                NewMaxLiveCopies is OldMaxLiveCopies
                ;
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList31, Sender, ForbiddenSenderInterval, Receiver, RemainReceiverInterval),
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList32, Sender, RemainSenderInterval, Receiver, ForbiddenReceiverInterval),
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList33, Sender, RemainSenderInterval, Receiver, RemainReceiverInterval),
                ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                copyTriggeredTime(TriggeredTime, TriggeredTime31),
                copyTriggeredTime(TriggeredTime, TriggeredTime32),
                copyTriggeredTime(TriggeredTime, TriggeredTime33),
                
                ChartVarList31=[Times, TriggeredTime31|ChartVarListTail],
                ChartVarList32=[Times, TriggeredTime32|ChartVarListTail],
                ChartVarList33=[Times, TriggeredTime33|ChartVarListTail],                
                
                ChartCopySet31=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList31, ChartVarList31, Cut]],
                ChartCopySet32=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList32, ChartVarList32, Cut]],
                ChartCopySet33=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList33, ChartVarList33, Cut]],

                NewPreActiveSet=[ChartCopySet31, ChartCopySet32, ChartCopySet33],
                ReadyActiveSet=[],
                NewMaxLiveCopies is OldMaxLiveCopies+2
          )
    ).


unifyPreActive(Message, SysVarList, InstanceVarList, [_|EventListTail], PreActiveChart, NewPreActiveSet, ReadyActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    unifyPreActive(Message, SysVarList, InstanceVarList, EventListTail, PreActiveChart, NewPreActiveSet, ReadyActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies).


%% checkEndOfPreCharts(PreChartName, NewChartCopySet, NewPreActiveSet, ReadyActiveSet),

checkEndOfPreCharts(_, [], [], []):- !.

checkEndOfPreCharts(PreChartName, NewChartCopySet, NewPreActiveSet, ReadyActiveSet):-
    NewChartCopySet=[ChartCopy|OtherChartCopies],
    checkEndOfPreChart(PreChartName, ChartCopy, NewPreActiveSet1, ReadyActiveSet1),
    checkEndOfPreCharts(PreChartName, OtherChartCopies, NewPreActiveSet2, ReadyActiveSet2),
    noNullAppend(NewPreActiveSet1, NewPreActiveSet2, NewPreActiveSet),
    noNullAppend(ReadyActiveSet1, ReadyActiveSet2, ReadyActiveSet).
    
    
%% checkEndOfPreChart(PreChartName, NewChartCopySet, NewPreActiveSet, ReadyActiveSet),
checkEndOfPreChart(PreChartName, ChartCopy, NewPreActiveSet, ReadyActiveSet):-
    ChartCopy= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, Cut],
    Cut= [_, LocationList],
    ( endOfChart(PreChartName, LocationList) ->
          NewPreActiveSet= [],
          ReadyActiveSet= [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, _]]
          ;
          getCutTempture(Tempture, PreChartName, LocationList),
          NewPreActiveSet= [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, [Tempture, LocationList]]],
          ReadyActiveSet=[]
    ).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  advance the preactive charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet, NewChartCopySet, Trace)
%%    ChartCopySet should be several prechart, the result are several new chartcopies in the NewChartCopySet
%%    this is because local condition and operation may also contain constraints on the symblic instances, resulting
%%    in splitting the current ChartCopy
%%    because of the hot condiston, main chart and prechart cannot be handled together. they have different strategies
%%        when hot conditions are evaulated to be false



advancePreActiveCut(_, _, [], [], _):- !.

advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet, NewChartCopySet, Trace):-
    ChartCopySet= [ChartCopy|OtherChartCopy],

    ChartCopy= [_, _, _, _, _, [_, LocationList]],
    
    checkPreActiveCutEvent(SysVarList, InstanceVarList, ChartCopy, ChartCopySet1, LocationList, IfAdvanced, Trace),
    
    ( IfAdvanced= advanced ->
          advancePreActiveCut(SysVarList, InstanceVarList, ChartCopySet1, ChartCopySet2, Trace),
          advancePreActiveCut(SysVarList, InstanceVarList, OtherChartCopy, ChartCopySet3, Trace),          
          noNullAppend(ChartCopySet2, ChartCopySet3, NewChartCopySet)
          ;
          advancePreActiveCut(SysVarList, InstanceVarList, OtherChartCopy, ChartCopySet2, Trace),
          noNullAppend(ChartCopySet1, ChartCopySet2, NewChartCopySet)
    ).


%% checkPreActiveCutEvent(SysVarList, InstanceVarList, ChartCopy, NewChartCopySet, LocationList, IfAdvanced, Trace),
%%    NewChartCopySet contains all new created chart copies
%%    LocationList is the locationList of a cut
%%    if local operations have been executed, the IfAdvanced will be instantiated to advanced, or it will
%%         be instantiaed to not_advanced
          
checkPreActiveCutEvent(_, _, ChartCopy, [ChartCopy], [], not_advanced, _):- !.

checkPreActiveCutEvent(SysVarList, InstanceVarList, ChartCopy, NewChartCopySet, LocationList, IfAdvanced, Trace):-
     LocationList=[[_, Location]|LocationListTail],
     ChartCopy= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, Cut],
     ChartVarList=[Times, TriggeredTime|ChartVarListTail],
     PreChart= [PreChartName, _, InstanceLocationList],
     Event=[Location, _, _, Type, InstanceList, _, _],
     
     declareEvent(PreChartName, Event),   
     
     ( notLocalOperation(Type) ->
           checkPreActiveCutEvent(SysVarList, InstanceVarList, ChartCopy, NewChartCopySet, LocationListTail, IfAdvanced, Trace)
           ;
           Cut=[_, OriginalLocationList],
           ( enabledEvent(Event, OriginalLocationList) ->
                 
                 IfAdvanced= advanced,
                 synchronizeLogicalTime(InstanceList, Times, NewTimes1),
%                 copyTimes(Times, NewTimes1),
%                 copyTriggeredTime(TriggeredTime, NewTriggeredTime1),
                 ChartVarList1= [NewTimes1, TriggeredTime|ChartVarListTail],
                       
                 ( executePreActiveLocalOperation(SysVarList, InstanceVarList, ChartVarList1, NewChartVarList, ChartSymbolicInstanceList, Event, Type, InstanceLocationList, OriginalLocationList, NewLocationList, Trace) ->
                       NewChartCopySet= [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, NewChartVarList, [_, NewLocationList]]]
                       ;
                       NewChartCopySet= []
                 )
                 ;
                 checkPreActiveCutEvents(SysVarList, InstanceVarList, ChartCopy,  NewChartCopySet, LocationListTail, IfAdvanced, Trace)
           )
      ).


%% executePreActiveLocalOperation(SysVarList, InstanceVarList, ChartVarList, NewChartVarList, ChartSymbolicInstanceList, Event, Type, InstanceLocationList, LocationList, NewLocationList, Trace)
%%     execute the local operation, including assignment and conditions

executePreActiveLocalOperation(SysVarList, InstanceVarList, ChartVarList, NewChartVarList, ChartSymbolicInstanceList, Event, time, InstanceLocationList, LocationList, NewLocationList, _):-
    Event=[_, _, _, _, InstanceList, [_, TimeConstraint], _],
    ChartVarList= [ Times|ChartVarListTail],
    
    increaseLogicalTimes(InstanceList, Times, Times1),
    InstanceList=[Instance|_],
   
    getListofInstance(Times1, Instance, [CurrentLogicalTime|_]),
    
    getCausalTimeConstaints(InstanceList, CurrentLogicalTime, Times1, CausalTimeConstaints),
    getMinimalTimeConstaints(CausalTimeConstaints, CausalTimeConstaints, MinimalTimeConstaints),
    
    ChartVarList1= [ Times1|ChartVarListTail],
    
    apply(TimeConstraint, [SysVarList, InstanceVarList, ChartVarList1, NewTime, ChartSymbolicInstanceList]),
    
    ( introduceCausalTimeConstaints( NewTime, MinimalTimeConstaints, empty)->
          insertNewTimeConstaints(InstanceList, NewTime, Times1, Times2),
          NewChartVarList= [Times2|ChartVarListTail],
          updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList)
          ;          
          fail
    ).
    
    



executePreActiveLocalOperation(_, _, ChartVarList,  ChartVarList, _, Event, subbegin, InstanceLocationList, LocationList, NewLocationList,  _):-
    Event=[_, _, _, _, InstanceList|_],
    updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList).

executePreActiveLocalOperation(_, _, ChartVarList, ChartVarList, _, Event, subend, InstanceLocationList, LocationList, NewLocationList, _):-
    Event=[_, _, _, _, InstanceList|_],
    updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList).

executePreActiveLocalOperation(SysVarList, InstanceVarList, ChartVarList, NewChartVarList, ChartSymbolicInstanceList, Event, assignment, InstanceLocationList, LocationList, NewLocationList, _):-
    Event= [_, _, _, _, InstanceList, [_, Method], _],
    apply(Method, [SysVarList, InstanceVarList, ChartVarList, NewChartVarList, ChartSymbolicInstanceList]),
    updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList).


executePreActiveLocalOperation(_, _, ChartVarList, ChartVarList, _, Event, goto, _, LocationList, NewLocationList, _):-
    Event= [_, _, _, _, _, [_, GotoLocationLists], _],
    gotoLocationList(LocationList, GotoLocationLists, NewLocationList).


%%  hot conditions
executePreActiveLocalOperation(SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, Event, condition, InstanceLocationList, LocationList, NewLocationList, _):-
    Event= [_, _, _, _, InstanceList, [_, Method|_], hot],
    ( apply(Method, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]) ->
          updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList)
          ;
          fail
    ).


%%  cola conditions
executePreActiveLocalOperation(SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, Event, condition, _, LocationList, NewLocationList, _):-
    Event= [_, _, _, _, _, [_, Method, GotoInfo], cold],
    ( apply(Method, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]) ->
          GotoInfo=[TrueLocationList, _],
          gotoLocationList(LocationList, TrueLocationList, NewLocationList)
          ;
          GotoInfo=[_, FalseLocationList],
          gotoLocationList(LocationList, FalseLocationList, NewLocationList)
    ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%

%%  executeLocalOperations(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ActiveSet, NewActiveSet, Trace, NewTrace, Step, NewStep, MaxLiveCopies)


executeLocalOperations(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ActiveSet, NewActiveSet, Trace, NewTrace, Step, NewStep, MaxLiveCopies):-
    getEnabledLocalOperation(ActiveSet, Event),
    ( Event = [] ->
          NewSysVarList= SysVarList,
          NewInstanceVarList= InstanceVarList,
          NewActiveSet= ActiveSet,
          NewTrace= Trace,
          NewStep is Step
          ;
          addToTrace(Event, Trace, NewTrace1),
          countOperation(Event, Step, NewStep1),
          executeLocalOperation(SysVarList, InstanceVarList, NewSysVarList1, NewInstanceVarList1, ActiveSet, NewActiveSet1, Event, NewTrace1, NewStep1, MaxLiveCopies),          
          executeLocalOperations(NewSysVarList1, NewInstanceVarList1, NewSysVarList, NewInstanceVarList, NewActiveSet1, NewActiveSet, NewTrace1, NewTrace, NewStep1, NewStep, MaxLiveCopies)
    ).
    
%% countOperation(Event, Step, NewStep1),

countOperation(Event, Step, NewStep):- 
    Event=[_, _, _, Type| _],
    ( isCountOperation(Type)->
          NewStep is Step+1
          ;
          NewStep is Step
    ).
    
isCountOperation(condition):- !.
isCountOperation(time):- !.
isCountOperation(bind):- !.
isCountOperation(assignment):- !.
    


    
%%  getEnabledLocalOperation(ActiveSet, Event)


getEnabledLocalOperation([], []):- !.

getEnabledLocalOperation([ActiveChart|ActiveSetTail], Event):-
    ActiveChart=[_, MainChart|_],
    MainChart=[_, EventList, _],
    getEnabledLocalEvent(ActiveChart, EventList, Event1),
    ( Event1= [] ->
          getEnabledLocalOperation(ActiveSetTail, Event)
          ;
          Event= Event1
    ).

%% getEnabledLocalEvent(ActiveChart, EventList, EnabledEvent)

getEnabledLocalEvent(_, [], []):- !.

getEnabledLocalEvent(ActiveChart, [Event|_], EnabledEvent):-
    ActiveChart= [_, _, _, _, _, Cut],
    Cut= [_, LocationList],

    Event=[_, _, _, Type| _],
    not(notMainLocalOperation(Type)),
    enabledEvent(Event, LocationList),
    !,
    EnabledEvent= Event.    
    
getEnabledLocalEvent(ActiveChart, [_|EventListTail], EnabledEvent):-    
    getEnabledLocalEvent(ActiveChart, EventListTail, EnabledEvent).
          
%% addToTrace(Event, Trace, NewTrace)

addToTrace(Event, Trace, NewTrace):-
    Event= [_, _, _, time, _, [_, TimeConstraint|_], _],
    noNullAppend(Trace, [[time, TimeConstraint]], NewTrace),
    !.
    

addToTrace(Event, Trace, NewTrace):-
    Event= [_, _, _, bind, _, [_, BindMethod|_], _],
    noNullAppend(Trace, [[bind, BindMethod]], NewTrace),
    !.

addToTrace(Event, Trace, NewTrace):-
    Event= [_, _, _, condition, _, [_, Method|_], _],
    noNullAppend(Trace, [[condition, Method]], NewTrace),
    !.

addToTrace(_, Trace, Trace).


%% executeLocalOperation(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ActiveSet, NewActiveSet, Event, Trace, Step, MaxLiveCopies)

executeLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, [], [], _, _, _, _):- !.

executeLocalOperation(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, [ActiveChart|ActiveSetTail], NewActiveSet, Event, Trace, Step, MaxLiveCopies):-
    ActiveChart= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, Cut],
    MainChart= [MainChartName, _, InstanceLocationList],
    Cut= [_, OriginalLocationList],

    declareEvent(MainChartName, Event),
    enabledEvent(Event, OriginalLocationList),
    !,
    
    Event= [_, _, _, Type, InstanceList, _, _],
    ChartVarList=[Times, TriggeredTime|ChartVarListTail],    
    synchronizeLogicalTime(InstanceList, Times, NewTimes1),
    ChartVarList1= [NewTimes1, TriggeredTime|ChartVarListTail],
    executeActiveLocalOperation(SysVarList, InstanceVarList, NewSysVarList1, NewInstanceVarList1, ChartVarList1, NewChartVarList, ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Event, Type, InstanceLocationList, OriginalLocationList, NewLocationList, Trace, Step, MaxLiveCopies),
    
    getCutTempture(Tempture1, MainChartName, NewLocationList),
    NewChartCopy= [ChartName, MainChart, PreChart, NewChartSymbolicInstanceList, NewChartVarList, [Tempture1, NewLocationList]],
    
    checkEndOfMainChart(MainChartName, NewChartCopy, NewChartCopy1),
    
    noNullAppend(NewChartCopy1, NewActiveSetTail, NewActiveSet),
%    ( NewChartCopy1= [] ->
%          NewActiveSet= NewActiveSetTail
%          ;
%          NewActiveSet= [NewChartCopy1|NewActiveSetTail]
%    ),
    executeLocalOperation(NewSysVarList1, NewInstanceVarList1, NewSysVarList, NewInstanceVarList, ActiveSetTail, NewActiveSetTail, Event, Trace, Step, MaxLiveCopies).


executeLocalOperation(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, [ActiveChart|ActiveSetTail], [ActiveChart|NewActiveSetTail], Event, Trace, Step, MaxLiveCopies):-
    executeLocalOperation(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ActiveSetTail, NewActiveSetTail, Event, Trace, Step, MaxLiveCopies).



%% notMainLocalOperation(Type)

notMainLocalOperation(asend):-!.
notMainLocalOperation(arecv):-!.
notMainLocalOperation(assignment):-!.
notMainLocalOperation(end):-!.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% predicate for Active chart copies
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% checkActive(Message, SysVarList, InstanceList, NewSysVarList, NewInstanceList, ActiveSet, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies),
%%    check the all active chart in the ActiveSet, in other words, check the main charts

checkActive(_, SysVarList, InstanceVarList, SysVarList, InstanceVarList, [], [], _, OldMaxLiveCopies, OldMaxLiveCopies):- !.


checkActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ActiveSet, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    ActiveSet=[ActiveChart|OtherActiveCharts],
    checkActiveChart(Message, SysVarList, InstanceVarList, SysVarList1, InstanceVarList1, ActiveChart, NewActiveSet1, Trace, OldMaxLiveCopies, NewMaxLiveCopies1),
    checkActive(Message, SysVarList1, InstanceVarList1, NewSysVarList, NewInstanceVarList, OtherActiveCharts, NewActiveSet2, Trace, NewMaxLiveCopies1, NewMaxLiveCopies),    
    noNullAppend(NewActiveSet1, NewActiveSet2, NewActiveSet).



%% deal with active which has reached its end from the beggining.

checkActiveChart(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    ActiveChart=[_, MainChart|_],
    MainChart=[MainChartName, EventList, _],
    unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, EventList, ActiveChart, NewActiveSet1, Trace, OldMaxLiveCopies, NewMaxLiveCopies),
    
    checkEndOfMainCharts(MainChartName, NewActiveSet1, NewActiveSet).
    
 
%% unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, EventList, ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):

unifyActive(_, SysVarList, InstanceVarList, SysVarList, InstanceVarList, [], ActiveChart, [ActiveChart], _, OldMaxLiveCopies, OldMaxLiveCopies):- !.

%% deal with assigment

unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, [Event|EventListTail], ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    Message= [assignment, Method|_],
    !,
    ( Event= [_, _, _, assignment, InstanceList, [_, Method], _] ->
          ActiveChart= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, [_, LocationList]],
          apply(Method, [SysVarList, InstanceVarList, ChartVarList, NewSysVarList1, NewInstanceVarList1, NewChartVarList1, ChartSymbolicInstanceList]),
          MainChart= [MainChartName, _, InstanceLocationList],
          updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList),
          getCutTempture(NewTempture, MainChartName, NewLocationList),
          
          NewChartVarList1=[Times1, TriggeredTime1|ChartVarListTail1],

          synchronizeLogicalTime(InstanceList, Times1, Times2),
          NewChartVarList2=[Times2, TriggeredTime1|ChartVarListTail1],          
          
          ChartCopySet=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList, NewChartVarList2, [NewTempture, NewLocationList]]],
          advanceActiveCut(NewSysVarList1, NewInstanceVarList1, NewSysVarList, NewInstanceVarList, ChartCopySet, NewActiveSet, Trace),
          NewMaxLiveCopies= OldMaxLiveCopies
          ;
          unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, EventListTail, ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies)
    ).


%%  deal with all enabled events
unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, [Event|EventListTail], ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    ActiveChart= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, Cut],
    MainChart= [MainChartName, _, InstanceLocationList],
    Cut= [_, LocationList],
    Event=[_, _, _, Type, InstanceList, [EventConstraints, Sender, Receiver, Method], _],
    haveNotProcess(Event, LocationList),
    enabledEvent(Event, LocationList),
    !,
    getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
    getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
    apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
    minusIntervalLists(CurrentSenderInterval, ConstraintSenderInterval, EnabledSenderInterval),
       
    getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
    getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
    apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
    minusIntervalLists(CurrentReceiverInterval, ConstraintReceiverInterval, EnabledReceiverInterval),
    
    updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList0, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval),

    apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList0]),
    
    ( Message= [Type, Sender, SenderInterval, Receiver, ReceiverInterval, Value, _] ->
           NewMaxLiveCopies0 is OldMaxLiveCopies-1,

           minusIntervalLists(EnabledSenderInterval, SenderInterval, TriggeredSenderInterval),
           minusIntervalLists(EnabledReceiverInterval, ReceiverInterval, TriggeredReceiverInterval),
           
           ( TriggeredSenderInterval= [] ->
                 NewActiveSet1=[],
                 SysVarList1= SysVarList,
                 InstanceVarList1= InstanceVarList,
                 NewMaxLiveCopies1 is NewMaxLiveCopies0
                 ;
                 ( TriggeredReceiverInterval= [] ->
                       NewActiveSet1=[],
                       SysVarList1= SysVarList,
                       InstanceVarList1= InstanceVarList,
                       NewMaxLiveCopies1 is NewMaxLiveCopies0
                       ;
                       ( Type= asend ->
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                             
                             updateLogicalTime(Sender, Times, Times1),
                             
                             getListofInstance(Times1, Sender, [SendTime|_]),
                             
                             copyTriggeredTime(TriggeredTime, TriggeredTime1),                             
                             append([[[Sender, Receiver, Value], SendTime]], TriggeredTime1, TriggeredTime11),
                             
                             ChartVarList1=[Times1, TriggeredTime11|ChartVarListTail]
                             ;
                             
                             ChartVarList=[Times, TriggeredTime|ChartVarListTail],                             
                             copyTriggeredTime(TriggeredTime, TriggeredTime1),
                             getMessangeTime(TriggeredTime1, [Sender, Receiver, Value], SendTime),
                             
                             updateLogicalTime2(Receiver, SendTime, Times, Times1),
                
                             deleteElementFromList([[Sender, Receiver, Value], SendTime], TriggeredTime1, NewTriggeredTime11),
                             
                             ChartVarList1=[Times1, NewTriggeredTime11|ChartVarListTail]
                       ),                       
                       
                       updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList1),                       
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList1, Sender, TriggeredSenderInterval, Receiver, TriggeredReceiverInterval),

                       getCutTempture(Tempture1, MainChartName, LocationList1),
                       
                       NewMaxLiveCopies1 is NewMaxLiveCopies0+1,
                       
                       ChartCopySet=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList1, ChartVarList1, [Tempture1, LocationList1]]],
                       advanceActiveCut(SysVarList, InstanceVarList, SysVarList1, InstanceVarList1, ChartCopySet, NewActiveSet1, Trace)
                 )
           ),

           removeIntervalList(EnabledSenderInterval, TriggeredSenderInterval, RemainSenderInterval),
           removeIntervalList(EnabledReceiverInterval, TriggeredReceiverInterval, RemainReceiverInterval),
           
           SysVarList2= SysVarList1,
           InstanceVarList2= InstanceVarList1,
           
           ( RemainSenderInterval= [] ->
                 ( RemainReceiverInterval= [] ->
                       NewActiveSet2=NewActiveSet1,
                       NewMaxLiveCopies2 is NewMaxLiveCopies1
                       ;
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList2, Sender, EnabledSenderInterval, Receiver, RemainReceiverInterval),
                       ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                       copyTriggeredTime(TriggeredTime, TriggeredTime2),
                       
                       ChartVarList2=[Times, TriggeredTime2|ChartVarListTail],
                       noNullAppend(NewActiveSet1, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList2, ChartVarList2, Cut]], NewActiveSet2)                       ,
                       NewMaxLiveCopies2 is NewMaxLiveCopies1+1
                 )
                 ;
                 ( RemainReceiverInterval= [] ->
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList2, Sender, RemainSenderInterval, Receiver, EnabledSenderInterval),
                       ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                       copyTriggeredTime(TriggeredTime, TriggeredTime2),
                       
                       ChartVarList2=[Times, TriggeredTime2|ChartVarListTail],
                       noNullAppend(NewActiveSet1, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList2, ChartVarList2, Cut]], NewActiveSet2),
                       NewMaxLiveCopies2 is NewMaxLiveCopies1+1
                       ;
                       
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList21, Sender, TriggeredSenderInterval, Receiver, RemainReceiverInterval),
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList22, Sender, RemainSenderInterval, Receiver, TriggeredReceiverInterval),
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList23, Sender, RemainSenderInterval, Receiver, RemainReceiverInterval),
                       ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                       copyTriggeredTime(TriggeredTime, TriggeredTime21),
                       copyTriggeredTime(TriggeredTime, TriggeredTime22),
                       copyTriggeredTime(TriggeredTime, TriggeredTime23),
                       
                       ChartVarList21=[Times, TriggeredTime21|ChartVarListTail],
                       ChartVarList22=[Times, TriggeredTime22|ChartVarListTail],
                       ChartVarList23=[Times, TriggeredTime23|ChartVarListTail],                       
                       
                       noNullAppend(NewActiveSet1, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList21, ChartVarList21, Cut]], NewActiveSet21),
                       noNullAppend(NewActiveSet21, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList22, ChartVarList22, Cut]], NewActiveSet22),
                       noNullAppend(NewActiveSet22, [[ChartName, MainChart, PreChart, ChartSymbolicInstanceList23, ChartVarList23, Cut]], NewActiveSet2),
                       NewMaxLiveCopies2 is NewMaxLiveCopies1+3
                 )
           ),
           
           removeIntervalList(CurrentSenderInterval, EnabledSenderInterval, OtherSenderInterval),
           removeIntervalList(CurrentReceiverInterval, EnabledReceiverInterval, OtherReceiverInterval),
           
          
           ( OtherSenderInterval= [] ->
                 ( OtherReceiverInterval= [] ->
                       NewActiveSet3=NewActiveSet2,
                       SysVarList3= SysVarList2,
                       InstanceVarList3= InstanceVarList2,
                       NewMaxLiveCopies3 is NewMaxLiveCopies2
                       ;
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList3, Sender, CurrentSenderInterval, Receiver, OtherReceiverInterval),
                       ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                       copyTriggeredTime(TriggeredTime, TriggeredTime3),
                       
                       ChartVarList3=[Times, TriggeredTime3|ChartVarListTail],
                       
                       updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList3),
                       getCutTempture(Tempture3, MainChartName, LocationList3),
                       
                       ChartCopySet3=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList3, ChartVarList3, [Tempture3, LocationList3]]],
                       
                       advanceActiveCut(SysVarList2, InstanceVarList2, SysVarList3, InstanceVarList3, ChartCopySet3, NewActiveSet31, Trace),
                       noNullAppend(NewActiveSet2, NewActiveSet31, NewActiveSet3),
                       NewMaxLiveCopies3 is NewMaxLiveCopies2+1
                 )
                 ;
                 ( OtherReceiverInterval= [] ->
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList3, Sender, OtherSenderInterval, Receiver, CurrentReceiverInterval),
                       ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                       copyTriggeredTime(TriggeredTime, TriggeredTime3),
                       
                       ChartVarList3=[Times, TriggeredTime3|ChartVarListTail],
                       
                       updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList3),
                       getCutTempture(Tempture3, MainChartName, LocationList3),
                       ChartCopySet3=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList3, ChartVarList3, [Tempture3, LocationList3]]],
                       
                       advanceActiveCut(SysVarList2, InstanceVarList2, SysVarList3, InstanceVarList3, ChartCopySet3, NewActiveSet31, Trace),
                       noNullAppend(NewActiveSet2, NewActiveSet31, NewActiveSet3),
                       NewMaxLiveCopies3 is NewMaxLiveCopies2+1
                       ;
                 
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList31, Sender, OtherSenderInterval, Receiver, EnabledReceiverInterval),
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList32, Sender, EnabledSenderInterval, Receiver, OtherReceiverInterval),
                       updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList33, Sender, OtherSenderInterval, Receiver, OtherReceiverInterval),
                       ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                       copyTriggeredTime(TriggeredTime, TriggeredTime31),
                       copyTriggeredTime(TriggeredTime, TriggeredTime32),
                       copyTriggeredTime(TriggeredTime, TriggeredTime33),
                       
                       ChartVarList31=[Times, TriggeredTime31|ChartVarListTail],
                       ChartVarList32=[Times, TriggeredTime32|ChartVarListTail],
                       ChartVarList33=[Times, TriggeredTime33|ChartVarListTail],
                       
                       updateLocationList(InstanceLocationList, InstanceList, LocationList, LocationList3),
                       getCutTempture(Tempture3, MainChartName, LocationList3),
                       
                       ChartCopySet31=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList31, ChartVarList31, [Tempture3, LocationList1]]],
                       ChartCopySet32=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList32, ChartVarList32, [Tempture3, LocationList1]]],
                       ChartCopySet33=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList33, ChartVarList33, [Tempture3, LocationList1]]],
                       
                       advancePreActiveCut(SysVarList2, InstanceVarList2, SysVarList31, InstanceVarList31, ChartCopySet31, NewActiveSet31, Trace),
                       advancePreActiveCut(SysVarList31, InstanceVarList31, SysVarList32, InstanceVarList32, ChartCopySet32, NewActiveSet32, Trace),
                       advancePreActiveCut(SysVarList32, InstanceVarList32, SysVarList3, InstanceVarList3, ChartCopySet33, NewActiveSet33, Trace),
                       
                       noNullAppend(NewActiveSet31, NewActiveSet32, NewActiveSet311),
                       noNullAppend(NewActiveSet311, NewActiveSet33, NewActiveSet34),
                       noNullAppend(NewActiveSet2, NewActiveSet34, NewActiveSet3),
                       NewMaxLiveCopies3 is NewMaxLiveCopies2+3
                 )
           ),
           
           NewActiveSet= NewActiveSet3,
           NewSysVarList= SysVarList3,
           NewInstanceVarList= InstanceVarList3,
           NewMaxLiveCopies is NewMaxLiveCopies3
           ;
           unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, EventListTail, ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies)
     ).


%%  deal with all not-enabled events
unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, [Event|_], ActiveChart, NewActiveSet, _, OldMaxLiveCopies, NewMaxLiveCopies):-
    Event=[_, _, _, Type, _, [EventConstraints, Sender, Receiver, Method], _],
    ActiveChart= [ChartName, MainChart, PreChart, ChartSymblicInstanceList, ChartVarList, Cut],
    Cut=[_, LocationList],
    haveNotProcess(Event, LocationList),
    apply(Method, [Value, SysVarList, InstanceVarList, ChartVarList, ChartSymblicInstanceList]),
    freeList(Value),
    Message= [Type, Sender, SenderInterval, Receiver, ReceiverInterval, Value, _],
    !,
    
    getListofInstance2(ChartSymbolicInstanceList, Sender, CurrentSenderInterval),
    getListofInstance2(EventConstraints, Sender, SendConstraintMethod),
    apply(SendConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintSenderInterval]),
    minusIntervalLists(ConstraintSenderInterval, SenderInterval, ForbiddenSenderInterval),
    removeIntervalList(CurrentSenderInterval, ForbiddenSenderInterval, RemainSenderInterval),
    
    getListofInstance2(ChartSymbolicInstanceList, Receiver, CurrentReceiverInterval),
    getListofInstance2(EventConstraints, Receiver, ReceiverConstraintMethod),
    apply(ReceiverConstraintMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, ConstraintReceiverInterval]),
    minusIntervalLists(ConstraintReceiverInterval, ReceiverInterval, ForbiddenReceiverInterval),
    removeIntervalList(CurrentReceiverInterval, ForbiddenReceiverInterval, RemainReceiverInterval),
    
    NewMaxLiveCopies1 is OldMaxLiveCopies-1,
    
    ( RemainSenderInterval= [] ->
          ( RemainReceiverInterval= [] ->
                NewActiveSet=[],
                NewSysVarList= SysVarList,
                NewInstanceVarList= InstanceVarList,
                NewMaxLiveCopies is NewMaxLiveCopies1
                ;
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList1, Sender, CurrentSenderInterval, Receiver, RemainReceiverInterval),
                ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                copyTriggeredTime(TriggeredTime, TriggeredTime1),
                
                ChartVarList1=[Times, TriggeredTime1|ChartVarListTail],
                       
                NewActiveSet=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList1, ChartVarList1, Cut]],
                NewSysVarList= SysVarList,
                NewInstanceVarList= InstanceVarList,
                NewMaxLiveCopies is NewMaxLiveCopies1+1
          )
          ;
          ( RemainReceiverInterval= [] ->
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList2, Sender, RemainSenderInterval, Receiver, CurrentReceiverInterval),
                ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                copyTriggeredTime(TriggeredTime, TriggeredTime2),
                
                ChartVarList2=[Times, TriggeredTime2|ChartVarListTail],
                       
                NewActiveSet=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList2, ChartVarList2, Cut]],
                NewSysVarList= SysVarList,
                NewInstanceVarList= InstanceVarList,
                NewMaxLiveCopies is NewMaxLiveCopies1+1
                ;
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList31, Sender, ForbiddenSenderInterval, Receiver, RemainReceiverInterval),
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList32, Sender, RemainSenderInterval, Receiver, ForbiddenReceiverInterval),
                updateSymbolicInstanceList(ChartSymbolicInstanceList, ChartSymbolicInstanceList33, Sender, RemainSenderInterval, Receiver, RemainReceiverInterval),
                ChartVarList=[Times, TriggeredTime|ChartVarListTail],
                copyTriggeredTime(TriggeredTime, TriggeredTime31),
                copyTriggeredTime(TriggeredTime, TriggeredTime32),
                copyTriggeredTime(TriggeredTime, TriggeredTime33),
                
                ChartVarList31=[Times, TriggeredTime31|ChartVarListTail],
                ChartVarList32=[Times, TriggeredTime32|ChartVarListTail],
                ChartVarList33=[Times, TriggeredTime33|ChartVarListTail],
                
                ChartCopySet31=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList31, ChartVarList31, Cut]],
                ChartCopySet32=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList32, ChartVarList32, Cut]],
                ChartCopySet33=[[ChartName, MainChart, PreChart, ChartSymbolicInstanceList33, ChartVarList33, Cut]],
                
                NewActiveSet=[ChartCopySet31, ChartCopySet32, ChartCopySet33],
                
                NewSysVarList= SysVarList,
                NewInstanceVarList= InstanceVarList,
                NewMaxLiveCopies is NewMaxLiveCopies1+3
          )
    ).


unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, [_|EventListTail], ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies):-
    unifyActive(Message, SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, EventListTail, ActiveChart, NewActiveSet, Trace, OldMaxLiveCopies, NewMaxLiveCopies).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  advance the active charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% advanceActiveCut(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartCopySet, NewChartCopySet, Trace)
%%    ChartCopySet should be several main, the result are several new chartcopies in the NewChartCopySet
%%    because of the hot condiston, main chart and prechart cannot be handled together. they have different strategies
%%        when hot conditions are evaulated to be false


%% disable the advanceActiveCut event
advanceActiveCut(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartCopySet, ChartCopySet, _):- !.

% advanceActiveCut(SysVarList, InstanceVarList, SysVarList, InstanceVarList, [], [], Trace, Trace):- !.

%advanceActiveCut(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartCopySet, NewChartCopySet, Trace):-
%    ChartCopySet= [ChartCopy|OtherChartCopy],
%    ChartCopy= [_, _, _, _, _, [_, LocationList]],    
%    checkActiveCutEvent(SysVarList, InstanceVarList, NewSysVarList1, NewInstanceVarList1, ChartCopy, ChartCopySet1, LocationList, IfAdvanced, Trace),
%
%    ( IfAdvanced= advanced ->
%          advanceActiveCut(NewSysVarList1, NewInstanceVarList1, NewSysVarList2, NewInstanceVarList2, ChartCopySet1, ChartCopySet2, Trace),
%          advanceActiveCut(NewSysVarList2, NewInstanceVarList2, NewSysVarList, NewInstanceVarList, OtherChartCopy, ChartCopySet3, Trace),
%          noNullAppend(ChartCopySet2, ChartCopySet3, NewChartCopySet)
%          ;
%          advanceActiveCut(NewSysVarList1, NewInstanceVarList1, NewSysVarList, NewInstanceVarList, OtherChartCopy, ChartCopySet2, Trace),
%          noNullAppend(ChartCopySet1, ChartCopySet2, NewChartCopySet)
%    ).


%% checkActiveCutEvent(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartCopy, NewChartCopySet, LocationList, IfAdvanced, Trace),
%%    NewChartCopySet contains all new created chart copies
%%    LocationList is the locationList of a cut
%%    if local operations have been executed, the IfAdvanced will be instantiated to advanced, or it will
%%         be instantiaed to not_advanced
          
          
checkActiveCutEvent(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartCopy, [ChartCopy], [], not_advanced, _):- !.

checkActiveCutEvent(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartCopy, NewChartCopySet, LocationList, IfAdvanced, Trace):-
     LocationList=[[_, Location]|LocationListTail],
     ChartCopy= [ChartName, MainChart, PreChart, ChartSymbolicInstanceList, ChartVarList, Cut],
     ChartVarList=[Times, TriggeredTime|ChartVarListTail],
     MainChart= [MainChartName, _, InstanceLocationList],
     Event=[Location, _, _, Type, InstanceList, _, _],
     
     declareEvent(MainChartName, Event),
     
     ( notLocalOperation(Type) ->
           checkActiveCutEvent(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartCopy, NewChartCopySet, LocationListTail, IfAdvanced, Trace)
           ;
           ( Type= assignment->
                 checkActiveCutEvent(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartCopy, NewChartCopySet, LocationListTail, IfAdvanced, Trace)
                 ;    
                 Cut=[_, OriginalLocationList],
                 ( enabledEvent(Event, OriginalLocationList) ->
                 
                       IfAdvanced= advanced,                       
                       synchronizeLogicalTime(InstanceList, Times, NewTimes1),
                       ChartVarList1= [NewTimes1, TriggeredTime|ChartVarListTail],
                       
                       executeActiveLocalOperation(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartVarList1, NewChartVarList, ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Event, Type, InstanceLocationList, OriginalLocationList, NewLocationList, Trace),
                 
                       getCutTempture(Tempture1, MainChartName, NewLocationList),
                       NewChartCopySet= [[ChartName, MainChart, PreChart, NewChartSymbolicInstanceList, NewChartVarList, [Tempture1, NewLocationList]]]
                       ;
                       checkActiveCutEvent(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartCopy, NewChartCopySet, LocationListTail, IfAdvanced, Trace)
                 )
           )
      ).



%% executeActiveLocalOperation(SysVarList, InstanceVarList, NewSysVarList, NewInstanceVarList, ChartVarList, ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Event, Type, InstanceLocationList, LocationList, NewLocationList, Trace, Step, MaxLiveCopies)

executeActiveLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartVarList, NewChartVarList, ChartSymbolicInstanceList, ChartSymbolicInstanceList, Event, time, InstanceLocationList, LocationList, NewLocationList, Trace, Step, MaxLiveCopies):-
    Event=[_, _, _, _, InstanceList, [_, TimeConstraint], _],
    ChartVarList= [ Times|ChartVarListTail],
    
    increaseLogicalTimes(InstanceList, Times, Times1),
    InstanceList=[Instance|_],
   
    getListofInstance(Times1, Instance, [CurrentLogicalTime|_]),
    
    getCausalTimeConstaints(InstanceList, CurrentLogicalTime, Times1, CausalTimeConstaints),
    getMinimalTimeConstaints(CausalTimeConstaints, CausalTimeConstaints, MinimalTimeConstaints),
    
    ChartVarList1= [ Times1|ChartVarListTail],
    
    apply(TimeConstraint, [SysVarList, InstanceVarList, ChartVarList1, NewTime, ChartSymbolicInstanceList]),
    
    ( introduceCausalTimeConstaints( NewTime, MinimalTimeConstaints, empty)->
          insertNewTimeConstaints(InstanceList, NewTime, Times1, Times2),
          NewChartVarList= [Times2|ChartVarListTail],
          updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList)
          ;
          print("time constraint 2\n"),
          print("violate@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n"),
          cputime(CurrentTime),
          debugPrint("CurrentTime", CurrentTime),
          debugPrint("SuperStep", Step),
          debugPrint("MaxLiveCopies", MaxLiveCopies),
          outputTrace(Trace),
          fail
    ).


executeActiveLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Event, bind, InstanceLocationList, LocationList, NewLocationList, _, _, _):-
    Event=[_, _, _, _, InstanceList, [_, BindMethod], _],
    apply(BindMethod, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList, NewChartSymbolicInstanceList]),
    updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList).
    


executeActiveLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, ChartSymbolicInstanceList, Event, subbegin, InstanceLocationList, LocationList, NewLocationList, _, _, _):-
    Event=[_, _, _, _, InstanceList|_],
    updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList).

executeActiveLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, ChartSymbolicInstanceList, Event, subend, InstanceLocationList, LocationList, NewLocationList, _, _, _):-
    Event=[_, _, _, _, InstanceList|_],
    updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList).

executeActiveLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, ChartSymbolicInstanceList, Event, goto, _, LocationList, NewLocationList, _, _, _):-
    Event= [_, _, _, _, _, [_, GotoLocationLists], _],
    gotoLocationList(LocationList, GotoLocationLists, NewLocationList).


%%  hot conditions
executeActiveLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, ChartSymbolicInstanceList, Event, condition, InstanceLocationList, LocationList, NewLocationList, Trace, Step, MaxLiveCopies):-
    Event= [_, _, _, _, InstanceList, [_, Method|_], hot],
    ( apply(Method, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]) ->
          updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList)
          ;
          print("check condition2\n"),
          print("violate@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n"),
          cputime(CurrentTime),
          debugPrint("CurrentTime", CurrentTime),
          debugPrint("SuperStep", Step),
          debugPrint("MaxLiveCopies", MaxLiveCopies),
          outputTrace(Trace),          
          fail
    ).


%%  cola conditions
executeActiveLocalOperation(SysVarList, InstanceVarList, SysVarList, InstanceVarList, ChartVarList, ChartVarList, ChartSymbolicInstanceList, ChartSymbolicInstanceList, Event, condition, _, LocationList, NewLocationList, _, _, _):-
    Event= [_, _, _, _, _, [_, Method, GotoInfo], cold],
    ( apply(Method, [SysVarList, InstanceVarList, ChartVarList, ChartSymbolicInstanceList]) ->
          GotoInfo=[TrueLocationList, _],
          gotoLocationList(LocationList, TrueLocationList, NewLocationList)
          ;          
          GotoInfo=[_, FalseLocationList],
          gotoLocationList(LocationList, FalseLocationList, NewLocationList)
    ).


%%checkEndOfMainCharts(MainChartName, ChartCopySet, NewActiveSet)

checkEndOfMainCharts(_, [], []):- !.

checkEndOfMainCharts(MainChartName, ChartCopySet, NewActiveSet):-
    ChartCopySet=[ChartCopy|OtherChartCopies],
    checkEndOfMainChart(MainChartName, ChartCopy, NewActiveSet1),
    checkEndOfMainCharts(MainChartName, OtherChartCopies, NewActiveSet2),
    
    noNullAppend(NewActiveSet1, NewActiveSet2, NewActiveSet).
    
    

%% checkEndOfMainChart(MainChartName, ChartCopy, NewActiveSet)
checkEndOfMainChart(MainChartName, ChartCopy, NewActiveSet):-
    ChartCopy= [_, _, _, _, _, Cut],
    Cut= [_, LocationList],
    ( endOfChart(MainChartName, LocationList) ->
          NewActiveSet= []
          ;
          NewActiveSet= [ChartCopy]
    ).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  common predicates, can be used for active, preactive and minimal 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
%% endOfChart(ChartName, LocationList), determine if the chart has reached its end
endOfChart(_, []) :- !.

endOfChart(ChartName, [[_, Location]|LocationListTail]):-
    declareEvent(ChartName, [Location, _, _, end|_]),
    endOfChart(ChartName, LocationListTail).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%  predicates for both active and preactive charts    
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
%% updateLocationList(InstanceLocationList, InstanceList, LocationList, NewLocationList)
%%     generate a new location list, if the instance is in the InstanceList, get the new location from InstanceLocationList
%%                                   else get it from the LocationList

updateLocationList(_, _, [], []):- !.

updateLocationList(InstanceLocationList, InstanceList, [[Instance, CutLocation]|CutLocationListTail], [[Instance, NewCutLocation]| NewCutLocationListTail]):-
    ( memberOfList(Instance, InstanceList) ->
        getAInstanceLocations(InstanceLocationList, Instance, LocationList), 
        getNextElement(LocationList, CutLocation, NewCutLocation)
        ;
        NewCutLocation= CutLocation
    ),
    updateLocationList(InstanceLocationList, InstanceList, CutLocationListTail, NewCutLocationListTail).
        

%% getAInstanceLocations(InstanceLocationList, Instance, LocationList),
%%     get the list of event from the InstanceLocationList of the Instance, belong to a particular chart

getAInstanceLocations([], _, _):- print("getAInstanceLocations error\n"), abort, !.

getAInstanceLocations([[Instance, LocationList]|_], Instance, LocationList):- !.

getAInstanceLocations([_|InstanceLocationListTail], Instance, LocationList):-
    getAInstanceLocations(InstanceLocationListTail, Instance, LocationList).


%% initCutLocations(InstanceLocationList, Locations): ini
initCutLocations([], []):- !.
    
initCutLocations([InstanceLocation|InstanceLocationListTail], [Location|LocationTail]):-
    InstanceLocation=[Instance, [First|_]],
    Location= [Instance, First],
    initCutLocations(InstanceLocationListTail, LocationTail).    
    
%% getCutTempture(Tempture, ChartName, LocationList): get the tempture of a cut, chartname is main chart name or prechart name
getCutTempture(cold, _, []):-!.

getCutTempture(Tempture, ChartName, [[_, EventId]|_]):-
    Event= [EventId, _, _, _, _, _, hot],
    declareEvent(ChartName, Event),
    Tempture= hot,
    !.
    
getCutTempture(Tempture, ChartName, [_|LocationListTail]):-
    getCutTempture(Tempture, ChartName, LocationListTail).
    
%% enabledEvent(Event, LocationList), check the Event is enable with current LocationList of a cut
enabledEvent(Event, LocationList):-
    Event=[Id, _, _, _, InstanceList, _, _],
    checkEnabled(Id, InstanceList, LocationList).
    
  
checkEnabled(_, [], _) :- !.

checkEnabled(Id, [Instance|InstanceListTail], LocationList):-
    checkEnableInstance(Id1, Instance, LocationList),
    Id=Id1,
    checkEnabled(Id, InstanceListTail, LocationList).
    

checkEnableInstance(_, _, []):- print("check Enable Instance error\n"), abort, !, fail.
    
checkEnableInstance(Id, Instance, [[Instance, Id]|_]):- !.
          
checkEnableInstance(Id, Instance, [[Instance1, _]|LocationListTail]):-
    Instance\= Instance1,
    checkEnableInstance(Id, Instance, LocationListTail).
    

%% getNewCut(Event, Cut, NewCut), move to the cut of the Event
getNewCut(_, [], []):- !.

getNewCut(Event, [[Instance, Location]|CutTail], [[Instance, Location1]|NewCutTail]):-
    Event= [Id, _, _, _, InstanceList, _, _],
    ( memberOfList(Instance, InstanceList)->
        Location1= Id
        ;
        Location1= Location
    ),
    getNewCut(Event, CutTail, NewCutTail).


    
%%  gotoLocationList(LocationList, GotoLocationList, NewLocationList)

gotoLocationList([], _, []):- !.

gotoLocationList([[Instance, OldLocation]|LocationListTail], GotoLocationList, [[Instance, NewLocation]|NewLocationListTail]):-
    ( ifExistInList(Instance, GotoLocationList, GotoTarget) ->
        NewLocation= GotoTarget
        ;
        NewLocation= OldLocation
    ),
    gotoLocationList(LocationListTail, GotoLocationList, NewLocationListTail).
    




    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% general useful functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% createList(Src, Des): create a new list Des with the same length as the Src, without instantiated
createList(Src, Des):-
    length(Src, Len),
    length(Des, Len).
    
%% copyList(Src, Des). if a variable is instantiated in Src, Des contains another variable, or contants the value

copyList([], []):- !.

copyList([X|Xs], [Y|Ys]):-
    ( var(X) ->
          copyList(Xs, Ys)
          ;
          X=Y,
          copyList(Xs, Ys)
    ).
         
         
%% deleteElementFromList(Element, List, NewList), remove all instances of Element from the List
%%    multiple copies will be removed if exist
deleteElementFromList(_, [], []):- !.

deleteElementFromList(Element, [Element|ListTail], NewList):-
    !,
    deleteElementFromList(Element, ListTail, NewList).

deleteElementFromList(Element, [Element1|ListTail], [Element1|NewListTail]):-
    deleteElementFromList(Element, ListTail, NewListTail).




%% the difference with deleteElementFromList is that
%%    if the element does not exists, return fail. 
%%    only remove one copy

testAndDeleteElementFromList(_, [], []):- !, fail.

testAndDeleteElementFromList(Element, [Element|ListTail], ListTail):- !.

testAndDeleteElementFromList(Element, [Element1|ListTail], [Element1|NewListTail]):-
    testAndDeleteElementFromList(Element, ListTail, NewListTail).



%% freeList(List): judge if List contains uninstantiad variables
%%     success if no variable exists
freeList([]):- !.

freeList([Variable|ListTail]):-
    not (var(Variable)),
    freeList(ListTail).
    
    
%%memberOfList(X, List), return true if X is a member of List.
memberOfList(_, []):- fail, !.

memberOfList(X, [X|_]):- !.

memberOfList(X, [_|ListTail]):-
    memberOfList(X, ListTail).

%% memberOfMessageSet(Message, MessageList)

memberOfMessageSet(_, []):- fail, !.

memberOfMessageSet(Message, MessageList):-
    Message= [Type, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value, EventTemp],
    MessageList= [Message1|_],
    Message1= [Type, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value1, EventTemp],
    copyList(Value, Value0),
    copyList(Value1, Value10),
    Value0= Value10,
    !.
 
memberOfMessageSet(Message, MessageList):-
    MessageList= [_|MessageListTail],
    memberOfMessageSet(Message, MessageListTail).



%% memberOfMessageSet2(Message, MessageList)

memberOfMessageSet2(_, []):- fail, !.

memberOfMessageSet2(Message, MessageList):-
    Message= [Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value, EventTemp],
    MessageList= [Message1|_],
    Message1= [Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval, Value1, EventTemp],
    copyList(Value, Value0),
    copyList(Value1, Value10),
    Value0= Value10,
    !.
 
memberOfMessageSet2(Message, MessageList):-
    MessageList= [_|MessageListTail],
    memberOfMessageSet2(Message, MessageListTail).


%% notLocalOperation(Operation): declare the nonLocal Operation
notLocalOperation(asend):-!.
notLocalOperation(arecv):-!.
notLocalOperation(end):-!.

%% getNextElement(List, X, Y), get the next element of X 
%%     for example, getNextElement([1,2,3],1, 2). or getNextElement([1,2,3],2, 3)
getNextElement([_], _, _) :- print("get Next Element error\n"), abort, !.

getNextElement([X, Y|_], X, Y) :- !.

getNextElement([_, Z|ListTail], X, Y) :- 
    getNextElement([Z|ListTail], X, Y).
    

%% getListofInstance(InstancePropertyList, Instance, PropertyList)
%%  getListofInstance([[a, [1,2]], [b, [3,4]]...], b, [3,4])

getListofInstance([], _, _):- print("getListOfInstance error\n"), abort, !.

getListofInstance([[Instance, PropertyList]|_], Instance, PropertyList):- !.

getListofInstance([_|InstancePropertyListTail], Instance, PropertyList):-
    getListofInstance(InstancePropertyListTail, Instance, PropertyList).
    
    
%% debugPrint(Name, Value)

debugPrint(Name, Value):-
    print(Name), print(":"), print(Value), print("\n").
    
debugPrintList(Name, Value):-
    print(Name), print(":"), print_list(Value), print("\n").


%% outputCharts(Charts)

outputCharts([]):- !.

outputCharts([Chart|ChartsTail]):-
    Chart= [ChartName, _, _, ChartSymblicInstanceList, ChartVarList, Cut],
    print("-------------------------------------\n"),
    debugPrint("ChartName", ChartName),
    debugPrint("ChartSymblicInstanceList", ChartSymblicInstanceList),
    debugPrint("ChartVarList", ChartVarList),
    debugPrint("Cut", Cut),
    outputCharts(ChartsTail).
    
%% getNewInstanceVarList(InstanceVarList, NewInstanceVarList, Instance, NewVarList)

getNewInstanceVarList([], [], _, _):- !.

getNewInstanceVarList(InstanceVarList, NewInstanceVarList, Instance, NewVarList):-
    InstanceVarList=[[Instance, _]|InstanceVarListTail],
    NewInstanceVarList= [[Instance, NewVarList]|InstanceVarListTail],
    !.
    
getNewInstanceVarList(InstanceVarList, NewInstanceVarList, Instance, NewVarList):-
    InstanceVarList=[X|InstanceVarListTail],
    NewInstanceVarList= [X|NewInstanceVarListTail],
    getNewInstanceVarList(InstanceVarListTail, NewInstanceVarListTail, Instance, NewVarList).




%% initMainTimes(InstanceList, InstanceList, Times, NewTimes)

initMainTimes([], _, _, []):- !.

initMainTimes([Instance|InstanceListTail], InstanceList, Times, [[Instance, [LogicalTime, TimeConstraints]]|NewTimesTail]):-
    initInstanceTime(Instance, InstanceList, LogicalTime),
    ( memberOfList([Instance, _], Times) ->
          getListofInstance(Times, Instance, [_, TimeConstraints1]),
          ( TimeConstraints1 \= [] ->
                TimeConstraints1=[[_, Time]|_],
                TimeConstraints=[[LogicalTime, Time]]
                ;
                TimeConstraints=[]
          )
          ;
          TimeConstraints=[]
    ),
    initMainTimes(InstanceListTail, InstanceList, Times, NewTimesTail).

    
%% initTimes(InstanceList, InstanceList, Times)
%%   here we use the logical vector time, so that we can find partial order later

initTimes([], _, []):- !.

initTimes([Instance|InstanceListTail], InstanceList, [[Instance, [LogicalTime, []]]|TimesTail]):-
    initInstanceTime(Instance, InstanceList, LogicalTime),
    initTimes(InstanceListTail, InstanceList, TimesTail).



 
initInstanceTime(_, [], []):- !.
   
initInstanceTime(Instance1, [Instance2|InstanceListTail], [[Instance2, Time]|LogicalTimeTail]):-
    ( Instance1 = Instance2 ->
          Time= 1
          ;
          Time= 0
    ),
    initInstanceTime(Instance1, InstanceListTail, LogicalTimeTail).


   
updateTimes(Times1, Times2, NewTimes):-
    updateList(Times1, Times2, NewTimes).
    


%% updateLogicalTime(Instance, Times, NewTimes)
%%  this update logical time when there is a send event

updateLogicalTime(_, [], []):- !.

updateLogicalTime(Instance, Times, NewTimes):-
    Times=[ [Instance, [LogicalTime,TimeConstraints]]|TimesTail],
    !,
    getNewLogicalTime(Instance, LogicalTime, NewLogicalTime),
    NewTimes= [ [Instance, [NewLogicalTime,TimeConstraints]]|NewTimesTail],
    updateLogicalTime(Instance, TimesTail, NewTimesTail).

    
updateLogicalTime(Instance, Times, NewTimes):-
    Times=[ X|TimesTail],
    NewTimes= [ X|NewTimesTail],
    updateLogicalTime(Instance, TimesTail, NewTimesTail).


getNewLogicalTime(_, [], []):- !.

getNewLogicalTime(Instance, [[Instance, Time]|LogicalTimeTail], [[Instance, NewTime]|NewLogicalTimeTail]):-
    !,
    NewTime is Time+1,
    getNewLogicalTime(Instance, LogicalTimeTail, NewLogicalTimeTail).
    
getNewLogicalTime(Instance, [[Instance1, Time]|LogicalTimeTail], [[Instance1, Time]|NewLogicalTimeTail]):-    
    getNewLogicalTime(Instance, LogicalTimeTail, NewLogicalTimeTail).
    
%% updateLogicalTime2(Receiver, SendTime, Times, NewTimes):-
%%   this updates logical time when there is a receive event

updateLogicalTime2(_, _, [], []):- !.

updateLogicalTime2(Receiver, SendTime, Times, NewTimes):-
    Times=[ [Receiver, [LogicalTime, TimeConstraints]]|TimesTail],
    !,
    getNewLogicalTime2(SendTime, LogicalTime, NewLogicalTime),
    NewTimes= [ [Receiver, [NewLogicalTime, TimeConstraints]]|NewTimesTail],
    updateLogicalTime2(Receiver, SendTime, TimesTail, NewTimesTail).
    

updateLogicalTime2(Receiver, SendTime, Times, NewTimes):-
    Times=[ X| TimesTail],
    NewTimes= [ X| NewTimesTail],
    updateLogicalTime2(Receiver, SendTime, TimesTail, NewTimesTail).


%% 

getNewLogicalTime2([], [], []):- !.

getNewLogicalTime2([[Instance, Time1]|LogicalTime1], [[Instance, Time2]|LogicalTime2], [[Instance, NewTime]|NewLogicalTime]):-
    ( Time1> Time2 ->
          NewTime= Time1
          ;
          NewTime= Time2
    ),
    getNewLogicalTime2(LogicalTime1, LogicalTime2, NewLogicalTime).


%% getCausalTimeConstaints(InstanceList, CurrentLogicalTime, Times, CausalTimeConstraints)


getCausalTimeConstaints(_, _, [], []):- !.

getCausalTimeConstaints(InstanceList, CurrentLogicalTime, Times, CausalTimeConstraints):-
    Times= [[_, [_, TimeConstraints]]|TimesTail],
    getLastCausal(CurrentLogicalTime, TimeConstraints, LastTimeConstraint),
    ( LastTimeConstraint= [] ->
          CausalTimeConstraints= CausalTimeConstraintsTail
          ;
          CausalTimeConstraints= [LastTimeConstraint|CausalTimeConstraintsTail]
    ),
    getCausalTimeConstaints(InstanceList, CurrentLogicalTime, TimesTail, CausalTimeConstraintsTail).



%% getLastCausal(CurrentLogicalTime, TimeConstraints, LastTimeConstraint)

getLastCausal(_, [], []):- !.

getLastCausal(CurrentLogicalTime, TimeConstraints, LastTimeConstraint):-
    TimeConstraints= [[LogicalTime, TimeConstraint]|TimeConstraintsTail],
    ( happenBefore(LogicalTime, CurrentLogicalTime) ->
          LastTimeConstraint= [LogicalTime, TimeConstraint]
          ;
          getLastCausal(CurrentLogicalTime, TimeConstraintsTail, LastTimeConstraint)
    ).



%% happenBefore(LogicalTime1, LogicalTime2) 

happenBefore(LogicalTime1, LogicalTime2):-
    checkHappenBefore1(LogicalTime1, LogicalTime2),
    checkHappenBefore2(LogicalTime1, LogicalTime2).


checkHappenBefore1([], []):- !.

checkHappenBefore1([[Instance, Time1]|LogicalTime1Tail], [[Instance, Time2]|LogicalTime2Tail]):-
    Time1=<Time2,
    checkHappenBefore1(LogicalTime1Tail, LogicalTime2Tail).


checkHappenBefore2([], []):- fail, !.

checkHappenBefore2([[Instance, Time1]|LogicalTime1Tail], [[Instance, Time2]|LogicalTime2Tail]):-
    ( Time1<Time2->
          true
          ;
          checkHappenBefore2(LogicalTime1Tail, LogicalTime2Tail)
    ).


%% increaseLogicalTimes(InstanceList, Times, NewTimes)

increaseLogicalTimes(_, [], []):- !.


increaseLogicalTimes(InstanceList, [[Instance, [LogicalTime, TimeConstraints]]|TimesTail], [[Instance, [NewLogicalTime, TimeConstraints]]|NewTimesTail]):-
    ( memberOfList(Instance, InstanceList) ->
          increaseLogicalTime(InstanceList, LogicalTime, NewLogicalTime)
          ;
          NewLogicalTime= LogicalTime
    ),
    increaseLogicalTimes(InstanceList, TimesTail, NewTimesTail).
    

increaseLogicalTime(_, [], []):- !.

increaseLogicalTime(InstanceList, [[Instance, Time]|LogicalTimeTail], [[Instance, NewTime]|NewLogicalTimeTail]):-
    ( memberOfList(Instance, InstanceList) ->
          NewTime is Time +1
          ;
          NewTime is Time
    ),
    increaseLogicalTime(InstanceList, LogicalTimeTail, NewLogicalTimeTail).


%% introduceCausalTimeConstaints( NewTime, MinimalTimeConstaints)

introduceCausalTimeConstaints( NewTime, [], empty):- NewTime #>=0, !.

introduceCausalTimeConstaints( _, [], _):- !.

introduceCausalTimeConstaints( NewTime, [[_, Time]|MinimalTimeConstaintsTail], _):-
    NewTime #>= Time,
    introduceCausalTimeConstaints( NewTime, MinimalTimeConstaintsTail, nonempty).
    
    
%% insertNewTimeConstaints(InstanceList, NewTime, Times1, Times2)

insertNewTimeConstaints(_, _, [], []):- !.

insertNewTimeConstaints(InstanceList, NewTime, [[Instance, [LogicalTime, TimeConstraints]]|TimesTail], [[Instance, [LogicalTime, NewTimeConstraints]]|NewTimesTail]):-
    ( memberOfList(Instance, InstanceList)->
          NewTimeConstraints= [[LogicalTime, NewTime]|TimeConstraints]
          ;
          NewTimeConstraints= TimeConstraints
    ),
    insertNewTimeConstaints(InstanceList, NewTime, TimesTail, NewTimesTail).
     
%% outputTrace(Trace),

outputTrace([]):- !.

outputTrace([Event|TraceTail]):-
    Event= [assignment|_],
    !,
    print(Event),
    print("\n"),
    outputTrace(TraceTail).
    
outputTrace([Event|TraceTail]):-
    Event= [condition|_],
    !,
    print(Event),
    print("\n"),
    outputTrace(TraceTail).

outputTrace([Event|TraceTail]):-
    Event= [bind|_],
    !,
    print(Event),
    print("\n"),
    outputTrace(TraceTail).
    
outputTrace([Event|TraceTail]):-
    Event= [time|_],
    !,
    print(Event),
    print("\n"),
    outputTrace(TraceTail).

outputTrace([Event|TraceTail]):-
    Event= [Type, Sender, SenderIntervalList, Receiver, RecvIntervalList, Value|_],
    print("["),
    print(Type),
    print(","),
    print(Sender),
    print(","),
    ( SenderIntervalList= [[0,0]] ->
          print("[]")
          ;
          print(SenderIntervalList)
    ),
    print(","),
    print(Receiver),
    print(","),
    ( RecvIntervalList= [[0,0]] ->
          print("[]")
          ;
          print(RecvIntervalList)
    ),
    print(","),
    print(Value),
    print("]\n"),
    outputTrace(TraceTail).


%% getMinimalTimeConstaints(CausalTimeConstaints, CausalTimeConstaints, MinimalTimeConstaints)

getMinimalTimeConstaints([], _, []):- !.

getMinimalTimeConstaints([TimeConstaints|CausalTimeConstaintsTail], CausalTimeConstaints, MinimalTimeConstaints):-
    ( minimalTimeConstaint( TimeConstaints, CausalTimeConstaints) ->
          MinimalTimeConstaints= [TimeConstaints|MinimalTimeConstaintsTail]
          ;
          MinimalTimeConstaints= MinimalTimeConstaintsTail
    ),
    getMinimalTimeConstaints(CausalTimeConstaintsTail, CausalTimeConstaints, MinimalTimeConstaintsTail).
    

%% minimalTimeConstaint( TimeConstaints, CausalTimeConstaints)

minimalTimeConstaint( _, []):- !.

minimalTimeConstaint( [LogicalTime, _], [[OtherLogicalTime|_]|CausalTimeConstaintsTail]):-
    ( happenBefore(OtherLogicalTime, LogicalTime) ->
          fail
          ;
          minimalTimeConstaint( [LogicalTime, _], CausalTimeConstaintsTail)
    ).


%% synchronizeLogicalTime(InstanceList, Times, Times, NewTimes)

synchronizeLogicalTime(InstanceList, Times, NewTimes):-
    getMaxLogicalTime(InstanceList, Times, Times, MaxLogicaiTime),
    updateLogicalTimes(InstanceList, Times, Times, MaxLogicaiTime, NewTimes).


%% getMaxLogicalTime(InstanceList, InstanceList, Times, MaxTimes)

getMaxLogicalTime(_, [], _, []):- !.

getMaxLogicalTime(InstanceList, [[Instance|_]|TimesTail], Times, [[Instance, MaxLogicalTime]|MaxLogicalTimeTail]):-
    getMax(Instance, InstanceList, Times, 0, MaxLogicalTime),
    getMaxLogicalTime(InstanceList, TimesTail, Times, MaxLogicalTimeTail).
    

getMax(_, [], _, Last, Last):- !.

getMax(Instance, [Instance1|InstanceListTail], Times, Last, MaxTime):-
    getListofInstance(Times, Instance1, [LogicalTime|_]),
    getListofInstance(LogicalTime, Instance, Time),
    ( Time> Last ->
          MaxTime1= Time
          ;
          MaxTime1= Last
    ),
    getMax(Instance, InstanceListTail, Times, MaxTime1, MaxTime).


%%  updateLogicalTimes(InstanceList, Times, Times, MaxLogicaiTime, NewTimes)

updateLogicalTimes(_, [], _, _, []) :- !.

updateLogicalTimes(InstanceList, [[Instance, LogicalTime]|TimesTail], Times, MaxLogicaiTime, [[Instance, NewLogicalTime]|NewTimesTail]):-
    ( memberOfList(Instance, InstanceList)->
          LogicalTime= [_, TimeConstraints],
          NewLogicalTime= [ MaxLogicaiTime, TimeConstraints]
          ;
          NewLogicalTime= LogicalTime
    ),
    updateLogicalTimes(InstanceList, TimesTail, Times, MaxLogicaiTime, NewTimesTail).
    

%% updateList(List1, List2, NewList)
%%   each list is [[instance, value]....]
%%   if all instance in List1 should be in NewList
%%   if this instance also occures in List2, use the value in List2

updateList([], _, []):- !.

updateList([[Instance, Value1]|List1Tail], List2, [[Instance, NewValue]|NewListTail]):-
    ( ifExistInList(Instance, List2, Value2)->
          NewValue= Value2
          ;
          NewValue= Value1
    ),
    updateList(List1Tail, List2, NewListTail).
    
    
%% getTimeofInstance(List, Instance, Time)

getTimeofInstance(List, Instance, Time):-
    getListofInstance(List, Instance, Time).
    
getMessangeTime(TriggeredTime,Message, SendTime):-
    getListofInstance(TriggeredTime,Message, SendTime).
    
    
%% ifExistInList(_, [], _)
%%    ifExistInList([[a, 1]...], a, 1).

ifExistInList(_, [], _):- !, fail.

ifExistInList(Instance, [[Instance, GotoTarget]|_], GotoTarget) :- !.

ifExistInList(Instance, [_|GotoLocationListTail], GotoTarget):-
    ifExistInList(Instance, GotoLocationListTail, GotoTarget).    
    
    
%% minusIntervalLists(IntervalLaist1, IntervalList2, ResultIntervalList)
%%     ResultIntervalList contain intervals in both IntervalList1 and IntervalList2


minusIntervalLists([], _, []):- !.

minusIntervalLists(IntervalList1, IntervalList2, ResultIntervalList):-
    IntervalList1= [Interval|IntervalList1Tail],
    minusIntervalLists(IntervalList1Tail, IntervalList2, ResultIntervalList1),
    minusIntervals(Interval, IntervalList2, ResultIntervalList2),
    append(ResultIntervalList2, ResultIntervalList1, ResultIntervalList).


minusIntervals(_, [], []):- !.


minusIntervals(Interval1, [Interval2|IntervalListTail], ResultIntervalList):-
    minusInterval(Interval1, Interval2, ResultIntervalList1, _),
    minusIntervals(Interval1, IntervalListTail, ResultIntervalList2),
    append(ResultIntervalList1, ResultIntervalList2, ResultIntervalList).
    

minusInterval([X1, X1], [X2, X2], ResultIntervalList, RemainIntervalList):-
    !,
    ( X1 = X2 ->
          ResultIntervalList=[[X1, X1]],
          RemainIntervalList=[]
          ;
          ResultIntervalList=[],
          RemainIntervalList=[[X1, X1]]
    ).
    
minusInterval([X1, X1], [X2, Y2], ResultIntervalList, RemainIntervalList):-
    !,
    ( X1 < X2 ->
          ResultIntervalList=[],
          RemainIntervalList=[[X1, X1]]
          ;
          ( X1>Y2 ->
                ResultIntervalList=[],
                RemainIntervalList=[[X1, X1]]
                ;                
                ResultIntervalList=[[X1, X1]],
                RemainIntervalList=[]
          )
    ).


minusInterval([X1, Y1], [X2, X2], ResultIntervalList, RemainIntervalList):-
    !,
    ( X2<X1 ->
          ResultIntervalList=[],
          RemainIntervalList=[[X1, Y1]]
          ;
          ( X2>Y1 ->
                ResultIntervalList=[],
                RemainIntervalList=[[X1, Y1]]
                ;
                ( X2=X1 ->
                      ResultIntervalList=[[X2, X2]],
                      N is X2+1,
                      RemainIntervalList=[[N, Y1]]
                      ;
                      ( X2=Y1-> 
                            ResultIntervalList=[[X2, X2]],
                            N is X2-1,
                            RemainIntervalList=[[X1, N]]
                            ;
                            ResultIntervalList=[[X2, X2]],
                            N1 is X2-1,
                            N2 is X2+1,
                            RemainIntervalList=[[X1, N1], [N2, Y1]]
                      )
                )
           )
     ).
        

minusInterval([X1, Y1], [X2, Y2], ResultIntervalList, RemainIntervalList):-
    !,
    ( X2>Y1 ->
          ResultIntervalList=[],
          RemainIntervalList=[[X1, Y1]]
          ;
          ( X2=Y1 ->
                ResultIntervalList=[[X2,X2]],
                N is Y1-1,
                RemainIntervalList=[[X1, N]]
                ;
                ( X2>X1 ->
                      ( Y2>=Y1 ->
                            ResultIntervalList=[[X2,Y1]],
                            N is X2-1,
                            RemainIntervalList=[[X1, N]]
                            ;
                            ResultIntervalList=[[X2,Y2]],
                            N1 is X2-1,
                            N2 is Y2+1,
                            RemainIntervalList=[[X1, N1], [N2,Y1]]
                       )
                       ;
                       ( X2=X1->
                             ( Y2>=Y1 ->
                                   ResultIntervalList=[[X2,Y1]],
                                   RemainIntervalList=[]
                                   ;
                                   ResultIntervalList=[[X2,Y2]],
                                   N is Y2+1,
                                   RemainIntervalList=[[N,Y1]]
                             )
                             ;
                             ( Y2>=Y1 ->
                                   ResultIntervalList=[[X1,Y1]],
                                   RemainIntervalList=[]
                                   ;
                                   ( Y2>=X1 ->
                                         ResultIntervalList=[[X1,Y2]],
                                         N is Y2+1,
                                         RemainIntervalList=[[N,Y1]]
                                         ;
                                         ResultIntervalList=[],
                                         RemainIntervalList=[[X1,Y1]]
                                   )
                             )
                       )
                 )
          )
    ).    


minusInterval([X], [X2, X2], ResultIntervalList, RemainIntervalList):-
    !,
    ( X>X2 ->
          ResultIntervalList=[],
          RemainIntervalList= [[X]]
          ;
          ( X=X2->
              ResultIntervalList=[[X2, X2]],
              N is X2+1,
              RemainIntervalList= [[N]]
              ;
              ResultIntervalList=[[X2, X2]],
              N1 is X2-1,
              N2 is X2+1,
              RemainIntervalList= [[X, N1], [N2]]
          )
    ).

%% X2<Y2
minusInterval([X], [X2, Y2], ResultIntervalList, RemainIntervalList):-
    !,
    ( X>Y2 ->
          ResultIntervalList=[],
          RemainIntervalList= [[X]]
          ;
          ( X=Y2 ->
                ResultIntervalList=[[Y2, Y2]],
                N is Y2+1,
                RemainIntervalList= [[N]]
                ;
                ( X>=X2 ->
                      ResultIntervalList=[[X, Y2]],
                      N is Y2+1,
                      RemainIntervalList= [[N]]
                      ;
                      ResultIntervalList=[[X2, Y2]],
                      N1 is X2-1,
                      N2 is Y2+1,
                      RemainIntervalList= [[X, N1], [N2]]
                )
          )
    ).


minusInterval([X1, X1], [X], ResultIntervalList, RemainIntervalList):-
    !,
    ( X>X1 ->
          ResultIntervalList=[],
          RemainIntervalList= [[X1, X1]]
          ;         
          ResultIntervalList=[[X1, X1]],
          RemainIntervalList= []   
    ).

%% X1<Y1    
minusInterval([X1, Y1], [X], ResultIntervalList, RemainIntervalList):-
    !,
    ( X>Y1 ->
          ResultIntervalList=[],
          RemainIntervalList= [[X1, Y1]]
          ;
          ( X=Y1 ->
                ResultIntervalList=[[Y1, Y1]],
                N is Y1-1,
                RemainIntervalList=[[X1, N]]
                ;
                ( X>X1 ->
                      ResultIntervalList=[[X, Y1]],
                      N is X-1,
                      RemainIntervalList=[[X1, N]]
                      ;
                      ResultIntervalList=[[X1, Y1]],
                      RemainIntervalList=[]
                )
          )
    ).

minusInterval([X1], [X2], ResultIntervalList, RemainIntervalList):-    
    ( X1=X2 ->
        ResultIntervalList=[[X1]],
        RemainIntervalList= []
        ;
        ( X1>X2 ->
              ResultIntervalList=[[X1]],
              RemainIntervalList= []
              ;
              % X1<X2
              ResultIntervalList=[[X2]],
              N is X2-1,
              RemainIntervalList= [[X1, N]]
        )
     ).
     
     
     
%% enumerateIntervalList(IntervalList, List):-
%%    enumerateIntervalList([[2,5]], [2,3,4,5])
%%    for [x], we enumerate [x, x+1, .., x+10])



enumerateIntervalList([], []):- !.

enumerateIntervalList([Interval|IntervalListTail], List):-
    enumerateInterval(Interval, List1),
    enumerateIntervalList(IntervalListTail, List2),
    append(List1, List2, List).
    

enumerateInterval([X], List):-
    !,
    N is X+5,
    enumerateInterval([X,N], List).


enumerateInterval([X,X], [X]):-  !.
 
    
enumerateInterval([X,Y], [X|ListTail]):-
    N is X+1,
    enumerateInterval([N,Y], ListTail).


%% removeIntervalList(IntervalList1, IntervalList2, ResultIntervalList)
%%    remove item which in both IntervalList1 and IntervalList2 from IntervalList1

removeIntervalList([], _, []):- !.

removeIntervalList(List, [], List):- !.

removeIntervalList(IntervalList1, IntervalList2, ResultIntervalList):-
    IntervalList1=[Interval|IntervalList1Tail],
    removeIntervals(Interval, IntervalList2, ResultIntervalList1),
    removeIntervalList(IntervalList1Tail, IntervalList2, ResultIntervalList2),
    append(ResultIntervalList1, ResultIntervalList2, ResultIntervalList).
    

removeIntervals(Interval1, [], [Interval1]):- !.

removeIntervals(Interval1, [Interval2|IntervalList2Tail], ResultIntervalList):-
    minusInterval(Interval1, Interval2, _, ResultIntervalList1),
    removeIntervalList(ResultIntervalList1, IntervalList2Tail, ResultIntervalList).
    
    
%% getMinimalInstance(IntervalList, OldIntervalList)
%%     getMinimalInstance([[4,4]], [[4,6],[8,10]]).

getMinimalInstance([[X,X]], [[X,_]|_]) :- !.

getMinimalInstance([[X,X]], [[X]|_]) :- !.    

%% notEmpty(SymbolicInstanceList)
%%   check if all symbolic instances are NULL interval

notEmpty([]):- !.

notEmpty([[_, []]|SymbolicInstanceListTail]):-
    notEmpty(SymbolicInstanceListTail).


%% getListofInstance2(InstancePropertyList, Instance, PropertyList)
%%  getListofInstance2([[a, [1,2]], [b, [3,4]]...], b, [3,4])
%%  this is different with getListofInstance in that: here the Instance 
%%     may not exists in InstancePropertyList, and will not report any error

getListofInstance2([], _, _):- !.

getListofInstance2([[Instance, PropertyList]|_], Instance, PropertyList):- !.

getListofInstance2([_|InstancePropertyListTail], Instance, PropertyList):-
    getListofInstance2(InstancePropertyListTail, Instance, PropertyList).
    

%% getNewChartSymbolicInstanceList(ChartSymbolicInstanceList, EventConstraints, NewChartSymbolicInstanceList1, NewChartSymbolicInstanceList2)

%getNewChartSymbolicInstanceList([], _, [], []):- !.

%getNewChartSymbolicInstanceList(ChartSymbolicInstanceList, EventConstraints, NewChartSymbolicInstanceList1, NewChartSymbolicInstanceList2):-
%    ChartSymbolicInstanceList=[[Instance, Interval]|ChartSymbolicInstanceListTail],
%    NewChartSymbolicInstanceList1=[[Instance, Interval1]|NewChartSymbolicInstanceListTail1],
%    NewChartSymbolicInstanceList2=[[Instance, Interval2]|NewChartSymbolicInstanceListTail2],
%    ( getListofInstance2(EventConstraints, Instance, Constraint) ->
%          minusIntervalLists(Interval, Constraint, Interval1),
%          removeIntervalList(Interval, Constraint, Interval2)
%          ;
%          Interval1= Interval,
%          Interval2= []
%    ).
    
%%  updateSymbolicInstanceList(ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval)
%%      change sender and receiver's inverval ChartSymbolicInstanceList

 
updateSymbolicInstanceList([], [], _, _, _, _):- !.

updateSymbolicInstanceList([[Sender, _]|ChartSymbolicInstanceListTail], [[Sender, EnabledSenderInterval]|NewChartSymbolicInstanceListTail], Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval):-
    !,
    updateSymbolicInstanceList(ChartSymbolicInstanceListTail, NewChartSymbolicInstanceListTail, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval).
    
updateSymbolicInstanceList([[Receiver, _]|ChartSymbolicInstanceListTail], [[Receiver, EnabledReceiverInterval]|NewChartSymbolicInstanceListTail], Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval):-
    !,
    updateSymbolicInstanceList(ChartSymbolicInstanceListTail, NewChartSymbolicInstanceListTail, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval).


updateSymbolicInstanceList([[Instance, Interval]|ChartSymbolicInstanceListTail], [[Instance, Interval]|NewChartSymbolicInstanceListTail], Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval):-
    updateSymbolicInstanceList(ChartSymbolicInstanceListTail, NewChartSymbolicInstanceListTail, Sender, EnabledSenderInterval, Receiver, EnabledReceiverInterval).


%%  updateSymbolicInstanceList(ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Instance, IntervalList)
%%      change Instance's inverval ChartSymbolicInstanceList

updateSymbolicInstanceList([], [], _, _):- print("cannot find instance, error\n"), abort, !.

updateSymbolicInstanceList(ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Instance, IntervalList):-
   ChartSymbolicInstanceList= [[Instance, _]|ChartSymbolicInstanceListTail],
   NewChartSymbolicInstanceList= [[Instance, IntervalList]|ChartSymbolicInstanceListTail],
   !.


updateSymbolicInstanceList(ChartSymbolicInstanceList, NewChartSymbolicInstanceList, Instance, IntervalList):-
   ChartSymbolicInstanceList= [X|ChartSymbolicInstanceListTail],
   NewChartSymbolicInstanceList= [X|NewChartSymbolicInstanceListTail],
   updateSymbolicInstanceList(ChartSymbolicInstanceListTail, NewChartSymbolicInstanceListTail, Instance, IntervalList).


%% copyTimes(Times, NewTimes)

copyTimes([], []):- !.

copyTimes([[Instance, Time]|OtherTimes], [[Instance, NewTime]|OtherNewTimes]):-
    NewTime #>= Time,
    copyTimes(OtherTimes, OtherNewTimes).


%% copyTriggeredTime(TriggeredTime, NewTriggeredTime)
copyTriggeredTime(TriggeredTime, NewTriggeredTime):- 
    TriggeredTime= NewTriggeredTime.
    
    
%% noNullAppend(List1, List2, ReslultList)
    
noNullAppend(List1, List2, ResultList):-
    ( List1= [] ->
          ResultList= List2
          ;
          append(List1, List2, ResultList)
    ).
    
    
%% noVarInInterval(Interval)
%%    all interval are concrete, contains no un-instantiated variables

noVarInInterval([]):- !.

noVarInInterval([[X, Y]|IntervalTail]):-
    not(var(X)),
    not(var(Y)),
    noVarInInterval(IntervalTail).
    
noVarInInterval([[X]|IntervalTail]):-
    not(var(X)),
    noVarInInterval(IntervalTail).
    
    
%% getInstanceVarList(InstanceVarList, X, VarList)

getInstanceVarList([], _, _):- print("getInstanceVarList error. interval not exist\n"), abort, !, false.

getInstanceVarList(InstanceVarList, X, VarList):-
    InstanceVarList= [[X, VarList]|_],
    !.
    
getInstanceVarList([_|InstanceVarListTail], X, VarList):-
    getInstanceVarList(InstanceVarListTail, X, VarList).
    
    
%% containInterVal(Interval1, InterVal)

containInterVal([], _):- fail.

containInterVal(Interval1, InterVal):-
    Interval1= [[X1, Y1]|_],
    InterVal=[X, Y],
    X1=<X,
    Y1>=Y,
    !.

containInterVal(Interval1, InterVal):-
    Interval1= [[X1]|_],
    InterVal=[X, _],
    X1=<X.
   
containInterVal([_|IntervalTail], Interval):-
    containInterVal(IntervalTail, Interval).


%%  beginOfChart(InstanceLocationList, LocationList)

beginOfChart(_, []):- !.

beginOfChart(InstanceLocationList, LocationList):-
    LocationList=[[Instance, Location]|LocationListTail],
    getListofInstance(InstanceLocationList, Instance, Locations),
    Locations=[Location|_],
    beginOfChart(InstanceLocationList, LocationListTail).
    

%%  getMax(Numbers, MaxLiveCopiesNum, MaxStepsNum)

getMax([[X, Y]], X, Y):- !.

getMax([[LiveCopiesNum, SetpsNum]|NumbersTail], MaxLiveCopiesNum, MaxStepsNum):-
    getMax(NumbersTail, MaxLiveCopiesNum1, MaxStepsNum1),
    
    ( LiveCopiesNum> MaxLiveCopiesNum1 ->
          MaxLiveCopiesNum= LiveCopiesNum
          ;
          MaxLiveCopiesNum= MaxLiveCopiesNum1
    ),
    
    ( SetpsNum> MaxStepsNum1 ->
          MaxStepsNum= SetpsNum
          ;
          MaxStepsNum= MaxStepsNum1
    ).

    
allsolution:-
    cputime(BeginTime),
    debugPrint("BeginTime", BeginTime),
    findallsolution,        
    cputime(EndTime),
    debugPrint("EndTime", EndTime).
    
    
findallsolution:- begin, fail.
findallsolution:- true.
