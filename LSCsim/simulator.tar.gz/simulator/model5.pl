%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Declaration of LSC Charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% figure 11 on "Multiple Instances and Symbolic Variables in Executable Sequence Charts"
%% this shows that our simulator can process complex LSC charts. This example involves several charts
%%   here we instantiate every object of class phone, because each of them has a unique property. It cannot be symbolic
%%   we change the event Set QResult to an assignment event,
%%   we also add an bind operation to the setInDB chart
 
allInstanceCount(4).

declareInstance(0, user).
declareInstance(1, phone).
declareInstance(2, switch).
declareInstance(3, phoneDB).

initInstance(user, [[0, []]]).

initInstance(phone, InstanceVars):-
    initPhoneVars(InstanceVars, 10).

initInstance(switch, [[0, [0]]]).

initInstance(phoneDB, [[0, [_]]]).   %% [QResult]

initPhoneVars([[1, [1, 4]]], 1):- !.    %%[ID, Display]

initPhoneVars(InstanceVars, X):-
    X2 is X-1,
    initPhoneVars(InstanceVars1, X2),
    X1 is X+4,
    noNullAppend(InstanceVars1, [[X, [X, X1]]], InstanceVars).
    

bindInstanceVars(_).

declareSysVars([]).                    
 

allChartCount(4).


 
declareChart(0, clickSet).
declareChart(1, verifyNumber).
declareChart(2, setInDB).
declareChart(3, ackNumber).

declareChartSymbolicInstances(clickSet, [[user, [[0,0]]], [phone, [[1]]], [switch, [[0,0]]]]).
declareChartSymbolicInstances(verifyNumber, [[phone, [[1]]], [switch, [[0,0]]], [phoneDB, [[0,0]]]]).
declareChartSymbolicInstances(setInDB, [[switch, [[0,0]]], [phoneDB, [[0,0]]], [phone, [[1]]]]).
declareChartSymbolicInstances(ackNumber, [[switch, [[0,0]]], [phone, [[1]]]]).



declarePreChart(clickSet, pre_clickSet).
declarePreChart(verifyNumber, pre_verifyNumber).
declarePreChart(setInDB, pre_setInDB).
declarePreChart(ackNumber, pre_ackNumber).


declareMainChart(clickSet, main_clickSet).
declareMainChart(verifyNumber, main_verifyNumber).
declareMainChart(setInDB, main_setInDB).
declareMainChart(ackNumber, main_ackNumber).


declareChartVars(clickSet, [_, _, _, _]).
declareChartVars(verifyNumber, [_, _, _, _]).
declareChartVars(setInDB, [_, _, _, _]).
declareChartVars(ackNumber, [_, _, _]).


 %%%%% declare events

chartEventCount(pre_clickSet, 3).
chartEventCount(main_clickSet, 5).

chartEventCount(pre_verifyNumber, 3).
chartEventCount(main_verifyNumber, 13).

chartEventCount(pre_setInDB, 3).
chartEventCount(main_setInDB, 11).

chartEventCount(pre_ackNumber, 3).
chartEventCount(main_ackNumber, 5).


declareChartInstances(pre_clickSet, [user, phone]).
declareChartInstances(main_clickSet, [phone, switch]).

declareChartInstances(pre_verifyNumber, [phone, switch]).
declareChartInstances(main_verifyNumber, [phone, switch, phoneDB]).

declareChartInstances(pre_setInDB, [switch, phoneDB]).
declareChartInstances(main_setInDB, [switch, phoneDB, phone]).

declareChartInstances(pre_ackNumber, [switch, phone]).
declareChartInstances(main_ackNumber, [phone]).



declareInstanceLocations(pre_clickSet, user, [0, 2]):- !.
declareInstanceLocations(pre_clickSet, phone, [1, 2]):- !.

declareInstanceLocations(main_clickSet, phone, [0, 1, 2, 4]):- !.
declareInstanceLocations(main_clickSet, switch, [3, 4]):- !.

declareInstanceLocations(pre_verifyNumber, phone, [0, 2]):- !.
declareInstanceLocations(pre_verifyNumber, switch, [1, 2]):- !.

declareInstanceLocations(main_verifyNumber, phone, [1, 5, 6, 9, 10, 11, 12]):- !.
declareInstanceLocations(main_verifyNumber, switch, [1, 3, 5, 6, 8, 10, 11, 12]):- !.
declareInstanceLocations(main_verifyNumber, phoneDB, [0, 1, 2, 4, 5, 6, 7, 10, 11, 12]):- !.

declareInstanceLocations(pre_setInDB, switch, [0, 2]):- !.
declareInstanceLocations(pre_setInDB, phoneDB, [1, 2]):- !.

declareInstanceLocations(main_setInDB, switch, [2, 4, 6, 7, 9, 10]):- !.
declareInstanceLocations(main_setInDB, phoneDB, [1, 2, 3, 6, 9, 10]):- !.
declareInstanceLocations(main_setInDB, phone, [0, 2, 5, 6, 8, 9, 10]):- !.

declareInstanceLocations(pre_ackNumber, switch, [0, 2]):- !.
declareInstanceLocations(pre_ackNumber, phone, [1, 2]):- !.

declareInstanceLocations(main_ackNumber, phone, [0, 1, 2, 3, 4]):- !.


declareChartActivationCondition(clickSet, main_clickSet_ac):- !.
declareChartActivationCondition(verifyNumber, main_verifyNumber_ac):- !.
declareChartActivationCondition(setInDB, main_setInDB_ac):- !.
declareChartActivationCondition(ackNumber, main_ackNumber_ac):- !.


main_clickSet_ac(_, _, _, _).
main_verifyNumber_ac(_, _, _, _).
main_setInDB_ac(_, _, _, _).
main_ackNumber_ac(_, _, _, _).


%% events, for 
declareEvent(pre_clickSet, [0, 1, hot, asend, [user], [[[user, send_const_p0_1], [phone, recv_const_p0_1]], user, phone, asend_p0_1], hot]):- !.
declareEvent(pre_clickSet, [1, 2, hot, arecv, [phone], [[[user, send_const_p0_1], [phone, recv_const_p0_1]], user, phone, arecv_p0_1], hot]):- !.
declareEvent(pre_clickSet, [2, 2, hot, end, [[], user, phone], [], cold]):- !.



declareEvent(main_clickSet, [0, 2, hot, assignment, [phone], [[], assign_m0_1], hot]):- !.
declareEvent(main_clickSet, [1, 2, hot, assignment, [phone], [[], assign_m0_2], hot]):- !.
declareEvent(main_clickSet, [2, 2, hot, asend, [phone], [[[phone, send_const_m0_1], [switch, recv_const_m0_1]], phone, switch, asend_m0_1], hot]):- !.
declareEvent(main_clickSet, [3, 2, hot, arecv, [switch], [[[phone, send_const_m0_1], [switch, recv_const_m0_1]], phone, switch, arecv_m0_1], hot]):- !.
declareEvent(main_clickSet, [4, 2, hot, end, [phone, switch], [[]], cold]):- !.


%% events
declareEvent(pre_verifyNumber, [0, 1, hot, asend, [phone], [[[phone, send_const_p1_1], [switch, recv_const_p1_1]], phone, switch, asend_p1_1], hot]):- !.
declareEvent(pre_verifyNumber, [1, 2, hot, arecv, [switch], [[[phone, send_const_p1_1], [switch, recv_const_p1_1]], phone, switch, arecv_p1_1], hot]):- !.
declareEvent(pre_verifyNumber, [2, 2, hot, end, [[], phone, switch], [], cold]):- !.

%% events
declareEvent(main_verifyNumber, [0, 2, hot, assignment, [phoneDB], [[], assign_m1_1], hot]):- !.
declareEvent(main_verifyNumber, [1, 2, hot, subbegin, [phone, switch, phoneDB], [[]], hot]):- !.
declareEvent(main_verifyNumber, [2, 2, hot, condition, [phoneDB], [[], cond_m1_1, [[[phoneDB, 4]], [[phone, 6], [switch, 6], [phoneDB, 6]]]], cold]):- !.
declareEvent(main_verifyNumber, [3, 2, hot, asend, [switch], [[[switch, send_const_m1_1], [phoneDB, recv_const_m1_1]], switch, phoneDB, asend_m1_1], hot]):- !.
declareEvent(main_verifyNumber, [4, 2, hot, arecv, [phoneDB], [[[switch, send_const_m1_1], [phoneDB, recv_const_m1_1]], switch, phoneDB, arecv_m1_1], hot]):- !.
declareEvent(main_verifyNumber, [5, 2, hot, goto, [phone, switch, phoneDB], [[], [[phone, 11], [switch, 11], [phoneDB, 11]]], hot]):- !.
declareEvent(main_verifyNumber, [6, 2, hot, subbegin, [phone, switch, phoneDB], [[]], hot]):- !.
declareEvent(main_verifyNumber, [7, 2, hot, condition, [phoneDB], [[], cond_m1_2, [[[phoneDB, 10]], [[phone, 10], [switch, 10], [phoneDB, 10]]]], cold]):- !.
declareEvent(main_verifyNumber, [8, 2, hot, asend, [switch], [[[switch, send_const_m1_2], [phone, recv_const_m1_2]], switch, phone, asend_m1_2], hot]):- !.
declareEvent(main_verifyNumber, [9, 2, hot, arecv, [phone], [[[switch, send_const_m1_2], [phone, recv_const_m1_2]], switch, phone, arecv_m1_2], hot]):- !.
declareEvent(main_verifyNumber, [10, 2, hot, subend, [phone, switch, phoneDB], [[]], hot]):- !.
declareEvent(main_verifyNumber, [11, 2, hot, subend, [phone, switch, phoneDB], [[]], hot]):- !.
declareEvent(main_verifyNumber, [12, 2, hot, end, [phone, switch, phoneDB], [[]], cold]):- !.

%% events
declareEvent(pre_setInDB, [0, 1, hot, asend, [switch], [[[switch, send_const_p2_1], [phoneDB, recv_const_p2_1]], switch, phoneDB, asend_p2_1], hot]):- !.
declareEvent(pre_setInDB, [1, 2, hot, arecv, [phoneDB], [[[switch, send_const_p2_1], [phoneDB, recv_const_p2_1]], switch, phoneDB, arecv_p2_1], hot]):- !.
declareEvent(pre_setInDB, [2, 2, hot, end, [[], switch, phoneDB], [], cold]):- !.

%% events
declareEvent(main_setInDB, [0, 2, hot, bind, [phone], [[], bind_m2_1], hot]):- !.
declareEvent(main_setInDB, [1, 2, hot, assignment, [phoneDB], [[], assign_m2_1], hot]):- !.
declareEvent(main_setInDB, [2, 2, hot, subbegin, [switch, phoneDB, phone], [[]], hot]):- !.
declareEvent(main_setInDB, [3, 2, hot, condition, [phoneDB], [[], cond_m2_1, [[[phoneDB, 6]], [[switch, 7], [phoneDB, 9], [phone, 8]]]], cold]):- !.
declareEvent(main_setInDB, [4, 2, hot, asend, [switch], [[[switch, send_const_m2_1], [phone, recv_const_m2_1]], switch, phone, asend_m2_1], hot]):- !.
declareEvent(main_setInDB, [5, 2, hot, arecv, [phone], [[[switch, send_const_m2_1], [phone, recv_const_m2_1]], switch, phone, arecv_m2_1], hot]):- !.
declareEvent(main_setInDB, [6, 2, hot, goto, [switch, phoneDB, phone], [[], [[switch, 9], [phoneDB, 9], [phone, 9]]], hot]):- !.
declareEvent(main_setInDB, [7, 2, hot, asend, [switch], [[[switch, send_const_m2_2], [phone, recv_const_m2_2]], switch, phone, asend_m2_2], hot]):- !.
declareEvent(main_setInDB, [8, 2, hot, arecv, [phone], [[[switch, send_const_m2_2], [phone, recv_const_m2_2]], switch, phone, arecv_m2_2], hot]):- !.
declareEvent(main_setInDB, [9, 2, hot, subend, [switch, phoneDB, phone], [[]], hot]):- !.
declareEvent(main_setInDB, [10, 2, hot, end, [switch, phoneDB, phone], [[]], cold]):- !.


%% events
declareEvent(pre_ackNumber, [0, 1, hot, asend, [switch], [[[switch, send_const_p3_1], [phone, recv_const_p3_1]], switch, phone, asend_p3_1], hot]):- !.
declareEvent(pre_ackNumber, [1, 2, hot, arecv, [phone], [[[switch, send_const_p3_1], [phone, recv_const_p3_1]], switch, phone, arecv_p3_1], hot]):- !.
declareEvent(pre_ackNumber, [2, 2, hot, end, [[], switch, phone], [], cold]):- !.

%% events
declareEvent(main_ackNumber, [0, 2, hot, asend, [phone], [[[phone, send_const_m3_1], [phone, recv_const_m3_1]], phone, phone, asend_m3_1], hot]):- !.
declareEvent(main_ackNumber, [1, 2, hot, arecv, [phone], [[[phone, send_const_m3_1], [phone, recv_const_m3_1]], phone, phone, arecv_m3_1], hot]):- !.
declareEvent(main_ackNumber, [2, 2, hot, asend, [phone], [[[phone, send_const_m3_2], [phone, recv_const_m3_2]], phone, phone, asend_m3_2], hot]):- !.
declareEvent(main_ackNumber, [3, 2, hot, arecv, [phone], [[[phone, send_const_m3_2], [phone, recv_const_m3_2]], phone, phone, arecv_m3_2], hot]):- !.
declareEvent(main_ackNumber, [4, 2, hot, end, [[], phone], [], cold]):- !.





send_const_p0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_p0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_p0_1([click, set], _, _, _, _).
arecv_p0_1([click, set], _, _, _, _).

assign_m0_1(SysVarList, InstanceVarList, ChartVarList, SysVarList, InstanceVarList, NewChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phone, PhoneVarList),
    getListofInstance(ChartSymblicInstanceList, phone, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(PhoneVarList, X, VarList),
    VarList=[ID|_],
    ChartVarList=[Times, TriggeredTime, _|ChartVarListTail],
    NewChartVarList= [Times, TriggeredTime, ID|ChartVarListTail].


assign_m0_2(SysVarList, InstanceVarList, ChartVarList, SysVarList, InstanceVarList, NewChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phone, PhoneVarList),
    getListofInstance(ChartSymblicInstanceList, phone, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(PhoneVarList, X, VarList),
    VarList=[ID, N],
    ChartVarList=[Times, TriggeredTime, ID, _],
    NewChartVarList= [Times, TriggeredTime, ID, N].
    

send_const_m0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m0_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
    
asend_m0_1([setNumber, ID, N], _, _, ChartVarList, _):-
    ChartVarList=[_, _, ID, N].


arecv_m0_1([setNumber, ID, N], _, _, ChartVarList, _):-
    ChartVarList=[_, _, ID, N].


send_const_p1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
recv_const_p1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

asend_p1_1([setNumber, ID, N], _, _, ChartVarList, _):-
    ChartVarList=[_, _, ID, N].

arecv_p1_1([setNumber, ID, N], _, _, ChartVarList, _):-
    ChartVarList=[_, _, ID, N].


assign_m1_1(SysVarList, InstanceVarList, ChartVarList, SysVarList, NewInstanceVarList, ChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[_|VarListTail],
    ChartVarList=[_, _, _, N|_],
    retrieveKey(Result, N),
    NewVarList= [Result|VarListTail],
    updateSymbolicInstanceList(InstanceVars, NewInstanceVars, X, NewVarList),
    updateSymbolicInstanceList(InstanceVarList, NewInstanceVarList, phoneDB, NewInstanceVars).

retrieveKey(_, _).

cond_m1_1(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[QResult|_],
    var(QResult).
    
cond_m1_2(_, InstanceVarList, ChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[QResult|_],
    ChartVarList=[_, _, ID|_],
    QResult =\= ID.
    
    

send_const_m1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m1_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_m1_1([setNumber, ID, N], _, _, ChartVarList, _):-
    ChartVarList=[_, _, ID, N].

arecv_m1_1([setNumber, ID, N], _, _, ChartVarList, _):-
    ChartVarList=[_, _, ID, N].


send_const_m1_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m1_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
        

asend_m1_2([showerror, numberOccupied], _, _, _,_).
    
arecv_m1_2([showerror, numberOccupied], _, _, _,_).


send_const_p2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_p2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_p2_1([setNumber, ID, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, ID, N|_].
    
arecv_p2_1([setNumber, ID, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, ID, N|_].


bind_m2_1(_, _, ChartVarList, ChartSymblicInstanceList, NewChartSymblicInstanceList):-
    ChartVarList=[_, _, ID|_],
    updateSymbolicInstanceList(ChartSymblicInstanceList, NewChartSymblicInstanceList, phone, [[ID, ID]]).
    

assign_m2_1(SysVarList, InstanceVarList, ChartVarList, SysVarList, NewInstanceVarList, ChartVarList, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[_|VarListTail],
    ChartVarList=[_, _, _, _ |_],
    NewVarList= [true|VarListTail],
    updateSymbolicInstanceList(InstanceVars, NewInstanceVars, X, NewVarList),
    updateSymbolicInstanceList(InstanceVarList, NewInstanceVarList, phoneDB, NewInstanceVars).


cond_m2_1(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, phoneDB, InstanceVars),
    getListofInstance(ChartSymblicInstanceList, phoneDB, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(InstanceVars, X, VarList),
    VarList=[true|_].




send_const_m2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
recv_const_m2_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].    



asend_m2_1([ackNumber, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, _, N|_].

arecv_m2_1([ackNumber, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, _, N|_].
    
send_const_m2_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].
    
recv_const_m2_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].    



asend_m2_2([showError, errorInSet], _, _, _, _).

arecv_m2_2([showError, errorInSet], _, _, _, _).



send_const_p3_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_p3_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_p3_1([ackNumber, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, N|_].
    
arecv_p3_1([ackNumber, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, N|_].


send_const_m3_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m3_1(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_m3_1([setNumber, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, N|_].
    
arecv_m3_1([setNumber, N], _, _, ChartVarList, _):- 
    ChartVarList=[_, _, N|_].


send_const_m3_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const_m3_2(_, _, _, _, IntervalList):-
    IntervalList= [[0]].


asend_m3_2([show, display], _, _, _, _).
    
arecv_m3_2([show, display], _, _, _, _).


begin:-
    run([[asend, user, [], phone, [[3, 3]], [click, set], hot], [arecv, user, [], phone, [[3, 3]], [click, set], hot]], _, _).
