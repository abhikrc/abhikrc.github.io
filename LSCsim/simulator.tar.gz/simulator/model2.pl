%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Declaration of LSC Charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% LSC chart in the figure 10 of "LSCs: Breathing Life into Message Sequence Charts"
%%  this shows that our simulator can process complex LSC charts
%%  Please note that the example here is not exactly the same as the picture. 
%%  because we want to execute most parts of the chart to test our simulator, some properties have to be changed during simulation.
%%     for example, after the chart is activated, the car is no longer idle, otherwise multi-copies of the same chart will be generated,
%%     which does not make any sense for this particular example

 
allInstanceCount(7).

declareInstance(0, destPanel).
declareInstance(1, terminal).
declareInstance(2, controlCenter).
declareInstance(3, crulser).
declareInstance(4, car).
declareInstance(5, carHandler).
declareInstance(6, proximitySensor).


initInstance(destPanel, [[0, []]]).

initInstance(terminal, [[0, []]]).

initInstance(controlCenter, [[0, []]]).

initInstance(crulser, [[0, []]]).

initInstance(car, [[0, [idle, departure, cruising, arrival, pass]]]).

initInstance(carHandler, [[0, []]]).

initInstance(proximitySensor, [[0, []]]).

bindInstanceVars(_).

declareSysVars([nonempty]).


                       

allChartCount(1).

 
declareChart(0, carBehavior).


declareChartSymbolicInstances(carBehavior, [[destPanel, [[0, 0]]], [terminal, [[0, 0]]], [controlCenter, [[0, 0]]], [crulser, [[0, 0]]], [car, [[0, 0]]], [carHandler, [[0, 0]]], [proximitySensor, [[0, 0]]]]).


declarePreChart(carBehavior, pre_carBehavior).

declareMainChart(carBehavior, main_carBehavior).

declareChartVars(carBehavior, [_, _, _, _]).


 
chartEventCount(pre_carBehavior, 0).
chartEventCount(main_carBehavior, 64).



declareChartInstances(pre_carBehavior, []).
declareChartInstances(main_carBehavior, [destPanel, terminal, controlCenter, crulser, car, carHandler, proximitySensor]).




declareInstanceLocations(main_carBehavior, destPanel, [0, 1, 2, 11, 63]):- !.
declareInstanceLocations(main_carBehavior, terminal, [0, 3, 4, 11, 29, 32, 33, 62, 63]):- !.
declareInstanceLocations(main_carBehavior, controlCenter, [0, 5, 6, 11, 63]):- !.
declareInstanceLocations(main_carBehavior, crulser, [0, 11, 12, 17, 20, 23, 25, 29, 37, 42, 43, 46, 48, 52, 53, 62, 63]):- !.
declareInstanceLocations(main_carBehavior, car, [0, 1, 7, 8, 9, 10, 11, 12, 13, 14, 16, 19, 21, 22, 24, 25, 26, 28, 29, 30, 31, 36, 37, 38, 40, 41, 43, 44, 45, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 59, 60, 61, 62, 63]):- !.
declareInstanceLocations(main_carBehavior, carHandler, [12, 15, 18, 25, 29, 34, 35, 54, 57, 58, 61, 62, 63]):- !.
declareInstanceLocations(main_carBehavior, proximitySensor, [26, 27, 29, 37, 39, 53, 62, 63]):- !.


declareChartActivationCondition(carBehavior, main_carBehavior_ac).

main_carBehavior_ac(_, InstanceVarList, _, _):- 
    getListofInstance(InstanceVarList, car, CarVarList),
    getInstanceVarList(CarVarList, 0, VarList),
    VarList=[idle|_].



declareEvent(main_carBehavior, [0, 2, hot, subbegin, [destPanel, terminal, controlCenter, crulser, car], [[]], hot]):- !.
declareEvent(main_carBehavior, [1, 2, hot, assignment, [destPanel, car], [[], assign_m0_0], hot]):- !.
declareEvent(main_carBehavior, [2, 2, hot, asend, [destPanel], [[[destPanel, send_const], [terminal, recv_const]], destPanel, terminal, asend_m0_0], hot]):- !.
declareEvent(main_carBehavior, [3, 2, hot, arecv, [terminal], [[[destPanel, send_const], [terminal, recv_const]], destPanel, terminal, arecv_m0_0], hot]):- !.
declareEvent(main_carBehavior, [4, 2, hot, asend, [terminal], [[[terminal, send_const], [controlCenter, recv_const]], terminal, controlCenter, asend_m0_1], hot]):- !.
declareEvent(main_carBehavior, [5, 2, hot, arecv, [controlCenter], [[[terminal, send_const], [controlCenter, recv_const]], terminal, controlCenter, arecv_m0_1], hot]):- !.
declareEvent(main_carBehavior, [6, 2, hot, asend, [controlCenter], [[[controlCenter, send_const], [car, recv_const]], controlCenter, car, asend_m0_2], hot]):- !.
declareEvent(main_carBehavior, [7, 2, hot, arecv, [car], [[[controlCenter, send_const], [car, recv_const]], controlCenter, car, arecv_m0_2], hot]):- !.
declareEvent(main_carBehavior, [8, 2, hot, asend, [car], [[[car, send_const], [car, recv_const]], car, car, asend_m0_3], hot]):- !.
declareEvent(main_carBehavior, [9, 2, hot, arecv, [car], [[[car, send_const], [car, recv_const]], car, car, arecv_m0_3], hot]):- !. 
declareEvent(main_carBehavior, [10, 2, hot, condition, [car], [[], cond_m0_0, []], hot]):- !.  
declareEvent(main_carBehavior, [11, 2, hot, subend, [destPanel, terminal, controlCenter, crulser, car], [[]], hot]):- !.
declareEvent(main_carBehavior, [12, 2, hot, subbegin, [crulser, car, carHandler], [[]], hot]):- !.
declareEvent(main_carBehavior, [13, 2, hot, condition, [car], [[], cond_m0_1, [[[car, 14]], [[crulser, 25], [car, 25], [carHandler, 25]]]], cold]):- !.
declareEvent(main_carBehavior, [14, 2, hot, asend, [car], [[[car, send_const], [carHandler, recv_const]], car, carHandler, asend_m0_4], hot]):- !.
declareEvent(main_carBehavior, [15, 2, hot, arecv, [carHandler], [[[car, send_const], [carHandler, recv_const]], car, carHandler, arecv_m0_4], hot]):- !.
declareEvent(main_carBehavior, [16, 2, hot, asend, [car], [[[car, send_const], [crulser, recv_const]], car, crulser, asend_m0_5], hot]):- !.
declareEvent(main_carBehavior, [17, 2, hot, arecv, [crulser], [[[car, send_const], [crulser, recv_const]], car, crulser, arecv_m0_5], hot]):- !.
declareEvent(main_carBehavior, [18, 2, hot, asend, [carHandler], [[[carHandler, send_const], [car, recv_const]], carHandler, car, asend_m0_6], hot]):- !.
declareEvent(main_carBehavior, [19, 2, hot, arecv, [car], [[[carHandler, send_const], [car, recv_const]], carHandler, car, arecv_m0_6], hot]):- !.
declareEvent(main_carBehavior, [20, 2, hot, asend, [crulser], [[[crulser, send_const], [car, recv_const]], crulser, car, asend_m0_7], hot]):- !.
declareEvent(main_carBehavior, [21, 2, hot, arecv, [car], [[[crulser, send_const], [car, recv_const]], crulser, car, arecv_m0_7], hot]):- !.
declareEvent(main_carBehavior, [22, 2, hot, asend, [car], [[[car, send_const], [crulser, recv_const]], car, crulser, asend_m0_8], hot]):- !.
declareEvent(main_carBehavior, [23, 2, hot, arecv, [crulser], [[[car, send_const], [crulser, recv_const]], car, crulser, arecv_m0_8], hot]):- !.
declareEvent(main_carBehavior, [24, 2, hot, condition, [car], [[], cond_m0_2, []], hot]):- !.
declareEvent(main_carBehavior, [25, 2, hot, subend, [crulser, car, carHandler], [[]], hot]):- !.
declareEvent(main_carBehavior, [26, 2, hot, condition, [car, proximitySensor], [[], cond_m0_3, []], hot]):- !.
declareEvent(main_carBehavior, [27, 2, hot, asend, [proximitySensor], [[[proximitySensor, send_const], [car, recv_const]], proximitySensor, car, asend_m0_9], hot]):- !.
declareEvent(main_carBehavior, [28, 2, hot, arecv, [car], [[[proximitySensor, send_const], [car, recv_const]], proximitySensor, car, arecv_m0_9], hot]):- !.
declareEvent(main_carBehavior, [29, 2, hot, subbegin, [terminal, crulser, car, carHandler, proximitySensor], [[]], hot]):- !.
declareEvent(main_carBehavior, [30, 2, hot, condition, [car], [[], cond_m0_4, [[[car, 31]], [[terminal, 62], [crulser, 62], [car, 62], [carHandler, 62], [proximitySensor, 62]]]], cold]):- !.
declareEvent(main_carBehavior, [31, 2, hot, asend, [car], [[[car, send_const], [terminal, recv_const]], car, terminal, asend_m0_10], hot]):- !.
declareEvent(main_carBehavior, [32, 2, hot, arecv, [terminal], [[[car, send_const], [terminal, recv_const]], car, terminal, arecv_m0_10], hot]):- !.
declareEvent(main_carBehavior, [33, 2, hot, asend, [terminal], [[[terminal, send_const], [carHandler, recv_const]], terminal, carHandler, asend_m0_11], hot]):- !.
declareEvent(main_carBehavior, [34, 2, hot, arecv, [carHandler], [[[terminal, send_const], [carHandler, recv_const]], terminal, carHandler, arecv_m0_11], hot]):- !.
declareEvent(main_carBehavior, [35, 2, hot, asend, [carHandler], [[[carHandler, send_const], [car, recv_const]], carHandler, car, asend_m0_12], hot]):- !.
declareEvent(main_carBehavior, [36, 2, hot, arecv, [car], [[[carHandler, send_const], [car, recv_const]], carHandler, car, arecv_m0_12], hot]):- !.
declareEvent(main_carBehavior, [37, 2, hot, subbegin, [crulser, car, proximitySensor], [[]], hot]):- !.
declareEvent(main_carBehavior, [38, 2, hot, condition, [car], [[], cond_m0_5, [[[car, 40]], [[crulser, 53], [car, 53], [proximitySensor, 53]]]], cold]):- !.
declareEvent(main_carBehavior, [39, 2, hot, asend, [proximitySensor], [[[proximitySensor, send_const], [car, recv_const]], proximitySensor, car, asend_m0_13], hot]):- !.
declareEvent(main_carBehavior, [40, 2, hot, arecv, [car], [[[proximitySensor, send_const], [car, recv_const]], proximitySensor, car, arecv_m0_13], hot]):- !.
declareEvent(main_carBehavior, [41, 2, hot, asend, [car], [[[car, send_const], [crulser, recv_const]], car, crulser, asend_m0_14], hot]):- !.
declareEvent(main_carBehavior, [42, 2, hot, arecv, [crulser], [[[car, send_const], [crulser, recv_const]], car, crulser, arecv_m0_14], hot]):- !.
declareEvent(main_carBehavior, [43, 2, hot, subbegin, [crulser, car], [[]], hot]):- !.
declareEvent(main_carBehavior, [44, 2, hot, condition, [car], [[], cond_m0_6, [[[car, 45]], [[crulser, 52], [car, 49]]]], cold]):- !.
declareEvent(main_carBehavior, [45, 2, hot, asend, [car], [[[car, send_const], [crulser, recv_const]], car, crulser, asend_m0_15], hot]):- !.
declareEvent(main_carBehavior, [46, 2, hot, arecv, [crulser], [[[car, send_const], [crulser, recv_const]], car, crulser, arecv_m0_15], hot]):- !.
declareEvent(main_carBehavior, [47, 2, hot, condition, [car], [[], cond_m0_7, []], hot]):- !.
declareEvent(main_carBehavior, [48, 2, hot, goto, [crulser, car], [[], [[crulser, 52], [car, 52]]], hot]):- !.
declareEvent(main_carBehavior, [49, 2, hot, asend, [car], [[[car, send_const], [car, recv_const]], car, car, asend_m0_16], hot]):- !.
declareEvent(main_carBehavior, [50, 2, hot, arecv, [car], [[[car, send_const], [car, recv_const]], car, car, arecv_m0_16], hot]):- !.
declareEvent(main_carBehavior, [51, 2, hot, condition, [car], [[], cond_m0_8, []], hot]):- !.
declareEvent(main_carBehavior, [52, 2, hot, subend, [crulser, car], [[]], hot]):- !.
declareEvent(main_carBehavior, [53, 2, hot, subend, [crulser, car, proximitySensor], [[]], hot]):- !.
declareEvent(main_carBehavior, [54, 2, hot, subbegin, [car, carHandler], [[]], hot]):- !.
declareEvent(main_carBehavior, [55, 2, hot, condition, [car], [[], cond_m0_9, [[[car, 56]], [[car, 61], [carHandler, 61]]]], cold]):- !.
declareEvent(main_carBehavior, [56, 2, hot, asend, [car], [[[car, send_const], [carHandler, recv_const]], car, carHandler, asend_m0_17], hot]):- !.
declareEvent(main_carBehavior, [57, 2, hot, arecv, [carHandler], [[[car, send_const], [carHandler, recv_const]], car, carHandler, arecv_m0_17], hot]):- !.
declareEvent(main_carBehavior, [58, 2, hot, asend, [carHandler], [[[carHandler, send_const], [car, recv_const]], carHandler, car, asend_m0_18], hot]):- !.
declareEvent(main_carBehavior, [59, 2, hot, arecv, [car], [[[carHandler, send_const], [car, recv_const]], carHandler, car, arecv_m0_18], hot]):- !.
declareEvent(main_carBehavior, [60, 2, hot, condition, [car], [[], cond_m0_10, []], hot]):- !.
declareEvent(main_carBehavior, [61, 2, hot, subend, [car, carHandler], [[]], hot]):- !.
declareEvent(main_carBehavior, [62, 2, hot, subend, [terminal, crulser, car, carHandler, proximitySensor], [[]], hot]):- !.
declareEvent(main_carBehavior, [63, 2, hot, end, [destPanel, terminal, controlCenter, crulser, car, carHandler, proximitySensor], [[]], cold]):- !.
 
 
assign_m0_0(SysVarList, InstanceVarList, ChartVarVarList, SysVarList, NewInstanceVarList, ChartVarVarList, _):-
    getListofInstance(InstanceVarList, car, InstanceVars),
    getInstanceVarList(InstanceVars, 0, VarList),    
    VarList=[_|VarListTail],
    NewVarList= [busy|VarListTail],
    updateSymbolicInstanceList(InstanceVars, NewInstanceVars, 0, NewVarList),
    updateSymbolicInstanceList(InstanceVarList, NewInstanceVarList, car, NewInstanceVars).
    

    
send_const(_, _, _, _, IntervalList):-
    IntervalList= [[0]].

recv_const(_, _, _, _, IntervalList):-
    IntervalList= [[0]].



asend_m0_0([callCar], _, _, _, _).
arecv_m0_0([callCar], _, _, _, _).
asend_m0_1([sendCar], _, _, _, _).
arecv_m0_1([sendCar], _, _, _, _).
asend_m0_2([setDest], _, _, _, _).
arecv_m0_2([setDest], _, _, _, _).
asend_m0_3([tm, 90], _, _, _, _).
arecv_m0_3([tm, 90], _, _, _, _).
asend_m0_4([departReq], _, _, _, _).
arecv_m0_4([departReq], _, _, _, _).
asend_m0_5([start], _, _, _, _).
arecv_m0_5([start], _, _, _, _).
asend_m0_6([departAck], _, _, _, _).
arecv_m0_6([departAck], _, _, _, _).
asend_m0_7([started], _, _, _, _).
arecv_m0_7([started], _, _, _, _).
asend_m0_8([engage], _, _, _, _).
arecv_m0_8([engage], _, _, _, _).
asend_m0_9([alert100], _, _, _, _).
arecv_m0_9([alert100], _, _, _, _).
asend_m0_10([arriveReq], _, _, _, _).
arecv_m0_10([arriveReq], _, _, _, _).
asend_m0_11([new], _, _, _, _).
arecv_m0_11([new], _, _, _, _).
asend_m0_12([arrivAck], _, _, _, _).
arecv_m0_12([arrivAck], _, _, _, _).
asend_m0_13([alertStop], _, _, _, _).
arecv_m0_13([alertStop], _, _, _, _).
asend_m0_14([disengage], _, _, _, _).
arecv_m0_14([disengage], _, _, _, _).
asend_m0_15([stop], _, _, _, _).
arecv_m0_15([stop], _, _, _, _).
asend_m0_16([tm, 90], _, _, _, _).
arecv_m0_16([tm, 90], _, _, _, _).
asend_m0_17([departReq], _, _, _, _).
arecv_m0_17([departReq], _, _, _, _).
asend_m0_18([departAck], _, _, _, _).
arecv_m0_18([departAck], _, _, _, _).


cond_m0_0(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, departure|_].

cond_m0_1(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, departure|_].
    
cond_m0_2(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, _, cruising|_].
    
cond_m0_3(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, _, cruising|_].

cond_m0_4(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, _, _, arrival|_]. 
    
cond_m0_5(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, _, _, _, stop]. 
  
  
cond_m0_6(SysVarList, _, _, _):-
    SysVarList=[empty].
    
      
    
cond_m0_7(_, _, _, _).
    
    
cond_m0_8(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, departure|_].
    
cond_m0_9(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, _, _, _, pass]. 
    
cond_m0_10(_, InstanceVarList, _, ChartSymblicInstanceList):-
    getListofInstance(InstanceVarList, car, CarVarList),
    getListofInstance(ChartSymblicInstanceList, car, IntervalList),
    IntervalList=[InterVal],
    InterVal=[X, X],
    getInstanceVarList(CarVarList, X, VarList),
    VarList=[_, _, cruising|_].

    

begin:-
    run([], _, _).
    