static char *addls_ss[] = {

	"uchar* add_ls(uchar *to_add, uchar *ls)",

	"{",

	"	/* add to front of the local state list of current proc type*/",

	"	((LocalState0 *)to_add)->nxt = (LocalState0 *)ls;",

	"	((LocalState0 *)to_add)->pre = ((LocalState0 *)ls)->pre;",

	"	if(((LocalState0 *)ls)->pre) {",

	"		((LocalState0 *)ls)->pre->nxt = (LocalState0 *)to_add;",

	"	}",

	"	((LocalState0 *)ls)->pre = (LocalState0 *)to_add;",

	"",

	"	return to_add;",

	"}",

	0,

};





static char *deleteUpdating_ss[] = {

	"void delete_updatingLS()",

	"{",

	"	if(!((LocalState0 *)updating_ls)->pr_count) {",

	"		if(((LocalState0 *)updating_ls)->pre) {",

	"			((LocalState0 *)updating_ls)->pre->nxt = ((LocalState0 *)updating_ls)->nxt;",

	"		}else {/* no partition was added, and delete the first partition */",

	"			((P0 *)this)->ls = ((LocalState0 *)updating_ls)->nxt;",

	"		}",

	"		if(((LocalState0 *)updating_ls)->nxt) {",

	"			((LocalState0 *)updating_ls)->nxt->pre = ((LocalState0 *)updating_ls)->pre;",

	"		}",

	"		if(this_ls == updating_ls) {",

	"			this_ls = (uchar *)((LocalState0 *)updating_ls)->pre;",

	"		}",

	"		free(updating_ls);",

	"		((P0 *)this)->partition_count--;",

	"	} /* if no deletion, no change on the this_ls pointer */",

	"}",

	0,

};



static char *deleteThisLS_ss[] = {

	"uchar* delete_this_ls()",

	"{	uchar *new_this_ls = this_ls;",

	"	if(!((LocalState0 *)this_ls)->pr_count) {",

	"		if(((LocalState0 *)this_ls)->pre) {",

	"			((LocalState0 *)this_ls)->pre->nxt = ((LocalState0 *)this_ls)->nxt;",

	"			new_this_ls = (uchar *)((LocalState0 *)this_ls)->pre; /* set to prev since the while",

	"																   *  loop would increment the pointer at the end in pan.c",

	"																   */",

	"		}else {/* no partition was added, and delete the first partition */",

	"			((P0 *)this)->ls = ((LocalState0 *)this_ls)->nxt;",

	"			new_this_ls = (uchar *) 0;",

	"		}",

	"		if(((LocalState0 *)this_ls)->nxt) {",

	"			((LocalState0 *)this_ls)->nxt->pre = ((LocalState0 *)this_ls)->pre;",

	"		}",

	"		extra_mempar = extra_mempar - getSize(((P0 *)this)->_t);",

	"		free(this_ls);",

	"		((P0 *)this)->partition_count--;",

	"	} /* if no deletion, no change on the this_ls pointer */",

	"	return new_this_ls;",

	"}",

	0,

};



static char *offset_ss[] = {

	"int min_proc_offset()",

	"{",

	"	int i, min_offset;",

	"	int numOfProc = now._nr_pr_type;",

	"	min_offset = proc_offset[0];",

	"	for(i = 0; i<numOfProc; i++){",

	"		if(proc_offset[i]<min_offset) {",

	"			min_offset = proc_offset[i];",

	"		}",

	"	}",

	"	return min_offset;",

	"}",

	0,

};

static char *backward_updateLS1[] = {
	"	case %d: {/* P%d */",
	"		P%d_ls = ((P%d *)this)->ls;",

	"		for(;P%d_ls; P%d_ls=P%d_ls->nxt) {",

	"			if((P%d_ls->_p) == st",

	0,
};

static char *updateLS_ss1[] = {

	"	case %d: {/* P%d */",
	"		/* for spuriousness detection */", /* ss: 6 June 2009 */
	"		free(trpt->exit_state.ls0);",
	"		free(trpt->entry_state.ls0);",
	"		trpt->exit_state.ls%d = (linear_LS%d*)malloc(sizeof(linear_LS%d));",
	"		trpt->exit_state.ls%d->_p = ((LocalState%d *)this_ls)->_p;",
	"		trpt->exit_state.ls%d->pr_count = ((LocalState%d *)this_ls)->pr_count;",
	"		/*******************************/",

		/* ss: to preserve par oder -- 20 Feb 08 */
	"		if(!par_deleted) /* if a par is deleted in pan.m (for ASGN), then no need to set deleted_pos */",
	"			trpt->deleted_pos = getDeletedPos();", 
	"		P%d_ls = ((P%d *)this)->ls;",
	"		for(;P%d_ls; P%d_ls=P%d_ls->nxt) {",
	"			if((P%d_ls->_p) == st",
	0,

};

static char *backward_updateLS2[] = {
	
	"			)", 

	"			break;",

	"		}",

	"",
	"		if((uchar*)P%d_ls != this_ls) {",

	"			if((int)P%d_ls) {/* ss: found partition*/",

	/* "				(P%d_ls->pr_count)++;", */
	"				/* ss: for OMEGA */",

	"				P%d_ls->pr_count = trpt->fromLs_count;",
	"				/***************/",

	"			}else {/* add new partition */",

	"				P%d_ls = (LocalState%d *)malloc(sizeof(LocalState%d));",

	"				extra_mempar +=sizeof(LocalState%d);",

	"				if(extra_mempar>max_mempar)",

	"					max_mempar = extra_mempar;",

	"				P%d_ls->_p = st;",

	/* "				P%d_ls->pr_count = 1;", */
	
	"				P%d_ls->pr_count = trpt->fromLs_count;",
	0,
};

static char *updateLS_ss2[] = {

	"			)", 

	"			break;",

	"		}",

	"",
	"		if((uchar*)P%d_ls != this_ls) {",

	"			if(!(int)P%d_ls) {/* add new partition */",
	"				new_par = 1;",
	"				P%d_ls = (LocalState%d *)malloc(sizeof(LocalState%d));",
	"				extra_mempar +=sizeof(LocalState%d);",
	"				if(extra_mempar>max_mempar)",
	"					max_mempar = extra_mempar;",
	"				P%d_ls->_p = st;",
	"				P%d_ls->pr_count = 0;",
	/*"				if(P%d_ls->pr_count<(cut[%d]-1)) {",
	"					(P%d_ls->pr_count)++;",
	"				}else{",
	"					P%d_ls->pr_count = _OMEGA;",
	"				}",
	*/
	0,

};

static char *backward_updateLS3[] = {
	"				/* add to front of the local state list of current proc type*/",

	"				((P%d *)this)->ls = (LocalState%d *)add_ls((uchar*)P%d_ls, (uchar *)((P%d *)this)->ls);",


	"				((P%d *)this)->partition_count++;",

	"			}",					

	"			/* decrease pr_count of current partition */",

/* 	"			((LocalState%d *)this_ls)->pr_count--;", */
	"			/* ss: change for OMEGA */", /* for OMEGA */
	
	"			((LocalState%d*)this_ls)->pr_count = trpt->toLs_count;",
	
	"			/*****************/",

	"			/* if pr_count = 0; delete the partition */",

	"			delete_this_ls();",

	"			/* keep track of which partition the object has gone into, for backward moves */",

	"			this_ls = (uchar *)P%d_ls;",
	"		}",

	"		break; ",

	"			}/* end case %d */",

	0,

};


static char *updateLS_ss3[] = {

	/*"			if(!uploop) {", */

	"				/* add to front of the local state list of current proc type*/",

	"				((P%d *)this)->ls = (LocalState%d *)add_ls((uchar*)P%d_ls, (uchar *)((P%d *)this)->ls);",

	/*"			}else {",

	"				add_ls((uchar*)P%d_ls, this_ls);",

    "				if((uchar *)((P0 *)this)->ls == this_ls)",

    "					((P%d *)this)->ls = P%d_ls;",

    "			}",

	*/

	"				((P%d *)this)->partition_count++;",

	"			}",	
	"			trpt->toLs_count = P%d_ls->pr_count;",

	"			/* decrease pr_count of current partition */",
	"			/* ss: change for OMEGA */", /* for OMEGA */
	"#ifdef INFINITE",
	"			if(P%d_ls->pr_count<(cut[%d]-1)) {",
	"				(P%d_ls->pr_count)++;",
	"			}else{",
	"				P%d_ls->pr_count = _OMEGA;",
	"			}",
	"",
	"			if(((LocalState%d *)this_ls)->pr_count < cut[%d]) {",
	"				((LocalState%d *)this_ls)->pr_count--;",
	"			}else {",
	"				if(choice_cnt ==0) {",
	"					choice_cnt = 1;",
	"					/* remains OMEGA -- not advance */",
	"				}else {",
	"					choice_cnt = 0;",
	"					((LocalState%d *)this_ls)->pr_count = cut[%d] - 1;",
	"				}",
	"			}",
	"#else",
	"			(P%d_ls->pr_count)++;",
	"			((LocalState%d *)this_ls)->pr_count--;",
	"#endif",

#if 0
	"			if(!isBackward) {",
	"				if(br_status == BR_RCV) {",
	"					((LocalState%d *)this_ls)->pr_count = 0;",
	"				}else {",
	"					if(((LocalState%d *)this_ls)->pr_count != _OMEGA) {",
	"						((LocalState%d *)this_ls)->pr_count--;",
	"					}else if(t->isOmega) {",
	"						t->isOmega = 0;",
	"						((LocalState%d *)this_ls)->pr_count = _CUT;",
	"					}else {",
	"						/* else remains OMEGA */",
	"						t->isOmega = 1;",
	"					}",
	"				}",
	"			}else {",
	"				((LocalState%d*)this_ls)->pr_count = trpt->toLs_count;",
	"			}",
	"			/*****************/",
#endif 
	"			/* if pr_count = 0; delete the partition */",

	"			delete_this_ls();",

	"			/* keep track of which partition the object has gone into, for backward moves */",

	"			this_ls = (uchar *)P%d_ls;",
	"		}",
	"		/* for spuriousness detection */", /* ss: 8 June, 2009 */
	"		trpt->entry_state.ls%d = malloc(sizeof(linear_LS%d));",
	"		trpt->entry_state.ls%d->_p = ((LocalState%d*)this_ls)->_p;",
	"		trpt->entry_state.ls%d->pr_count = ((LocalState%d*)this_ls)->pr_count;",
	"		/******************************/",
	"		break; ",

	"			}/* end case %d */",

	0,

};



static char *updatingLS_ss4[] = {

	"	LocalState%d *P%d_ls;",

	0,

};



static char *compareLS_ss1[] = {

	"int compare_LS%d(const void* l1, const void* l0) {",

	"	/* compare linear_LS */",

	"	linear_LS%d* ls1 = (linear_LS%d *) l1;",

	"	linear_LS%d* ls0 = (linear_LS%d *) l0;",

	"	if(ls1->_p < ls0->_p) {",

	"		return -1;",

	"	}",

	"	if(ls1->_p > ls0->_p) {",

	"		return 1;",

	"	}",

	"	/* _p equal */",

	"	if(ls1->pr_count < ls0->pr_count) {",

	"		return -1;",

	"	}",

	"	if(ls1->pr_count > ls0->pr_count) {",

	"		return 1;",

	"	}",

	0,

};



static char *compareNoCount_ss1[] = {

	"int compareLS%d_noCount(const void* l1, const void* l0) {",

	"	/* compare LocalState */",

	"	LocalState%d* ls1 = (LocalState%d *) l1;",

	"	LocalState%d* ls0 = (LocalState%d *) l0;",

	"	if(ls1->_p < ls0->_p) {",

	"		return -1;",

	"	}",

	"	if(ls1->_p > ls0->_p) {",

	"		return 1;",

	"	}",

	"	/* _p equal */",

	0,

};



static char *trackLS_ss1[] = {

	"uchar*",

	"track_ls(uchar *o_ls, uchar pr_type, uchar *trackLS)",

	"{",

	"	int size;",

	"	free(o_ls);",

	"	switch(pr_type) {",

	0,

};



static char *trackLS_ss2[] = {

	"	case %d:",

	"		size = sizeof(LocalState%d);",

	"		break;",

	0,

};



static char *trackLS_ss3[] = {

	"	}", /* end switch */

	"	o_ls = (uchar *)malloc(size);",

	"	extra_memtrail += size;",

	"	if(extra_memtrail>max_memtrail)",

	"		max_memtrail = extra_memtrail;",

	"	memcpy(o_ls, trackLS, size);",

	"	return o_ls;",

	"}", /* end function */

	0,

};



static char *findLS_ss1[] = {

	"uchar*",

	"find_ls(uchar* this_ls, uchar *to_ls, uchar pr_type)",

	"{ /*	printf(\"find_ls(): to_ls = %d\\n\", to_ls); */",

	"	if(!to_ls) {",

	"		return to_ls;",

	"	}",

	"	switch(pr_type) {",

	0,

};



static char *findLS_ss2[] = {

	"	case %d: {",

	"		while(this_ls) {",

	"			if(!compareLS%d_noCount(to_ls, this_ls)) {",

	"				break;",

	"			}",

	"			this_ls = (uchar *)((LocalState%d *)this_ls)->nxt;",

	"		}",

	"			}",

	"		break;",

	0,

};



static char *linearNow_ss1[] = {

	"char* linearize_now()",

	"{",	

	"	int i,j, global_info_size;",

	"	P0 *pr;",

	"	char *linear_pointer, *linear_offset, *linear_mem;",

	"	int local_size, offset;",

	"	char* pointer;",

	"	char* tmp_local;",

	"",

	"/*	printf(\"***** Linearize_stateInfo ****** \\n\");",

	"	/* step 1: get the proper size */",

	"	linear_vsize = 0;",

	"	global_info_size = min_proc_offset();",

	"	linear_vsize += global_info_size; /* size of global info*/",

	"	int type_count = now._nr_pr_type;",

	"	for(i = 0; i<type_count; i++) {",

	"		pr = (P0 *)pptr(i);",

	"		switch(pr->_t) {",

	0,

};





static char *linear_ss1[] = {

	"int linearize_stateInfo(char *vin, int n, char* linear_mem)",

	"{",	

	"	int i,j, global_info_size, linear_size = 0;",

	"	P0 *pr;",

	"	char *linear_pointer, *linear_offset;",

	"	int local_size, offset;",

	"	char* pointer;",

	"	char* tmp_local;",

	"",

	"/*	printf(\"***** Linearize_stateInfo ****** \\n\");",

	"	/* step 1: get the proper size */",

	"	global_info_size = min_proc_offset();",

	"	linear_size += global_info_size; /* size of global info*/",

	"	int type_count = now._nr_pr_type;",

	"	for(i = 0; i<type_count; i++) {",

	"		pr = (P0 *)pptr(i);",

	"		switch(pr->_t) {",

	0,

};



static char *linearNow_ss2[] = {

	"		case %d: /* P%d */",

	"			linear_vsize+= (pr->partition_count)* (sizeof(LocalState%d) ",

	"							- 2* sizeof(LocalState%d*));",

	"			break;",

	0,

};



static char *linear_ss2[] = {

	"		case %d: /* P%d */",

	"			linear_size+= (pr->partition_count)* (sizeof(LocalState%d) ",

	"							- 2* sizeof(LocalState%d*));",

	"			break;",

	0,

};



static char *linearNow_ss3[] = {

	"		}/* end switch type*/",

	"	}",

	"	/* step 2: malloc memory */",

	"	/*	linear_mem = (char *)malloc(linear_size); */ ",

	"	linear_mem = (char *)malloc(linear_vsize);",

	"	extra_mempar +=sizeof(linear_vsize);",

	"	if(extra_mempar>max_mempar)",

	"		max_mempar = extra_mempar;",

	"	linear_pointer = linear_mem;",

	"",

	"	/* step  3: store global info*/",

	"	memcpy(linear_mem, &now, global_info_size);",

	"	linear_pointer += global_info_size;",

	"",

	"	/* step 4: sort partitions and linearization */",

	"	for(i = 0; i<type_count; i++) {",

	"		pr = (P0 *)pptr(i);",

	"		switch(pr->_t) {",

	0,

};



static char *linear_ss3[] = {

	"		}/* end switch type*/",

	"	}",

	"	/* step 2: malloc memory */",

	"	/*	linear_mem = (char *)malloc(linear_size); */ ",

	"	linear_pointer = linear_mem;",

	"",

	"	/* step  3: store global info*/",

	"	memcpy(linear_mem, &now, global_info_size);",

	"	linear_pointer += global_info_size;",

	"",

	"	/* step 4: sort partitions and linearization */",

	"	for(i = 0; i<type_count; i++) {",

	"		pr = (P0 *)pptr(i);",

	"		switch(pr->_t) {",

	0,

};



static char *linear_ss4[] = {

	"		case %d: {",

	"			pointer = (char *)pr->ls;",

	"			linear_offset = linear_pointer;",

	"",

	"			for(j = 0; j<pr->partition_count; j++) {",

	"				memset(linear_offset, 0, sizeof(linear_LS%d));",

	"				((linear_LS%d *) linear_offset)->_p = ((LocalState%d *)pointer)->_p;",

	"				((linear_LS%d *) linear_offset)->pr_count = ((LocalState%d *)pointer)->pr_count;",

	0,

};



static char *linear_ss5[] = {

	"				pointer = (char *)((LocalState%d *)pointer)->nxt;",

	"				linear_offset +=sizeof(linear_LS%d);",

	"			}",

	"			qsort(linear_pointer, pr->partition_count, sizeof(linear_LS%d), compare_LS%d);",

	"			linear_pointer = linear_offset;",

	"			break;",

	"				}",

	0,

};



static char *linearNow_ss6[] = {

	"		}",

	"	}",

	"",

	"	return linear_mem;",

	"}",

	0,

};





static char *linear_ss6[] = {

	"		}",

	"	}",

	"",

	"	return linear_size;",

	"}",

	0,

};



static char *cmp_ss1[] = {

	"/* only return 0 or 1 */",

	"int deep_statecmp ( const void * ptr1, const void * ptr2)",

	"{",

	"	int result, hasMatched;",

	"	P0 *tmp_pr1, *tmp_pr2;",

	"	short From_type, To, i;",

	"	uchar *head1, *head2;",

	"	/* step 1: compare global State */",

	"	if(!(result=memcmp(ptr1, ptr2, sizeof(State)))) {",

	"		/* step 2: compare local states */",

	"		From_type = ((State *)ptr1)->_nr_pr_type;",

	"		To = BASE; ",

	"		for(i = From_type; i>=To; i--) {",

	"			tmp_pr1 = (P0 *) (((uchar *)ptr1)+(int)proc_offset[i]);",

	"			tmp_pr2 = (P0 *) (((uchar *)ptr2)+(int)proc_offset[i]);",

	"",

	"			if(tmp_pr1->partition_count !=tmp_pr2->partition_count) {",

	"				return 1; ",

	"			}",

	"			switch(i) {",

	0,

};



static char *cmp_ss2[] = {

	"				case %d: /* P%d */",

	"					for(head1 = (uchar *)tmp_pr1->ls; head1; head1 = (uchar *)((LocalState%d *)head1)->nxt){",

	"						hasMatched = 0;",

	"						for(head2 = (uchar *)tmp_pr2->ls; head2; head2 = (uchar *)((LocalState%d *)head2)->nxt){",

	"							if(!memcmp(head1,head2, sizeof(LocalState%d))) {",

	"								hasMatched = 1;",

	"								break; /* break inner for loop */",

	"							}",

	"						}",

	"						if(!hasMatched) {",

	"							return 1; ",

	"						}",

	"					}",

	"					break;",

	0,

};

/* sDetection  8 June 2009 */
static char *ss_state2string0[] = {
	"char* state2string(int pid, state_t s)",
	"{",
	"	char* result = (char *)malloc(128); ",
	"	memset(result, 0, 128);",
	"	int len;",
	"	if(s.ls0) {",
	"		switch(pid){",
	0,
};

static char *ss_printConcrete[] = {
	"	printf(\"Proctype %%s\\n\", procname[procType]);",
	"	if(!tmp)",
  	"	printf(\"\\thas %%d instances\\n\", prCounts[procType]);",
	"	while(tmp) {",
	"		if(tmp->init>tmp->finiteExit)",
	"			tmpValue = tmp->finiteExit;",
	"		else ",
	"			tmpValue = tmp->init;",
	"		printf(\"\\thas %%d objects at initial local state (%%s)\\n\", tmpValue, tmp->exeState);",
	"		tmp = tmp->nxt;",
	"	}",
	"}",
	0,
};

static char *ss_zFile0[] = {
	"short infinite;",
	"",
	"/* if not exists, create a new one */",
	"NumExe* getNumExe(int procType, int ctrl, char* exeState)",
	"{",
	"	int cmpResult;",
	"	NumExe* tmp;",
	"	NumExe* item = exeTable[procType][ctrl];",
	"",
	"	if(!item) {/* initial state */",
	"		item = (NumExe *)malloc(sizeof(NumExe));",
	"		item->exeState = (char*)malloc(100);",
	"		strcpy(item->exeState, exeState);",
	"		if(getInitCtrl(procType)==ctrl)",
	"			item->init = prCounts[procType];",
	"		else",
	"			item->init = 0;",
	"		item->pre = NULL;",
	"		item->nxt = NULL;",
	"		exeTable[procType][ctrl] = item;",
	"		return item;",
	"	}",
	"",
	"	while(item) {",
	"		cmpResult = strcmp(item->exeState, exeState);",	
	"		if(!cmpResult) {",
	"			return item;",
	"		}else if(cmpResult>0 || !item->nxt) {",
	"			/* insert new NumExe */",
	"			tmp = (NumExe *)malloc(sizeof(NumExe));",
	"			tmp->exeState = exeState;",
	"			tmp->pre = item;",
	"			tmp->nxt = item->nxt;",
	"			if(item->nxt)",
	"				item->nxt->pre = tmp;",
	"			item->nxt = tmp;",
	"			return tmp;",
	"		}",
	"		item = item->nxt;",
	"	}",
	"	return NULL;",
	"}",
	"",
	"short",
	"isStateValid(NumExe *tmp)",
	"{",
	"	if(tmp->init + tmp->finiteEntry - tmp->finiteExit <=0)",
	"		return 0;",
	"	return 1;",
	"}",
	"",
	"/* valid: -1; not valid: proctype */",
	"int",
	"getInvalidProc(void)",
	"{",
	"	int getInfiniteInvalid(void);",
	"	void initExeTable(void);",
	"	FILE *fd;",
	"	char fnm[512];",
	"	int procType, t_id, i, entryL, exitL;",
	"	char entryS[100];",
	"	char exitS[100];",
	"	NumExe *tmpExitS;",
	"	NumExe *tmpEntryS;",
	"	infinite = 0;",
	"",
	"	initExeTable();",
	"",
	"	/* parse .trace file */",
	"	if (iterative == 0 && (Nr_Trails -1) > 0)",
	"		sprintf(fnm, \"%%s%%d.trace\",",
	"			TrailFile, Nr_Trails-1);",
	"	else",
	"		sprintf(fnm, \"%%s.trace\", TrailFile);",
	"",
	"	if((fd = fopen(fnm, \"r\")) == NULL)",
	"	{",
	"		printf(\"pan: cannot find trace file %%s\\n\", fnm);",
	"		pan_exit(1);",
	"	}",
	"",
	"	while(fscanf(fd, \"%%d=%%d %%s :%%d:%%d %%s\\n\", &procType, &exitL, exitS, &t_id, &entryL, entryS)>0) {",
	"		if(procType < 0) {",
	"			/* infinite trace */",
	"			infinite = 1;",
	"			continue;",
	"		}",
	"		/* adjust procType: move never: to (numOfTypes - 1), and the other proctype = proctype - 1*/",
	"#ifdef VERI",
	"		if(procType == 0) {",
	"			procType = VERI;",
	"		}else if(procType<=VERI){",
	"			procType--;",
	"		}",
	"#endif",
	"		tmpExitS = getNumExe(procType, exitL, exitS);",
	"		tmpEntryS = getNumExe(procType, entryL, entryS);",

	"		if(!isStateValid(tmpExitS))",
	"			return procType;",
	"		/* valid */",
	"		tmpEntryS->finiteEntry++;",
	"		tmpExitS->finiteExit++;",
	"",
	"		if(infinite) {",
	"			tmpEntryS->infiniteEntry++;",
	"			tmpExitS->infiniteExit++;",
	"		}",
	"	}",
	"	/* finite valid */",
	"	if(infinite) {",
	"		return getInfiniteInvalid();",
	"	}",
	"	return -1;",
	"}",
	"",
	"/* check whether all exeState of a ctrl location is infinite valid",
	"* return 1 if valid; 0 otherwise;",
	"*/",
	"short",
	"isInfiniteValid(int procType, int ctrl)",
	"{",
	"	NumExe *tmp = exeTable[procType][ctrl];",
	"	while(tmp) {",
	"		if(tmp->infiniteEntry != tmp->infiniteExit)",
	"			return 0;",
	"		tmp = tmp->nxt;",
	"	}",
	"	return 1;",
	"}",
	"",
	"void",
	"freeNumExe(int procType)",
	"{",
	"	int size, i;",
	"	NumExe *tmp1, *tmp2;",
	"",
	"	size = getExeSize(procType);",
	"",
	"	for(i = 0; i<size; i++) {",
	"		tmp1 = exeTable[procType][i];",
	"		while(tmp1) {",
	"			tmp2 = tmp1->nxt;",
	"			free(tmp1->exeState);",
	"			free(tmp1);",
	"			tmp1 = tmp2;",
	"		}",
	"	}",
	"	free(exeTable[procType]);",
	"}",
	0,
};

static char *ss_zFile1[] = {
	"int",
	"getInfiniteInvalid(void)",
	"{",
	"	int i, j, size;",
	"	NumExe *tmp;",
	"",
	"	for(i = 0; i<%d; i++) {", /* # of processes */
	"		size = getExeSize(i);",
	"		for(j = 0; j<size; j++){",
	"			if(!isInfiniteValid(i, j))",
	"				return i;",
	"		}",
	"	}",
	"	return -1;",
	"}",
	"",
	"void",
	"freeExeTable(void)",
	"{",
	"	int i, j;",
	"	for(i = 0; i<%d; i++) {", /* # of processes */
	"		freeNumExe(i);",
	"	}",
	"	free(exeTable);",
	"}",
	"",
	"void",
	"initExeTable(void)",
	"{",
	"	int i, size;",
	"	exeTable = (NumExe ***) malloc(%d *sizeof(NumExe **));",
	"",
	"	for(i = 0; i<%d; i++) {",
	"		size = getExeSize(i);",
	"		exeTable[i] = (NumExe **) malloc(size*sizeof(NumExe *));",
	"	}",
	"}",
	"",
	"void",
	"printSmallSystem(void)",
	"{",
	"	int i;",
	"	for(i = 0; i<%d; i++) {",
	"		printConcreteNum(i);",
	"	}",
	"}",
	0,
};
/**********************/



static char *funDecl_ss[] = {

	"uchar* add_ls(uchar* to_add, uchar* ls);",

/*	"int update_this_ls(Trans* t, short isBackward);",*/
	"int update_this_ls(Trans* t);",
	"void backward_update_this_ls(int st);",

	"int getDeletedPos(void);",

	"uchar* delete_this_ls();",

	"uchar* track_ls(uchar *, uchar, uchar *);",

	"uchar* find_ls(uchar*, uchar *, uchar);",

	"void get_mempar(void);",
	"",
	"#include \"pan.z\" /* for spuriousness detection */", 
	"",
	"#ifdef INFINITE",
	"void update_t_hasCount(int *var, int cutoff) /* different proc type may have differnet cutoff */",
	"{",
	"	o_choice = choice;",
	"	if(*var ==_OMEGA) {",
	"		if(choice==1) {",
	"			choice = 2;",
	"			/* remains omega */",
	"		}else if(choice==2) {",
	"			choice = 3;",
	"			*var = cutoff-1;",
	"		}",
	"	}else {",
	"		choice = 3;",
	"		*var = (*var) -1;",
	"	}",				
	"}",
	"",
	"/* update proc count var in the merged statement, no change for choice */",
	"void update_merged_count(int *var, int cutoff)",
	"{",
	"	if(*var == _OMEGA) {",
	"		if(choice!=2) {",
	"			*var = cutoff-1;",
	"		}/* else remain omega */",
	"	}else {	",
	"		*var = (*var) -1;	",
	"	}",
	"}",
	"#endif",
	0,
};



static char *cpy_ss1[] = {

	"void* deep_statecpy(void * dest, const void * src)",

	"{	",

	"	uchar *new_ls, *tmp_head, *new_state, *new_head;",

	"	P0 *tmp_pr;",

	"	short From_type = ((State *)src)->_nr_pr_type, To = BASE; /* might need to use BASE*/",

	"	short i;",

	"	memcpy(dest,src,sizeof(State));",

	"",

	"	for(i = From_type - 1; i>=0; i--) {",

	"		tmp_pr = (P0 *) (((uchar *)src)+(int)proc_offset[i]);",

	"		switch(i) {",

	0,

};



static char *cpy_ss2[] = {

	"			case %d: /* P%d */",

	"				for(tmp_head = (uchar *)tmp_pr->ls; tmp_head; tmp_head = (uchar *)((LocalState0 *)tmp_head)->nxt) {",

	"					new_state = (uchar *)malloc(sizeof(LocalState%d));",

	"					extra_mempar +=sizeof(LocalState%d);",

	"					if(extra_mempar>max_mempar)",

	"						max_mempar = extra_mempar;",

	"					memcpy(new_state, tmp_head, sizeof(LocalState%d));",

	"					if(tmp_head == (uchar *)tmp_pr->ls) {",

	"						new_ls = new_state;",

	"						new_head = new_ls;",

	"					}else {",

	"						((LocalState%d *)new_head)->nxt = (LocalState%d *)new_state;",

	"						((LocalState%d *)new_state)->pre = (LocalState%d *)new_head; ",

	"						new_head = (uchar*) ((LocalState%d *)new_head)->nxt;",

	"					}",

	"				}",

	"				break;",

	0,

};



static char *check_claim_ss[] = {

	"#ifdef VERI",

	"void",

	"check_claim_ss(LocalState0 *ls)",

	"{",

	"	int flag = 0; ",

	"	while(ls) {",

	"		if(ls->_p == endclaim) {",

	"			uerror(\"claim violated!\");",

	"			flag = 1;",

	"		}",

	"		if(stopstate[VERI][ls->_p]) {",

	"			uerror(\"end state in claim reached\");",

	"			flag=1;",

	"		}",

	"		if(flag) {",

	"			return; /* only find one violation */",

	"		}",

	"		ls = ls->nxt;",

	"	}",

	"}",

	"#endif",

	0,

};



static char *mempar_ss1[] = {

	"void",

	"get_mempar(void)",

	"{	int i;",

	"	for(i = 0; i<now._nr_pr_type; i++) {",

	"		P0 *tmp_p = (P0*) pptr(i);",

	"		switch(tmp_p->_t) {	",

	0,

};



static char *mempar_ss2[] = {

	"case %d:",

	"	extra_mempar += tmp_p->partition_count * sizeof(LocalState%d);",

	"	break;",

	0,

};



static char *noasc_ss[] = {

	"#ifdef NOASC",

	"void forward_asc() {}",

	"void backward_asc(short rcv) {}",

	"short snderInAsc(int ascId, int ascStatus){ return 1;}",

	"short ascPairExists(int ascId, int ascStatus){ return 1;}",

	"void forwardUpdateAsc() {}",

	"#else ",

	0,
};



static char *compareAscLS_ss1[] = {

	"int compare_AscLS%d(const void* l1, const void* l0) {",

	"	/* compare Asc_LS */",

	"	Asc_LS%d* ls1 = (Asc_LS%d *) l1;",

	"	Asc_LS%d* ls0 = (Asc_LS%d *) l0;",

	"",

	"	if(ls1->_t < ls0->_t) {",

	"		return -1;",

	"	}",

	"	if(ls1->_t > ls0->_t) {",

	"		return 1;",

	"	}",

	"",

	"	if(ls1->_p < ls0->_p) {",

	"		return -1;",

	"	}",

	"	if(ls1->_p > ls0->_p) {",

	"		return 1;",

	"	}",

	"	/* _p equal */",

	0,

};



static char *compareAscLS_ss2[] = {

	"int compare_AscLS(const void* l1, const void* l0) {",

	"	if(!l1 || !l0) ",

	"		return -2;",

	"",

	"	if(((Asc_LS0 *)l1)->_t != ((Asc_LS0 *)l0)->_t)",

	"		return -2;",

	"	switch(((Asc_LS0 *)l1)->_t) {",

	0,

};



static char *cpyAscLS_ss1[] = {

	"uchar* cpyAscLS(uchar *ascLS)",

	"{	",

	"	switch(((Asc_LS0 *)ascLS)->_t) {",

	0,

};



static char *cpyAscLS_ss2[] = {

	"	case %d: {",

	"		Asc_LS%d *l%d = (Asc_LS%d *)malloc(sizeof(Asc_LS%d));",

	"		extra_memAsc += sizeof(Asc_LS%d);",

	"		if(extra_memAsc>max_memAsc)",

	"			max_memAsc = extra_memAsc;",

	"		l%d->_t = %d;",

	"		l%d->_p = ((Asc_LS%d *)ascLS)->_p;",

	0,

};





static char *ascFunc_ss2[] = {

	/* findAscPair() */

	"AscPair* findAscPair(Asc *a, uchar* snd_stored, uchar* rcv_stored)",

	"{",

	"	AscPair *ap = a->pairs;",

	"",

	"	if(!snd_stored||!rcv_stored)",

	"		return (AscPair *)0;",

	"	while(ap) {",

	"		if((ap->left==snd_stored&&ap->right==rcv_stored)||(ap->left==rcv_stored&&ap->right==snd_stored))",

	"			return ap;",

	"		ap = ap->nxt;",

	"	}",

	"	return (AscPair*)0;",

	"}",

	/* addAscPair() */

	"/* input snd_nxtLS and rcv_nxtLS are from asc_space, so the comparision can be done by comparing addresses */",

	"AscPair* addAscPair(Asc *a, uchar* snd_nxtLS, uchar* rcv_nxtLS)",

	"{",

	"	short pairFound;",

	"	AscPair *tmp;",

	"	pairFound = 0;",

	"",

	"	if(!snd_nxtLS || !rcv_nxtLS)",

	"		return (AscPair*)0;",

	"",

	"	/* case 1: AscPair found */",

	"	tmp = findAscPair(a, snd_nxtLS, rcv_nxtLS);",

	"	if(tmp) {",

	"		tmp->count++;",

	"		return tmp;",

	"	}",

	"",

	"	/* case 2: add new pair */",

	"	tmp = (AscPair *)malloc(sizeof(AscPair));",

	"",

	"	extra_memAsc += sizeof(AscPair);",

	"	if(extra_memAsc>max_memAsc)",

	"		max_memAsc = extra_memAsc;",

	"",

	"	if(((Asc_LS0 *)snd_nxtLS)->_t < ((Asc_LS0 *)rcv_nxtLS)->_t) {",

	"		tmp->left = snd_nxtLS;",

	"		tmp->right = rcv_nxtLS;",

	"	}else {",

	"		tmp->left = rcv_nxtLS;",

	"		tmp->right = snd_nxtLS;",

	"	}",

	"	tmp->count = 1;",

	"	/* add to front */",

	"	tmp->nxt = a->pairs;",

	"	if(a->pairs) {",

	"		(a->pairs)->pre = tmp;",

	"	}",

	"	a->pairs = tmp;",

	"	tmp->pre = (AscPair *)0;",

	"",

	"	return tmp;",

	"}",

	"",

	/* addAscLS() */

	"/* cpy input and add to front of asc_space; return added Asc_LS*/",

	"Asc_LS0* addAscLS(uchar *al, short backward)",

	"{",

	"	if(!al)",

	"		return (Asc_LS0 *)0;",

	"",

	"	Asc_LS0 *tmp = (Asc_LS0 *)cpyAscLS(al);",

	"	tmp->pr_count = 0; /* will increment outside this function */",

	"	tmp->nxt = asc_space;",

	"	tmp->pre = (uchar *)0;",

	"	if(asc_space)",

	"		((Asc_LS0 *)asc_space)->pre = (uchar*)tmp;",

	"	asc_space = (uchar*)tmp;",

	"	if(!backward) { /* add to newAscLS record -- 22 Jan 08 */",

	"		AscLS *tmpLS = (AscLS *)malloc(sizeof(AscLS));",

	"		if(!tmpLS)",

	"			uerror(\"addAscLS(): malloc failed \");",

	"		extra_memAsc += sizeof(AscLS);",

	"		if(extra_memAsc>max_memAsc)",

	"			max_memAsc = extra_memAsc;",

	"		tmpLS->ascLS = (uchar*)tmp;",

	"		tmpLS->nxt = newAscLS;",

	"		tmpLS->pre = (AscLS *)0;",

	"		if(newAscLS) ",

	"			newAscLS->pre = tmpLS;",

	"		newAscLS = tmpLS;				",

	"	}",

	"	return tmp; ",

	"}",

	"",

	/* findAscLS() */

	"Asc_LS0 *findAscLS(uchar* in_ascLS)",

	"{",

	"	uchar *al;",

	"",

	"	if(!in_ascLS)",

	"		return (Asc_LS0*)0;",

	"",

	"	al = asc_space;",

	"	while(al) {",

	"		if(!compare_AscLS(in_ascLS, al)){",

	"			return (Asc_LS0 *)al;",

	"		}",

	"		al = ((Asc_LS0*)al)->nxt;",

	"	}",

	"	return (Asc_LS0 *)0;",

	"}",

	"",

	/* removeUnusedAsc() */

	"void removeUnusedAsc()",

	"{",

	"	Asc *a, *a_nxt;",

	"	AscPair *ap, *move_nxt;",

	"",

	"	/* remove ascPair if count == 0 */",

	"	a = global_ascList;",

	"	while(a){",

	"		ap = a->pairs; ",

	"		while(ap){",

	"			if(ap->count == 0 || ((Asc_LS0 *)ap->left)->pr_count==0 || ((Asc_LS0 *)ap->right)->pr_count==0){",

	"				if(ap->nxt)",

	"					ap->nxt->pre = ap->pre;",

	"				if(ap->pre)",

	"					ap->pre->nxt = ap->nxt;",

	"				if(ap==a->pairs)",

	"					a->pairs = ap->nxt;",

	"				move_nxt = ap->nxt;",

	"				free(ap);",

	"				extra_memAsc = extra_memAsc - sizeof(AscPair);",

	"				ap = move_nxt;",

	"			}else {",

	"				ap = ap->nxt;",

	"			}",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	/* remove asc if no pairs */",

	"	a = global_ascList;",

	"	while(a) {",

	"		if(!a->pairs) {",

	"			if(a->nxt)",

	"				a->nxt->pre = a->pre;",

	"			if(a->pre)",

	"				a->pre->nxt = a->nxt;",

	"			if(a==global_ascList)",

	"				global_ascList = a->nxt;",

	"			a_nxt = a->nxt;",

	"			free(a);",

	"			extra_memAsc = extra_memAsc - sizeof(Asc);",

	"			a = a_nxt;",

	"		}else {",

	"			a = a->nxt;",

	"		}",

	"	}",

	"",

	"	/* not remove Asc_LS in asc_space even if count = 0; so that the update would be faster */",

	"}",

	"",

	/* getRefNum() */

	"int getRefNum(AscPair *ap, Asc_LS0 *matched_curr)",

	"{",

	"	AscPair *x = 0;",

	"	int count = 0;",

	"	x = ap;",

	"	while(x){",

	"		if((uchar*)matched_curr==x->left||(uchar*)matched_curr==x->right)",

	"			count += x->count;",

	"		x = x->nxt;",

	"	}",

	"	return count;",

	"}",

	"",

	/* min() */

	"int min(int a, int b)",

	"{",

	"	if(a<b)",

	"		return a;",

	"	return b;",

	"}",

	"",

/* addRecord() */

	"AscRecord* addRecord(Asc_LS0 *snd, Asc_LS0 *rcv, AscRecord *recordList)",

	"{",

	"	AscRecord *newRecord = 0;",

	"",

	"	newRecord = (AscRecord *)malloc(sizeof(AscRecord));",

	"	extra_memAsc += sizeof(AscRecord);",

	"	if(extra_memAsc>max_memAsc)",

	"		max_memAsc = extra_memAsc;",

	"	newRecord->snd = snd;",

	"	newRecord->rcv = rcv;",

	"	newRecord->nxt = recordList;",

	"	newRecord->pre = (AscRecord*)0;",

	"",

	"	if(recordList)",

	"		recordList->pre = newRecord;",

	"",

	"	return newRecord;	",

	"}",

	"",

	/* freeRecord() */

	"void freeRecord(AscRecord *record)",

	"{",

	"	AscRecord *ar = record;",

	"",

	"	while(ar){",

	"		if(ar->nxt){",

	"			ar = ar->nxt;",

	"			free(ar->pre);",

	"			extra_memAsc = extra_memAsc - sizeof(AscRecord);",

	"		}else {",

	"			free(ar);",

	"			extra_memAsc = extra_memAsc - sizeof(AscRecord);",

	"			ar = (AscRecord *)0;",

	"		}",

	"	}",

	"	record = (AscRecord *)0;",

	"}",

	"",

	/* freeAscLS() */

	"/* if backtrack has reached the place where a Asc_LS was added, then it can removed at this point -- 2 Jan */",

	"void freeAscLS(AscLS *lsList)",

	"{",

	"	AscLS *tmp = lsList;",

	"	while(tmp){",

	"		if(tmp->nxt){",

	"			tmp = tmp->nxt;",

	"			free(tmp->pre);",

	"			extra_memAsc = extra_memAsc - sizeof(AscLS);",

	"		}else {",

	"			free(tmp);",

	"			tmp = (AscLS *)0;",

	"			extra_memAsc = extra_memAsc - sizeof(AscLS);",

	"		}",

	"	}",

	"}",

	"",

	/* backwardUpdate() */

	"void backwardUpdate(Asc_LS0 *o_snd, Asc_LS0* o_rcv, Asc_LS0* n_snd, Asc_LS0* n_rcv, int asc_id)",

	"{",

	"	/* only need to reset asc from the two list */",

	"	Asc* a = global_ascList;",

	"	AscRecord *tmpRecord = 0, *nxtRecord = 0;",

	"	AscPair *ap = 0, *o_ap = 0, *n_ap = 0;",

	"	short recordFound;",

	"",

	/************** 28 Feb ****************/

	"	o_ap = 0; ",

	"	n_ap = 0;",

	"	while(a) {",

	"		if(a->id == asc_id) {",

	"			o_ap = findAscPair(a, (uchar*)o_snd, (uchar*)o_rcv);",

	"			n_ap = findAscPair(a, (uchar*)n_snd, (uchar*)n_rcv);",

	"			break;",

	"		}",

	"		a = a->nxt;		",

	"	}",

	"	a = global_ascList;",

/******************************************************/

	"	while(a){",

	"		/* reverse insertion -- deletion */",

	"		tmpRecord = inserted;",

	"		while(tmpRecord){",

	"			if(tmpRecord->asc_id == a->id) {",

	"				ap = a->pairs;",

	"				recordFound = 0;",

	"				while(ap){",

	"					if((ap->left==(uchar*)tmpRecord->snd&&ap->right==(uchar*)tmpRecord->rcv)||",

	"						(ap->left==(uchar*)tmpRecord->rcv&&ap->right==(uchar*)tmpRecord->snd)){",

	"						if(ap != o_ap && ap != n_ap)",

	"							ap->count = ap->count - tmpRecord->drift;",

	"						recordFound = 1;",

	"						/* remove tmpRecord*/",

	"						if(tmpRecord->pre)",

	"							tmpRecord->pre->nxt = tmpRecord->nxt;",

	"						if(tmpRecord->nxt)",

	"							tmpRecord->nxt->pre = tmpRecord->pre;",

	"						if(tmpRecord==inserted)",

	"							inserted = tmpRecord->nxt;",

	"						nxtRecord = tmpRecord->nxt;",

	"						free(tmpRecord);",

	"						extra_memAsc = extra_memAsc - sizeof(AscRecord);",

	"",

	"						break;",

	"					}",

	"					ap = ap->nxt;",

	"				}",

	"				if(!recordFound || ap->count<0 ){",

	"					uerror(\"backward: cannot reverse asc\");",

	"				}",

	"			}else {",

	"				nxtRecord = tmpRecord->nxt;",

	"			}",

	"			tmpRecord = nxtRecord;",

	"		}",

	"",

	"		/* revere deletion -- insertion */",

	"		tmpRecord = deleted;",

	"		while(tmpRecord) {",

	"			if(tmpRecord->asc_id==a->id) {",

	"				ap = findAscPair(a, (uchar*)tmpRecord->snd, (uchar*)tmpRecord->rcv);",

	"				if(ap && (ap == o_ap || ap == n_ap) ){",

	"					/* ignore */",

	"				}else {				",

	"					ap = addAscPair(a, (uchar*)tmpRecord->snd, (uchar*)tmpRecord->rcv);",

	"					ap->count = ap->count + tmpRecord->drift - 1;",

	"				}",

	"				/* remove tmpRecord */",

	"				if(tmpRecord->pre)",

	"					tmpRecord->pre->nxt = tmpRecord->nxt;",

	"				if(tmpRecord->nxt)",

	"					tmpRecord->nxt->pre = tmpRecord->pre;",

	"				if(tmpRecord==deleted)",

	"					deleted = tmpRecord->nxt;",

	"				nxtRecord = tmpRecord->nxt;",

	"				free(tmpRecord);",

	"				extra_memAsc = extra_memAsc - sizeof(AscRecord);",

	"			}else {",

	"				nxtRecord = tmpRecord->nxt;",

	"			}",

	"			tmpRecord = nxtRecord;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	removeUnusedAsc();",

	"",

	"	freeRecord(inserted);",

	"	freeRecord(deleted);",

	"	freeAscLS(newAscLS); /* ss: 22 Jan 08 */",

	"}",

	"",

	/* updateOnM() */

	"void updateOnM(Asc *a, AscPair *ap, Asc_LS0 *matched_nxt, uchar *not_matched)",

	"{",

	"	AscPair *new_ap;",

	"	/* m:1 -- always need to add new pair */",

	"	new_ap = addAscPair(a, (uchar*)matched_nxt, not_matched);",

	"	ap->count--;",

	"",

	"	/* record */",

	"	if(matched_nxt->pr_count>0 && ((Asc_LS0*)not_matched)->pr_count>0) { ",

	"		inserted = addRecord(matched_nxt, (Asc_LS0 *)not_matched, inserted);",

	"		inserted->asc_id = a->id;",

	"		inserted->drift = 1;",

	"	}",

	"",

	"	deleted = addRecord((Asc_LS0*)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"	deleted->asc_id = a->id;",

	"	deleted->drift = 1;",

	"	if(((Asc_LS0 *)ap->left)->pr_count==0 || ((Asc_LS0 *)ap->right)->pr_count==0) { /* ss: 25 Feb */",

	"		deleted->drift = deleted->drift + ap->count;",

	"	}",

	"}",

	"",

	/* updateOnOne() */

	"void updateOnOne(Asc *a, AscPair *ap, Asc_LS0 *matched_curr, Asc_LS0 *matched_nxt, uchar *not_matched)",

	"{",

	"	int numRef, numRef2, drift, old_count;",

	"	AscPair *new_ap;",

	"	short mul = a->multiplicity;",

	"	short foundAP;",

	"	numRef = min(ap->count, mul*(matched_curr->pr_count));",

	"	/* add new pairs */",

	"	if(((Asc_LS0 *)not_matched)->pr_count>0 && matched_nxt->pr_count>0) {",

	"		numRef2 = min(ap->count, mul);",

	"		/* 25 Feb */",

	"		new_ap = findAscPair(a, (uchar*)matched_nxt, not_matched);",

	"		if(!new_ap) {",

	"			new_ap = addAscPair(a, (uchar*)matched_nxt, not_matched);",

	"			foundAP = 0;",

	"		}else {",

	"			foundAP = 1;",

	"			old_count = new_ap->count;  /* record old count */",

	"			new_ap->count++; /* same effect as addAscPair() */",

	"		}",

	"		new_ap->count += numRef2 - 1; ",

	"		drift = numRef2;",

	"		if(new_ap->count > ((Asc_LS0 *)not_matched)->pr_count) { /* restrict count by multiplicity */",

	"			drift = drift + ((Asc_LS0 *)not_matched)->pr_count - new_ap->count;",

	"			new_ap->count = ((Asc_LS0 *)not_matched)->pr_count;",

	"",

	"			if(foundAP && old_count>new_ap->count) {/* update deleted -- 25 Feb */",

	"				deleted = addRecord(matched_nxt, (Asc_LS0 *)not_matched, deleted);",

	"				deleted ->asc_id = a->id;",

	"				deleted->drift = old_count - new_ap->count;",

	"			}",

	"		}",

	"",

	"		/* update inserted/deleted records */		",

	"		if(drift>0) {",

	"			inserted = addRecord(matched_nxt, (Asc_LS0 *)not_matched, inserted);",

	"			inserted->asc_id = a->id;",

	"			inserted->drift = drift;",

	"		}",

	"	}",

	"",

	"	if(numRef!=ap->count){ /* ap->count > mul; numRef==mul*(matched_curr->pr_count) */",

	"		deleted = addRecord(matched_curr, (Asc_LS0 *)not_matched, deleted);",

	"		deleted->asc_id = a->id;",

	"		deleted->drift = ap->count - numRef;",

	"	}else if(ap->count>0 && (((Asc_LS0 *)ap->left)->pr_count<=0 || ((Asc_LS0 *)ap->right)->pr_count<=0)){",

	"		deleted = addRecord(matched_curr, (Asc_LS0 *)not_matched, deleted);",

	"		deleted->asc_id = a->id;",

	"		deleted->drift = ap->count;	",

	"	}",

	"	ap->count = numRef; /* implies: if ap->count < mul, ap->count does not change */",

	"}",

	"",

	/* updateSamePair() */

	"/* update pair count if snd = rcv */",

	"void updateSamePair()",

	"{",

	"	Asc *a = 0;",

	"	AscPair *ap;",

	"	int drift;",

	"	a = global_ascList;",

	"	ap = (AscPair *)0;",

	"	while(a) {",

	"		ap = a->pairs;",

	"		while(ap) {",

	"			if(((Asc_LS0 *)ap->left)->_t != ((Asc_LS0 *)ap->right)->_t) {",

	"				break;",

	"			}",

	"			if(ap->left == ap->right && ap->count>(((Asc_LS0 *)ap->left)->pr_count/2)) {",

	"				drift = ap->count - ((Asc_LS0 *)ap->left)->pr_count/2;",

	"				ap->count = ((Asc_LS0 *)ap->left)->pr_count/2;",

	"				/* add to deleted */",

	"				deleted = addRecord((Asc_LS0 *)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"				deleted->asc_id = a->id;",

	"				deleted->drift = drift;",

	"			}",

	"			ap = ap->nxt;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"}",

	"",

	/* updateRelatedAsc_over() */

	"/* over approximation version */",

	"void updateRelatedAsc_over(Asc_LS0 *snd_currStored, Asc_LS0 *rcv_currStored, Asc_LS0 *snd_nxtStored, ",

	"							Asc_LS0 *rcv_nxtStored, uchar curr_asc)",

	"{",

	"	Asc *a = 0;",

	"	AscPair *ap = 0, *new_ap = 0, *currPair = 0;",

	"	short mode;",

	"	int mul, numRef;",

	"	Asc_LS0 *o_left = 0, *o_right = 0, *n_left = 0, *n_right = 0;",

	"",

	"	a = global_ascList;",

	"	inserted = (AscRecord *)0;",

	"	deleted = (AscRecord *)0;",

	"	while(a){	",

	"		mode = a->mul_mode;",

	"		mul = a->multiplicity;",

	"		if(a->id == curr_asc) {",

	"			currPair = findAscPair(a, (uchar*)snd_currStored, (uchar*)rcv_currStored);",

	"			if(!currPair){",

	"				goto others;",

	"			}			",

	"			ap = a->pairs;",

	"			while(ap){",

	"				if(ap==currPair && currPair->count>0){ /* need to transfer some asc */",

	"					if(mode==-1){ /* left:right == 1:m */",

	"						if((uchar*)snd_currStored==ap->left&&(uchar*)rcv_currStored==ap->right){",

	"							updateOnOne(a, ap, snd_currStored, snd_nxtStored, ap->right);",

	"						}else if((uchar *)rcv_currStored==ap->left && (uchar *)snd_currStored == ap->right) {",

	"							updateOnOne(a, ap, rcv_currStored, rcv_nxtStored, ap->right);",

	"						}",

	"					}else if(mode==1) {",

	"						if((uchar*)snd_currStored==ap->right&&(uchar*)rcv_currStored==ap->left){",

	"							updateOnOne(a, ap, snd_currStored, snd_nxtStored, ap->left);",

	"						}else if((uchar *)rcv_currStored==ap->right && (uchar *)snd_currStored == ap->left) {",

	"							updateOnOne(a, ap, rcv_currStored, rcv_nxtStored, ap->left);",

	"						}",

	"					}else {/* if it is 1:1 mapping, need to add some pairs to deleted ascRecord",

	"							* those pairs were added previously due to over approximation ",

	"							* 20 Feb 08",

	"							*/",

	"						if(((Asc_LS0 *)ap->left)->pr_count<=0 || ((Asc_LS0 *)ap->right)->pr_count<=0) {",

	"							deleted = addRecord((Asc_LS0 *)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"							deleted->asc_id = a->id;",

	"							deleted->drift = ap->count;",

	"						}",						

	"					}",

	"				}",

	"				if(ap!=currPair && !(ap->left==(uchar*)snd_nxtStored && ap->right==(uchar*)rcv_nxtStored) ",

	"					&& !(ap->left==(uchar*)rcv_nxtStored && ap->right==(uchar*)snd_nxtStored)) {",

	"						/* not currPair and not nxtPair */",

	"					if(mode==-1) { /* left: right == 1: m */",

	"						if((uchar*)snd_currStored==ap->left&&(uchar*)rcv_currStored!=ap->right){",

	"							updateOnOne(a, ap, snd_currStored, snd_nxtStored, ap->right);",

	"						}else if((uchar *)rcv_currStored==ap->left && (uchar *)snd_currStored != ap->right) {",

	"							updateOnOne(a, ap, rcv_currStored, rcv_nxtStored, ap->right);",

	"						}",

	"						else if((uchar *)snd_currStored==ap->right && (uchar *)rcv_currStored != ap->left ",

	"								&& ap->count > snd_currStored->pr_count) {",

	"							updateOnM(a, ap, snd_nxtStored, ap->left);",

	"						}else if((uchar *)rcv_currStored==ap->right && (uchar *)snd_currStored != ap->left",

	"								&& ap->count > rcv_currStored->pr_count) {",

	"							updateOnM(a, ap, rcv_nxtStored, ap->left);",

	"						}",

	"					}else if(mode==1) { /* left::right == m:1 */",

	"						if((uchar*)snd_currStored==ap->right&&(uchar*)rcv_currStored!=ap->left){",

	"							updateOnOne(a, ap, snd_currStored, snd_nxtStored, ap->left);",

	"						}else if((uchar *)rcv_currStored==ap->right && (uchar *)snd_currStored != ap->left) {",

	"							updateOnOne(a, ap, rcv_currStored, rcv_nxtStored, ap->left);",

	"						}",						

	"						else if((uchar*)snd_currStored==ap->left && (uchar *)rcv_currStored!=ap->right",

	"								&& ap->count > snd_currStored->pr_count) {",

	"							updateOnM(a, ap, snd_nxtStored, ap->right);",

	"						}else if((uchar *)rcv_currStored==ap->left && (uchar *)snd_currStored!=ap->right",

	"								&& ap->count > rcv_currStored->pr_count){",

	"							updateOnM(a, ap, rcv_nxtStored, ap->right);",

	"						}",

	"					}else {/* if it is 1:1 mapping, need to add some pairs to deleted ascRecord ",

	"							* those pairs were added previously due to over approximation ",

	"							*/",

	"						if(((Asc_LS0 *)ap->left)->pr_count<=0 || ((Asc_LS0 *)ap->right)->pr_count<=0) {",

	"							deleted = addRecord((Asc_LS0 *)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"							deleted->asc_id = a->id;",

	"							deleted->drift = ap->count;",

	"						}",

	"					}",				

	"				}",

	"				ap = ap->nxt;",

	"			}",

	"		}",

	"		if(a->id != curr_asc) {",

	"others:	ap = a->pairs;",

	"			while(ap){",

	"				if((uchar*)snd_currStored==ap->left&&(uchar*)rcv_currStored!=ap->right){",

	"					if(mode<=0) {/* left: right = 1: m = snd:rcv OR 1:1 */",

	"						updateOnOne(a, ap, snd_currStored, snd_nxtStored, ap->right);",

	"					}else {",

	"						updateOnM(a, ap, snd_nxtStored, ap->right);						",

	"					}",

	"				}else if((uchar*)snd_currStored==ap->right&&(uchar*)rcv_currStored!=ap->left){",

	"					if(mode<0) {/* left:right=1:m = rcv: snd */",

	"						updateOnM(a, ap, snd_nxtStored, ap->left);",

	"					}else {",

	"						updateOnOne(a, ap, snd_currStored, snd_nxtStored, ap->left);",

	"					}",								

	"				}else if((uchar*)rcv_currStored==ap->right&&(uchar*)snd_currStored!=ap->left){",

	"					if(mode<0) {/* left:right = 1: m = snd:rcv */",

	"						updateOnM(a, ap, rcv_nxtStored, ap->left);",

	"					}else {",

	"						updateOnOne(a, ap, rcv_currStored, rcv_nxtStored, ap->left);",

	"					}",

	"				}else if((uchar*)rcv_currStored==ap->left&&(uchar*)snd_currStored!=ap->right){",

	"					if(mode<=0) { /* left:right = 1: m = rcv: snd */",

	"						updateOnOne(a, ap, rcv_currStored, rcv_nxtStored, ap->right);",

	"					}else {",

	"						updateOnM(a, ap, rcv_nxtStored, ap->right);",

	"					}",

	"				}",

	"				ap = ap->nxt;",

	"			}",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	updateSamePair(); /* 26 Feb */",

	"	removeUnusedAsc();",

	"}",

	"",

	/* updateAP() */
#if 0
	"/* only for forward move */",

	"void updateAP(Asc *a,  AscPair* ap, int numRef,Asc_LS0* matched_curr, Asc_LS0 *matched_nxt)",

	"{",

	"	int refCount, remain;",

	"	AscPair *new_ap;",

	"	AscPair *x = ap;",

	"",

	"	remain = numRef;",

	"	while(x){",

	"		if(!remain)",

	"			return;",

	"		refCount = min(remain, x->count);",

	"		if(x->left==(uchar*)matched_curr){			",

	"			if(refCount>0){",

	"				new_ap = addAscPair(a, x->right, (uchar*)matched_nxt);",

	"				new_ap->count +=(refCount-1);",

	"				x->count = x->count - refCount;",

	"				remain = remain - refCount; ",

	"",

	"				/* update deleted record */",

	"				inserted = addRecord((Asc_LS0 *)x->right, matched_nxt, inserted);",

	"				inserted->asc_id = a->id;",

	"				inserted->drift = refCount;",

	"",

	"				deleted = addRecord((Asc_LS0 *)x->left, (Asc_LS0 *)x->right, deleted);",

	"				deleted->asc_id = a->id;",

	"				deleted->drift = refCount;",

	"			}",

	"		}else if(x->right==(uchar*)matched_curr){",

	"			if(refCount>0){",

	"				new_ap = addAscPair(a, x->left, (uchar*)matched_nxt);",

	"				new_ap->count +=(refCount-1);",

	"				x->count = x->count - refCount;",

	"				remain = remain - refCount; ",

	"",

	"				/* update deleted record */",

	"				inserted = addRecord((Asc_LS0 *)x->left, matched_nxt, inserted);",

	"				inserted->asc_id = a->id;",

	"				inserted->drift = refCount;",

	"",

	"				deleted = addRecord((Asc_LS0 *)x->left, (Asc_LS0 *)x->right, deleted);",

	"				deleted->asc_id = a->id;",

	"				deleted->drift = refCount;",

	"			}",

	"		}",

	"		x = x->nxt;",

	"	}",

	"}",

	"",

	/* updateRelatedAsc() */

	"/* only for forward movement */",

	"void updateRelatedAsc(Asc_LS0 *snd_currStored, Asc_LS0 *rcv_currStored, Asc_LS0 *snd_nxtStored, ",

	"					  Asc_LS0 *rcv_nxtStored, uchar curr_asc)",

	"{",

	"	Asc *a;",

	"	AscPair *ap, *new_ap, *currPair;",

	"	short mode;",

	"	int mul, numRef;",

	"	Asc_LS0 *o_left, *o_right, *n_left, *n_right;",

	"",

	"	a = global_ascList;",

	"	inserted = (AscRecord *)0;",

	"	deleted = (AscRecord *)0;",

	"	while(a){	",

	"		mode = a->mul_mode;",

	"		mul = a->multiplicity;",

	"		if(a->id == curr_asc) {",

	"			currPair = findAscPair(a, (uchar*)snd_currStored, (uchar*)rcv_currStored);",

	"			if(!currPair){",

	"				goto others;",

	"			}",

	"			if((uchar*)snd_currStored==currPair->left&&(uchar*)rcv_currStored==currPair->right){",

	"				if(mode==-1){/* left::right == 1:m == snd::rcv */",

	"					numRef = getRefNum(a->pairs, snd_currStored) - mul*(snd_currStored->pr_count);",

	"					if(numRef>0){",

	"						updateAP(a, a->pairs, numRef, snd_currStored, snd_nxtStored);",

	"					}",

	"				}",

	"				if(mode==1) {/* left::right == m:1 == snd::rcv */",

	"					numRef = getRefNum(a->pairs, rcv_currStored) - mul*(rcv_currStored->pr_count);",

	"					if(numRef>0){",

	"						updateAP(a, a->pairs, numRef, rcv_currStored, rcv_nxtStored);",

	"					}",

	"				}",

	"			}else if((uchar*)snd_currStored==currPair->right&&(uchar*)rcv_currStored==currPair->left){",

	"				if(mode==-1){/*  left::right == 1:m == rcv::snd */",

	"					numRef = getRefNum(a->pairs, rcv_currStored) - mul*(rcv_currStored->pr_count);",

	"					if(numRef>0){",

	"						updateAP(a, a->pairs, numRef, rcv_currStored, rcv_nxtStored);",

	"					}",

	"				}",

	"				if(mode==1){/* left::right == m:1 == rcv::snd */",

	"					numRef = getRefNum(a->pairs, snd_currStored) - mul*(snd_currStored->pr_count);",

	"					if(numRef>0){",

	"						updateAP(a, a->pairs, numRef, snd_currStored, snd_nxtStored);",

	"					}",

	"				}",

	"			}",

	"		}",

	"		if(a->id != curr_asc) {",

	"others:	ap = a->pairs;",

	"			while(ap){",

	"				if((uchar*)snd_currStored==ap->left&&(uchar*)rcv_currStored!=ap->right){",

	"					if(mode<=0) {/* 1:m and 1:1 */",

	"						numRef = getRefNum(ap, snd_currStored) - mul*(snd_currStored->pr_count);",

	"						if(numRef>0) {",

	"							updateAP(a, ap, numRef, snd_currStored, snd_nxtStored);/* whole list is searched */",

	"							break;",

	"						}",

	"					}else { /* m:1 -- always need to add new pair */",

	"						new_ap = addAscPair(a, (uchar*)snd_nxtStored, ap->right);",

	"						ap->count--;",

	"",						

	"						/* record */",

	"						inserted = addRecord(snd_nxtStored, (Asc_LS0 *)ap->right, inserted);",

	"						inserted->asc_id = a->id;",

	"						inserted->drift = 1;",

	"",

	"						deleted = addRecord((Asc_LS0*)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"						deleted->asc_id = a->id;",

	"						deleted->drift = 1;",

	"",

	"						break;",

	"					}",

	"				}else if((uchar*)snd_currStored==ap->right&&(uchar*)rcv_currStored!=ap->left){",

	"					if(mode<0) {/* 1:m  */",

	"						new_ap = addAscPair(a, (uchar*)snd_nxtStored, ap->left);",

	"						ap->count--;",

	"",

	"						/* record */",

	"						inserted = addRecord(snd_nxtStored, (Asc_LS0 *)ap->left, inserted);",

	"						inserted->asc_id = a->id;",

	"						inserted->drift = 1;",

	"",

	"						deleted = addRecord((Asc_LS0*)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"						deleted->asc_id = a->id;",

	"						deleted->drift = 1;",

	"						break;",

	"					}else { /* m:1 and 1:1  -- always need to add new pair (snd_curr is on the 1 side) */",

	"						numRef = getRefNum(ap, snd_currStored) - mul*(snd_currStored->pr_count);",

	"						if(numRef>0) {						",

	"							updateAP(a, ap, numRef, snd_currStored, snd_nxtStored);/* whole list is searched */",

	"							break;",

	"						}",

	"					}",

	"				}else if((uchar*)rcv_currStored==ap->right&&(uchar*)snd_currStored!=ap->left){",

	"					if(mode<0) {/* left::right == 1:m == snd::rcv */",

	"						new_ap = addAscPair(a, ap->left, (uchar*)rcv_nxtStored);",

	"						ap->count--;",

	"",

	"						/* record */",

	"						inserted = addRecord(rcv_nxtStored, (Asc_LS0 *)ap->left, inserted);",

	"						inserted->asc_id = a->id;",

	"						inserted->drift = 1;",

	"",

	"						deleted = addRecord((Asc_LS0*)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"						deleted->asc_id = a->id;",

	"						deleted->drift = 1;",

	"						break;",

	"					}else{ /* m:1 and 1:1 (on 1 side) */",

	"						numRef = getRefNum(ap, rcv_currStored) - mul*(rcv_currStored->pr_count);",

	"						if(numRef>0){",

	"							updateAP(a, ap, numRef, rcv_currStored, rcv_nxtStored);/* whole list is searched */",

	"							break;",

	"						}",

	"					}",

	"				}else if((uchar*)rcv_currStored==ap->left&&(uchar*)snd_currStored!=ap->right){",

	"					if(mode<=0) {/* 1:1 and 1:m (on 1 side) */",

	"						numRef = getRefNum(ap, rcv_currStored) - mul*(rcv_currStored->pr_count);",

	"						if(numRef>0){",

	"							updateAP(a, ap, numRef, rcv_currStored, rcv_nxtStored);/* whole list is searched */",

	"							break;",

	"						}",

	"					}else{/* m:1*/",

	"						new_ap = addAscPair(a, ap->right, (uchar*)rcv_nxtStored);",

	"						ap->count--;",

	"",

	"						/* record */",

	"						inserted = addRecord(rcv_nxtStored, (Asc_LS0 *)ap->right, inserted);",

	"						inserted->asc_id = a->id;",

	"						inserted->drift = 1;",

	"",

	"						deleted = addRecord((Asc_LS0*)ap->left, (Asc_LS0 *)ap->right, deleted);",

	"						deleted->asc_id = a->id;",

	"						deleted->drift = 1;",

	"						break;",

	"					}",

	"				}",

	"				ap = ap->nxt;",

	"			}",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	removeUnusedAsc();",

	"}",

	"",
#endif 

	/* imposeAsc() */

	"void imposeAsc(uchar* snd_currLS, uchar* rcv_currLS, uchar *snd_nxtLS, uchar* rcv_nxtLS, ",

	"				short backward)",

	"{",

	"	short foundSnd, foundRcv, ascFound;",

	"	Asc_LS0 *snd_nxtStored = 0, *rcv_nxtStored = 0, *snd_currStored = 0, *rcv_currStored = 0, *left = 0, *right = 0; ",

	"	Asc *a = 0, *found_a = 0;",

	"	Asc_LS0 *al = 0;",

	"	AscRecord *tmpRecord = 0;",

	"	AscPair *o_ap = 0, *n_ap = 0;",

	"",

	"	if(!snd_nxtLS||!rcv_nxtLS)",

	"		return;",

	"",

	"	al = (Asc_LS0 *)asc_space;	",

	"	foundSnd = 0;",

	"	foundRcv = 0;",

	"",

	"	/* STEP 1: record count */",

	"	snd_currStored = findAscLS(snd_currLS);",

	"	if(snd_currLS)",

	"		((Asc_LS0 *)snd_currLS)->pr_count = (snd_currStored)?snd_currStored->pr_count:0;",

	"	rcv_currStored = findAscLS(rcv_currLS);",

	"	if(rcv_currLS)",

	"		((Asc_LS0 *)rcv_currLS)->pr_count = (rcv_currStored)?rcv_currStored->pr_count:0;",

	"",

	"	a = global_ascList;",

	"	o_pairCount = 0;",

	"	o_ap = 0;",

	"	while(a) {",

	"		if(a->id == asc_id) {",

	"			o_ap = findAscPair(a, (uchar*)snd_currStored, (uchar *)rcv_currStored);",

	"			break;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	o_pairCount = (o_ap)?o_ap->count:0;",

	"",

	"	snd_nxtStored = findAscLS(snd_nxtLS);",

	"	if(snd_nxtLS)",

	"		((Asc_LS0 *)snd_nxtLS)->pr_count = (snd_nxtStored)?snd_nxtStored->pr_count:0;",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS);",

	"	if(rcv_nxtLS)",

	"		((Asc_LS0 *)rcv_nxtLS)->pr_count = (rcv_nxtStored)?rcv_nxtStored->pr_count:0;",

	"",

	"	a = global_ascList;",

	"	n_pairCount = 0;",

	"	n_ap = 0;",

	"	found_a = 0;",

	"	while(a) {",

	"		if(a->id == asc_id) {",

	"			found_a = a;",

	"			n_ap = findAscPair(a, (uchar *)snd_nxtStored, (uchar *)rcv_nxtStored);",

	"			break;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	n_pairCount = (n_ap)?n_ap->count:0;",

	"",

	"	/* STEP 2: update */",

	"	if(!snd_nxtStored) {",

	"		snd_nxtStored = addAscLS(snd_nxtLS, backward);",

	"	}",

	"	snd_nxtStored->pr_count = (snd_nxtStored->pr_count>0)?(snd_nxtStored->pr_count + 1):1;",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS); /* need to check, in case rcv_nxtStored == snd_nxtStored */",

	"	if(!rcv_nxtStored) {",

	"		rcv_nxtStored = addAscLS(rcv_nxtLS, backward);",

	"	}",

	"	rcv_nxtStored->pr_count = (rcv_nxtStored->pr_count>0)?(rcv_nxtStored->pr_count + 1):1;",

	"",

	"	/* step 3: search for AscPair(snd_nxtLS, rcv_nxtLS), if not found, then create a new pair and add to global_ascList */",

	"	if(found_a){",

	"		addAscPair(found_a, (uchar *)snd_nxtStored, (uchar*)rcv_nxtStored);",

	"	}else {",

	"	/* add new Asc */",

	"	Asc *tmp = (Asc *)malloc(sizeof(Asc));",

	"	extra_memAsc += sizeof(Asc);",

	"	if(extra_memAsc>max_memAsc)",

	"		max_memAsc = extra_memAsc;",

	"		tmp->id = asc_id;",

	"		tmp->nxt = global_ascList;",

	"		tmp->pairs = (AscPair *)0;",

	"		tmp->pre = (Asc*)0;",

	"		tmp->mul_mode = mul_mode;",

	"		tmp->multiplicity = mul;",

	"",

	"		if(global_ascList){",

	"			global_ascList->pre = tmp;",

	"		}",

	"		global_ascList = tmp;",

	"		addAscPair(tmp, (uchar*)snd_nxtStored, (uchar*)rcv_nxtStored);",

	"	}",

	"",

	"	/* step 4: decrement curr_ pr_count (may not exist) */",

	"	snd_currStored = findAscLS(snd_currLS);",

	"	if(snd_currStored)",

	"		snd_currStored->pr_count = (snd_currStored->pr_count>0)?(snd_currStored->pr_count - 1):0; /* lower bound is 0 */",

	"	rcv_currStored = findAscLS(rcv_currLS);",

	"	if(rcv_currStored)",

	"		rcv_currStored->pr_count = (rcv_currStored->pr_count>0)?(rcv_currStored->pr_count - 1):0;",

	"",

	"	/* step 5: update related asc - */",

	"	if(snd_currStored ||rcv_currStored) {/* if not exist, no need to update */",

	"		updateRelatedAsc_over(snd_currStored, rcv_currStored, snd_nxtStored, rcv_nxtStored, asc_id);		",

	"	}",

	"}",

	"",

	/* releaseAsc() */

	"void releaseAsc(uchar *snd_currLS, uchar *rcv_currLS, uchar *snd_nxtLS, uchar* rcv_nxtLS,",

	"				short backward)",

	"{",

	"	/* step 1: look for snd_currLS and rcv_currLS separately */",

	"	Asc_LS0 *snd_currStored, *rcv_currStored, *snd_nxtStored, *rcv_nxtStored;",

	"	AscPair *o_ap = (AscPair*)0;",

	"	AscPair *n_ap = (AscPair *)0;",

	"	Asc* a;",

	"",

	"	snd_currStored = findAscLS(snd_currLS);",

	"	rcv_currStored = findAscLS(rcv_currLS);",

	"",

	"	if(!snd_currStored || !rcv_currStored)",

	"		uerror(\"1. wrong Asc_LS\");",

	"",

	"	if(snd_currStored->pr_count==0 || rcv_currStored->pr_count==0)",

	"		uerror(\"2. wrong Asc_LS\");",

	"",

	"	/* look for ascPair(tmp_currSnd, tmp_currRcv) */",

	"	a = global_ascList;",

	"	while(a) {",

	"		if(a->id==asc_id){",

	"			o_ap = findAscPair(a, (uchar*)snd_currStored, (uchar*)rcv_currStored);",

	"			break;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	if(!o_ap)",

	"		uerror(\"forward release: AscPair not found! \");",

	"",

	"	/* STEP 1: record count */",

	"	((Asc_LS0 *)snd_currLS)->pr_count = snd_currStored->pr_count;",

	"	((Asc_LS0 *)rcv_currLS)->pr_count = rcv_currStored->pr_count;",

	"	o_pairCount = o_ap->count; ",

	"",

	"	snd_nxtStored = findAscLS(snd_nxtLS);",

	"	if(snd_nxtLS)",

	"		((Asc_LS0 *)snd_nxtLS)->pr_count = (snd_nxtStored)?snd_nxtStored->pr_count:0;",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS);",

	"	if(rcv_nxtLS)",

	"		((Asc_LS0 *)rcv_nxtLS)->pr_count = (rcv_nxtStored)?rcv_nxtStored->pr_count:0;",

	"",

	"	n_pairCount = 0;",

	"	a = global_ascList;",

	"	while(a){",

	"		if(a->id == asc_id){",

	"			n_ap = findAscPair(a, (uchar*)snd_nxtStored, (uchar *)rcv_nxtStored);",

	"			break;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	n_pairCount = (n_ap)?n_ap->count:0;",

	"",

	"	/* STEP 2: update count */",

	"	snd_currStored->pr_count = (snd_currStored->pr_count>0)?(snd_currStored->pr_count - 1):0; /* lower bound is 0 */",

	"	rcv_currStored->pr_count = (rcv_currStored->pr_count>0)?(rcv_currStored->pr_count - 1):0; /* lower bound is 0 */",

	"	o_ap->count--;",

	"",

	"	/* step 2: look for snd_nxtLS and rcv_nxtLS (may not exist) */",

	"	/* may add in ascLS that never been involved in any asc */",

	"	if(!snd_nxtStored)",

	"		snd_nxtStored = addAscLS(snd_nxtLS, backward);",

	"	snd_nxtStored->pr_count = (snd_nxtStored->pr_count>0)?(snd_nxtStored->pr_count + 1):1;",

	"",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS); /* need to check again, in case snd_nxtStored == rcv_nxtStored */",

	"	if(!rcv_nxtStored)",

	"		rcv_nxtStored = addAscLS(rcv_nxtLS, backward);",

	"	rcv_nxtStored->pr_count = (rcv_nxtStored->pr_count>0)?(rcv_nxtStored->pr_count + 1):1;",

	"",

	"	/* step 3: update related asc*/",

	"	updateRelatedAsc_over(snd_currStored, rcv_currStored, snd_nxtStored, rcv_nxtStored, asc_id);",

	"}",

	"",

	/* carryPair() */

	"void carryPair(uchar *snd_currLS, uchar *rcv_currLS, uchar *snd_nxtLS, uchar* rcv_nxtLS, ",

	"				short backward)",

	"{",

	"	Asc_LS0 *snd_currStored, *rcv_currStored, *snd_nxtStored, *rcv_nxtStored;",

	"	AscPair *ap, *n_ap;",

	"	Asc* a;",

	"	short pairFound;",

	"",

	"	/* step 1: decrease current */",

	"	snd_currStored = findAscLS(snd_currLS);",

	"	rcv_currStored = findAscLS(rcv_currLS);",

	"",

	"	if(!snd_currStored || !rcv_currStored)",

	"		uerror(\"1. wrong Asc_LS to carry\");",

	"",

	"	if(snd_currStored->pr_count==0 || rcv_currStored->pr_count==0)",

	"		uerror(\"2. wrong Asc_LS to carry\");",

	"",

	"	/* look for ascPair(tmp_currSnd, tmp_currRcv) */",

	"	a = global_ascList;",

	"	ap = (AscPair *)0;",

	"	while(a) {",

	"		if(a->id==asc_id){",

	"			ap = findAscPair(a, (uchar*)snd_currStored, (uchar*)rcv_currStored);",

	"			break;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	if(!ap)",

	"		uerror(\"(forward carry) AscPair not found! \");",

	"",

	"	/* STEP 1: record pr_count */",

	"	((Asc_LS0 *)snd_currLS)->pr_count = snd_currStored->pr_count;",

	"	((Asc_LS0 *)rcv_currLS)->pr_count = rcv_currStored->pr_count;",

	"	o_pairCount = ap->count; ",

	"",

	"	snd_nxtStored = findAscLS(snd_nxtLS);",

	"	((Asc_LS0 *)snd_nxtLS)->pr_count = (snd_nxtStored)?snd_nxtStored->pr_count:0;",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS);",

	"	((Asc_LS0 *)rcv_nxtLS)->pr_count = (rcv_nxtStored)?rcv_nxtStored->pr_count:0;",

	"	n_ap = 0;",

	"	a = global_ascList;",

	"	while(a) {",

	"		if(a->id == asc_id) {",

	"			n_ap = findAscPair(a, (uchar*)snd_nxtStored, (uchar *)rcv_nxtStored);",

	"			break;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	n_pairCount = (n_ap)? n_ap->count:0;",

	"",	

	"	/* STEP 2: update */",

	"	snd_currStored->pr_count = (snd_currStored->pr_count>0)?(snd_currStored->pr_count - 1):0; /* lower bound is 0 */",

	"	rcv_currStored->pr_count = (rcv_currStored->pr_count>0)?(rcv_currStored->pr_count - 1):0; /* lower bound is 0 */",

	"	ap->count--;",

	"",

	"	/* step 2: increase nxt */",

	"	/* if not exists, create a new one and add to asc_space */",

	"	if(!snd_nxtStored) ",

	"		snd_nxtStored = addAscLS(snd_nxtLS, backward);",

	"	snd_nxtStored->pr_count = (snd_nxtStored->pr_count>0)?(snd_nxtStored->pr_count + 1):1;",

	"",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS); /* need to check it since snd_nxtStored is added, in case they r the same */",

	"	if(!rcv_nxtStored)",

	"		rcv_nxtStored = addAscLS(rcv_nxtLS, backward);",

	"	rcv_nxtStored->pr_count = (rcv_nxtStored->pr_count>0)?(rcv_nxtStored->pr_count + 1):1;",

	"",

	"	if(n_ap) {",

	"		n_ap->count++;",

	"	}else {",

	"		addAscPair(a, (uchar*)snd_nxtStored, (uchar*)rcv_nxtStored);",

	"	}",

	"",

	"	/* step 4: update related */",

	"	updateRelatedAsc_over(snd_currStored, rcv_currStored, snd_nxtStored, rcv_nxtStored, asc_id);",	

	"}",

	/* carrySingle() */

	"/* asc_status = 4 or 3: no need to look for AscPair */",

	"void carrySingle(uchar *snd_currLS, uchar *rcv_currLS, uchar *snd_nxtLS, uchar* rcv_nxtLS,",

	"				short backward)",

	"{",

	"	Asc_LS0 *snd_currStored, *rcv_currStored, *snd_nxtStored, *rcv_nxtStored;",

	"	AscPair *ap;",

	"	Asc* a;",

	"",

	"	/* step 1: decrease current (may not exist) */",

	"	snd_currStored = findAscLS(snd_currLS);",

	"	if(snd_currLS)",

	"		((Asc_LS0 *)snd_currLS)->pr_count = (snd_currStored)? (snd_currStored->pr_count):0;",

	"	rcv_currStored = findAscLS(rcv_currLS);",

	"	if(rcv_currLS)",

	"		((Asc_LS0 *)rcv_currLS)->pr_count = (rcv_currStored)?(rcv_currStored->pr_count):0;",

	"	snd_nxtStored = findAscLS(snd_nxtLS);",

	"	if(snd_nxtLS)",

	"		((Asc_LS0 *)snd_nxtLS)->pr_count = (snd_nxtStored)?snd_nxtStored->pr_count:0;",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS);",

	"	if(rcv_nxtLS)",

	"		((Asc_LS0 *)rcv_nxtLS)->pr_count = (rcv_nxtStored)?rcv_nxtStored->pr_count:0;",

	"",

	"	if(snd_currStored)",

	"		snd_currStored->pr_count = (snd_currStored->pr_count>0)?(snd_currStored->pr_count - 1):0;",

	"	if(rcv_currStored)",

	"		rcv_currStored->pr_count = (rcv_currStored->pr_count>0)?(rcv_currStored->pr_count - 1):0;",

	"",

	"	/* if snd_currStored exists, then need to create snd_nxtStored, since the proctype of snd_currStored is involved",

	"	* in some asc, so need to update",

	"	*/",

	"	if(snd_nxtStored) {",

	"		snd_nxtStored->pr_count = (snd_nxtStored->pr_count>0)?(snd_nxtStored->pr_count + 1):1;",

	"	}else if(snd_currStored){",

	"		snd_nxtStored = addAscLS(snd_nxtLS, backward);",

	"		snd_nxtStored->pr_count = (snd_nxtStored->pr_count>0)?(snd_nxtStored->pr_count + 1):1;",

	"	}",

	"	rcv_nxtStored = findAscLS(rcv_nxtLS);",

	"	if(rcv_nxtStored){",

	"		rcv_nxtStored->pr_count = (rcv_nxtStored->pr_count>0)?(rcv_nxtStored->pr_count + 1):1;",

	"	}else if(rcv_currStored) {",

	"		rcv_nxtStored = addAscLS(rcv_nxtLS, backward);",

	"		rcv_nxtStored->pr_count = (rcv_nxtStored->pr_count>0)?(rcv_nxtStored->pr_count + 1):1;",

	"	}",

	"",

	"	if(snd_currStored || rcv_currStored) {",

	"		updateRelatedAsc_over(snd_currStored, rcv_currStored, snd_nxtStored, rcv_nxtStored, 0);",	

	"	}",

	"}",

	"",

	/* forward_asc() */

	"void forward_asc()",

	"{",

	"	Asc_LS0 *tmp;",

	"",

	"	if(isRcv) {",

	"		inserted = (AscRecord *)0;",

	"		deleted - (AscRecord*)0;",

	"		newAscLS = (AscLS *)0; /* ss: 22 Jan 08 */",

	"		switch(asc_status) {",

	"		case 0: /* impose - add to list */",

	"			imposeAsc((trpt-1)->o_sndAsc, (trpt-1)->o_rcvAsc, (trpt-1)->n_sndAsc, (trpt-1)->n_rcvAsc, 0);",

	"			(trpt-1)->inserted = inserted;",

	"			(trpt-1)->deleted = deleted;",

	"			(trpt-1)->newAscLS = newAscLS;",

	"			(trpt-1)->o_pairCount = o_pairCount;",

	"			(trpt-1)->n_pairCount = n_pairCount;",

	"			break;",

	"		case 1: /* carry - check asc */",

	"			carryPair((trpt-1)->o_sndAsc, (trpt-1)->o_rcvAsc, (trpt-1)->n_sndAsc, (trpt-1)->n_rcvAsc, 0);",

	"			(trpt-1)->inserted = inserted;",

	"			(trpt-1)->deleted = deleted;",

	"			(trpt-1)->newAscLS = newAscLS;",

	"			(trpt-1)->o_pairCount = o_pairCount;",

	"			(trpt-1)->n_pairCount = n_pairCount;",

	"			break;",

	"		case 2: /* remove - delete asc */",

	"			releaseAsc((trpt-1)->o_sndAsc, (trpt-1)->o_rcvAsc, (trpt-1)->n_sndAsc, (trpt-1)->n_rcvAsc, 0);",

	"			(trpt-1)->inserted = inserted;",

	"			(trpt-1)->deleted = deleted;",

	"			(trpt-1)->newAscLS = newAscLS;",

	"			(trpt-1)->o_pairCount = o_pairCount;",

	"			(trpt-1)->n_pairCount = n_pairCount;",

	"			break;",

	"		case 3: ",

	"			carrySingle((trpt-1)->o_sndAsc, (trpt-1)->o_rcvAsc, (trpt-1)->n_sndAsc, (trpt-1)->n_rcvAsc, 0);",

	"			(trpt-1)->inserted = inserted;",

	"			(trpt-1)->deleted = deleted;",

	"			(trpt-1)->newAscLS = newAscLS;",

	"			(trpt-1)->o_pairCount = 0;",

	"			(trpt-1)->n_pairCount = 0;",

	"			break;",

	"		case 4:",

	"			carrySingle(trpt->o_sndAsc, 0, trpt->n_sndAsc, 0, 0);",

	"			trpt->inserted = inserted;",

	"			trpt->deleted = deleted;",

	"			trpt->newAscLS = newAscLS;",

	"			trpt->o_pairCount = 0;",

	"			trpt->n_pairCount = 0;",

	"		}",

	"		/*reset flags*/",

	"		asc_status = 3;",

	"		isRcv = 0;",

	"",

	"		if(snd_currLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_currLS)->_t);	",

	"			free(snd_currLS);",

	"		}",

	"		snd_currLS = (uchar *)0;",

	"		if(snd_nxtLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_nxtLS)->_t);	",

	"			free(snd_nxtLS);",

	"		}",

	"		snd_nxtLS = (uchar *)0;",

	"		if(rcv_currLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)rcv_currLS)->_t);	",

	"			free(rcv_currLS);",

	"		}",

	"		rcv_currLS = (uchar *)0;",

	"		if(rcv_nxtLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)rcv_nxtLS)->_t);	",

	"			free(rcv_nxtLS);",

	"		}",

	"		rcv_nxtLS = (uchar *)0;",

	"",

	"		inserted = (AscRecord *)0;",

	"		deleted = (AscRecord *)0;",

	"		newAscLS = (AscLS *)0;",

	"		return;",

	"	}",

	"}",

	"",

	/* backward_asc() */

	"/*",

	" * called after unsend() ",

	" */",

	"void backward_asc(short rcv)",

	"{",

	"	Trail *tr;",

	"	Asc_LS0 *o_snd, *o_rcv, *n_snd, *n_rcv;",

	"	Asc *a;",

	"	AscPair *o_pair, *n_pair;",

	"	short ascFound;",

	"",

	"	if(rcv) {",

	"		tr = trpt-1;",

	"	}else{",

	"		tr = trpt;",

	"	}",

	"",

	"	asc_status = tr->asc_status;",

	"	asc_id = tr->asc_id;",

	"	if(asc_status!=4 && (!tr->n_rcvAsc || !tr->o_rcvAsc)) {",

	"		asc_status = 3;",

	"		return;",

	"	}",

	"	inserted = tr->inserted;",

	"	deleted = tr->deleted;",

	"	newAscLS = tr->newAscLS;",

	"",

	"	/* backward for curr pair*/",

	"	o_pairCount = tr->o_pairCount;",

	"	n_pairCount = tr->n_pairCount;",

	"",

	"	o_snd = 0; o_rcv = 0; n_snd = 0; n_rcv = 0;",

	"	if(tr->o_sndAsc) {",

	"		o_snd = findAscLS(tr->o_sndAsc);",

	"		if(!o_snd)",

	"			o_snd = addAscLS(tr->o_sndAsc, 1);",

	"		o_snd->pr_count = ((Asc_LS0 *)tr->o_sndAsc)->pr_count; ",

	"	}",

	"	if(tr->o_rcvAsc) {",

	"		o_rcv = findAscLS(tr->o_rcvAsc);",

	"		if(!o_rcv)",

	"			o_rcv = addAscLS(tr->o_rcvAsc, 1);",

	"		o_rcv->pr_count = ((Asc_LS0 *)tr->o_rcvAsc)->pr_count;",

	"	}",

	"	if(o_snd && o_rcv && asc_status < 3) {",

	"		a = global_ascList;",

	"		ascFound = 0;",

	"		while(a) {",

	"			if(a->id == asc_id) {",

	"				o_pair = addAscPair(a, (uchar*)o_snd, (uchar*)o_rcv);",

	"				o_pair->count = o_pairCount;",

	"				ascFound = 1;",

	"			}",

	"			a = a->nxt;",

	"		}",

	"		if(!ascFound) {/* add new asc */",

	"			Asc *tmp = (Asc *)malloc(sizeof(Asc));",

	"			tmp->id = asc_id;",

	"			tmp->nxt = global_ascList;",

	"			tmp->pairs = (AscPair *)0;",

	"			tmp->pre = (Asc*)0;",

	"			tmp->mul_mode = mul_mode;",

	"			tmp->multiplicity = mul;",

	"",

	"			if(global_ascList)",

	"				global_ascList->pre = tmp;",

	"			global_ascList = tmp;",

	"			o_pair = addAscPair(tmp, (uchar*)o_snd, (uchar*)o_rcv);",

	"			o_pair->count = o_pairCount;",

	"		}",

	"	}",

	"",

	"	if(tr->n_sndAsc) {",

	"		n_snd = findAscLS(tr->n_sndAsc);",

	"		if(!n_snd)",

	"			n_snd = addAscLS(tr->n_sndAsc, 1);",

	"		n_snd->pr_count = ((Asc_LS0 *)tr->n_sndAsc)->pr_count;",

	"	}",

	"",

	"	if(tr->n_rcvAsc) {",

	"		n_rcv = findAscLS(tr->n_rcvAsc);",

	"		if(!n_rcv)",

	"			n_rcv = addAscLS(tr->n_rcvAsc, 1);",

	"		n_rcv->pr_count = ((Asc_LS0*)tr->n_rcvAsc)->pr_count;",

	"	}",

	"",

	"	if(n_snd && n_rcv && n_snd->pr_count>0 && n_rcv->pr_count>0 && asc_status < 3) {	/* if pr_count <= 0, ",

	"																	 * then no need to add pair ",

	"																	 * as it will be deleted in the end */",

	"		a = global_ascList;",

	"		ascFound = 0;",

	"		while(a) {",

	"			if(a->id == asc_id) {",

	"				n_pair = addAscPair(a, (uchar*)n_snd, (uchar*)n_rcv);",

	"				n_pair->count = n_pairCount;",

	"				ascFound = 1;",

	"			}",

	"			a = a->nxt;",

	"		}",

	"		if(!ascFound) {/* add new asc */",

	"			Asc *tmp = (Asc *)malloc(sizeof(Asc));",

	"			tmp->id = asc_id;",

	"			tmp->nxt = global_ascList;",

	"			tmp->pairs = (AscPair *)0;",

	"			tmp->pre = (Asc*)0;",

	"			tmp->mul_mode = mul_mode;",

	"			tmp->multiplicity = mul;",

	"",

	"			if(global_ascList)",

	"				global_ascList->pre = tmp;",

	"			global_ascList = tmp;",

	"			n_pair = addAscPair(tmp, (uchar*)n_snd, (uchar*)n_rcv);",

	"			n_pair->count = n_pairCount;",

	"		}",

	"	}",

	"",

	"	backwardUpdate(o_snd, o_rcv, n_snd, n_rcv, asc_id);",



	"	/* reset flags */",

	"	asc_status = 3;",

	"",

	"	inserted = (AscRecord *)0;",

	"	deleted = (AscRecord *)0;",

	"	newAscLS = (AscLS*)0;",

	"	if(rcv) {",

	"		(trpt-1)->inserted = (AscRecord *)0;",

	"		(trpt-1)->deleted = (AscRecord *)0;",

	"		(trpt-1)->newAscLS = (AscLS *)0;",

	"	}else {",

	"		trpt->inserted = (AscRecord *)0;",

	"		trpt->deleted = (AscRecord *)0;",

	"		trpt->newAscLS = (AscLS *)0;",

	"	}",

	"}",

	"",

	/* snderInAsc() */



	"/* ",

	" * applicable for carry or remove asc ",

	" * return 1 if ascStaus == 3 or this_ls is in some ascPair",

	" */",

	"short snderInAsc(int ascId, int ascStatus)",

	"{",

	"	Asc *a; ",

	"	AscPair *ap;",

	"",

	"	if(ascStatus != 1 && ascStatus != 2) /* not related to asc */",

	"		return 1;",

	"",

	"	a = global_ascList;",

	"	while(a){",

	"		if(a->id == ascId) {",

	"			if(snd_currLS){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_currLS)->_t);",

	"				free(snd_currLS);",

	"			}",

	"			snd_currLS = (uchar*)convertAscLS(this_ls);",

	"			/* look for ascpair */",

	"			ap = a->pairs;",

	"			while(ap) {",

	"				if(!compare_AscLS(snd_currLS, ap->left)||!compare_AscLS(snd_currLS, ap->right))",

	"					return 1;",

	"				ap = ap->nxt;",

	"			}",

	"			if(snd_currLS){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_currLS)->_t);	",

	"				free(snd_currLS); /* free space */",

	"			}",

	"			snd_currLS = (uchar *)0;",

	"			return 0;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	return 0;",

	"}",

	"",

	/* ascPairExists() */

	"/*",

	" * function only applies on carry or remove asc",

	" */",

	"short ascPairExists(int ascId, int ascStatus)",

	"{",

	"	Asc *a;",

	"	uchar *snd_currStored, *rcv_currStored;",

	"",

	"	if(ascStatus != 1 && ascStatus != 2) ",

	"		return 1;",

	"",

	"	a = global_ascList;",

	"	while(a) {",

	"		if(a->id == ascId) {",

	"			if(rcv_currLS){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)rcv_currLS)->_t);	",

	"				free(rcv_currLS);",

	"			}",

	"			rcv_currLS = (uchar*)convertAscLS(this_ls);",

	"			rcv_currStored = (uchar*)findAscLS(rcv_currLS);",

	"			/*	snd_currStored = (uchar*)findAscLS(snd_currLS); */",

	"			snd_currStored = (uchar*)findAscLS(trpt->o_sndAsc); /* called in tm, so trpt no need to decrement */",

	"",

	"			if(findAscPair(a, snd_currStored, rcv_currStored)) {",

	"				return 1;",

	"			}",

	"			if(rcv_currLS){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)rcv_currLS)->_t);	",

	"				free(rcv_currLS);",

	"			}",

	"			rcv_currLS = (uchar *)0;",

	"			return 0;",

	"		}",

	"		a = a->nxt;",

	"	}",

	"	return 0;",

	"}",

	/*  () */

	"void forwardUpdateAsc() {",

	"	if(isRcv) { /* qrecv is called */",

	"		if(rcv_nxtLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)rcv_nxtLS)->_t);	",

	"			free(rcv_nxtLS);",

	"		}",

	"		rcv_nxtLS = (uchar *)convertAscLS(this_ls);",

	"		if(asc_status!=4) {",

	"			if((trpt-1)->n_rcvAsc){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)(trpt-1)->n_rcvAsc)->_t);",

	"				free((trpt-1)->n_rcvAsc);",

	"			}",

	"			(trpt-1)->n_rcvAsc = (uchar *)convertAscLS(this_ls);",

	"		}else {",

	"			/* ASGN - only one step */",

	"			if(snd_nxtLS){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_nxtLS)->_t);	",

	"				free(snd_nxtLS);",

	"			}",

	"			snd_nxtLS = (uchar *)convertAscLS(this_ls);",

	"			if(trpt->n_rcvAsc){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)trpt->n_rcvAsc)->_t);",

	"				free(trpt->n_rcvAsc);",

	"			}",

	"			/* trpt->n_rcvAsc = (uchar *)convertAscLS(this_ls); */",

	"			trpt->n_rcvAsc = 0;",

	"			if(trpt->n_sndAsc){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)trpt->n_sndAsc)->_t);",

	"				free(trpt->n_sndAsc);",

	"			}",

	"			trpt->n_sndAsc = (uchar *)convertAscLS(this_ls);",

	"		}",

	"	}else {",

	"		if(snd_nxtLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_nxtLS)->_t);	",

	"			free(snd_nxtLS);",

	"		}",

	"		snd_nxtLS = (uchar *)convertAscLS(this_ls);",

	"		if(trpt->n_sndAsc){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)trpt->n_sndAsc)->_t);",

	"			free(trpt->n_sndAsc);",

	"		}",

	"		trpt->n_sndAsc = (uchar *)convertAscLS(this_ls);",

	"		if(trpt->o_rcvAsc){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)trpt->o_rcvAsc)->_t);",

	"			free(trpt->o_rcvAsc);",

	"		}",

	"		trpt->o_rcvAsc = (uchar *)0;",

	"		if(trpt->n_rcvAsc){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)trpt->n_rcvAsc)->_t);",

	"			free(trpt->n_rcvAsc);",

	"		}",

	"		trpt->n_rcvAsc = (uchar *)0;",

	"	}",

	"}",

	0,

};





static char *convertAscLS_ss1[] = {

	"Asc_LS0* convertAscLS(uchar *this_ls)",

	"{	",

	"	switch(((P0 *)this)->_t) {",

	0,

};



static char *convertAscLS_ss2[] = {

	"	case %d: {",

	"		Asc_LS%d *l%d = (Asc_LS%d *)malloc(sizeof(Asc_LS%d));",

	"		extra_memAsc += sizeof(Asc_LS%d);",

	"		if(extra_memAsc>max_memAsc)",

	"			max_memAsc = extra_memAsc;",

	"		l%d->_t = %d;",

	"		l%d->_p = ((LocalState%d *)this_ls)->_p;",

	0,

};

static char *ascVars_ss[] = {

	"/* ss: for asc */",
	"uchar *snd_currLS = 0, *snd_nxtLS = 0, *rcv_currLS = 0, *rcv_nxtLS = 0; /* Asc_LS */",
	"short asc_status; /* impose = 0, carry = 1, remove = 2, not_asc = 3 */",
	"int chan_id;",
	"short isRcv;",
	"uchar asc_id; ",
	"uchar* asc_space = 0;",
	"short mul_mode, mul;",
	"AscRecord *inserted = 0, *deleted = 0;",
	"Asc *global_ascList = 0;",
	"AscLS *newAscLS = 0; /* corresponds to trpt->newAscLS, a list of pointers to newly added ASC, which can be removed in backtrack */",
	"/*****/",
	"int o_pairCount, n_pairCount; /* ss: for asc backward */", /* 28 Feb */
};

static char *omegaVars_ss[] = {
		/* for OMEGA */
#if 0
	"/* ss: for br */",
	"short br_status; ",
	"short isBrSnd; /* 1 to all avail partitions */",
	"/*************/",
#endif
	"short lsUpdated; /* ss: if ls is udpated in pan.m (for assignment), ",
	"				   * then no need to do it again in update_this_ls()",
	"				   */",
	"short par_deleted = 0; /* to preserve the pos of the deleted partition during forward */",
	/*************/
	0,
};





static char *ascInUpdateThisLS_ss[] = {

	"	/* ss: for asc - not generic, only for rv ",

	"	*  this block should not be accessed during backtracking, isRcv should be able to ensure that",

	"	*/",

	"	if(isRcv) { /* qrecv is called */",

	"		if(rcv_nxtLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)rcv_nxtLS)->_t);	",

	"			free(rcv_nxtLS);",

	"		}",

	"		rcv_nxtLS = (uchar *)convertAscLS(this_ls);",

	"		if(asc_status!=4) {",

	"			(trpt-1)->n_rcvAsc = (uchar *)convertAscLS(this_ls);",

	"		}else {",

	"			/* ASGN - only one step */",

	"			if(snd_nxtLS){",

	"				extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_nxtLS)->_t);	",

	"				free(snd_nxtLS);",

	"			}",

	"			snd_nxtLS = rcv_nxtLS;",

	"			trpt->n_rcvAsc = (uchar *)convertAscLS(this_ls);",

	"			trpt->n_sndAsc = trpt->n_rcvAsc;",

	"		}",

		/*	isRcv = 0; 

		 */

	"	}else {",

	"		if(snd_nxtLS){",

	"			extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_nxtLS)->_t);	",

	"			free(snd_nxtLS);",

	"		}",

	"		snd_nxtLS = (uchar *)convertAscLS(this_ls);",

	"		trpt->n_sndAsc = (uchar *)convertAscLS(this_ls);",

	"		/*tmp_nxtSnder = this_ls; */",

	"	}",

	"	/***/",

	0,

};



static char* ascTmAsgn_ss[] = {

	"#ifndef NOASC",

	"		/* ss: for asc -- ASGN */",

	"	asc_status = 4; /* ASGN */",

	"	if(snd_currLS){",

	"		extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)snd_currLS)->_t);	",

	"		free(snd_currLS);",

	"	}",

	"	snd_currLS = (uchar*)convertAscLS(this_ls);",

	"	if(rcv_currLS){",

	"		extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0*)rcv_currLS)->_t);	",

	"		free(rcv_currLS);",

	"	}",

	"	rcv_currLS = (uchar *)convertAscLS(this_ls);",

	"	isRcv = 1;",

	"	if((trpt+1)->o_sndAsc){",

	"		extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)(trpt+1)->o_sndAsc)->_t);",

	"		free((trpt+1)->o_sndAsc);",

	"	}",

	"	(trpt+1)->o_sndAsc = (uchar *)convertAscLS(this_ls);",

	"	if((trpt+1)->o_rcvAsc){",

	"		extra_memAsc = extra_memAsc - getAscLSSize(((Asc_LS0 *)(trpt+1)->o_rcvAsc)->_t);",

	"		free((trpt+1)->o_rcvAsc);",

	"	}",

	"	/* (trpt+1)->o_rcvAsc = (uchar *)convertAscLS(this_ls); */",

	"	(trpt+1)->o_rcvAsc = 0;",

	"	(trpt+1)->asc_status = asc_status;",

	"	(trpt+1)->asc_id = asc_id;",

	"		/********************/",

	"#endif",

	0,

};



static char* reverseParOrder_ss[] = {

	/* ss: to preserve the position of the deleted partition in backtrack */

	"int getDeletedPos()",

	"{",

	"	int pos = -1; /* no deletion */",

	"	LocalState0 *tmpLS = ((P0 *)this)->ls;",

	"",

	"	if(((LocalState0 *)this_ls)->pr_count>1) /* will not be deleted */",

	"		return pos;",

	"	pos = 0;",

	"	while(tmpLS){",

	"		if((uchar*)tmpLS == this_ls) ",

	"			return pos;",

	"		pos++;",

	"		tmpLS = tmpLS->nxt;",

	"	}",

	"	return -1; /* shold not reached */",

	"}",

	"",

	"/* in reverse move: if trpt->deleted_pos>-1, then reset the 1st par(newly added) in this->ls to that pos */",

	"void resetPos()",

	"{",

	"	int i; ",

	"	LocalState0 *tmpLS, *addedPar;",

	"	if(trpt->deleted_pos>0) {/* no move for pos 0 */",

	"		i = 0;",

	"		addedPar = ((P0 *)this)->ls;",

	"		tmpLS = ((P0 *)this)->ls;",

	"		while(i<trpt->deleted_pos){",

	"			tmpLS = tmpLS->nxt;",

	"			i++;",

	"		}",

	"		((P0 *)this)->ls = addedPar->nxt;",

	"		((P0 *)this)->ls->pre = (LocalState0 *)0;",

	"		if(tmpLS->nxt)",

	"			tmpLS->nxt->pre = addedPar;",

	"		addedPar->nxt = tmpLS->nxt;",

	"		tmpLS->nxt = addedPar;",

	"		addedPar->pre = tmpLS;",

	"	}",

	"}",

	0,

};


static char *partition_tm_ss[] = {
	"			break;",
	"		}",
	"		if((int)tmp_ls) {/* ss: found partition*/",
			/* (tmp_ls->pr_count)++; */
	"			/* ss: for OMEGA */",
	"			(trpt+1)->toLs_count = tmp_ls->pr_count;",
	/*
	"				if(br_status == BR_RCV) {",
	"					tmp_ls->pr_count = _OMEGA;",
	"				}else "*/
	"#ifdef INFINITE",
	"				if(tmp_ls->pr_count < cut[((P0 *)this)->_t]-1) {",
	"					(tmp_ls->pr_count)++;",
	"				}else {",
	"					tmp_ls->pr_count = _OMEGA;",
	"				}", 
	"#else",			
	"				(tmp_ls->pr_count)++;",
	"#endif",
	
	"		}else {/* add new partition */",
	"			partition_added = 1;",
	"			tmp_ls = (LocalState%d *)malloc(sizeof(LocalState%d));",
	"			tmp_ls->_p = t->st;",
			/* tmp_ls->pr_count = 1; */
	"			(trpt+1)->toLs_count = 0;",
/*	"			if(((LocalState0 *)this_ls)->pr_count == _OMEGA) {",
	"				tmp_ls->pr_count = _OMEGA;",
	"			}else {",
*/
	/*"			if(br_status == BR_RCV) {",
	"				tmp_ls->pr_count = ((LocalState0 *)this_ls)->pr_count; /* transfer all ",
	"			}else"*/
	"			{",
	"				tmp_ls->pr_count = 1; /* no change for VERI */",
	"			}",
/*	"			}", */
	0,
			
};

static char *partition_tm_ss1[] = {
	"				/* add to front of the local state list of current proc type*/",
	"				((P%d *)this)->ls = (LocalState%d *)add_ls((uchar *)tmp_ls, (uchar *)((P%d *)this)->ls);",
	"				((P%d *)this)->partition_count++;",
	"			}",
	"			/* decrease pr_count of current partition */",
	"			/* ((LocalState8 *)this_ls)->pr_count--; */",
	"			/* ss: change for OMEGA */",
	/*
	"			if(br_status == BR_RCV) {",
	"				((LocalState%d *)this_ls)->pr_count = 0;",
	"			}else"*/ 
	"#ifdef INFINITE",
	"			if(((LocalState%d *)this_ls)->pr_count < cut[%d]) {",
	"				((LocalState%d *)this_ls)->pr_count--;",
	"			}else {",
	"				if(choice_cnt ==0) {",
	"					choice_cnt = 1;",
	"					/* remains OMEGA -- not advance */",
	"				}else {",
	"					choice_cnt = 0;",
	"					((LocalState%d *)this_ls)->pr_count = cut[%d] - 1;",
	"				}",
	"			}",
	"#else",
	"			((LocalState%d *)this_ls)->pr_count--;",
	"#endif",
	"			/* if pr_count = 0; delete the partition */",
	"			delete_this_ls();",
	"			this_ls = (uchar *)tmp_ls;",
	"		}",
	0,
};

