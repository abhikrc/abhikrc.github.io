#define Version	"Spin Version 4.2.9 -- 8 February 2007"

