/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ASSERT = 258,
     PRINT = 259,
     PRINTM = 260,
     C_CODE = 261,
     C_DECL = 262,
     C_EXPR = 263,
     C_STATE = 264,
     C_TRACK = 265,
     RUN = 266,
     LEN = 267,
     ENABLED = 268,
     EVAL = 269,
     PC_VAL = 270,
     TYPEDEF = 271,
     MTYPE = 272,
     INLINE = 273,
     LABEL = 274,
     OF = 275,
     GOTO = 276,
     BREAK = 277,
     ELSE = 278,
     SEMI = 279,
     IF = 280,
     FI = 281,
     DO = 282,
     OD = 283,
     SEP = 284,
     ATOMIC = 285,
     NON_ATOMIC = 286,
     D_STEP = 287,
     UNLESS = 288,
     TIMEOUT = 289,
     NONPROGRESS = 290,
     ACTIVE = 291,
     PROCTYPE = 292,
     D_PROCTYPE = 293,
     CUT = 294,
     HIDDEN = 295,
     SHOW = 296,
     ISLOCAL = 297,
     PRIORITY = 298,
     PROVIDED = 299,
     FULL = 300,
     EMPTY = 301,
     NFULL = 302,
     NEMPTY = 303,
     CONST = 304,
     TYPE = 305,
     XU = 306,
     NAME = 307,
     UNAME = 308,
     PNAME = 309,
     INAME = 310,
     STRING = 311,
     CLAIM = 312,
     TRACE = 313,
     INIT = 314,
     ASGN = 315,
     R_RCV = 316,
     RCV = 317,
     O_SND = 318,
     SND = 319,
     OR = 320,
     AND = 321,
     NE = 322,
     EQ = 323,
     LE = 324,
     GE = 325,
     LT = 326,
     GT = 327,
     RSHIFT = 328,
     LSHIFT = 329,
     DECR = 330,
     INCR = 331,
     NEG = 332,
     UMIN = 333,
     DOT = 334
   };
#endif
/* Tokens.  */
#define ASSERT 258
#define PRINT 259
#define PRINTM 260
#define C_CODE 261
#define C_DECL 262
#define C_EXPR 263
#define C_STATE 264
#define C_TRACK 265
#define RUN 266
#define LEN 267
#define ENABLED 268
#define EVAL 269
#define PC_VAL 270
#define TYPEDEF 271
#define MTYPE 272
#define INLINE 273
#define LABEL 274
#define OF 275
#define GOTO 276
#define BREAK 277
#define ELSE 278
#define SEMI 279
#define IF 280
#define FI 281
#define DO 282
#define OD 283
#define SEP 284
#define ATOMIC 285
#define NON_ATOMIC 286
#define D_STEP 287
#define UNLESS 288
#define TIMEOUT 289
#define NONPROGRESS 290
#define ACTIVE 291
#define PROCTYPE 292
#define D_PROCTYPE 293
#define CUT 294
#define HIDDEN 295
#define SHOW 296
#define ISLOCAL 297
#define PRIORITY 298
#define PROVIDED 299
#define FULL 300
#define EMPTY 301
#define NFULL 302
#define NEMPTY 303
#define CONST 304
#define TYPE 305
#define XU 306
#define NAME 307
#define UNAME 308
#define PNAME 309
#define INAME 310
#define STRING 311
#define CLAIM 312
#define TRACE 313
#define INIT 314
#define ASGN 315
#define R_RCV 316
#define RCV 317
#define O_SND 318
#define SND 319
#define OR 320
#define AND 321
#define NE 322
#define EQ 323
#define LE 324
#define GE 325
#define LT 326
#define GT 327
#define RSHIFT 328
#define LSHIFT 329
#define DECR 330
#define INCR 331
#define NEG 332
#define UMIN 333
#define DOT 334




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

