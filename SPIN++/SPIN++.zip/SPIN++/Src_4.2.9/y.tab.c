/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ASSERT = 258,
     PRINT = 259,
     PRINTM = 260,
     C_CODE = 261,
     C_DECL = 262,
     C_EXPR = 263,
     C_STATE = 264,
     C_TRACK = 265,
     RUN = 266,
     LEN = 267,
     ENABLED = 268,
     EVAL = 269,
     PC_VAL = 270,
     TYPEDEF = 271,
     MTYPE = 272,
     INLINE = 273,
     LABEL = 274,
     OF = 275,
     GOTO = 276,
     BREAK = 277,
     ELSE = 278,
     SEMI = 279,
     IF = 280,
     FI = 281,
     DO = 282,
     OD = 283,
     SEP = 284,
     ATOMIC = 285,
     NON_ATOMIC = 286,
     D_STEP = 287,
     UNLESS = 288,
     TIMEOUT = 289,
     NONPROGRESS = 290,
     ACTIVE = 291,
     PROCTYPE = 292,
     D_PROCTYPE = 293,
     CUT = 294,
     HIDDEN = 295,
     SHOW = 296,
     ISLOCAL = 297,
     PRIORITY = 298,
     PROVIDED = 299,
     FULL = 300,
     EMPTY = 301,
     NFULL = 302,
     NEMPTY = 303,
     CONST = 304,
     TYPE = 305,
     XU = 306,
     NAME = 307,
     UNAME = 308,
     PNAME = 309,
     INAME = 310,
     STRING = 311,
     CLAIM = 312,
     TRACE = 313,
     INIT = 314,
     ASGN = 315,
     R_RCV = 316,
     RCV = 317,
     O_SND = 318,
     SND = 319,
     OR = 320,
     AND = 321,
     NE = 322,
     EQ = 323,
     LE = 324,
     GE = 325,
     LT = 326,
     GT = 327,
     RSHIFT = 328,
     LSHIFT = 329,
     DECR = 330,
     INCR = 331,
     NEG = 332,
     UMIN = 333,
     DOT = 334
   };
#endif
/* Tokens.  */
#define ASSERT 258
#define PRINT 259
#define PRINTM 260
#define C_CODE 261
#define C_DECL 262
#define C_EXPR 263
#define C_STATE 264
#define C_TRACK 265
#define RUN 266
#define LEN 267
#define ENABLED 268
#define EVAL 269
#define PC_VAL 270
#define TYPEDEF 271
#define MTYPE 272
#define INLINE 273
#define LABEL 274
#define OF 275
#define GOTO 276
#define BREAK 277
#define ELSE 278
#define SEMI 279
#define IF 280
#define FI 281
#define DO 282
#define OD 283
#define SEP 284
#define ATOMIC 285
#define NON_ATOMIC 286
#define D_STEP 287
#define UNLESS 288
#define TIMEOUT 289
#define NONPROGRESS 290
#define ACTIVE 291
#define PROCTYPE 292
#define D_PROCTYPE 293
#define CUT 294
#define HIDDEN 295
#define SHOW 296
#define ISLOCAL 297
#define PRIORITY 298
#define PROVIDED 299
#define FULL 300
#define EMPTY 301
#define NFULL 302
#define NEMPTY 303
#define CONST 304
#define TYPE 305
#define XU 306
#define NAME 307
#define UNAME 308
#define PNAME 309
#define INAME 310
#define STRING 311
#define CLAIM 312
#define TRACE 313
#define INIT 314
#define ASGN 315
#define R_RCV 316
#define RCV 317
#define O_SND 318
#define SND 319
#define OR 320
#define AND 321
#define NE 322
#define EQ 323
#define LE 324
#define GE 325
#define LT 326
#define GT 327
#define RSHIFT 328
#define LSHIFT 329
#define DECR 330
#define INCR 331
#define NEG 332
#define UMIN 333
#define DOT 334




/* Copy the first part of user declarations.  */
#line 15 "spin.y"

#include "spin.h"
#include <stdarg.h>
#define YYDEBUG	0
#define Stop	nn(ZN,'@',ZN,ZN)
extern  Symbol	*context, *owner;
extern  int	u_sync, u_async, dumptab;
extern	short	has_sorted, has_random, has_enabled, has_pcvalue, has_np;
extern	short	has_code, has_state, has_io;
extern	void	count_runs(Lextok *);
extern	void	no_internals(Lextok *);
extern	void	any_runs(Lextok *);
extern	void	validref(Lextok *, Lextok *);
extern	char	yytext[];
int	Mpars = 0;	/* max nr of message parameters  */
int	runsafe = 1;	/* 1 if all run stmnts are in init */
int	Expand_Ok = 0, realread = 1, IArgs = 0, NamesNotAdded = 0;
char	*claimproc = (char *) 0;
char	*eventmap = (char *) 0;
static	int	Embedded = 0, inEventMap = 0, has_ini = 0;


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 286 "y.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  41
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1207

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  99
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  86
/* YYNRULES -- Number of rules.  */
#define YYNRULES  224
/* YYNRULES -- Number of states.  */
#define YYNSTATES  415

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   334

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    82,    69,     2,
      89,    90,    80,    78,    96,    79,    97,    81,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    95,     2,
       2,     2,     2,     2,    98,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    91,     2,    92,    68,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    93,    67,    94,    85,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    70,    71,    72,    73,    74,    75,    76,    77,
      83,    84,    86,    87,    88
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     7,    10,    12,    14,    16,    18,
      20,    22,    24,    26,    28,    30,    31,    32,    45,    47,
      49,    50,    52,    57,    58,    60,    65,    70,    71,    76,
      77,    81,    82,    86,    87,    94,    96,    98,    99,   106,
     108,   110,   114,   118,   123,   128,   130,   132,   134,   135,
     136,   143,   145,   149,   151,   154,   158,   162,   164,   168,
     169,   171,   173,   175,   176,   178,   182,   186,   193,   195,
     199,   200,   202,   204,   208,   210,   214,   216,   220,   224,
     232,   234,   238,   243,   245,   247,   248,   254,   255,   259,
     260,   263,   265,   267,   268,   273,   274,   279,   283,   284,
     289,   291,   294,   298,   302,   305,   308,   309,   316,   321,
     326,   329,   331,   332,   337,   338,   345,   346,   353,   354,
     359,   361,   363,   364,   371,   372,   379,   380,   386,   387,
     388,   396,   398,   401,   402,   407,   408,   410,   412,   415,
     417,   419,   423,   427,   431,   435,   439,   443,   447,   451,
     455,   459,   463,   467,   471,   475,   479,   483,   487,   491,
     495,   498,   501,   504,   512,   513,   521,   526,   531,   532,
     539,   540,   547,   549,   551,   553,   555,   557,   562,   569,
     576,   580,   584,   585,   588,   590,   592,   593,   598,   601,
     603,   607,   611,   615,   619,   623,   627,   631,   636,   641,
     646,   651,   653,   655,   657,   659,   663,   664,   666,   667,
     670,   672,   677,   679,   683,   685,   690,   692,   695,   697,
     701,   706,   710,   712,   715
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     100,     0,    -1,   101,    -1,   102,    -1,   101,   102,    -1,
     103,    -1,   109,    -1,   111,    -1,   113,    -1,   131,    -1,
     115,    -1,   120,    -1,   118,    -1,    24,    -1,     1,    -1,
      -1,    -1,   108,   107,   106,    52,   104,    89,   133,    90,
     105,   171,   173,   124,    -1,    37,    -1,    38,    -1,    -1,
      39,    -1,    39,    91,    49,    92,    -1,    -1,    36,    -1,
      36,    91,    49,    92,    -1,    36,    91,    52,    92,    -1,
      -1,    59,   110,   171,   124,    -1,    -1,    57,   112,   124,
      -1,    -1,    58,   114,   124,    -1,    -1,    16,    52,   116,
      93,   132,    94,    -1,    52,    -1,    55,    -1,    -1,    18,
     117,    89,   119,   178,    90,    -1,   122,    -1,   121,    -1,
       9,    56,    56,    -1,    10,    56,    56,    -1,     9,    56,
      56,    56,    -1,    10,    56,    56,    56,    -1,     6,    -1,
       7,    -1,     8,    -1,    -1,    -1,    93,   125,   127,   164,
     126,    94,    -1,   128,    -1,   127,   165,   128,    -1,   131,
      -1,    51,   134,    -1,    52,    95,   131,    -1,    52,    95,
      51,    -1,   145,    -1,   145,    33,   145,    -1,    -1,    40,
      -1,    41,    -1,    42,    -1,    -1,    60,    -1,   129,    50,
     135,    -1,   129,    53,   135,    -1,   129,    50,   130,    93,
     184,    94,    -1,   131,    -1,   131,    24,   132,    -1,    -1,
     132,    -1,   139,    -1,   139,    96,   134,    -1,   136,    -1,
     136,    96,   135,    -1,   138,    -1,   138,    60,   167,    -1,
     138,    60,   137,    -1,    91,    49,    92,    20,    93,   177,
      94,    -1,    52,    -1,    52,    95,    49,    -1,    52,    91,
      49,    92,    -1,   142,    -1,    52,    -1,    -1,    52,   141,
      91,   167,    92,    -1,    -1,   140,   143,   144,    -1,    -1,
      97,   142,    -1,   146,    -1,   150,    -1,    -1,   139,    62,
     147,   183,    -1,    -1,   139,    64,   148,   180,    -1,    25,
     161,    26,    -1,    -1,    27,   149,   161,    28,    -1,    22,
      -1,    21,    52,    -1,    52,    95,   145,    -1,   139,    60,
     167,    -1,   139,    84,    -1,   139,    83,    -1,    -1,     4,
      89,    56,   151,   179,    90,    -1,     5,    89,   139,    90,
      -1,     5,    89,    49,    90,    -1,     3,   172,    -1,   122,
      -1,    -1,   139,    61,   152,   183,    -1,    -1,   139,    62,
     153,    74,   183,    75,    -1,    -1,   139,    61,   154,    74,
     183,    75,    -1,    -1,   139,    63,   155,   180,    -1,   172,
      -1,    23,    -1,    -1,    30,    93,   156,   127,   164,    94,
      -1,    -1,    32,    93,   157,   127,   164,    94,    -1,    -1,
      93,   158,   127,   164,    94,    -1,    -1,    -1,    55,   159,
      89,   178,    90,   160,   150,    -1,   162,    -1,   162,   161,
      -1,    -1,    29,   163,   127,   164,    -1,    -1,    24,    -1,
      24,    -1,   165,    24,    -1,    52,    -1,    54,    -1,    89,
     167,    90,    -1,   167,    78,   167,    -1,   167,    79,   167,
      -1,   167,    80,   167,    -1,   167,    81,   167,    -1,   167,
      82,   167,    -1,   167,    69,   167,    -1,   167,    68,   167,
      -1,   167,    67,   167,    -1,   167,    75,   167,    -1,   167,
      74,   167,    -1,   167,    73,   167,    -1,   167,    72,   167,
      -1,   167,    71,   167,    -1,   167,    70,   167,    -1,   167,
      66,   167,    -1,   167,    65,   167,    -1,   167,    77,   167,
      -1,   167,    76,   167,    -1,    85,   167,    -1,    79,   167,
      -1,    64,   167,    -1,    89,   167,    24,   167,    95,   167,
      90,    -1,    -1,    11,   166,   168,    89,   178,    90,   171,
      -1,    12,    89,   139,    90,    -1,    13,    89,   167,    90,
      -1,    -1,   139,    62,   169,    91,   183,    92,    -1,    -1,
     139,    61,   170,    91,   183,    92,    -1,   139,    -1,   123,
      -1,    49,    -1,    34,    -1,    35,    -1,    15,    89,   167,
      90,    -1,    54,    91,   167,    92,    98,    52,    -1,    54,
      91,   167,    92,    95,   140,    -1,    54,    98,    52,    -1,
      54,    95,   140,    -1,    -1,    43,    49,    -1,   167,    -1,
     174,    -1,    -1,    44,    89,   172,    90,    -1,    44,     1,
      -1,   175,    -1,    89,   174,    90,    -1,   174,    66,   174,
      -1,   174,    66,   167,    -1,   174,    65,   174,    -1,   174,
      65,   167,    -1,   167,    66,   174,    -1,   167,    65,   174,
      -1,    45,    89,   139,    90,    -1,    47,    89,   139,    90,
      -1,    46,    89,   139,    90,    -1,    48,    89,   139,    90,
      -1,    50,    -1,    53,    -1,     1,    -1,   176,    -1,   176,
      96,   177,    -1,    -1,   181,    -1,    -1,    96,   181,    -1,
     181,    -1,   167,    89,   181,    90,    -1,   167,    -1,   167,
      96,   181,    -1,   139,    -1,    14,    89,   167,    90,    -1,
      49,    -1,    79,    49,    -1,   182,    -1,   182,    96,   183,
      -1,   182,    89,   183,    90,    -1,    89,   183,    90,    -1,
      52,    -1,   184,    52,    -1,   184,    96,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    68,    68,    70,    71,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    87,    95,    85,   115,   116,
     120,   121,   122,   127,   128,   129,   134,   151,   151,   160,
     160,   169,   169,   180,   180,   187,   188,   193,   193,   198,
     202,   204,   208,   212,   216,   222,   230,   240,   250,   251,
     250,   255,   256,   259,   260,   261,   262,   263,   264,   266,
     267,   268,   269,   271,   272,   275,   276,   279,   291,   292,
     295,   296,   298,   299,   301,   302,   304,   308,   311,   315,
     325,   326,   334,   336,   338,   339,   339,   342,   342,   360,
     361,   363,   364,   370,   370,   375,   375,   381,   385,   385,
     390,   393,   401,   411,   416,   424,   432,   432,   434,   435,
     436,   437,   438,   438,   444,   444,   450,   450,   456,   456,
     463,   464,   466,   466,   471,   471,   477,   477,   481,   482,
     481,   486,   487,   490,   490,   495,   496,   499,   500,   503,
     504,   507,   508,   509,   510,   511,   512,   513,   514,   515,
     516,   517,   518,   519,   520,   521,   522,   523,   524,   525,
     526,   527,   528,   530,   535,   535,   548,   549,   552,   552,
     556,   556,   561,   568,   569,   573,   574,   577,   580,   582,
     584,   585,   588,   589,   592,   593,   596,   597,   604,   611,
     612,   613,   614,   615,   616,   617,   618,   621,   622,   623,
     624,   627,   632,   635,   638,   639,   642,   643,   646,   647,
     650,   651,   658,   663,   670,   672,   674,   678,   683,   688,
     693,   698,   701,   703,   706
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ASSERT", "PRINT", "PRINTM", "C_CODE",
  "C_DECL", "C_EXPR", "C_STATE", "C_TRACK", "RUN", "LEN", "ENABLED",
  "EVAL", "PC_VAL", "TYPEDEF", "MTYPE", "INLINE", "LABEL", "OF", "GOTO",
  "BREAK", "ELSE", "SEMI", "IF", "FI", "DO", "OD", "SEP", "ATOMIC",
  "NON_ATOMIC", "D_STEP", "UNLESS", "TIMEOUT", "NONPROGRESS", "ACTIVE",
  "PROCTYPE", "D_PROCTYPE", "CUT", "HIDDEN", "SHOW", "ISLOCAL", "PRIORITY",
  "PROVIDED", "FULL", "EMPTY", "NFULL", "NEMPTY", "CONST", "TYPE", "XU",
  "NAME", "UNAME", "PNAME", "INAME", "STRING", "CLAIM", "TRACE", "INIT",
  "ASGN", "R_RCV", "RCV", "O_SND", "SND", "OR", "AND", "'|'", "'^'", "'&'",
  "NE", "EQ", "LE", "GE", "LT", "GT", "RSHIFT", "LSHIFT", "'+'", "'-'",
  "'*'", "'/'", "'%'", "DECR", "INCR", "'~'", "NEG", "UMIN", "DOT", "'('",
  "')'", "'['", "']'", "'{'", "'}'", "':'", "','", "'.'", "'@'", "$accept",
  "program", "units", "unit", "proc", "@1", "@2", "proctype", "cutoff",
  "inst", "init", "@3", "claim", "@4", "events", "@5", "utype", "@6", "nm",
  "ns", "@7", "c_fcts", "cstate", "ccode", "cexpr", "body", "@8", "@9",
  "sequence", "step", "vis", "asgn", "one_decl", "decl_lst", "decl",
  "vref_lst", "var_list", "ivar", "ch_init", "vardcl", "varref", "pfld",
  "@10", "cmpnd", "@11", "sfld", "stmnt", "Special", "@12", "@13", "@14",
  "Stmnt", "@15", "@16", "@17", "@18", "@19", "@20", "@21", "@22", "@23",
  "@24", "options", "option", "@25", "OS", "MS", "aname", "expr", "@26",
  "@27", "@28", "Opt_priority", "full_expr", "Opt_enabler", "Expr",
  "Probe", "basetype", "typ_list", "args", "prargs", "margs", "arg",
  "rarg", "rargs", "nlst", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   124,    94,    38,
     322,   323,   324,   325,   326,   327,   328,   329,    43,    45,
      42,    47,    37,   330,   331,   126,   332,   333,   334,    40,
      41,    91,    93,   123,   125,    58,    44,    46,    64
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    99,   100,   101,   101,   102,   102,   102,   102,   102,
     102,   102,   102,   102,   102,   104,   105,   103,   106,   106,
     107,   107,   107,   108,   108,   108,   108,   110,   109,   112,
     111,   114,   113,   116,   115,   117,   117,   119,   118,   120,
     120,   121,   121,   121,   121,   122,   122,   123,   125,   126,
     124,   127,   127,   128,   128,   128,   128,   128,   128,   129,
     129,   129,   129,   130,   130,   131,   131,   131,   132,   132,
     133,   133,   134,   134,   135,   135,   136,   136,   136,   137,
     138,   138,   138,   139,   140,   141,   140,   143,   142,   144,
     144,   145,   145,   147,   146,   148,   146,   146,   149,   146,
     146,   146,   146,   150,   150,   150,   151,   150,   150,   150,
     150,   150,   152,   150,   153,   150,   154,   150,   155,   150,
     150,   150,   156,   150,   157,   150,   158,   150,   159,   160,
     150,   161,   161,   163,   162,   164,   164,   165,   165,   166,
     166,   167,   167,   167,   167,   167,   167,   167,   167,   167,
     167,   167,   167,   167,   167,   167,   167,   167,   167,   167,
     167,   167,   167,   167,   168,   167,   167,   167,   169,   167,
     170,   167,   167,   167,   167,   167,   167,   167,   167,   167,
     167,   167,   171,   171,   172,   172,   173,   173,   173,   174,
     174,   174,   174,   174,   174,   174,   174,   175,   175,   175,
     175,   176,   176,   176,   177,   177,   178,   178,   179,   179,
     180,   180,   181,   181,   182,   182,   182,   182,   183,   183,
     183,   183,   184,   184,   184
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     0,     0,    12,     1,     1,
       0,     1,     4,     0,     1,     4,     4,     0,     4,     0,
       3,     0,     3,     0,     6,     1,     1,     0,     6,     1,
       1,     3,     3,     4,     4,     1,     1,     1,     0,     0,
       6,     1,     3,     1,     2,     3,     3,     1,     3,     0,
       1,     1,     1,     0,     1,     3,     3,     6,     1,     3,
       0,     1,     1,     3,     1,     3,     1,     3,     3,     7,
       1,     3,     4,     1,     1,     0,     5,     0,     3,     0,
       2,     1,     1,     0,     4,     0,     4,     3,     0,     4,
       1,     2,     3,     3,     2,     2,     0,     6,     4,     4,
       2,     1,     0,     4,     0,     6,     0,     6,     0,     4,
       1,     1,     0,     6,     0,     6,     0,     5,     0,     0,
       7,     1,     2,     0,     4,     0,     1,     1,     2,     1,
       1,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       2,     2,     2,     7,     0,     7,     4,     4,     0,     6,
       0,     6,     1,     1,     1,     1,     1,     4,     6,     6,
       3,     3,     0,     2,     1,     1,     0,     4,     2,     1,
       3,     3,     3,     3,     3,     3,     3,     4,     4,     4,
       4,     1,     1,     1,     1,     3,     0,     1,     0,     2,
       1,     4,     1,     3,     1,     4,     1,     2,     1,     3,
       4,     3,     1,     2,     2
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,    14,    45,    46,     0,     0,     0,     0,    13,    24,
      60,    61,    62,    29,    31,    27,     0,     0,     3,     5,
      20,     6,     7,     8,    10,    12,    11,    40,    39,     0,
       9,     0,     0,    33,    35,    36,     0,     0,     0,     0,
     182,     1,     4,    21,     0,    63,     0,    41,    42,     0,
      37,     0,     0,    48,    30,    32,     0,     0,     0,    18,
      19,     0,    80,    64,     0,    65,    74,    76,    66,    43,
      44,    59,   206,    25,    26,    59,   183,    28,     0,    15,
       0,     0,     0,     0,     0,    68,     0,    47,     0,     0,
       0,     0,   175,   176,   174,    84,     0,     0,     0,     0,
       0,   173,   172,    87,    83,   212,     0,   207,     0,     0,
       0,     0,   100,   121,     0,    98,     0,     0,     0,     0,
       0,     0,     0,    84,   128,     0,   126,   111,   135,    51,
      53,   172,    57,    91,    92,   184,   120,   185,   189,    22,
       0,     0,    81,   222,     0,    75,     0,    78,    77,    59,
      34,   139,   140,   164,     0,     0,     0,     0,     0,     0,
       0,   162,   161,   160,     0,   170,   168,    89,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    38,   110,     0,
       0,   101,   133,     0,   131,     0,   122,   124,     0,     0,
       0,     0,    54,    72,    59,     0,     0,     0,    59,   137,
      49,    59,     0,   112,    93,   118,    95,   105,   104,     0,
       0,     0,     0,     0,    59,    82,   223,    67,   224,     0,
      69,     0,     0,     0,     0,     0,     0,   181,   180,     0,
     141,     0,     0,     0,    88,   157,   156,   149,   148,   147,
     155,   154,   153,   152,   151,   150,   159,   158,   142,   143,
     144,   145,   146,   213,   106,     0,     0,    59,    97,   132,
       0,    59,    59,     0,     0,     0,     0,     0,    56,    84,
      55,   102,   206,   190,   135,     0,   138,    52,   103,     0,
       0,     0,     0,     0,     0,    58,   157,   196,   156,   195,
     194,   193,   192,   191,    71,     0,     0,   206,   166,   167,
     177,     0,     0,     0,     0,     0,    90,   208,   109,   108,
     135,    99,   135,   135,   197,   199,   198,   200,    73,     0,
       0,     0,    50,     0,   216,     0,     0,   214,   218,   113,
       0,    94,     0,   212,   119,   210,    96,    16,     0,     0,
      86,     0,     0,     0,     0,     0,     0,     0,   134,     0,
       0,   129,   127,     0,   217,     0,     0,     0,     0,     0,
       0,   182,     0,   182,   179,   178,     0,   171,   169,   209,
     107,   123,   125,     0,     0,   221,     0,   219,   117,   115,
       0,   186,   203,   201,   202,   204,     0,   165,   163,   172,
     130,   215,   220,   211,     0,     0,     0,    79,   114,   188,
       0,    17,   205,     0,   187
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    16,    17,    18,    19,   140,   371,    61,    44,    20,
      21,    40,    22,    38,    23,    39,    24,    49,    36,    25,
      72,    26,    27,   127,   101,    54,    75,   285,   128,   129,
      29,    64,   130,    86,   305,   202,    65,    66,   147,    67,
     102,   103,   157,   104,   167,   244,   132,   133,   291,   294,
     195,   134,   317,   289,   292,   290,   293,   271,   272,   208,
     205,   383,   193,   194,   267,   210,   211,   153,   135,   231,
     242,   241,    57,   136,   405,   137,   138,   395,   396,   106,
     357,   344,   107,   338,   339,   144
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -278
static const yytype_int16 yypact[] =
{
     778,  -278,  -278,  -278,   -33,   -10,   -35,    54,  -278,   -55,
    -278,  -278,  -278,  -278,  -278,  -278,    77,   733,  -278,  -278,
      66,  -278,  -278,  -278,  -278,  -278,  -278,  -278,  -278,    70,
    -278,   123,   125,  -278,  -278,  -278,    93,    79,    99,    99,
     143,  -278,  -278,   103,    74,    47,   144,   149,   160,   106,
    -278,   112,   126,  -278,  -278,  -278,   170,    99,   171,  -278,
    -278,   173,   -16,  -278,   129,  -278,   133,   168,  -278,  -278,
    -278,   148,   172,  -278,  -278,   373,  -278,  -278,   139,  -278,
     183,   184,   182,   144,    19,   211,   145,  -278,    41,   153,
     154,   155,  -278,  -278,  -278,   146,   -56,   172,   172,   172,
     172,  -278,    57,  -278,  -278,   805,   156,  -278,   596,   158,
     159,   186,  -278,  -278,   216,  -278,   161,   163,   164,   169,
     174,   175,   197,   -13,  -278,   596,  -278,  -278,   228,  -278,
    -278,   213,   226,  -278,  -278,  1028,  -278,    89,  -278,  -278,
     176,   177,  -278,  -278,   -27,  -278,   218,  -278,  1046,   148,
    -278,  -278,  -278,  -278,   197,   172,   172,   180,   172,   197,
     208,  -278,  -278,  -278,   622,  -278,  -278,   181,   172,   172,
     172,   172,   172,   172,   172,   172,   172,   172,   172,   172,
     172,   172,   172,   172,   172,   172,   172,  -278,  -278,   224,
      83,  -278,  -278,   246,   216,   216,  -278,  -278,   197,   197,
     197,   197,  -278,   191,   438,   190,   648,    -9,   373,   -18,
    -278,   308,   172,   -50,   -46,  -278,  -278,  -278,  -278,   503,
     596,   596,   596,   596,   -20,  -278,  -278,  -278,  -278,   196,
    -278,   200,   201,   924,   950,   172,   868,  -278,  -278,   172,
    -278,   199,   203,   197,  -278,  1063,  1096,  1111,  1125,   818,
     686,   686,    71,    71,    71,    71,    60,    60,   132,   132,
    -278,  -278,  -278,  -278,  -278,   209,   210,   373,  -278,  -278,
     270,   373,   373,   212,   215,   220,   227,   197,  -278,     1,
    -278,  -278,   172,  -278,   228,   207,  -278,  -278,  1046,    -5,
     229,    -5,   234,   172,   172,  -278,  1080,   252,  1096,  -278,
    1080,   252,  1096,  -278,  -278,   232,   304,   172,  -278,  -278,
    -278,   896,    38,   837,    -5,    -5,  -278,   230,  -278,  -278,
     228,  -278,   228,   228,  -278,  -278,  -278,  -278,  -278,   503,
     235,   233,  -278,   239,  -278,   285,    -5,  -278,   -34,  -278,
      -5,  -278,    -5,   773,  -278,  -278,  -278,  -278,   243,   247,
    -278,   197,   287,   172,   253,   254,   172,   257,  -278,   258,
     267,  -278,  -278,   172,  -278,   274,    -5,    -5,   290,   292,
     172,   143,    11,   143,  -278,  -278,   976,  -278,  -278,  -278,
    -278,  -278,  -278,   568,  1002,  -278,   278,  -278,  -278,  -278,
     279,   326,  -278,  -278,  -278,   275,   280,  -278,  -278,   223,
    -278,  -278,  -278,  -278,     5,    99,    11,  -278,   282,  -278,
     596,  -278,  -278,   293,  -278
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -278,  -278,  -278,   358,  -278,  -278,  -278,  -278,  -278,  -278,
    -278,  -278,  -278,  -278,  -278,  -278,  -278,  -278,  -278,  -278,
    -278,  -278,  -278,    33,  -278,   -39,  -278,  -278,  -150,   178,
    -278,  -278,    26,  -133,  -278,   105,   -17,  -278,  -278,  -278,
     -74,  -156,  -278,   147,  -278,  -278,  -200,  -278,  -278,  -278,
    -278,     8,  -278,  -278,  -278,  -278,  -278,  -278,  -278,  -278,
    -278,  -278,     7,  -278,  -278,  -271,  -278,  -278,   -12,  -278,
    -278,  -278,  -195,  -106,  -278,  -120,  -278,  -278,   -14,  -267,
    -278,   108,  -179,  -278,  -277,  -278
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -171
static const yytype_int16 yytable[] =
{
      55,   131,   188,   237,   281,   207,   409,   263,  -136,   333,
    -136,  -136,   392,   331,   341,   330,   230,    33,    77,   295,
      10,    11,    12,    31,  -116,   226,    30,    87,  -114,    68,
      88,    89,    90,    28,    91,   158,    37,   354,   355,   159,
     349,  -170,   160,    30,   334,  -168,    32,    95,   203,   358,
      28,   359,   360,    92,    93,   366,   222,   223,   284,   365,
     105,   393,   367,   368,   394,   369,   145,   227,    94,   228,
     -70,    95,   148,    96,   335,    80,  -136,    41,   -85,    81,
     232,   283,   204,    97,   336,   161,   162,   163,   164,   386,
     387,   304,   -85,   151,   410,   152,   329,    85,    98,    62,
     297,   299,   301,   303,    99,    43,    34,    63,   100,    35,
     146,    59,    60,   206,   345,   345,   266,   320,   165,   166,
      45,   322,   323,    46,   273,   274,   275,   276,    51,   281,
     131,    52,   265,   351,   131,    95,   352,   131,   181,   182,
     183,   184,   185,   233,   234,   131,   236,   179,   180,   181,
     182,   183,   184,   185,   222,   223,   245,   246,   247,   248,
     249,   250,   251,   252,   253,   254,   255,   256,   257,   258,
     259,   260,   261,   262,   105,    85,   391,   379,   397,    47,
      87,    48,    50,    88,    89,    90,    56,    91,    10,    11,
      12,   390,    53,   131,    58,   374,    62,   131,   131,    71,
     288,   269,   270,   203,    73,    69,    92,    93,   296,   298,
     300,   302,   183,   184,   185,   337,    70,   337,    74,    76,
      78,    94,    82,   311,    95,    79,    96,   313,    84,    83,
     280,   139,   141,   142,   143,   149,    97,   -85,   191,   150,
     337,   337,   154,   155,   156,   192,   187,   189,   190,    95,
      85,    98,   209,   198,   196,   131,   197,    99,   199,   219,
     238,   100,   337,   200,   201,   224,   337,   229,   337,   225,
     105,   235,   268,   212,   213,   214,   215,   216,   243,   282,
     264,   343,   343,   212,   213,   408,   215,   277,   306,   307,
     314,   308,   337,   337,   315,   105,   217,   218,   321,   318,
     319,   332,   324,   340,   413,   325,   217,   218,   342,   399,
     326,   108,   109,   110,     2,     3,    87,   327,   223,    88,
      89,    90,   347,    91,   348,   361,   356,   362,   363,   111,
     112,   113,   286,   114,   364,   115,   372,   373,   116,   375,
     117,   376,    92,    93,   105,   377,   378,   380,    10,    11,
      12,   384,   381,   118,   119,   120,   121,    94,   105,   122,
     123,   382,    96,   124,   385,   388,   411,   389,   402,   403,
     404,   406,    97,  -168,   407,    42,   108,   109,   110,     2,
       3,    87,   328,   414,    88,    89,    90,    98,    91,   287,
     316,   400,   412,    99,   111,   112,   113,   125,   114,     0,
     115,   126,   346,   116,     0,   117,     0,    92,    93,     0,
       0,     0,     0,    10,    11,    12,     0,     0,   118,   119,
     120,   121,    94,     0,   122,   123,     0,    96,   124,     0,
       0,     0,     0,     0,     0,     0,     0,    97,     0,     0,
       0,   108,   109,   110,     2,     3,    87,     0,     0,    88,
      89,    90,    98,    91,     0,     0,     0,     0,    99,   111,
     112,   113,   125,   114,     0,   115,   126,     0,   116,     0,
     117,     0,    92,    93,     0,     0,     0,     0,    10,    11,
      12,     0,     0,   118,   119,   120,   121,    94,     0,   278,
     279,     0,    96,   124,     0,     0,     0,     0,     0,     0,
       0,     0,    97,     0,     0,     0,   108,   109,   110,     2,
       3,    87,     0,     0,    88,    89,    90,    98,    91,     0,
       0,     0,     0,    99,   111,   112,   113,   125,   114,     0,
     115,   126,     0,   116,     0,   117,     0,    92,    93,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   118,   119,
     120,   121,    94,     0,     0,   279,     0,    96,   124,     0,
       0,     0,     0,     0,     0,     0,     0,    97,     0,     0,
       0,   108,   109,   110,     2,     3,    87,     0,     0,    88,
      89,    90,    98,    91,     0,     0,     0,     0,    99,     0,
       0,   113,   125,     0,     0,     0,   126,     0,   116,     0,
     117,     0,    92,    93,    87,     0,     0,    88,    89,    90,
       0,    91,     0,   118,   119,   120,   121,    94,     0,     0,
      95,     0,    96,   124,     0,     0,     0,     0,     0,     0,
      92,    93,    97,     0,     0,     0,     0,     0,     0,     0,
       0,   118,   119,   120,   121,    94,   239,    98,    95,     0,
      96,     0,     0,    99,     0,     0,     0,   125,     0,     0,
      97,   126,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   239,     0,     0,    98,     0,     0,     0,     0,
       0,    99,     0,     0,     0,   125,     0,   168,   169,   170,
     171,   172,   173,   174,   175,   176,   177,   178,   179,   180,
     181,   182,   183,   184,   185,     0,     0,     0,     0,     0,
       0,     0,   240,   220,   221,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,     0,     0,    -2,     1,     0,     0,     0,   240,     2,
       3,     0,     4,     5,     0,     0,     0,     0,     0,     6,
       0,     7,     0,     0,     0,     0,     0,     8,   175,   176,
     177,   178,   179,   180,   181,   182,   183,   184,   185,     9,
     -23,   -23,   -23,    10,    11,    12,     0,     0,     0,     1,
       0,     0,     0,   -59,     2,     3,   -59,     4,     5,     0,
      13,    14,    15,     0,     6,     0,     7,     0,     0,     0,
       0,     0,     8,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     9,   -23,   -23,   -23,    10,    11,
      12,     0,     0,     0,     0,     0,     0,     0,   -59,     0,
       0,   -59,     0,     0,     0,    13,    14,    15,   168,   169,
     170,   171,   172,   173,   174,   175,   176,   177,   178,   179,
     180,   181,   182,   183,   184,   185,     0,     0,     0,     0,
       0,     0,   370,     0,     0,     0,     0,     0,     0,   186,
     168,   169,   170,   171,   172,   173,   174,   175,   176,   177,
     178,   179,   180,   181,   182,   183,   184,   185,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   168,   169,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   353,   168,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     312,   168,   169,   170,   171,   172,   173,   174,   175,   176,
     177,   178,   179,   180,   181,   182,   183,   184,   185,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   350,   168,
     169,   170,   171,   172,   173,   174,   175,   176,   177,   178,
     179,   180,   181,   182,   183,   184,   185,     0,     0,     0,
       0,     0,     0,     0,   309,   168,   169,   170,   171,   172,
     173,   174,   175,   176,   177,   178,   179,   180,   181,   182,
     183,   184,   185,     0,     0,     0,     0,     0,     0,     0,
     310,   168,   169,   170,   171,   172,   173,   174,   175,   176,
     177,   178,   179,   180,   181,   182,   183,   184,   185,     0,
       0,     0,     0,     0,     0,     0,   398,   168,   169,   170,
     171,   172,   173,   174,   175,   176,   177,   178,   179,   180,
     181,   182,   183,   184,   185,     0,     0,     0,     0,     0,
       0,     0,   401,   220,   221,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   168,   169,   170,   171,   172,   173,   174,   175,   176,
     177,   178,   179,   180,   181,   182,   183,   184,   185,   169,
     170,   171,   172,   173,   174,   175,   176,   177,   178,   179,
     180,   181,   182,   183,   184,   185,   221,   170,   171,   172,
     173,   174,   175,   176,   177,   178,   179,   180,   181,   182,
     183,   184,   185,   170,   171,   172,   173,   174,   175,   176,
     177,   178,   179,   180,   181,   182,   183,   184,   185,   171,
     172,   173,   174,   175,   176,   177,   178,   179,   180,   181,
     182,   183,   184,   185,   172,   173,   174,   175,   176,   177,
     178,   179,   180,   181,   182,   183,   184,   185
};

static const yytype_int16 yycheck[] =
{
      39,    75,   108,   159,   204,   125,     1,   186,    26,    14,
      28,    29,     1,   284,   291,   282,   149,    52,    57,   219,
      40,    41,    42,    56,    74,    52,     0,     8,    74,    46,
      11,    12,    13,     0,    15,    91,    91,   314,   315,    95,
     307,    91,    98,    17,    49,    91,    56,    52,   122,   320,
      17,   322,   323,    34,    35,    89,    65,    66,   208,   336,
      72,    50,    96,   340,    53,   342,    83,    94,    49,    96,
      90,    52,    84,    54,    79,    91,    94,     0,    91,    95,
     154,    90,    95,    64,    89,    97,    98,    99,   100,   366,
     367,   224,    91,    52,    89,    54,    95,    71,    79,    52,
     220,   221,   222,   223,    85,    39,    52,    60,    89,    55,
      91,    37,    38,   125,   293,   294,   190,   267,    61,    62,
      50,   271,   272,    53,   198,   199,   200,   201,    49,   329,
     204,    52,    49,    95,   208,    52,    98,   211,    78,    79,
      80,    81,    82,   155,   156,   219,   158,    76,    77,    78,
      79,    80,    81,    82,    65,    66,   168,   169,   170,   171,
     172,   173,   174,   175,   176,   177,   178,   179,   180,   181,
     182,   183,   184,   185,   186,   149,   371,   356,   373,    56,
       8,    56,    89,    11,    12,    13,    43,    15,    40,    41,
      42,   370,    93,   267,    91,   351,    52,   271,   272,    93,
     212,   194,   195,   277,    92,    56,    34,    35,   220,   221,
     222,   223,    80,    81,    82,   289,    56,   291,    92,    49,
      49,    49,    93,   235,    52,    52,    54,   239,    60,    96,
     204,    92,    49,    49,    52,    24,    64,    91,    52,    94,
     314,   315,    89,    89,    89,    29,    90,    89,    89,    52,
     224,    79,    24,    89,    93,   329,    93,    85,    89,    33,
      52,    89,   336,    89,    89,    89,   340,    49,   342,    92,
     282,    91,    26,    60,    61,    62,    63,    64,    97,    89,
      56,   293,   294,    60,    61,    62,    63,    96,    92,    89,
      91,    90,   366,   367,    91,   307,    83,    84,    28,    90,
      90,    94,    90,    74,   410,    90,    83,    84,    74,   383,
      90,     3,     4,     5,     6,     7,     8,    90,    66,    11,
      12,    13,    90,    15,    20,    90,    96,    94,    89,    21,
      22,    23,    24,    25,    49,    27,    93,    90,    30,    52,
      32,   353,    34,    35,   356,    92,    92,    90,    40,    41,
      42,   363,    94,    45,    46,    47,    48,    49,   370,    51,
      52,    94,    54,    55,    90,    75,   405,    75,    90,    90,
      44,    96,    64,    91,    94,    17,     3,     4,     5,     6,
       7,     8,   277,    90,    11,    12,    13,    79,    15,   211,
     243,   383,   406,    85,    21,    22,    23,    89,    25,    -1,
      27,    93,   294,    30,    -1,    32,    -1,    34,    35,    -1,
      -1,    -1,    -1,    40,    41,    42,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    52,    -1,    54,    55,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,    -1,    -1,
      -1,     3,     4,     5,     6,     7,     8,    -1,    -1,    11,
      12,    13,    79,    15,    -1,    -1,    -1,    -1,    85,    21,
      22,    23,    89,    25,    -1,    27,    93,    -1,    30,    -1,
      32,    -1,    34,    35,    -1,    -1,    -1,    -1,    40,    41,
      42,    -1,    -1,    45,    46,    47,    48,    49,    -1,    51,
      52,    -1,    54,    55,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    64,    -1,    -1,    -1,     3,     4,     5,     6,
       7,     8,    -1,    -1,    11,    12,    13,    79,    15,    -1,
      -1,    -1,    -1,    85,    21,    22,    23,    89,    25,    -1,
      27,    93,    -1,    30,    -1,    32,    -1,    34,    35,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    -1,    52,    -1,    54,    55,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,    -1,    -1,
      -1,     3,     4,     5,     6,     7,     8,    -1,    -1,    11,
      12,    13,    79,    15,    -1,    -1,    -1,    -1,    85,    -1,
      -1,    23,    89,    -1,    -1,    -1,    93,    -1,    30,    -1,
      32,    -1,    34,    35,     8,    -1,    -1,    11,    12,    13,
      -1,    15,    -1,    45,    46,    47,    48,    49,    -1,    -1,
      52,    -1,    54,    55,    -1,    -1,    -1,    -1,    -1,    -1,
      34,    35,    64,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    45,    46,    47,    48,    49,    24,    79,    52,    -1,
      54,    -1,    -1,    85,    -1,    -1,    -1,    89,    -1,    -1,
      64,    93,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    24,    -1,    -1,    79,    -1,    -1,    -1,    -1,
      -1,    85,    -1,    -1,    -1,    89,    -1,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    90,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    -1,    -1,     0,     1,    -1,    -1,    -1,    90,     6,
       7,    -1,     9,    10,    -1,    -1,    -1,    -1,    -1,    16,
      -1,    18,    -1,    -1,    -1,    -1,    -1,    24,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    36,
      37,    38,    39,    40,    41,    42,    -1,    -1,    -1,     1,
      -1,    -1,    -1,    50,     6,     7,    53,     9,    10,    -1,
      57,    58,    59,    -1,    16,    -1,    18,    -1,    -1,    -1,
      -1,    -1,    24,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    36,    37,    38,    39,    40,    41,
      42,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    50,    -1,
      -1,    53,    -1,    -1,    -1,    57,    58,    59,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    -1,    -1,    -1,    -1,
      -1,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,    96,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    96,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    95,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      92,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    92,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    90,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      90,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    90,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    90,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     1,     6,     7,     9,    10,    16,    18,    24,    36,
      40,    41,    42,    57,    58,    59,   100,   101,   102,   103,
     108,   109,   111,   113,   115,   118,   120,   121,   122,   129,
     131,    56,    56,    52,    52,    55,   117,    91,   112,   114,
     110,     0,   102,    39,   107,    50,    53,    56,    56,   116,
      89,    49,    52,    93,   124,   124,    43,   171,    91,    37,
      38,   106,    52,    60,   130,   135,   136,   138,   135,    56,
      56,    93,   119,    92,    92,   125,    49,   124,    49,    52,
      91,    95,    93,    96,    60,   131,   132,     8,    11,    12,
      13,    15,    34,    35,    49,    52,    54,    64,    79,    85,
      89,   123,   139,   140,   142,   167,   178,   181,     3,     4,
       5,    21,    22,    23,    25,    27,    30,    32,    45,    46,
      47,    48,    51,    52,    55,    89,    93,   122,   127,   128,
     131,   139,   145,   146,   150,   167,   172,   174,   175,    92,
     104,    49,    49,    52,   184,   135,    91,   137,   167,    24,
      94,    52,    54,   166,    89,    89,    89,   141,    91,    95,
      98,   167,   167,   167,   167,    61,    62,   143,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    96,    90,   172,    89,
      89,    52,    29,   161,   162,   149,    93,    93,    89,    89,
      89,    89,   134,   139,    95,   159,   167,   174,   158,    24,
     164,   165,    60,    61,    62,    63,    64,    83,    84,    33,
      65,    66,    65,    66,    89,    92,    52,    94,    96,    49,
     132,   168,   139,   167,   167,    91,   167,   140,    52,    24,
      90,   170,   169,    97,   144,   167,   167,   167,   167,   167,
     167,   167,   167,   167,   167,   167,   167,   167,   167,   167,
     167,   167,   167,   181,    56,    49,   139,   163,    26,   161,
     161,   156,   157,   139,   139,   139,   139,    96,    51,    52,
     131,   145,    89,    90,   127,   126,    24,   128,   167,   152,
     154,   147,   153,   155,   148,   145,   167,   174,   167,   174,
     167,   174,   167,   174,   132,   133,    92,    89,    90,    90,
      90,   167,    92,   167,    91,    91,   142,   151,    90,    90,
     127,    28,   127,   127,    90,    90,    90,    90,   134,    95,
     178,   164,    94,    14,    49,    79,    89,   139,   182,   183,
      74,   183,    74,   167,   180,   181,   180,    90,    20,   178,
      92,    95,    98,    95,   183,   183,    96,   179,   164,   164,
     164,    90,    94,    89,    49,   183,    89,    96,   183,   183,
      89,   105,    93,    90,   140,    52,   167,    92,    92,   181,
      90,    94,    94,   160,   167,    90,   183,   183,    75,    75,
     181,   171,     1,    50,    53,   176,   177,   171,    90,   139,
     150,    90,    90,    90,    44,   173,    96,    94,    62,     1,
      89,   124,   177,   172,    90
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 68 "spin.y"
    { yytext[0] = '\0'; }
    break;

  case 15:
#line 87 "spin.y"
    {
			  setptype((yyvsp[(4) - (4)]), PROCTYPE, ZN);
			  setpname((yyvsp[(4) - (4)]));
			  context = (yyvsp[(4) - (4)])->sym;
			  context->ini = (yyvsp[(3) - (4)]); /* linenr and file */
			  Expand_Ok++; /* expand struct names in decl */
			  has_ini = 0;
			}
    break;

  case 16:
#line 95 "spin.y"
    { Expand_Ok--;
			  if (has_ini)
			  fatal("initializer in parameter list", (char *) 0);
			}
    break;

  case 17:
#line 101 "spin.y"
    { ProcList *rl;
			  rl = ready((yyvsp[(4) - (12)])->sym, (yyvsp[(7) - (12)]), (yyvsp[(12) - (12)])->sq, (yyvsp[(3) - (12)])->val, (yyvsp[(11) - (12)])); /* ss.comment: list of proctypes */
			  rl->cutoff = (yyvsp[(2) - (12)])->val; /* ss.add */ 
			  if ((yyvsp[(1) - (12)]) != ZN && (yyvsp[(1) - (12)])->val > 0) /* ss.comment: ACTIVE or ACTIVE[const] */
			  {	int j;
			  	for (j = 0; j < (yyvsp[(1) - (12)])->val; j++)
				runnable(rl, (yyvsp[(10) - (12)])?(yyvsp[(10) - (12)])->val:1, 1); /* ss.comment: # of active objects for each proctype */
				announce(":root:");
				if (dumptab) (yyvsp[(4) - (12)])->sym->ini = (yyvsp[(1) - (12)]);
			  }
			  context = ZS;
			}
    break;

  case 18:
#line 115 "spin.y"
    { (yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = 0; }
    break;

  case 19:
#line 116 "spin.y"
    { (yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = 1; }
    break;

  case 20:
#line 120 "spin.y"
    {(yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = 1000;}
    break;

  case 21:
#line 121 "spin.y"
    { (yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = 1; }
    break;

  case 22:
#line 122 "spin.y"
    {
		(yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = (yyvsp[(3) - (4)])->val;
		}
    break;

  case 23:
#line 127 "spin.y"
    { (yyval) = ZN; }
    break;

  case 24:
#line 128 "spin.y"
    { (yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = 1; }
    break;

  case 25:
#line 129 "spin.y"
    {
			  (yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = (yyvsp[(3) - (4)])->val;
			  if ((yyvsp[(3) - (4)])->val > 255)
				non_fatal("max nr of processes is 255\n", "");
			}
    break;

  case 26:
#line 134 "spin.y"
    {
			  (yyval) = nn(ZN,CONST,ZN,ZN);
			  (yyval)->val = 0; 
			  if (!(yyvsp[(3) - (4)])->sym->type) {
			    if(!strcmp((yyvsp[(3) - (4)])->sym->name, "_OMEGA")) {
					(yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = 1000;
			    }else 								    
					non_fatal("undeclared variable %s",
						(yyvsp[(3) - (4)])->sym->name);
			  }
			  else if ((yyvsp[(3) - (4)])->sym->ini->ntyp != CONST)
				non_fatal("need constant initializer for %s\n",
					(yyvsp[(3) - (4)])->sym->name);
			  else
				(yyval)->val = (yyvsp[(3) - (4)])->sym->ini->val;
			}
    break;

  case 27:
#line 151 "spin.y"
    { context = (yyvsp[(1) - (1)])->sym; }
    break;

  case 28:
#line 153 "spin.y"
    { ProcList *rl;
			  rl = ready(context, ZN, (yyvsp[(4) - (4)])->sq, 0, ZN);
			  runnable(rl, (yyvsp[(3) - (4)])?(yyvsp[(3) - (4)])->val:1, 1);
			  announce(":root:");
			  context = ZS;
        		}
    break;

  case 29:
#line 160 "spin.y"
    { context = (yyvsp[(1) - (1)])->sym;
			  if (claimproc)
				non_fatal("claim %s redefined", claimproc);
			  claimproc = (yyvsp[(1) - (1)])->sym->name;
			}
    break;

  case 30:
#line 165 "spin.y"
    { (void) ready((yyvsp[(1) - (3)])->sym, ZN, (yyvsp[(3) - (3)])->sq, 0, ZN);
        		  context = ZS;
        		}
    break;

  case 31:
#line 169 "spin.y"
    { context = (yyvsp[(1) - (1)])->sym;
			  if (eventmap)
				non_fatal("trace %s redefined", eventmap);
			  eventmap = (yyvsp[(1) - (1)])->sym->name;
			  inEventMap++;
			}
    break;

  case 32:
#line 175 "spin.y"
    { (void) ready((yyvsp[(1) - (3)])->sym, ZN, (yyvsp[(3) - (3)])->sq, 0, ZN);
        		  context = ZS;
			  inEventMap--;
			}
    break;

  case 33:
#line 180 "spin.y"
    { if (context)
				   fatal("typedef %s must be global",
						(yyvsp[(2) - (2)])->sym->name);
				   owner = (yyvsp[(2) - (2)])->sym;
				}
    break;

  case 34:
#line 185 "spin.y"
    { setuname((yyvsp[(5) - (6)])); owner = ZS; }
    break;

  case 35:
#line 187 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 36:
#line 188 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]);
				  if (IArgs)
				  fatal("invalid use of '%s'", (yyvsp[(1) - (1)])->sym->name);
				}
    break;

  case 37:
#line 193 "spin.y"
    { NamesNotAdded++; }
    break;

  case 38:
#line 194 "spin.y"
    { prep_inline((yyvsp[(2) - (6)])->sym, (yyvsp[(5) - (6)]));
				  NamesNotAdded--;
				}
    break;

  case 39:
#line 198 "spin.y"
    { /* leaves pseudo-inlines with sym of
				   * type CODE_FRAG or CODE_DECL in global context
				   */
				}
    break;

  case 41:
#line 204 "spin.y"
    {
				  c_state((yyvsp[(2) - (3)])->sym, (yyvsp[(3) - (3)])->sym, ZS);
				  has_code = has_state = 1;
				}
    break;

  case 42:
#line 208 "spin.y"
    {
				  c_track((yyvsp[(2) - (3)])->sym, (yyvsp[(3) - (3)])->sym, ZS);
				  has_code = has_state = 1;
				}
    break;

  case 43:
#line 212 "spin.y"
    {
				  c_state((yyvsp[(2) - (4)])->sym, (yyvsp[(3) - (4)])->sym, (yyvsp[(4) - (4)])->sym);
				  has_code = has_state = 1;
				}
    break;

  case 44:
#line 216 "spin.y"
    {
				  c_track((yyvsp[(2) - (4)])->sym, (yyvsp[(3) - (4)])->sym, (yyvsp[(4) - (4)])->sym);
				  has_code = has_state = 1;
				}
    break;

  case 45:
#line 222 "spin.y"
    { Symbol *s;
				  NamesNotAdded++;
				  s = prep_inline(ZS, ZN);
				  NamesNotAdded--;
				  (yyval) = nn(ZN, C_CODE, ZN, ZN);
				  (yyval)->sym = s;
				  has_code = 1;
				}
    break;

  case 46:
#line 230 "spin.y"
    { Symbol *s;
				  NamesNotAdded++;
				  s = prep_inline(ZS, ZN);
				  NamesNotAdded--;
				  s->type = CODE_DECL;
				  (yyval) = nn(ZN, C_CODE, ZN, ZN);
				  (yyval)->sym = s;
				  has_code = 1;
				}
    break;

  case 47:
#line 240 "spin.y"
    { Symbol *s;
				  NamesNotAdded++;
				  s = prep_inline(ZS, ZN);
				  NamesNotAdded--;
				  (yyval) = nn(ZN, C_EXPR, ZN, ZN);
				  (yyval)->sym = s;
				  no_side_effects(s->name);
				  has_code = 1;
				}
    break;

  case 48:
#line 250 "spin.y"
    { open_seq(1); }
    break;

  case 49:
#line 251 "spin.y"
    { add_seq(Stop); }
    break;

  case 50:
#line 252 "spin.y"
    { (yyval)->sq = close_seq(0); }
    break;

  case 51:
#line 255 "spin.y"
    { if ((yyvsp[(1) - (1)])) add_seq((yyvsp[(1) - (1)])); }
    break;

  case 52:
#line 256 "spin.y"
    { if ((yyvsp[(3) - (3)])) add_seq((yyvsp[(3) - (3)])); }
    break;

  case 53:
#line 259 "spin.y"
    { (yyval) = ZN; }
    break;

  case 54:
#line 260 "spin.y"
    { setxus((yyvsp[(2) - (2)]), (yyvsp[(1) - (2)])->val); (yyval) = ZN; }
    break;

  case 55:
#line 261 "spin.y"
    { fatal("label preceding declaration,", (char *)0); }
    break;

  case 56:
#line 262 "spin.y"
    { fatal("label predecing xr/xs claim,", 0); }
    break;

  case 57:
#line 263 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 58:
#line 264 "spin.y"
    { (yyval) = do_unless((yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 59:
#line 266 "spin.y"
    { (yyval) = ZN; }
    break;

  case 60:
#line 267 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 61:
#line 268 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 62:
#line 269 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 65:
#line 275 "spin.y"
    { setptype((yyvsp[(3) - (3)]), (yyvsp[(2) - (3)])->val, (yyvsp[(1) - (3)])); (yyval) = (yyvsp[(3) - (3)]); }
    break;

  case 66:
#line 276 "spin.y"
    { setutype((yyvsp[(3) - (3)]), (yyvsp[(2) - (3)])->sym, (yyvsp[(1) - (3)]));
				  (yyval) = expand((yyvsp[(3) - (3)]), Expand_Ok);
				}
    break;

  case 67:
#line 279 "spin.y"
    {
				  if ((yyvsp[(2) - (6)])->val != MTYPE)
					fatal("malformed declaration", 0);
				  setmtype((yyvsp[(5) - (6)]));
				  if ((yyvsp[(1) - (6)]))
					non_fatal("cannot %s mtype (ignored)",
						(yyvsp[(1) - (6)])->sym->name);
				  if (context != ZS)
					fatal("mtype declaration must be global", 0);
				}
    break;

  case 68:
#line 291 "spin.y"
    { (yyval) = nn(ZN, ',', (yyvsp[(1) - (1)]), ZN); }
    break;

  case 69:
#line 293 "spin.y"
    { (yyval) = nn(ZN, ',', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 70:
#line 295 "spin.y"
    { (yyval) = ZN; }
    break;

  case 71:
#line 296 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 72:
#line 298 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (1)]), XU, (yyvsp[(1) - (1)]), ZN); }
    break;

  case 73:
#line 299 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (3)]), XU, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 74:
#line 301 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (1)]), TYPE, ZN, ZN); }
    break;

  case 75:
#line 302 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (3)]), TYPE, ZN, (yyvsp[(3) - (3)])); }
    break;

  case 76:
#line 304 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]);
				  (yyvsp[(1) - (1)])->sym->ini = nn(ZN,CONST,ZN,ZN);
				  (yyvsp[(1) - (1)])->sym->ini->val = 0;
				}
    break;

  case 77:
#line 308 "spin.y"
    { (yyvsp[(1) - (3)])->sym->ini = (yyvsp[(3) - (3)]); (yyval) = (yyvsp[(1) - (3)]);
				  trackvar((yyvsp[(1) - (3)]),(yyvsp[(3) - (3)])); has_ini = 1;
				}
    break;

  case 78:
#line 311 "spin.y"
    { (yyvsp[(1) - (3)])->sym->ini = (yyvsp[(3) - (3)]);
				  (yyval) = (yyvsp[(1) - (3)]); has_ini = 1;
				}
    break;

  case 79:
#line 316 "spin.y"
    { if ((yyvsp[(2) - (7)])->val) u_async++;
				  else u_sync++;
        			  {	int i = cnt_mpars((yyvsp[(6) - (7)]));
					Mpars = max(Mpars, i);
				  }
        			  (yyval) = nn(ZN, CHAN, ZN, (yyvsp[(6) - (7)]));
				  (yyval)->val = (yyvsp[(2) - (7)])->val;
        			}
    break;

  case 80:
#line 325 "spin.y"
    { (yyvsp[(1) - (1)])->sym->nel = 1; (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 81:
#line 326 "spin.y"
    { (yyvsp[(1) - (3)])->sym->nbits = (yyvsp[(3) - (3)])->val;
				  if ((yyvsp[(3) - (3)])->val >= 8*sizeof(long))
				  {	non_fatal("width-field %s too large",
						(yyvsp[(1) - (3)])->sym->name);
					(yyvsp[(3) - (3)])->val = 8*sizeof(long)-1;
				  }
				  (yyvsp[(1) - (3)])->sym->nel = 1; (yyval) = (yyvsp[(1) - (3)]);
				}
    break;

  case 82:
#line 334 "spin.y"
    { (yyvsp[(1) - (4)])->sym->nel = (yyvsp[(3) - (4)])->val; (yyval) = (yyvsp[(1) - (4)]); }
    break;

  case 83:
#line 336 "spin.y"
    { (yyval) = mk_explicit((yyvsp[(1) - (1)]), Expand_Ok, NAME); }
    break;

  case 84:
#line 338 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (1)]), NAME, ZN, ZN); }
    break;

  case 85:
#line 339 "spin.y"
    { owner = ZS; }
    break;

  case 86:
#line 340 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (5)]), NAME, (yyvsp[(4) - (5)]), ZN); }
    break;

  case 87:
#line 342 "spin.y"
    { Embedded++;
				  if ((yyvsp[(1) - (1)])->sym->type == STRUCT)
					owner = (yyvsp[(1) - (1)])->sym->Snm;
				}
    break;

  case 88:
#line 346 "spin.y"
    { (yyval) = (yyvsp[(1) - (3)]); (yyval)->rgt = (yyvsp[(3) - (3)]);
				  if ((yyvsp[(3) - (3)]) && (yyvsp[(1) - (3)])->sym->type != STRUCT)
					(yyvsp[(1) - (3)])->sym->type = STRUCT;
				  Embedded--;
				  if (!Embedded && !NamesNotAdded
				  &&  !(yyvsp[(1) - (3)])->sym->type) { /* ss */
				  if(strcmp((yyvsp[(1) - (3)])->sym->name, "_OMEGA"))
					non_fatal("undeclared variable: %s",
							(yyvsp[(1) - (3)])->sym->name);
					}
				  if ((yyvsp[(3) - (3)])) validref((yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])->lft);
				  owner = ZS;
				}
    break;

  case 89:
#line 360 "spin.y"
    { (yyval) = ZN; }
    break;

  case 90:
#line 361 "spin.y"
    { (yyval) = nn(ZN, '.', (yyvsp[(2) - (2)]), ZN); }
    break;

  case 91:
#line 363 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 92:
#line 364 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]);
				  if (inEventMap)
				   non_fatal("not an event", (char *)0);
				}
    break;

  case 93:
#line 370 "spin.y"
    { Expand_Ok++; }
    break;

  case 94:
#line 371 "spin.y"
    { Expand_Ok--; has_io++;
				  (yyval) = nn((yyvsp[(1) - (4)]),  'r', (yyvsp[(1) - (4)]), (yyvsp[(4) - (4)]));
				  trackchanuse((yyvsp[(4) - (4)]), ZN, 'R');
				}
    break;

  case 95:
#line 375 "spin.y"
    { Expand_Ok++; }
    break;

  case 96:
#line 376 "spin.y"
    { Expand_Ok--; has_io++;
				  (yyval) = nn((yyvsp[(1) - (4)]), 's', (yyvsp[(1) - (4)]), (yyvsp[(4) - (4)]));
				  (yyval)->val=0; trackchanuse((yyvsp[(4) - (4)]), ZN, 'S');
				  any_runs((yyvsp[(4) - (4)]));
				}
    break;

  case 97:
#line 381 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (3)]), IF, ZN, ZN);
        			  (yyval)->sl = (yyvsp[(2) - (3)])->sl;
				  prune_opts((yyval));
        			}
    break;

  case 98:
#line 385 "spin.y"
    { pushbreak(); }
    break;

  case 99:
#line 386 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (4)]), DO, ZN, ZN);
        			  (yyval)->sl = (yyvsp[(3) - (4)])->sl;
				  prune_opts((yyval));
        			}
    break;

  case 100:
#line 390 "spin.y"
    { (yyval) = nn(ZN, GOTO, ZN, ZN);
				  (yyval)->sym = break_dest();
				}
    break;

  case 101:
#line 393 "spin.y"
    { (yyval) = nn((yyvsp[(2) - (2)]), GOTO, ZN, ZN);
				  if ((yyvsp[(2) - (2)])->sym->type != 0
				  &&  (yyvsp[(2) - (2)])->sym->type != LABEL) {
				  	non_fatal("bad label-name %s",
					(yyvsp[(2) - (2)])->sym->name);
				  }
				  (yyvsp[(2) - (2)])->sym->type = LABEL;
				}
    break;

  case 102:
#line 401 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (3)]), ':',(yyvsp[(3) - (3)]), ZN);
				  if ((yyvsp[(1) - (3)])->sym->type != 0
				  &&  (yyvsp[(1) - (3)])->sym->type != LABEL) {
				  	non_fatal("bad label-name %s",
					(yyvsp[(1) - (3)])->sym->name);
				  }
				  (yyvsp[(1) - (3)])->sym->type = LABEL;
				}
    break;

  case 103:
#line 411 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (3)]), ASGN, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)]));
				  trackvar((yyvsp[(1) - (3)]), (yyvsp[(3) - (3)]));
				  nochan_manip((yyvsp[(1) - (3)]), (yyvsp[(3) - (3)]), 0);
				  no_internals((yyvsp[(1) - (3)]));
				}
    break;

  case 104:
#line 416 "spin.y"
    { (yyval) = nn(ZN,CONST, ZN, ZN); (yyval)->val = 1;
				  (yyval) = nn(ZN,  '+', (yyvsp[(1) - (2)]), (yyval));
				  (yyval) = nn((yyvsp[(1) - (2)]), ASGN, (yyvsp[(1) - (2)]), (yyval));
				  trackvar((yyvsp[(1) - (2)]), (yyvsp[(1) - (2)]));
				  no_internals((yyvsp[(1) - (2)]));
				  if ((yyvsp[(1) - (2)])->sym->type == CHAN)
				   fatal("arithmetic on chan", (char *)0);
				}
    break;

  case 105:
#line 424 "spin.y"
    { (yyval) = nn(ZN,CONST, ZN, ZN); (yyval)->val = 1;
				  (yyval) = nn(ZN,  '-', (yyvsp[(1) - (2)]), (yyval));
				  (yyval) = nn((yyvsp[(1) - (2)]), ASGN, (yyvsp[(1) - (2)]), (yyval));
				  trackvar((yyvsp[(1) - (2)]), (yyvsp[(1) - (2)]));
				  no_internals((yyvsp[(1) - (2)]));
				  if ((yyvsp[(1) - (2)])->sym->type == CHAN)
				   fatal("arithmetic on chan id's", (char *)0);
				}
    break;

  case 106:
#line 432 "spin.y"
    { realread = 0; }
    break;

  case 107:
#line 433 "spin.y"
    { (yyval) = nn((yyvsp[(3) - (6)]), PRINT, (yyvsp[(5) - (6)]), ZN); realread = 1; }
    break;

  case 108:
#line 434 "spin.y"
    { (yyval) = nn(ZN, PRINTM, (yyvsp[(3) - (4)]), ZN); }
    break;

  case 109:
#line 435 "spin.y"
    { (yyval) = nn(ZN, PRINTM, (yyvsp[(3) - (4)]), ZN); }
    break;

  case 110:
#line 436 "spin.y"
    { (yyval) = nn(ZN, ASSERT, (yyvsp[(2) - (2)]), ZN); AST_track((yyvsp[(2) - (2)]), 0); }
    break;

  case 111:
#line 437 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 112:
#line 438 "spin.y"
    { Expand_Ok++; }
    break;

  case 113:
#line 439 "spin.y"
    { Expand_Ok--; has_io++;
				  (yyval) = nn((yyvsp[(1) - (4)]),  'r', (yyvsp[(1) - (4)]), (yyvsp[(4) - (4)]));
				  (yyval)->val = has_random = 1;
				  trackchanuse((yyvsp[(4) - (4)]), ZN, 'R');
				}
    break;

  case 114:
#line 444 "spin.y"
    { Expand_Ok++; }
    break;

  case 115:
#line 445 "spin.y"
    { Expand_Ok--; has_io++;
				  (yyval) = nn((yyvsp[(1) - (6)]), 'r', (yyvsp[(1) - (6)]), (yyvsp[(5) - (6)]));
				  (yyval)->val = 2;	/* fifo poll */
				  trackchanuse((yyvsp[(5) - (6)]), ZN, 'R');
				}
    break;

  case 116:
#line 450 "spin.y"
    { Expand_Ok++; }
    break;

  case 117:
#line 451 "spin.y"
    { Expand_Ok--; has_io++;	/* rrcv poll */
				  (yyval) = nn((yyvsp[(1) - (6)]), 'r', (yyvsp[(1) - (6)]), (yyvsp[(5) - (6)]));
				  (yyval)->val = 3; has_random = 1;
				  trackchanuse((yyvsp[(5) - (6)]), ZN, 'R');
				}
    break;

  case 118:
#line 456 "spin.y"
    { Expand_Ok++; }
    break;

  case 119:
#line 457 "spin.y"
    { Expand_Ok--; has_io++;
				  (yyval) = nn((yyvsp[(1) - (4)]), 's', (yyvsp[(1) - (4)]), (yyvsp[(4) - (4)]));
				  (yyval)->val = has_sorted = 1;
				  trackchanuse((yyvsp[(4) - (4)]), ZN, 'S');
				  any_runs((yyvsp[(4) - (4)]));
				}
    break;

  case 120:
#line 463 "spin.y"
    { (yyval) = nn(ZN, 'c', (yyvsp[(1) - (1)]), ZN); count_runs((yyval)); }
    break;

  case 121:
#line 464 "spin.y"
    { (yyval) = nn(ZN,ELSE,ZN,ZN);
				}
    break;

  case 122:
#line 466 "spin.y"
    { open_seq(0); }
    break;

  case 123:
#line 467 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (6)]), ATOMIC, ZN, ZN);
        			  (yyval)->sl = seqlist(close_seq(3), 0);
        			  make_atomic((yyval)->sl->this, 0);
        			}
    break;

  case 124:
#line 471 "spin.y"
    { open_seq(0); rem_Seq(); }
    break;

  case 125:
#line 472 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (6)]), D_STEP, ZN, ZN);
        			  (yyval)->sl = seqlist(close_seq(4), 0);
        			  make_atomic((yyval)->sl->this, D_ATOM);
				  unrem_Seq();
        			}
    break;

  case 126:
#line 477 "spin.y"
    { open_seq(0); }
    break;

  case 127:
#line 478 "spin.y"
    { (yyval) = nn(ZN, NON_ATOMIC, ZN, ZN);
        			  (yyval)->sl = seqlist(close_seq(5), 0);
        			}
    break;

  case 128:
#line 481 "spin.y"
    { IArgs++; }
    break;

  case 129:
#line 482 "spin.y"
    { pickup_inline((yyvsp[(1) - (5)])->sym, (yyvsp[(4) - (5)])); IArgs--; }
    break;

  case 130:
#line 483 "spin.y"
    { (yyval) = (yyvsp[(7) - (7)]); }
    break;

  case 131:
#line 486 "spin.y"
    { (yyval)->sl = seqlist((yyvsp[(1) - (1)])->sq, 0); }
    break;

  case 132:
#line 487 "spin.y"
    { (yyval)->sl = seqlist((yyvsp[(1) - (2)])->sq, (yyvsp[(2) - (2)])->sl); }
    break;

  case 133:
#line 490 "spin.y"
    { open_seq(0); }
    break;

  case 134:
#line 491 "spin.y"
    { (yyval) = nn(ZN,0,ZN,ZN);
				  (yyval)->sq = close_seq(6); }
    break;

  case 136:
#line 496 "spin.y"
    { /* redundant semi at end of sequence */ }
    break;

  case 137:
#line 499 "spin.y"
    { /* at least one semi-colon */ }
    break;

  case 138:
#line 500 "spin.y"
    { /* but more are okay too   */ }
    break;

  case 139:
#line 503 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 140:
#line 504 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 141:
#line 507 "spin.y"
    { (yyval) = (yyvsp[(2) - (3)]); }
    break;

  case 142:
#line 508 "spin.y"
    { (yyval) = nn(ZN, '+', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 143:
#line 509 "spin.y"
    { (yyval) = nn(ZN, '-', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 144:
#line 510 "spin.y"
    { (yyval) = nn(ZN, '*', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 145:
#line 511 "spin.y"
    { (yyval) = nn(ZN, '/', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 146:
#line 512 "spin.y"
    { (yyval) = nn(ZN, '%', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 147:
#line 513 "spin.y"
    { (yyval) = nn(ZN, '&', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 148:
#line 514 "spin.y"
    { (yyval) = nn(ZN, '^', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 149:
#line 515 "spin.y"
    { (yyval) = nn(ZN, '|', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 150:
#line 516 "spin.y"
    { (yyval) = nn(ZN,  GT, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 151:
#line 517 "spin.y"
    { (yyval) = nn(ZN,  LT, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 152:
#line 518 "spin.y"
    { (yyval) = nn(ZN,  GE, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 153:
#line 519 "spin.y"
    { (yyval) = nn(ZN,  LE, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 154:
#line 520 "spin.y"
    { (yyval) = nn(ZN,  EQ, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 155:
#line 521 "spin.y"
    { (yyval) = nn(ZN,  NE, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 156:
#line 522 "spin.y"
    { (yyval) = nn(ZN, AND, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 157:
#line 523 "spin.y"
    { (yyval) = nn(ZN,  OR, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 158:
#line 524 "spin.y"
    { (yyval) = nn(ZN, LSHIFT,(yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 159:
#line 525 "spin.y"
    { (yyval) = nn(ZN, RSHIFT,(yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 160:
#line 526 "spin.y"
    { (yyval) = nn(ZN, '~', (yyvsp[(2) - (2)]), ZN); }
    break;

  case 161:
#line 527 "spin.y"
    { (yyval) = nn(ZN, UMIN, (yyvsp[(2) - (2)]), ZN); }
    break;

  case 162:
#line 528 "spin.y"
    { (yyval) = nn(ZN, '!', (yyvsp[(2) - (2)]), ZN); }
    break;

  case 163:
#line 530 "spin.y"
    {
				  (yyval) = nn(ZN,  OR, (yyvsp[(4) - (7)]), (yyvsp[(6) - (7)]));
				  (yyval) = nn(ZN, '?', (yyvsp[(2) - (7)]), (yyval));
				}
    break;

  case 164:
#line 535 "spin.y"
    { Expand_Ok++;
				  if (!context)
				  fatal("used 'run' outside proctype",
					(char *) 0);
				  if (strcmp(context->name, ":init:") != 0)
					runsafe = 0;
				}
    break;

  case 165:
#line 543 "spin.y"
    { Expand_Ok--;
				  (yyval) = nn((yyvsp[(2) - (7)]), RUN, (yyvsp[(5) - (7)]), ZN);
				  (yyval)->val = ((yyvsp[(7) - (7)])) ? (yyvsp[(7) - (7)])->val : 1;
				  trackchanuse((yyvsp[(5) - (7)]), (yyvsp[(2) - (7)]), 'A'); trackrun((yyval));
				}
    break;

  case 166:
#line 548 "spin.y"
    { (yyval) = nn((yyvsp[(3) - (4)]), LEN, (yyvsp[(3) - (4)]), ZN); }
    break;

  case 167:
#line 549 "spin.y"
    { (yyval) = nn(ZN, ENABLED, (yyvsp[(3) - (4)]), ZN);
				  has_enabled++;
				}
    break;

  case 168:
#line 552 "spin.y"
    { Expand_Ok++; }
    break;

  case 169:
#line 553 "spin.y"
    { Expand_Ok--; has_io++;
				  (yyval) = nn((yyvsp[(1) - (6)]), 'R', (yyvsp[(1) - (6)]), (yyvsp[(5) - (6)]));
				}
    break;

  case 170:
#line 556 "spin.y"
    { Expand_Ok++; }
    break;

  case 171:
#line 557 "spin.y"
    { Expand_Ok--; has_io++;
				  (yyval) = nn((yyvsp[(1) - (6)]), 'R', (yyvsp[(1) - (6)]), (yyvsp[(5) - (6)]));
				  (yyval)->val = has_random = 1;
				}
    break;

  case 172:
#line 561 "spin.y"
    { /* ss */
						if(!strcmp((yyvsp[(1) - (1)])->sym->name, "_OMEGA")) {
							(yyval) = nn(ZN,CONST,ZN,ZN); (yyval)->val = 1000;
						}else {	
							(yyval) = (yyvsp[(1) - (1)]); trapwonly((yyvsp[(1) - (1)]), "varref"); 
						}
					}
    break;

  case 173:
#line 568 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 174:
#line 569 "spin.y"
    { (yyval) = nn(ZN,CONST,ZN,ZN);
				  (yyval)->ismtyp = (yyvsp[(1) - (1)])->ismtyp;
				  (yyval)->val = (yyvsp[(1) - (1)])->val;
				}
    break;

  case 175:
#line 573 "spin.y"
    { (yyval) = nn(ZN,TIMEOUT, ZN, ZN); }
    break;

  case 176:
#line 574 "spin.y"
    { (yyval) = nn(ZN,NONPROGRESS, ZN, ZN);
				  has_np++;
				}
    break;

  case 177:
#line 577 "spin.y"
    { (yyval) = nn(ZN, PC_VAL, (yyvsp[(3) - (4)]), ZN);
				  has_pcvalue++;
				}
    break;

  case 178:
#line 581 "spin.y"
    { (yyval) = rem_lab((yyvsp[(1) - (6)])->sym, (yyvsp[(3) - (6)]), (yyvsp[(6) - (6)])->sym); }
    break;

  case 179:
#line 583 "spin.y"
    { (yyval) = rem_var((yyvsp[(1) - (6)])->sym, (yyvsp[(3) - (6)]), (yyvsp[(6) - (6)])->sym, (yyvsp[(6) - (6)])->lft); }
    break;

  case 180:
#line 584 "spin.y"
    { (yyval) = rem_lab((yyvsp[(1) - (3)])->sym, ZN, (yyvsp[(3) - (3)])->sym); }
    break;

  case 181:
#line 585 "spin.y"
    { (yyval) = rem_var((yyvsp[(1) - (3)])->sym, ZN, (yyvsp[(3) - (3)])->sym, (yyvsp[(3) - (3)])->lft); }
    break;

  case 182:
#line 588 "spin.y"
    { (yyval) = ZN; }
    break;

  case 183:
#line 589 "spin.y"
    { (yyval) = (yyvsp[(2) - (2)]); }
    break;

  case 184:
#line 592 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 185:
#line 593 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 186:
#line 596 "spin.y"
    { (yyval) = ZN; }
    break;

  case 187:
#line 597 "spin.y"
    { if (!proper_enabler((yyvsp[(3) - (4)])))
				  {	non_fatal("invalid PROVIDED clause",
						(char *)0);
					(yyval) = ZN;
				  } else
					(yyval) = (yyvsp[(3) - (4)]);
				 }
    break;

  case 188:
#line 604 "spin.y"
    { (yyval) = ZN;
				  non_fatal("usage: provided ( ..expr.. )",
					(char *)0);
				}
    break;

  case 189:
#line 611 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 190:
#line 612 "spin.y"
    { (yyval) = (yyvsp[(2) - (3)]); }
    break;

  case 191:
#line 613 "spin.y"
    { (yyval) = nn(ZN, AND, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 192:
#line 614 "spin.y"
    { (yyval) = nn(ZN, AND, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 193:
#line 615 "spin.y"
    { (yyval) = nn(ZN,  OR, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 194:
#line 616 "spin.y"
    { (yyval) = nn(ZN,  OR, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 195:
#line 617 "spin.y"
    { (yyval) = nn(ZN, AND, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 196:
#line 618 "spin.y"
    { (yyval) = nn(ZN,  OR, (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)])); }
    break;

  case 197:
#line 621 "spin.y"
    { (yyval) = nn((yyvsp[(3) - (4)]),  FULL, (yyvsp[(3) - (4)]), ZN); }
    break;

  case 198:
#line 622 "spin.y"
    { (yyval) = nn((yyvsp[(3) - (4)]), NFULL, (yyvsp[(3) - (4)]), ZN); }
    break;

  case 199:
#line 623 "spin.y"
    { (yyval) = nn((yyvsp[(3) - (4)]), EMPTY, (yyvsp[(3) - (4)]), ZN); }
    break;

  case 200:
#line 624 "spin.y"
    { (yyval) = nn((yyvsp[(3) - (4)]),NEMPTY, (yyvsp[(3) - (4)]), ZN); }
    break;

  case 201:
#line 627 "spin.y"
    { (yyval)->sym = ZS;
				  (yyval)->val = (yyvsp[(1) - (1)])->val;
				  if ((yyval)->val == UNSIGNED)
				  fatal("unsigned cannot be used as mesg type", 0);
				}
    break;

  case 202:
#line 632 "spin.y"
    { (yyval)->sym = (yyvsp[(1) - (1)])->sym;
				  (yyval)->val = STRUCT;
				}
    break;

  case 204:
#line 638 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (1)]), (yyvsp[(1) - (1)])->val, ZN, ZN); }
    break;

  case 205:
#line 639 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (3)]), (yyvsp[(1) - (3)])->val, ZN, (yyvsp[(3) - (3)])); }
    break;

  case 206:
#line 642 "spin.y"
    { (yyval) = ZN; }
    break;

  case 207:
#line 643 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 208:
#line 646 "spin.y"
    { (yyval) = ZN; }
    break;

  case 209:
#line 647 "spin.y"
    { (yyval) = (yyvsp[(2) - (2)]); }
    break;

  case 210:
#line 650 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); }
    break;

  case 211:
#line 651 "spin.y"
    { if ((yyvsp[(1) - (4)])->ntyp == ',')
					(yyval) = tail_add((yyvsp[(1) - (4)]), (yyvsp[(3) - (4)]));
				  else
				  	(yyval) = nn(ZN, ',', (yyvsp[(1) - (4)]), (yyvsp[(3) - (4)]));
				}
    break;

  case 212:
#line 658 "spin.y"
    { if ((yyvsp[(1) - (1)])->ntyp == ',')
					(yyval) = (yyvsp[(1) - (1)]);
				  else
				  	(yyval) = nn(ZN, ',', (yyvsp[(1) - (1)]), ZN);
				}
    break;

  case 213:
#line 663 "spin.y"
    { if ((yyvsp[(1) - (3)])->ntyp == ',')
					(yyval) = tail_add((yyvsp[(1) - (3)]), (yyvsp[(3) - (3)]));
				  else
				  	(yyval) = nn(ZN, ',', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)]));
				}
    break;

  case 214:
#line 670 "spin.y"
    { (yyval) = (yyvsp[(1) - (1)]); trackvar((yyvsp[(1) - (1)]), (yyvsp[(1) - (1)]));
				  trapwonly((yyvsp[(1) - (1)]), "rarg"); }
    break;

  case 215:
#line 672 "spin.y"
    { (yyval) = nn(ZN,EVAL,(yyvsp[(3) - (4)]),ZN);
				  trapwonly((yyvsp[(1) - (4)]), "eval rarg"); }
    break;

  case 216:
#line 674 "spin.y"
    { (yyval) = nn(ZN,CONST,ZN,ZN);
				  (yyval)->ismtyp = (yyvsp[(1) - (1)])->ismtyp;
				  (yyval)->val = (yyvsp[(1) - (1)])->val;
				}
    break;

  case 217:
#line 678 "spin.y"
    { (yyval) = nn(ZN,CONST,ZN,ZN);
				  (yyval)->val = - ((yyvsp[(2) - (2)])->val);
				}
    break;

  case 218:
#line 683 "spin.y"
    { if ((yyvsp[(1) - (1)])->ntyp == ',')
					(yyval) = (yyvsp[(1) - (1)]);
				  else
				  	(yyval) = nn(ZN, ',', (yyvsp[(1) - (1)]), ZN);
				}
    break;

  case 219:
#line 688 "spin.y"
    { if ((yyvsp[(1) - (3)])->ntyp == ',')
					(yyval) = tail_add((yyvsp[(1) - (3)]), (yyvsp[(3) - (3)]));
				  else
				  	(yyval) = nn(ZN, ',', (yyvsp[(1) - (3)]), (yyvsp[(3) - (3)]));
				}
    break;

  case 220:
#line 693 "spin.y"
    { if ((yyvsp[(1) - (4)])->ntyp == ',')
					(yyval) = tail_add((yyvsp[(1) - (4)]), (yyvsp[(3) - (4)]));
				  else
				  	(yyval) = nn(ZN, ',', (yyvsp[(1) - (4)]), (yyvsp[(3) - (4)]));
				}
    break;

  case 221:
#line 698 "spin.y"
    { (yyval) = (yyvsp[(2) - (3)]); }
    break;

  case 222:
#line 701 "spin.y"
    { (yyval) = nn((yyvsp[(1) - (1)]), NAME, ZN, ZN);
				  (yyval) = nn(ZN, ',', (yyval), ZN); }
    break;

  case 223:
#line 703 "spin.y"
    { (yyval) = nn((yyvsp[(2) - (2)]), NAME, ZN, ZN);
				  (yyval) = nn(ZN, ',', (yyval), (yyvsp[(1) - (2)]));
				}
    break;

  case 224:
#line 706 "spin.y"
    { (yyval) = (yyvsp[(1) - (2)]); /* commas optional */ }
    break;


/* Line 1267 of yacc.c.  */
#line 3386 "y.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 708 "spin.y"


void
yyerror(char *fmt, ...)
{
	non_fatal(fmt, (char *) 0);
}

