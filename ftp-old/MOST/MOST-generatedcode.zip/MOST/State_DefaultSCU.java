/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=DefaultSCU
*/
public class State_DefaultSCU extends AState {
	private SystemConfigurationUpdate baseClass;
	
	public State_DefaultSCU (SystemConfigurationUpdate baseClass) {
		this.parentRegionName = "SCU";
		this.baseClass = baseClass;

		
	}
	
	public State_DefaultSCU (SystemConfigurationUpdate baseClass, AState[] children) {
		this.parentRegionName = "SCU";
		this.baseClass = baseClass;		

		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_update:
				
				
				
				if(ConfigUpdateSuccesschoice_Condition()) {
					
					ConfigUpdateSuccesschoice_Taken();
				} else
				
				if(ConfigUpdateErrorchoice_Condition()) {
					
					ConfigUpdateErrorchoice_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=ConfigUpdateSuccesschoice subtype=condition
	*/
	private boolean ConfigUpdateSuccesschoice_Condition() {
		return baseClass.configUpdate==ConfigUpdateChoice.Success;
	}
	/**
	* @model type=transition name=ConfigUpdateSuccesschoice subtype=take
	*/
	private void ConfigUpdateSuccesschoice_Taken() {
		
		AState target = new State_ConfigUpdateSuccess(this.baseClass);
		
		this.parentRegion.processTransition("SCU", target);
	}
	
	
	/**
	* @model type=transition name=ConfigUpdateErrorchoice subtype=condition
	*/
	private boolean ConfigUpdateErrorchoice_Condition() {
		return baseClass.configUpdate==ConfigUpdateChoice.Error;
	}
	/**
	* @model type=transition name=ConfigUpdateErrorchoice subtype=take
	*/
	private void ConfigUpdateErrorchoice_Taken() {
		
		AState target = new State_ConfigUpdateError(this.baseClass);
		
		this.parentRegion.processTransition("SCU", target);
	}
	
	
	
	
	
	
}