/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:30 PM
*/

package MOST;

/**
* @model type=state name=NMGenInitSysConfigUpdate
*/
public class State_NMGenInitSysConfigUpdate extends AState {
	private NetworkMaster baseClass;
	
	public State_NMGenInitSysConfigUpdate (NetworkMaster baseClass) {
		this.parentRegionName = "NMGenInit";
		this.baseClass = baseClass;

		
	}
	
	public State_NMGenInitSysConfigUpdate (NetworkMaster baseClass, AState[] children) {
		this.parentRegionName = "NMGenInit";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=NMGenInitSysConfigUpdate subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		SystemConfigurationUpdate scu = new SystemConfigurationUpdate();scu.update(new Integer(ConfigUpdateChoice.Error));baseClass.InitProgress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NMInitProgress:
				
				
				
				NMGenInitSysCfgUpd_Action(event.parameter);
				
				NMGenInitSysCfgUpd_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	/**
	* @model type=transition name=NMGenInitSysCfgUpd subtype=action
	*/
	private void NMGenInitSysCfgUpd_Action(Object parameter) {
		CentralRegistry.clear();
	}
	
	
	
	
	
	/**
	* @model type=transition name=NMGenInitSysCfgUpd subtype=take
	*/
	private void NMGenInitSysCfgUpd_Taken() {
		
		AState target = new State_NMGenInitInitializeVariable(this.baseClass);
		
		this.parentRegion.processTransition("NMGenInit", target);
	}
	
	
}