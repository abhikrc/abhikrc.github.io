/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=abstractregion
*/
abstract class ARegion {
	public AState activeState;
	public AState parentState;
	public String elementName="";
	public boolean isEnterByDefault = true;
	
	public abstract void trigger(Events event);
	public abstract void entryActivity();
	
	public void processTransition(String lcr, AState target) {
		if(this.elementName.equals(lcr)) {
			this.activeState.exitActivity();
			this.activeState = target;
			this.activeState.parentRegion = this;
			this.activeState.entryActivity();
		}
		else {
			this.parentState.parentRegion.processTransition(lcr, target);
		}
	}
}