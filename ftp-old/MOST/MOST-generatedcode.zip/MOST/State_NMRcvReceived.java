/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

/**
* @model type=state name=NMRcvReceived
*/
public class State_NMRcvReceived extends AState {
	private NetworkMaster baseClass;
	
	public State_NMRcvReceived (NetworkMaster baseClass) {
		this.parentRegionName = "NMReceiveConfig";
		this.baseClass = baseClass;

		
	}
	
	public State_NMRcvReceived (NetworkMaster baseClass, AState[] children) {
		this.parentRegionName = "NMReceiveConfig";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=NMRcvReceived subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		baseClass.RcvProgress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NMRcvProgress:
				
				
				
				if(NMRcvNodeAddressInvalidchoice_Condition()) {
					
					NMRcvNodeAddressInvalidchoice_Taken();
				} else
				
				if(NMRcvInstIDInvalidchoice_Condition()) {
					
					NMRcvInstIDInvalidchoice_Taken();
				} else
				
				{
				
					
					
					NMRcvReceivedElseChoice_Taken();
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NMRcvNodeAddressInvalidchoice subtype=condition
	*/
	private boolean NMRcvNodeAddressInvalidchoice_Condition() {
		return !CentralRegistry.validateNodeAddress(baseClass.currReceivedFBlockID);
	}
	/**
	* @model type=transition name=NMRcvNodeAddressInvalidchoice subtype=take
	*/
	private void NMRcvNodeAddressInvalidchoice_Taken() {
		
		AState target = new State_NMRcvNodeAddressInvalid(this.baseClass);
		
		this.parentRegion.processTransition("NMReceiveConfig", target);
	}
	
	
	/**
	* @model type=transition name=NMRcvInstIDInvalidchoice subtype=condition
	*/
	private boolean NMRcvInstIDInvalidchoice_Condition() {
		return !CentralRegistry.validateInstID(baseClass.currReceivedFBlockID);
	}
	/**
	* @model type=transition name=NMRcvInstIDInvalidchoice subtype=take
	*/
	private void NMRcvInstIDInvalidchoice_Taken() {
		
		AState target = new State_NMRcvInstIDInvalid(this.baseClass);
		
		this.parentRegion.processTransition("NMReceiveConfig", target);
	}
	
	
	
	
	
	/**
	* @model type=transition name=NMRcvReceivedElseChoice subtype=take
	*/
	private void NMRcvReceivedElseChoice_Taken() {
		
		AState target = new State_NMRcvUpdate(this.baseClass);
		
		this.parentRegion.processTransition("NMReceiveConfig", target);
	}
	
	
	
	
}