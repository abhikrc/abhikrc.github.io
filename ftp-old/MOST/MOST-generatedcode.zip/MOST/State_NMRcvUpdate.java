/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

/**
* @model type=state name=NMRcvUpdate
*/
public class State_NMRcvUpdate extends AState {
	private NetworkMaster baseClass;
	
	public State_NMRcvUpdate (NetworkMaster baseClass) {
		this.parentRegionName = "NMReceiveConfig";
		this.baseClass = baseClass;

		
	}
	
	public State_NMRcvUpdate (NetworkMaster baseClass, AState[] children) {
		this.parentRegionName = "NMReceiveConfig";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=NMRcvUpdate subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		CentralRegistry.updateEntry(baseClass.currReceivedFBlockID); baseClass.currReceivedFBlockID=null; baseClass.RcvProgress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NMRcvProgress:
				
				
				
				if(NMRcvAfterUpdateNotOKchoice_Condition()) {
					
					NMRcvAfterUpdateNotOKchoice_Taken();
				} else
				
				if(NMRcvAfterUpdateOKchoice_Condition()) {
					
					NMRcvAfterUpdateOKchoice_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NMRcvAfterUpdateNotOKchoice subtype=condition
	*/
	private boolean NMRcvAfterUpdateNotOKchoice_Condition() {
		return SystemState.CurrentState==SystemState.NotOK;
	}
	/**
	* @model type=transition name=NMRcvAfterUpdateNotOKchoice subtype=take
	*/
	private void NMRcvAfterUpdateNotOKchoice_Taken() {
		
		AState target = new State_NMRcvSysCfgUpdNotOK(this.baseClass);
		
		this.parentRegion.processTransition("NMReceiveConfig", target);
	}
	
	
	/**
	* @model type=transition name=NMRcvAfterUpdateOKchoice subtype=condition
	*/
	private boolean NMRcvAfterUpdateOKchoice_Condition() {
		return SystemState.CurrentState==SystemState.OK;
	}
	/**
	* @model type=transition name=NMRcvAfterUpdateOKchoice subtype=take
	*/
	private void NMRcvAfterUpdateOKchoice_Taken() {
		
		AState target = new State_NMRcvSysCfgUpdOK(this.baseClass);
		
		this.parentRegion.processTransition("NMReceiveConfig", target);
	}
	
	
	
	
	
	
}