/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

/**
* @model type=state name=MsgNotRcv
*/
public class State_MsgNotRcv extends AState {
	private NetworkSlave baseClass;
	
	public State_MsgNotRcv (NetworkSlave baseClass) {
		this.parentRegionName = "NSGenInit";
		this.baseClass = baseClass;

		
	}
	
	public State_MsgNotRcv (NetworkSlave baseClass, AState[] children) {
		this.parentRegionName = "NSGenInit";
		this.baseClass = baseClass;		

		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_GetFBlockID:
				
				
				
				if(InitPriGetBefore_Condition()) {
					
					InitPriGetBefore_Action(event.parameter);
					
					InitPriGetBefore_Taken();
				} else
				
				if(InitSecGetBefore_Condition()) {
					
					InitSecGetBefore_Action(event.parameter);
					
					InitSecGetBefore_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			case Events.EVENT_GetSetFBlockID:
				
				
				
				if(InitPriGetSetBefore_Condition()) {
					
					InitPriGetSetBefore_Action(event.parameter);
					
					InitPriGetSetBefore_Taken();
				} else
				
				if(InitSecGetSetBefore_Condition()) {
					
					InitSecGetSetBefore_Action(event.parameter);
					
					InitSecGetSetBefore_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			case Events.EVENT_UpdateConfigurationStatus:
				
				
				
				if(InitCfgStatusNotOKBefore_Condition()) {
					
					InitCfgStatusNotOKBefore_Taken();
				} else
				
				{
				
					
					
					InitCfgStatusElseBefore_Action(event.parameter);
					
					InitCfgStatusElseBefore_Taken();
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=InitPriGetBefore subtype=action
	*/
	private void InitPriGetBefore_Action(Object parameter) {
		NetworkMaster.getInstance().ReceiveFBlockIDStatus(baseClass.getNextFBlockID());
	}
	
	/**
	* @model type=transition name=InitPriGetBefore subtype=condition
	*/
	private boolean InitPriGetBefore_Condition() {
		return baseClass.type==NetworkSlave.PRIMARY_TYPE;
	}
	/**
	* @model type=transition name=InitPriGetBefore subtype=take
	*/
	private void InitPriGetBefore_Taken() {
		
		AState target = new State_InitPriGet(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
	/**
	* @model type=transition name=InitSecGetBefore subtype=action
	*/
	private void InitSecGetBefore_Action(Object parameter) {
		NetworkMaster.getInstance().ReceiveFBlockIDError();
	}
	
	/**
	* @model type=transition name=InitSecGetBefore subtype=condition
	*/
	private boolean InitSecGetBefore_Condition() {
		return baseClass.type==NetworkSlave.SECONDARY_TYPE;
	}
	/**
	* @model type=transition name=InitSecGetBefore subtype=take
	*/
	private void InitSecGetBefore_Taken() {
		
		AState target = new State_InitSecGet(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
	
	
	
	
	
	
	
	
	
	/**
	* @model type=transition name=InitPriGetSetBefore subtype=action
	*/
	private void InitPriGetSetBefore_Action(Object parameter) {
		NetworkMaster.getInstance().ReceiveFBlockIDStatus(baseClass.getNextFBlockID());
	}
	
	/**
	* @model type=transition name=InitPriGetSetBefore subtype=condition
	*/
	private boolean InitPriGetSetBefore_Condition() {
		return baseClass.type==NetworkSlave.PRIMARY_TYPE;
	}
	/**
	* @model type=transition name=InitPriGetSetBefore subtype=take
	*/
	private void InitPriGetSetBefore_Taken() {
		
		AState target = new State_InitPriGetSet(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
	/**
	* @model type=transition name=InitSecGetSetBefore subtype=action
	*/
	private void InitSecGetSetBefore_Action(Object parameter) {
		NetworkMaster.getInstance().ReceiveFBlockIDError();
	}
	
	/**
	* @model type=transition name=InitSecGetSetBefore subtype=condition
	*/
	private boolean InitSecGetSetBefore_Condition() {
		return baseClass.type==NetworkSlave.SECONDARY_TYPE;
	}
	/**
	* @model type=transition name=InitSecGetSetBefore subtype=take
	*/
	private void InitSecGetSetBefore_Taken() {
		
		AState target = new State_InitSecGetSet(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
	
	
	
	
	
	
	
	
	
	/**
	* @model type=transition name=InitCfgStatusNotOKBefore subtype=condition
	*/
	private boolean InitCfgStatusNotOKBefore_Condition() {
		return baseClass.configControlValue==ConfigurationControl.NotOK;
	}
	/**
	* @model type=transition name=InitCfgStatusNotOKBefore subtype=take
	*/
	private void InitCfgStatusNotOKBefore_Taken() {
		
		AState target = new State_InitCfgStatusNotOK(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
	
	
	
	/**
	* @model type=transition name=InitCfgStatusElseBefore subtype=action
	*/
	private void InitCfgStatusElseBefore_Action(Object parameter) {
		//store master addr
	}
	
	/**
	* @model type=transition name=InitCfgStatusElseBefore subtype=take
	*/
	private void InitCfgStatusElseBefore_Taken() {
		
		AState target = new State_InitCfgStatusElse(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
	
	
}