/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

import java.util.*;

/**
* @model type=statechart name=NM
*/
public class SC_NM {
	private Region_NM region;
	private LinkedList eventQueue = new LinkedList();
	private boolean isProcessing = false;
	
	public SC_NM(NetworkMaster baseClass) {
		baseClass.statechart = this;
		region = new Region_NM(baseClass);
		region.entryActivity();
	}
	
	public void trigger(Events event) {
		eventQueue.add(event);
		if(!isProcessing) {
			processEvent();
		}
	}
	
	private void processEvent() {
		isProcessing = true;
		while(!eventQueue.isEmpty()) {
			Events currentEvent = (Events)eventQueue.removeFirst();
			this.region.trigger(currentEvent);
		}
		isProcessing = false;
	}
}