/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;


public class SystemConfigurationUpdate {

	public int configUpdate;

	//The associated statechart
	public SC_SCU statechart;

	public void gen_event(Events event) {
		this.statechart.trigger(event);
	}
	
	
	
	
	/**
	* @model type=trigger name=update
	*/	
	
	public void update(Integer value) {
		
		configUpdate = value.intValue();

		
		Events events = new Events(Events.EVENT_update);
		
		events.parameter = value;
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=SCUprogress
	*/	
	
	 void progress() {
		
		
		
		Events events = new Events(Events.EVENT_SCUprogress);
		
		gen_event(events);
		
	}
	

	
	/**
	* @model type=class name=SystemConfigurationUpdate
	*/
	
	
	
	  SystemConfigurationUpdate() {
		
		statechart = new SC_SCU(this);
		
		
		
	}
	


}