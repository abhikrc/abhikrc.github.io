/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;


public class FBlockIDEntry {

	public int nodepos;
	public int NodeAddress;
	public int FBlockID;
	public int InstID;

	
	
	
	
	public boolean equals(Object obj) {
		
		FBlockIDEntry entry = (FBlockIDEntry)obj;
return this.NodeAddress==entry.NodeAddress && this.FBlockID==entry.FBlockID && this.InstID==entry.InstID;

		
	}
	


}