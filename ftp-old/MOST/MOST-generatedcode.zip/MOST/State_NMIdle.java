/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:30 PM
*/

package MOST;

/**
* @model type=state name=NMIdle
*/
public class State_NMIdle extends AState {
	private NetworkMaster baseClass;
	
	public State_NMIdle (NetworkMaster baseClass) {
		this.parentRegionName = "NM";
		this.baseClass = baseClass;

		
	}
	
	public State_NMIdle (NetworkMaster baseClass, AState[] children) {
		this.parentRegionName = "NM";
		this.baseClass = baseClass;		

		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NMNetOn:
				
				
				
				NMIdleNetOn_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NMIdleNetOn subtype=take
	*/
	private void NMIdleNetOn_Taken() {
		
		AState target = new State_NMGenInit(this.baseClass);
		
		this.parentRegion.processTransition("NM", target);
	}
	
	
}