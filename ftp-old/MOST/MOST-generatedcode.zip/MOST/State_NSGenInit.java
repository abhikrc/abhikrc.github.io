/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=NSGenInit
*/
public class State_NSGenInit extends AState {
	private NetworkSlave baseClass;
	
	public State_NSGenInit (NetworkSlave baseClass) {
		this.parentRegionName = "NS";
		this.baseClass = baseClass;

		
		
		ARegion r0 = new Region_NSGenInit(this.baseClass);
		r0.parentState = this;
		this.regions.add(r0);
		
	}
	
	public State_NSGenInit (NetworkSlave baseClass, AState[] children) {
		this.parentRegionName = "NS";
		this.baseClass = baseClass;		

		
		
		ARegion r0 = new Region_NSGenInit(this.baseClass, children);
		r0.parentState = this;
		this.regions.add(r0);
		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NSInitComplete:
				
				
				
				if(nodeTypeChoicePri_Condition()) {
					
					nodeTypeChoicePri_Taken();
				} else
				
				if(nodeTypeChoiceSec_Condition()) {
					
					nodeTypeChoiceSec_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=nodeTypeChoicePri subtype=condition
	*/
	private boolean nodeTypeChoicePri_Condition() {
		return baseClass.type==NetworkSlave.PRIMARY_TYPE;
	}
	/**
	* @model type=transition name=nodeTypeChoicePri subtype=take
	*/
	private void nodeTypeChoicePri_Taken() {
		
		AState target = new State_NSGenRunningPrimary(this.baseClass);
		
		this.parentRegion.processTransition("NS", target);
	}
	
	
	/**
	* @model type=transition name=nodeTypeChoiceSec subtype=condition
	*/
	private boolean nodeTypeChoiceSec_Condition() {
		return baseClass.type==NetworkSlave.SECONDARY_TYPE;
	}
	/**
	* @model type=transition name=nodeTypeChoiceSec subtype=take
	*/
	private void nodeTypeChoiceSec_Taken() {
		
		AState target = new State_NSGenRunningSecondary(this.baseClass);
		
		this.parentRegion.processTransition("NS", target);
	}
	
	
	
	
	
	
}