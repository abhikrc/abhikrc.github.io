/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

/**
* @model type=state name=InitPriGet
*/
public class State_InitPriGet extends AState {
	private NetworkSlave baseClass;
	
	public State_InitPriGet (NetworkSlave baseClass) {
		this.parentRegionName = "NSGenInit";
		this.baseClass = baseClass;

		
	}
	
	public State_InitPriGet (NetworkSlave baseClass, AState[] children) {
		this.parentRegionName = "NSGenInit";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=InitPriGet subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		baseClass.progress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NSprogress:
				
				
				
				InitPriGetAfter_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=InitPriGetAfter subtype=take
	*/
	private void InitPriGetAfter_Taken() {
		
		AState target = new State_InitEnd(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
}