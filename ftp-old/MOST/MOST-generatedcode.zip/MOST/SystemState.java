/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;


public class SystemState {

	public static int OK = 0;
	public static int NotOK = 1;
	public static int CurrentState = SystemState.NotOK;

	

}