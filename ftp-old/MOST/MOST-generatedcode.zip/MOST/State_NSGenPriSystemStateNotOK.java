/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=NSGenPriSystemStateNotOK
*/
public class State_NSGenPriSystemStateNotOK extends AState {
	private NetworkSlave baseClass;
	
	public State_NSGenPriSystemStateNotOK (NetworkSlave baseClass) {
		this.parentRegionName = "NSGenRunningPrimary";
		this.baseClass = baseClass;

		
	}
	
	public State_NSGenPriSystemStateNotOK (NetworkSlave baseClass, AState[] children) {
		this.parentRegionName = "NSGenRunningPrimary";
		this.baseClass = baseClass;		

		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_GetFBlockID:
				
				
				
				NSGenPriNotOKGetFBlockID_Taken();
				
				
				
				break;
			
			case Events.EVENT_GetSetFBlockID:
				
				
				
				NSGenPriNotOKGetSetFBlockID_Taken();
				
				
				
				break;
			
			case Events.EVENT_UpdateConfigurationStatus:
				
				
				
				if(NSGenPriNotOKCfgOKBefore_Condition()) {
					
					NSGenPriNotOKCfgOKBefore_Taken();
				} else
				
				if(NSGenPriNotOKCfgNotOKBefore_Condition()) {
					
					NSGenPriNotOKCfgNotOKBefore_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NSGenPriNotOKGetFBlockID subtype=take
	*/
	private void NSGenPriNotOKGetFBlockID_Taken() {
		
		AState target = new State_NSGenPriSendFBlockID(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningPrimary", target);
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NSGenPriNotOKGetSetFBlockID subtype=take
	*/
	private void NSGenPriNotOKGetSetFBlockID_Taken() {
		
		AState target = new State_NSGenPriSendFBlockID(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningPrimary", target);
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NSGenPriNotOKCfgOKBefore subtype=condition
	*/
	private boolean NSGenPriNotOKCfgOKBefore_Condition() {
		return baseClass.configControlValue==ConfigurationControl.OK;
	}
	/**
	* @model type=transition name=NSGenPriNotOKCfgOKBefore subtype=take
	*/
	private void NSGenPriNotOKCfgOKBefore_Taken() {
		
		AState target = new State_NSGenPriNotOKCfgOK(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningPrimary", target);
	}
	
	
	/**
	* @model type=transition name=NSGenPriNotOKCfgNotOKBefore subtype=condition
	*/
	private boolean NSGenPriNotOKCfgNotOKBefore_Condition() {
		return baseClass.configControlValue==ConfigurationControl.NotOK;
	}
	/**
	* @model type=transition name=NSGenPriNotOKCfgNotOKBefore subtype=take
	*/
	private void NSGenPriNotOKCfgNotOKBefore_Taken() {
		
		AState target = new State_NSGenPriNotOKCfgNotOK(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningPrimary", target);
	}
	
	
	
	
	
	
}