/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=InitCfgStatusElse
*/
public class State_InitCfgStatusElse extends AState {
	private NetworkSlave baseClass;
	
	public State_InitCfgStatusElse (NetworkSlave baseClass) {
		this.parentRegionName = "NSGenInit";
		this.baseClass = baseClass;

		
	}
	
	public State_InitCfgStatusElse (NetworkSlave baseClass, AState[] children) {
		this.parentRegionName = "NSGenInit";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=InitCfgStatusElse subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		baseClass.progress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NSprogress:
				
				
				
				InitCfgStatusElseAfter_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=InitCfgStatusElseAfter subtype=take
	*/
	private void InitCfgStatusElseAfter_Taken() {
		
		AState target = new State_InitEnd(this.baseClass);
		
		this.parentRegion.processTransition("NSGenInit", target);
	}
	
	
}