/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=region name=NSGenInit
*/
public class Region_NSGenInit extends ARegion {
	public NetworkSlave baseClass;

	public Region_NSGenInit(NetworkSlave baseClass) {
		this.elementName = "NSGenInit";
		this.baseClass = baseClass;
		
		
		AState currState = new State_NSGenInitDefault(this.baseClass);
		this.activeState = currState;
		currState.parentRegion = this;
		
	}

	public Region_NSGenInit(NetworkSlave baseClass, AState[] children) {
		this.elementName = "NSGenInit";
		this.baseClass = baseClass;
		
		for(int i=0; i<children.length; i++) {
			if(children[i].parentRegionName.equals(this.elementName)) {
				this.activeState = children[i];
				children[i].parentRegion = this;
				this.isEnterByDefault = false;
				break;
			}
		}
		if(this.isEnterByDefault) {
			
			AState currState = new State_NSGenInitDefault(this.baseClass);
			this.activeState = currState;
			currState.parentRegion = this;
			
		}
	}
	
	public void entryActivity() {
		if(this.isEnterByDefault) {
			defaultActivity();
		}
		this.activeState.entryActivity();
	}

	
	/**
	* @model type=region name=NSGenInit subtype=defaultaction
	*/
	
	private void defaultActivity() {
		baseClass.ResolveNodeAddr();
	}
	
	public void trigger(Events event) {
		this.activeState.trigger(event);
	}
}