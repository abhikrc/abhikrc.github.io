/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

/**
* @model type=state name=NMRcvInstIDInvalid
*/
public class State_NMRcvInstIDInvalid extends AState {
	private NetworkMaster baseClass;
	
	public State_NMRcvInstIDInvalid (NetworkMaster baseClass) {
		this.parentRegionName = "NMReceiveConfig";
		this.baseClass = baseClass;

		
	}
	
	public State_NMRcvInstIDInvalid (NetworkMaster baseClass, AState[] children) {
		this.parentRegionName = "NMReceiveConfig";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=NMRcvInstIDInvalid subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		((NetworkSlave)MOSTSystem.getSlave(baseClass.currReceivedFBlockID.nodepos)).GetSetFBlockID();baseClass.RcvProgress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NMRcvProgress:
				
				
				
				NMRcvAfterInstIDInvalid_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NMRcvAfterInstIDInvalid subtype=take
	*/
	private void NMRcvAfterInstIDInvalid_Taken() {
		
		AState target = new State_NMRcvUpdate(this.baseClass);
		
		this.parentRegion.processTransition("NMReceiveConfig", target);
	}
	
	
}