/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=PreviousNotOK
*/
public class State_PreviousNotOK extends AState {
	private SystemConfigurationUpdate baseClass;
	
	public State_PreviousNotOK (SystemConfigurationUpdate baseClass) {
		this.parentRegionName = "SCU";
		this.baseClass = baseClass;

		
	}
	
	public State_PreviousNotOK (SystemConfigurationUpdate baseClass, AState[] children) {
		this.parentRegionName = "SCU";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=PreviousNotOK subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		MOSTSystem.UpdateConfigurationStatusToSlave(ConfigurationControl.OK);SystemState.CurrentState=SystemState.OK;
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
}