/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;


public class ConfigurationControl {

	public static int OK;
	public static int NotOK;
	public static int New;
	public static int Invalid;

	

}