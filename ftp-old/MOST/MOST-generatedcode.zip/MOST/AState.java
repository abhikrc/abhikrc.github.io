/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;
import java.util.*;

/**
* @model type=abstractstate
*/
abstract class AState {
	public ARegion parentRegion;
	public String parentRegionName="";
	protected ArrayList regions = new ArrayList();

	//for event dispatching
	public abstract void trigger(Events event);
	//entry and exit activity
	public abstract void entryActivity();
	public abstract void exitActivity();
	
	protected ArrayList getActiveSubStates() {
		ArrayList activeSubstates = new ArrayList();
		for(int i=0; i<regions.size(); i++) {
			ARegion subRegion = (ARegion) regions.get(i);
			String className = subRegion.activeState.getClass().getName();
			int index = className.lastIndexOf(".");
			activeSubstates.add(className.substring(index+1));
			activeSubstates.addAll(subRegion.activeState.getActiveSubStates());
		}
		return activeSubstates;
	}
}