/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=ConfigUpdateSuccess
*/
public class State_ConfigUpdateSuccess extends AState {
	private SystemConfigurationUpdate baseClass;
	
	public State_ConfigUpdateSuccess (SystemConfigurationUpdate baseClass) {
		this.parentRegionName = "SCU";
		this.baseClass = baseClass;

		
	}
	
	public State_ConfigUpdateSuccess (SystemConfigurationUpdate baseClass, AState[] children) {
		this.parentRegionName = "SCU";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=ConfigUpdateSuccess subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		baseClass.progress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_SCUprogress:
				
				
				
				if(PreviousNotOKchoice_Condition()) {
					
					PreviousNotOKchoice_Taken();
				} else
				
				if(PreviousOKchoice_Condition()) {
					
					PreviousOKchoice_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=PreviousNotOKchoice subtype=condition
	*/
	private boolean PreviousNotOKchoice_Condition() {
		return SystemState.CurrentState==SystemState.NotOK;
	}
	/**
	* @model type=transition name=PreviousNotOKchoice subtype=take
	*/
	private void PreviousNotOKchoice_Taken() {
		
		AState target = new State_PreviousNotOK(this.baseClass);
		
		this.parentRegion.processTransition("SCU", target);
	}
	
	
	/**
	* @model type=transition name=PreviousOKchoice subtype=condition
	*/
	private boolean PreviousOKchoice_Condition() {
		return SystemState.CurrentState==SystemState.OK;
	}
	/**
	* @model type=transition name=PreviousOKchoice subtype=take
	*/
	private void PreviousOKchoice_Taken() {
		
		AState target = new State_PreviousOK(this.baseClass);
		
		this.parentRegion.processTransition("SCU", target);
	}
	
	
	
	
	
	
}