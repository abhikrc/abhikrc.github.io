/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

import java.util.*;

public class MOSTSystem {

	public static ArrayList slaves = new ArrayList();

	
	
	
	
	public static NetworkSlave getSlave(int pos) {
		
		return (NetworkSlave)slaves.get(pos);

		
	}
	

	
	
	
	public static void UpdateConfigurationStatusToSlave(int value) {
		
		for(int i=0; i<slaves.size(); i++)
((NetworkSlave)slaves.get(i)).UpdateConfigurationStatus(new Integer(value));

		
	}
	


}