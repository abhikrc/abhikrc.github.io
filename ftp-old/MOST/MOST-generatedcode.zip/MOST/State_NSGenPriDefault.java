/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=NSGenPriDefault
*/
public class State_NSGenPriDefault extends AState {
	private NetworkSlave baseClass;
	
	public State_NSGenPriDefault (NetworkSlave baseClass) {
		this.parentRegionName = "NSGenRunningPrimary";
		this.baseClass = baseClass;

		
	}
	
	public State_NSGenPriDefault (NetworkSlave baseClass, AState[] children) {
		this.parentRegionName = "NSGenRunningPrimary";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=NSGenPriDefault subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		baseClass.progress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NSprogress:
				
				
				
				if(NSGenPriSysStateOKBefore_Condition()) {
					
					NSGenPriSysStateOKBefore_Taken();
				} else
				
				if(NSGenPriSysStateNotOKBefore_Condition()) {
					
					NSGenPriSysStateNotOKBefore_Taken();
				} else
				
				{
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NSGenPriSysStateOKBefore subtype=condition
	*/
	private boolean NSGenPriSysStateOKBefore_Condition() {
		return SystemState.CurrentState==SystemState.OK;
	}
	/**
	* @model type=transition name=NSGenPriSysStateOKBefore subtype=take
	*/
	private void NSGenPriSysStateOKBefore_Taken() {
		
		AState target = new State_NSGenPriSystemStateOK(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningPrimary", target);
	}
	
	
	/**
	* @model type=transition name=NSGenPriSysStateNotOKBefore subtype=condition
	*/
	private boolean NSGenPriSysStateNotOKBefore_Condition() {
		return SystemState.CurrentState==SystemState.NotOK;
	}
	/**
	* @model type=transition name=NSGenPriSysStateNotOKBefore subtype=take
	*/
	private void NSGenPriSysStateNotOKBefore_Taken() {
		
		AState target = new State_NSGenPriSystemStateNotOK(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningPrimary", target);
	}
	
	
	
	
	
	
}