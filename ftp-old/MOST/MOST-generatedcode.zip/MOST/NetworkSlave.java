/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

import java.util.*;

public class NetworkSlave {

	public int type = NetworkSlave.PRIMARY_TYPE;
	public static int PRIMARY_TYPE = 1;
	public static int SECONDARY_TYPE = 2;
	public int NodeAddress;
	public boolean configStatusRcved;
	public int configControlValue;
	public int[] addressList;
	public int addrCount = 0;
	public ArrayList FBlockIDList;
	public int FBlockIDcount = 0;

	//The associated statechart
	public SC_NS statechart;

	public void gen_event(Events event) {
		this.statechart.trigger(event);
	}
	
	
	
	
	/**
	* @model type=trigger name=GetFBlockID
	*/	
	
	public void GetFBlockID() {
		
		
		
		Events events = new Events(Events.EVENT_GetFBlockID);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=GetSetFBlockID
	*/	
	
	public void GetSetFBlockID() {
		
		
		
		Events events = new Events(Events.EVENT_GetSetFBlockID);
		
		gen_event(events);
		
	}
	

	
	
	
	public FBlockIDEntry getNextFBlockID() {
		
		FBlockIDEntry next = (FBlockIDEntry)FBlockIDList.get(FBlockIDcount);
if(FBlockIDcount < FBlockIDList.size() - 1)
FBlockIDcount++;
return next;

		
	}
	

	
	
	
	/**
	* @model type=trigger name=NSNetOn
	*/	
	
	public void NetOn() {
		
		
		
		Events events = new Events(Events.EVENT_NSNetOn);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=NSprogress
	*/	
	
	public void progress() {
		
		
		
		Events events = new Events(Events.EVENT_NSprogress);
		
		gen_event(events);
		
	}
	

	
	
	
	public void ResolveNodeAddr() {
		
		NodeAddress=addressList[addrCount];
if(addrCount<addressList.length-1)
addrCount++;

		
	}
	

	
	
	
	/**
	* @model type=trigger name=UpdateConfigurationStatus
	*/	
	
	public void UpdateConfigurationStatus(Integer configControl) {
		
		this.configStatusRcved = true;
this.configControlValue=configControl.intValue();

		
		Events events = new Events(Events.EVENT_UpdateConfigurationStatus);
		
		events.parameter = configControl;
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=NSInitComplete
	*/	
	
	public void InitComplete() {
		
		
		
		Events events = new Events(Events.EVENT_NSInitComplete);
		
		gen_event(events);
		
	}
	

	
	
	
	public void NCE() {
		
		
		
	}
	

	
	/**
	* @model type=class name=NetworkSlave
	*/
	
	
	
	public  NetworkSlave(int[] addressList) {
		
		statechart = new SC_NS(this);
		
		this.addressList=addressList;

		
	}
	


}