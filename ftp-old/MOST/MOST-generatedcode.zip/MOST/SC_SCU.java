/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

import java.util.*;

/**
* @model type=statechart name=SCU
*/
public class SC_SCU {
	private Region_SCU region;
	private LinkedList eventQueue = new LinkedList();
	private boolean isProcessing = false;
	
	public SC_SCU(SystemConfigurationUpdate baseClass) {
		baseClass.statechart = this;
		region = new Region_SCU(baseClass);
		region.entryActivity();
	}
	
	public void trigger(Events event) {
		eventQueue.add(event);
		if(!isProcessing) {
			processEvent();
		}
	}
	
	private void processEvent() {
		isProcessing = true;
		while(!eventQueue.isEmpty()) {
			Events currentEvent = (Events)eventQueue.removeFirst();
			this.region.trigger(currentEvent);
		}
		isProcessing = false;
	}
}