/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=state name=NSGenSecDefault
*/
public class State_NSGenSecDefault extends AState {
	private NetworkSlave baseClass;
	
	public State_NSGenSecDefault (NetworkSlave baseClass) {
		this.parentRegionName = "NSGenRunningSecondary";
		this.baseClass = baseClass;

		
	}
	
	public State_NSGenSecDefault (NetworkSlave baseClass, AState[] children) {
		this.parentRegionName = "NSGenRunningSecondary";
		this.baseClass = baseClass;		

		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_GetFBlockID:
				
				
				
				NSGenSecGetFBlockID_Taken();
				
				
				
				break;
			
			case Events.EVENT_GetSetFBlockID:
				
				
				
				NSGenSecGetSetFBlockID_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NSGenSecGetFBlockID subtype=take
	*/
	private void NSGenSecGetFBlockID_Taken() {
		
		AState target = new State_NSGenSecSendFBlockID(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningSecondary", target);
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=NSGenSecGetSetFBlockID subtype=take
	*/
	private void NSGenSecGetSetFBlockID_Taken() {
		
		AState target = new State_NSGenSecSendFBlockID(this.baseClass);
		
		this.parentRegion.processTransition("NSGenRunningSecondary", target);
	}
	
	
}