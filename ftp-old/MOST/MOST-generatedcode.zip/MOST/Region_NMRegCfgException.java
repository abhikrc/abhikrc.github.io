/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

/**
* @model type=region name=NMRegCfgException
*/
public class Region_NMRegCfgException extends ARegion {
	public NetworkMaster baseClass;

	public Region_NMRegCfgException(NetworkMaster baseClass) {
		this.elementName = "NMRegCfgException";
		this.baseClass = baseClass;
		
		
		AState currState = new State_NMRegExceptionDefault(this.baseClass);
		this.activeState = currState;
		currState.parentRegion = this;
		
	}

	public Region_NMRegCfgException(NetworkMaster baseClass, AState[] children) {
		this.elementName = "NMRegCfgException";
		this.baseClass = baseClass;
		
		for(int i=0; i<children.length; i++) {
			if(children[i].parentRegionName.equals(this.elementName)) {
				this.activeState = children[i];
				children[i].parentRegion = this;
				this.isEnterByDefault = false;
				break;
			}
		}
		if(this.isEnterByDefault) {
			
			AState currState = new State_NMRegExceptionDefault(this.baseClass);
			this.activeState = currState;
			currState.parentRegion = this;
			
		}
	}
	
	public void entryActivity() {
		if(this.isEnterByDefault) {
			defaultActivity();
		}
		this.activeState.entryActivity();
	}

	
	/**
	* @model type=region name=NMRegCfgException subtype=defaultaction
	*/
	
	private void defaultActivity() {
		
	}
	
	public void trigger(Events event) {
		this.activeState.trigger(event);
	}
}