/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:30 PM
*/

package MOST;

/**
* @model type=state name=NMRegNormalDefault2
*/
public class State_NMRegNormalDefault2 extends AState {
	private NetworkMaster baseClass;
	
	public State_NMRegNormalDefault2 (NetworkMaster baseClass) {
		this.parentRegionName = "NMReqCfgNormal";
		this.baseClass = baseClass;

		
	}
	
	public State_NMRegNormalDefault2 (NetworkMaster baseClass, AState[] children) {
		this.parentRegionName = "NMReqCfgNormal";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=NMRegNormalDefault2 subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		baseClass.ReqProgress();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_NMReqProgress:
				
				
				
				NMReqNormalBeforeTimer_Action(event.parameter);
				
				NMReqNormalBeforeTimer_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	/**
	* @model type=transition name=NMReqNormalBeforeTimer subtype=action
	*/
	private void NMReqNormalBeforeTimer_Action(Object parameter) {
		baseClass.updateNumNodes();
	}
	
	
	
	
	
	/**
	* @model type=transition name=NMReqNormalBeforeTimer subtype=take
	*/
	private void NMReqNormalBeforeTimer_Taken() {
		
		AState target = new State_NMReqNormalAfterTimer(this.baseClass);
		
		this.parentRegion.processTransition("NMReqCfgNormal", target);
	}
	
	
}