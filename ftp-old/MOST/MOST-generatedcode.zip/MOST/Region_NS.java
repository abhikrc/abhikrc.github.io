/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=region name=NS
*/
public class Region_NS extends ARegion {
	public NetworkSlave baseClass;

	public Region_NS(NetworkSlave baseClass) {
		this.elementName = "NS";
		this.baseClass = baseClass;
		
		
		AState currState = new State_NSIdle(this.baseClass);
		this.activeState = currState;
		currState.parentRegion = this;
		
	}

	public Region_NS(NetworkSlave baseClass, AState[] children) {
		this.elementName = "NS";
		this.baseClass = baseClass;
		
		for(int i=0; i<children.length; i++) {
			if(children[i].parentRegionName.equals(this.elementName)) {
				this.activeState = children[i];
				children[i].parentRegion = this;
				this.isEnterByDefault = false;
				break;
			}
		}
		if(this.isEnterByDefault) {
			
			AState currState = new State_NSIdle(this.baseClass);
			this.activeState = currState;
			currState.parentRegion = this;
			
		}
	}
	
	public void entryActivity() {
		if(this.isEnterByDefault) {
			defaultActivity();
		}
		this.activeState.entryActivity();
	}

	
	/**
	* @model type=region name=NS subtype=defaultaction
	*/
	
	private void defaultActivity() {
		
	}
	
	public void trigger(Events event) {
		this.activeState.trigger(event);
	}
}