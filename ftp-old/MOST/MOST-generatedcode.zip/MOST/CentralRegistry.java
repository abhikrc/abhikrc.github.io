/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

import java.util.*;

public class CentralRegistry {

	public static ArrayList FBlockIDs = new ArrayList();
	public static ArrayList requests = new ArrayList();
	public static ArrayList numErrs = new ArrayList();

	
	
	
	
	public static boolean hasRequest(int pos) {
		
		return ((Boolean)requests.get(pos)).booleanValue();

		
	}
	

	
	
	
	public static int getNumErr(int pos) {
		
		return ((Integer)numErrs.get(pos)).intValue();

		
	}
	

	
	
	
	public static boolean anyRequestTrue() {
		
		boolean any=false; for(int i=0;i<requests.size();i++) { if(hasRequest(i)) any=true; break; } return any;

		
	}
	

	
	
	
	public static boolean validateNodeAddress(FBlockIDEntry entry) {
		
		       if(entry.NodeAddress==0xFFFF || entry.NodeAddress==0x0) return false;
       if(contains(entry)) return true;
       for(int j=0; j<FBlockIDs.size(); j++) {
              FBlockIDEntry existing = (FBlockIDEntry)FBlockIDs.get(j);
            if(entry.nodepos!=existing.nodepos && entry.NodeAddress==existing.NodeAddress)
                   return false;
       }
return true;

		
	}
	

	
	
	
	public static boolean contains(FBlockIDEntry entry) {
		
		if(entry.nodepos>=FBlockIDs.size()) return false;
FBlockIDEntry existing = (FBlockIDEntry)FBlockIDs.get(entry.nodepos);
if(entry.equals(existing))
           return true;
return false;

		
	}
	

	
	
	
	public static boolean validateInstID(FBlockIDEntry entry) {
		
		if(entry.InstID==0xFFFF) return false;
return true;

		
	}
	

	
	
	
	public static void insertNewEntry(FBlockIDEntry entry) {
		
		FBlockIDs.add(entry.nodepos, entry);
if(entry.nodepos >= requests.size()) {
requests.add(entry.nodepos, new Boolean(false));
numErrs.add(entry.nodepos, new Integer(0));
} else {
requests.set(entry.nodepos, new Boolean(false));
numErrs.set(entry.nodepos, new Integer(0));
}

		
	}
	

	
	
	
	public static boolean isEmpty() {
		
		return FBlockIDs.isEmpty();

		
	}
	

	
	
	
	public static void clear() {
		
		FBlockIDs.clear();
requests.clear();
numErrs.clear();

		
	}
	

	
	
	
	public static void updateEntry(FBlockIDEntry entry) {
		
		if(entry.nodepos == FBlockIDs.size())
       insertNewEntry(entry);
else if(entry.nodepos > FBlockIDs.size())
        System.out.println("FBlockID inserted wrongly");
else {
FBlockIDs.set(entry.nodepos, entry);
requests.set(entry.nodepos, new Boolean(false));
numErrs.set(entry.nodepos, new Integer(0));
}

		
	}
	


}