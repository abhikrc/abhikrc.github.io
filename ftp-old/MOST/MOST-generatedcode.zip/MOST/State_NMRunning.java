/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

/**
* @model type=state name=NMRunning
*/
public class State_NMRunning extends AState {
	private NetworkMaster baseClass;
	
	public State_NMRunning (NetworkMaster baseClass) {
		this.parentRegionName = "NM";
		this.baseClass = baseClass;

		
		
		ARegion r0 = new Region_NMRequestConfig(this.baseClass);
		r0.parentState = this;
		this.regions.add(r0);
		
		
		ARegion r1 = new Region_NMReceiveConfig(this.baseClass);
		r1.parentState = this;
		this.regions.add(r1);
		
	}
	
	public State_NMRunning (NetworkMaster baseClass, AState[] children) {
		this.parentRegionName = "NM";
		this.baseClass = baseClass;		

		
		
		ARegion r0 = new Region_NMRequestConfig(this.baseClass, children);
		r0.parentState = this;
		this.regions.add(r0);
		
		
		ARegion r1 = new Region_NMReceiveConfig(this.baseClass, children);
		r1.parentState = this;
		this.regions.add(r1);
		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
}