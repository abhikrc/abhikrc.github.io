/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:31 PM
*/

package MOST;

import java.util.*;

public class NetworkMaster {

	public boolean doRequest = false;
	public int ConfigUpdate;
	public int numNodes = 0;
	public int NodeAddress = 0;
	private static NetworkMaster self;
	public int[] address;
	public FBlockIDEntry currReceivedFBlockID = null;
	public ArrayList receivedFBlockIDList = new ArrayList();
	public int addrCount = 0;

	//The associated statechart
	public SC_NM statechart;

	public void gen_event(Events event) {
		this.statechart.trigger(event);
	}
	
	
	/**
	* @model type=class name=NetworkMaster
	*/
	
	
	
	protected  NetworkMaster(int[] address) {
		
		statechart = new SC_NM(this);
		
		this.address=address;

		
	}
	

	
	
	
	public static NetworkMaster getInstance() {
		
		return self;

		
	}
	

	
	
	
	public static void createInstance(int[] address) {
		
		self=new NetworkMaster(address);

		
	}
	

	
	
	
	/**
	* @model type=trigger name=NMNetOn
	*/	
	
	public void NetOn() {
		
		
		
		Events events = new Events(Events.EVENT_NMNetOn);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=NMInitComplete
	*/	
	
	public void InitComplete() {
		
		
		
		Events events = new Events(Events.EVENT_NMInitComplete);
		
		gen_event(events);
		
	}
	

	
	
	
	 void AssignNodeAddress() {
		
		//for(int i=0; i<numNodes; i++) { CentralRegistry.nodeAddresses.add(i,new Integer(i+1));}
NodeAddress=address[addrCount];
if(addrCount<address.length-1)
addrCount++;

		
	}
	

	
	
	
	/**
	* @model type=trigger name=NMInitProgress
	*/	
	
	 void InitProgress() {
		
		
		
		Events events = new Events(Events.EVENT_NMInitProgress);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=NCE
	*/	
	
	public void NCE() {
		
		
		
		Events events = new Events(Events.EVENT_NCE);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=breakCurrent
	*/	
	
	public void breakCurrent() {
		
		
		
		Events events = new Events(Events.EVENT_breakCurrent);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=setDoRequestTrue
	*/	
	
	public void setDoRequestTrue() {
		
		doRequest=true;

		
		Events events = new Events(Events.EVENT_setDoRequestTrue);
		
		gen_event(events);
		
	}
	

	
	
	
	public void updateNumNodes() {
		
		int numNodes=0; for(int i=0;i<CentralRegistry.requests.size();i++) { if(((Boolean)CentralRegistry.requests.get(i)).booleanValue()){numNodes++;} } this.numNodes = this.numNodes+numNodes;

		
	}
	

	
	
	
	public void ReceiveFBlockIDStatus(FBlockIDEntry FBlockID) {
		
		receivedFBlockIDList.add(FBlockID);
if(currReceivedFBlockID==null)
       processReceivedFBlockID();

		
	}
	

	
	
	
	/**
	* @model type=trigger name=ProcessReceivedFBlockID
	*/	
	
	public void processReceivedFBlockID() {
		
		
		
		Events events = new Events(Events.EVENT_ProcessReceivedFBlockID);
		
		gen_event(events);
		
	}
	

	
	
	
	public void ReceiveFBlockIDError() {
		
		numNodes--;

		
	}
	

	
	
	
	/**
	* @model type=trigger name=NMReqProgress
	*/	
	
	 void ReqProgress() {
		
		
		
		Events events = new Events(Events.EVENT_NMReqProgress);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=NMRcvProgress
	*/	
	
	 void RcvProgress() {
		
		
		
		Events events = new Events(Events.EVENT_NMRcvProgress);
		
		gen_event(events);
		
	}
	

	
	
	
	public void ManualRescan() {
		
		for(int i=0; i<CentralRegistry.requests.size(); i++)
      CentralRegistry.requests.set(i, new Boolean(true));
setDoRequestTrue();

		
	}
	


}