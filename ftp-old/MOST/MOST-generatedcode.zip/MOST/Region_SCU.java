/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=region name=SCU
*/
public class Region_SCU extends ARegion {
	public SystemConfigurationUpdate baseClass;

	public Region_SCU(SystemConfigurationUpdate baseClass) {
		this.elementName = "SCU";
		this.baseClass = baseClass;
		
		
		AState currState = new State_DefaultSCU(this.baseClass);
		this.activeState = currState;
		currState.parentRegion = this;
		
	}

	public Region_SCU(SystemConfigurationUpdate baseClass, AState[] children) {
		this.elementName = "SCU";
		this.baseClass = baseClass;
		
		for(int i=0; i<children.length; i++) {
			if(children[i].parentRegionName.equals(this.elementName)) {
				this.activeState = children[i];
				children[i].parentRegion = this;
				this.isEnterByDefault = false;
				break;
			}
		}
		if(this.isEnterByDefault) {
			
			AState currState = new State_DefaultSCU(this.baseClass);
			this.activeState = currState;
			currState.parentRegion = this;
			
		}
	}
	
	public void entryActivity() {
		if(this.isEnterByDefault) {
			defaultActivity();
		}
		this.activeState.entryActivity();
	}

	
	/**
	* @model type=region name=SCU subtype=defaultaction
	*/
	
	private void defaultActivity() {
		
	}
	
	public void trigger(Events event) {
		this.activeState.trigger(event);
	}
}