/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;

/**
* @model type=events
*/
public class Events {
	public static final int EVENT_NMNetOn=0;
	public static final int EVENT_NMInitComplete=1;
	public static final int EVENT_NCE=2;
	public static final int EVENT_breakCurrent=3;
	public static final int EVENT_setDoRequestTrue=4;
	public static final int EVENT_ProcessReceivedFBlockID=5;
	public static final int EVENT_NMInitProgress=6;
	public static final int EVENT_NMReqProgress=7;
	public static final int EVENT_NMRcvProgress=8;
	public static final int EVENT_NSNetOn=9;
	public static final int EVENT_NSprogress=10;
	public static final int EVENT_UpdateConfigurationStatus=11;
	public static final int EVENT_GetFBlockID=12;
	public static final int EVENT_GetSetFBlockID=13;
	public static final int EVENT_NSInitComplete=14;
	public static final int EVENT_update=15;
	public static final int EVENT_SCUprogress=16;

	public int event = -1;
	
	public Events(int v) {
		this.event = v;
	}
	
	Object parameter = null;
}