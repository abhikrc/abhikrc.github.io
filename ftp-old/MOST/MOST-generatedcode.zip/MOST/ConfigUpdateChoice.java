/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:24:32 PM
*/

package MOST;


public class ConfigUpdateChoice {

	public static int Success = 0;
	public static int Error = 1;

	

}