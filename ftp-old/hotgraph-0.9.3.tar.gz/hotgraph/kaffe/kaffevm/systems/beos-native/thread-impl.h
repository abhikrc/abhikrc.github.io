#if !defined(__thread_impl_h__)
#define __thread_impl_h__

#include "jthread.h"

#endif
