#ifndef	CALLFRAME_H
#define CALLFRAME_H

#include "slicing.h"
#include "linklist.h"
#include "nativeHandle.h"

class JMethod;
class JBytecode;

class CallFrame
{
	int localCount;	
    int *operStack;
    int operStackTop;

public:    
    int* locals;
    int *basicBlockIsSlice;
	CallFrame *prev;
	JMethod *meth;	
	SliceType slice;
	
	int nextPC;
	int currentPC;
	int nextPCExplicit; //1 - next pc value is set by exception handling, should not be changed normally
	//int invokedByNonStaticInitNative; //1 - this method is transitively invoked by non-static-init native method;
	native_called_method *invokeList;
	CallFrame(JMethod*, CallFrame*, int);
	CallFrame* getPrev();
	~CallFrame();
	void useLocal(int);
	int hasUseLocal(int);
    void pushOperStack(int, int);
    int popOperStack(int);
    int getOperStackTop();
    void updateOperStack(int, int);
    void updateOperStackMiddle(int, int, int);
};

#endif
