/*
 * exceptionHandle.h
 *
 * maintain information during exception
 * 
 *
 * Written by Liang Guo <guol@comp.nus.edu.sg> 
 */


#ifndef __exceptionHandle_h
#define __exceptionHandle_h
//#include "trace.h"



struct _method_trace;
struct _methods;

typedef enum _exception_type
{
	Internal = 0,
	External = 1 //through athrow
}exception_type;

typedef struct _catch_instance
{
	struct _methods			*meth;
	int						spSize;//the current size of operand stack
	int						lastPC;
	struct _catch_instance	*prev;
}catch_instance; //each poped call frame during exception

typedef struct _catch_handler
{
	catch_instance*			instance; //point to last catch_instance
	struct _catch_handler*	prev;
	int						eoid;
	int						lastPC;
	exception_type			type;
}catch_handler; //a catch_hanlder contains call frames poped from exception to catch

typedef struct _catch_inst
{
	int 					inst;
	catch_handler*			handler; //point to last catch_handler
	struct _catch_inst*		prev;
	catch_handler*			latest; //used for slicing
}catch_inst; //each catch_inst may be executed several times thus contains several catch_handler

/***************
* Example of catch handler:
* method1()
*	inst 8:
*		first catch: m2(), m3(), m4()
*		second catch: m2(), m3()
*	inst 15:
*		first catch: m5(), m6()
*/

catch_handler* getNextCatchHandler(catch_inst* catchinst);
void insertTempCatchInstance(catch_handler *, struct _methods *, int, int);
void endTempCatchHandler(catch_handler *, struct _method_trace *, int, int, int);
void dumpCatchInst(struct _method_trace *);
catch_inst* getCatchInstForInstruction(catch_inst *, int);
catch_handler* getNextCatchHandler(catch_inst*);

extern exception_type exceptionType;
#endif
