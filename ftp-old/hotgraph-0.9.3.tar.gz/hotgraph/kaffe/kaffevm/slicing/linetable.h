#ifndef	LINETABLE_H
#define LINETABLE_H

class LineTable
{
	int lineNum;
	int startPC;
	int slice;
public:
	int getStartPC();
	int getLineNum();
	void setSlice();
	int isSlice();
	void init(int, int);
};

#endif
