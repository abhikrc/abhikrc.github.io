/***************************************************************************
                          cnamelist.cpp  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "cnamelist.h"
#include "slicing.h"

CNameList::CNameList(int initSize)
:names(initSize)
{

}


CNameList::CNameList()
{
}

CNameList::~CNameList()
{
    int i;
    for(i=0; i<names.size(); i++)
    {
        free(names.getAt(i));
    }
}

int CNameList::update(const char* name)
{
	int index;
	char *dupli;

	//printf("updating name %s - ", name);
	
	index= getNameId(name);
	if (index<0)
	{
		//printf("new\n");
		dupli= (char *)cleanMalloc(sizeof(char)*(strlen(name)+1));
		strcpy(dupli, name);
		dupli[strlen(name)]='\0';
		index= names.addTail(dupli);		
	}
	else
	{
		//printf("exist\n");
	}
	return index;
}


int CNameList::getNameId(const char *name){
	int i, size;
	size= names.size();
	for (i=0; i<size; i++)
	{
		if (strcmp(names.getAt(i), name) ==0)
			return i;
	}
	return -1;
}


char* CNameList::getCNameAt(int index)
{
	if (index<0)
		return NULL;

	return names.getAt(index);	
}

int CNameList::size()
{
	return names.size();
}

