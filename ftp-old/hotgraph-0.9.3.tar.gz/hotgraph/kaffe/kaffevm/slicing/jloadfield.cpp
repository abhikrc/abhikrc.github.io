// JLoadField.cpp: implementation of the JLoadField class.
//
//////////////////////////////////////////////////////////////////////

#include "jloadfield.h"
#include "bytecodelist.h"
#include "slicing.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

JLoadField::JLoadField(JMethod *meth, int operation, int pc, int field, int fieldSize): 
JBytecode(meth, operation, pc, LoadFieldBytecode)
{	
	this->field= field;
    this->fieldSize=fieldSize;
}

JLoadField::~JLoadField()
{

}

int JLoadField::getField()
{
	return field;
}
