#include "jnewarray.h"

JNewArray::JNewArray(JMethod *meth, int operation, int pc):
JBytecode(meth, operation, pc, NewArray)
{
}


