#include "slicing.h"
#include "jinvokenonstatic.h"
#include "signature.h"
#include "bytecodelist.h"
#include "jclass.h"
#include "cnamelist.h"

JInvokeNonStatic::JInvokeNonStatic(JMethod* meth, int operation, int pc, int classNameId, int methodNameId, int methodSigId, const char *sig):
JBytecode(meth, operation, pc, InvokeNonStaticBytecode)
{
	this->classNameId= classNameId;
	this->methodNameId= methodNameId;
	this->methodSigId= methodSigId;
	signature= new Signature(sig);
    argsNum= signature->getNargs();
    if (argsNum >0)
    {
        argsUseOperNum= (int *)cleanMalloc(sizeof(int) * argsNum);
        argsLocalVarPos= (int *)cleanMalloc(sizeof(int) * argsNum);
    }
    else
    {
        argsUseOperNum= NULL;
        argsLocalVarPos= NULL;
    }

    defOperNum=0;
    allArgsUseOperNum=0;
	//reflectCall=0;
	javaMethods= NULL;  
}
	

JInvokeNonStatic::~JInvokeNonStatic()
{

	delete signature;
	signature=NULL;
    free(argsUseOperNum);
    free(argsLocalVarPos);
	argsUseOperNum=NULL;
}

int JInvokeNonStatic::getnArgsLocalPos(int index)
{
	return argsLocalVarPos[index];
}

void JInvokeNonStatic::setnUseOperNum(int index, int operNum)
{
	argsUseOperNum[index]= operNum;
    argsLocalVarPos[index]= allArgsUseOperNum+1;
    allArgsUseOperNum+= operNum;
}
	
int JInvokeNonStatic::getnUseOperNum(int index)
{
	return argsUseOperNum[index];
}

int JInvokeNonStatic::getAllArgsUseOperNum()
{
	return allArgsUseOperNum;
}

void JInvokeNonStatic::setDefOperNum(int operNum)
{
	defOperNum= operNum;
}
	
int JInvokeNonStatic::getDefOperNum()
{
	return defOperNum;
}

int JInvokeNonStatic::getArgsCount()
{
	return argsNum;
}

Signature* JInvokeNonStatic::getSig()
{
	return signature;
}

/*void JInvokeNonStatic::initReflectCalls()
{
	JClass *jClass;	
	int i;
	int initCallNameId= methodNames->getNameId("<init>");

	reflectCall=1;

	for (i=0; i<classCount; i++)
	{
		jClass= &(classes[i]);
		int j, methodCount;
		JMethod *meths= jClass->getMethods();
		methodCount= jClass->getMethodCount();		

		for( j=0; j< methodCount; j++)
		{
			if (meths[j].getNameId() == initCallNameId)
			{
				invokeMethod.addTail(&(meths[j]));				
			}
		}		
	}
}*/

JClass* JInvokeNonStatic::getInvokeJClass()
{
	int i;
	JClass *current=classes;
	while(current!=NULL)
	{
		if(current->getNameId() == classNameId)
			return current;
		current= current->nextClass;
	}
	return NULL;
}

void JInvokeNonStatic::initCalls()
{
	int i;
	
	if( INVOKESPECIAL== operation)
	{
		//printf("at %s.%s\n", meth->getParentClass()->getClassName(), meth->getMethodName());
		JClass *currClass = getInvokeJClass();
		while(currClass!= NULL && invokeMethod.size()==0)
		{
			JMethod *meths= currClass->getMethods();
			int methodCount= currClass->getMethodCount();

			for (i=0; i<methodCount; i++)
		    {
			    if (meths[i].getNameId()== methodNameId && meths[i].getSigId()== methodSigId)
			    {
			    	//printf("build special: method %s.%s\n", meths[i].getParentClass()->getClassName(), meths[i].getMethodName());
				    invokeMethod.addTail(&(meths[i]));
			    }
		    }
		    currClass= currClass->getSuperJClass();
		}
	}
	else
	{
		JClass * currentClass= classes;
		while(currentClass!=NULL)
		{
        /*if ( INVOKESPECIAL== operation &&  classes[i].getNameId() != classNameId)
        {
            continue;
        }*/
			int j, methodCount;
			JMethod *meths= currentClass->getMethods();

			methodCount= currentClass->getMethodCount();

			for (j=0; j<methodCount; j++)
			{
            /*if ( INVOKESPECIAL== operation && strcmp (methodNames->getCNameAt(methodNameId), initName)==0)
            {
                if (strcmp(meths[j].getMethodName(), initName)==0 && meths[j].getSigId()== methodSigId)
                {
                    invokeMethod.addTail(&(meths[j]));
                }  
            }
            else	
            {*/
			     if (meths[j].getNameId()== methodNameId && meths[j].getSigId()== methodSigId)
    			 {
	   			     invokeMethod.addTail(&(meths[j]));
			     }
            //}
			}
			currentClass= currentClass->nextClass;
		}
	}

/*    if (invokeMethod.size()==0)
    {
        printf("warning: invoke non static method not found: %s.%s\n", classNames->getCNameAt(classNameId), 
                                                methodNames->getCNameAt(methodNameId));
    }
    if ( INVOKESPECIAL== operation && invokeMethod.size()!=1)
    {
        printf("warning: invokespecial should invoke one method\n");
    }*/
   
	return;
}

void JInvokeNonStatic::getInvokeMethodFromClass(JClass *jClass)
{
	int i, methodCount;
	JMethod *meths= jClass->getMethods();

	methodCount= jClass->getMethodCount();

	for (i=0; i<methodCount; i++)
	{
		if (meths[i].getNameId()== methodNameId && meths[i].getSigId()== methodSigId)
		{
			invokeMethod.uniqueInsert(&(meths[i]));
		}
	}
}

LinkList<JMethod*>* JInvokeNonStatic::getInvokeMethod()
{
	return &invokeMethod;
}

void JInvokeNonStatic::dumpCallGraph()
{
	printf("pc: %d, instruction: %s, call \n", pc, bytecodeName[operation]);
	JMethod *ite;

	for(ite= invokeMethod.getHead(); invokeMethod.hasNext(); ite=invokeMethod.getNext())
	{
		printf("	%s %s %s\n", classNames->getCNameAt(ite->getParentClass()->getNameId()),
					methodNames->getCNameAt(ite->getNameId()), sigs->getCNameAt(ite->getSigId()));
	}

}

char* JInvokeNonStatic::getInvokedMethodName()
{
	return methodNames->getCNameAt(methodNameId);
}

int JInvokeNonStatic::getInvokedClassNameId()
{
	return classNameId;
}

int JInvokeNonStatic::getInvokedMethodNameId()
{
	return methodNameId;
}

int JInvokeNonStatic::getInvokedMethodSigId()
{
	return methodSigId;
}

native_called_method_list* JInvokeNonStatic::getNextNativeCalledMethodList()
{
	native_called_method_list *curr = javaMethods;
	if(curr!=NULL)
	{
		javaMethods = curr->prev;
		return curr;
	}
	return NULL;
}

