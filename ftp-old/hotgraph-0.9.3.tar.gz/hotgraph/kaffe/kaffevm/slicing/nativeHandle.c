/*
 * native.c
 *
 * maintain native call information
 * 
 */

#include "classMethod.h"
#include "nativeHandle.h"
#include "trace.h"

//extern int currentCallFrameLevel;

native_call* addNativeCallSlotForInstruction(struct _method_trace *, int);
native_call* getNativeCallForInstruction(struct _method_trace *, int);
void updateCallee(native_called_method_list*, struct _call_frame*);
void pushStack(native_call *caller, native_called_method_list *invoke);
native_called_method_list* popStack(native_call *caller);
native_called_method_list* getStackTop(native_call *caller);

//called when the method to be invoked is native
//create the native_call structure for calling method and create an empty invoked_list
//this is to make sure if called native method does not call any java method,
//we still have a dummy entry
void initNativeCall(struct _method_trace *callerTrace, int lastPC)
{
	
	native_call *curr = getNativeCallForInstruction(callerTrace, lastPC);
	if(curr == NULL)
	{
		curr = addNativeCallSlotForInstruction(callerTrace, lastPC);
	}
	native_called_method_list *invoke= (native_called_method_list*)cleanMalloc(sizeof(native_called_method_list));
	invoke->callFrameLevel= -1;
	
	pushStack(curr, invoke);
}

//this is called when exiting from a native method
//this pop the list entry from stack (java methods invoked by this native)
//and append it to the list
void finalizeNativeCall(struct _method_trace *callerTrace, int lastPC)
{
	native_call *caller = getNativeCallForInstruction(callerTrace, lastPC);
	if(caller == NULL)
	{
		printf("error: nativeHandle.c: finalize: native call slot should not be null\n");
	}
	native_called_method_list *invoke= popStack(caller);
	invoke->prev= caller->calledMethods;
	caller->calledMethods= invoke;
}

//this is called when entering a java method from native method
//(after the call frame for the java method is created)
//it updates the top list entry in stack, with its call frame level
void enterNativeCalledJavaMethod(struct _call_frame *callerFrame, int calleeFrameLevel)
{
	native_call *caller = getNativeCallForInstruction(callerFrame->methodTrace, callerFrame->lastPC);
	if(caller == NULL)
	{
		printf("error: nativeHandle.c: enter: native call slot should not be null\n");
	}
	native_called_method_list *invoke= getStackTop(caller);
	if(invoke == NULL)
	{
		printf("error: nativeHandle.c: enter: stack top is null\n");
	}

	if(-1 == invoke->callFrameLevel)
	{
		//first entry of current native of current level
		//applicable to the first entry when the native called multiple java
		//assign current call frame level
		invoke->callFrameLevel= calleeFrameLevel;
	}
	else if(calleeFrameLevel == invoke->callFrameLevel)
	{
		//subsequent jave method entering for current native
		//do nothing
	}
	else
	{
		printf("error: nativeHandle.c: enter: the cf level of stack top is wrong\n");
	}
}

//called after callee call frame is constructed
//update with the real callee
void exitNativeCalledJavaMethod(struct _call_frame *callerFrame, struct _call_frame *calleeFrame, int calleeFrameLevel)
{
	native_call *caller = getNativeCallForInstruction(callerFrame->methodTrace, callerFrame->lastPC);
	if(caller == NULL)
	{
		printf("error: nativeHandle.c: exit: native call slot should not be null\n");
	}
	native_called_method_list *invoke= getStackTop(caller);
	if(invoke == NULL)
	{
		printf("error: nativeHandle.c: exit: tack top is null\n");
	}
	
	if(calleeFrameLevel == invoke->callFrameLevel)
	{
		updateCallee(invoke, calleeFrame);
	}
	else
	{
		printf("error: nativeHandle.c: exit: the cf level of stack top is wrong\n");
	}
}

void updateCallee(native_called_method_list *invoke, struct _call_frame *calleeFrame)
{
	native_called_method *callee= (native_called_method*)cleanMalloc(sizeof(native_called_method));
	callee->classID= calleeFrame->classID;
	callee->methodID= calleeFrame->methodTrace->methodID;
	callee->sigID= calleeFrame->methodTrace->sigID;
	
	callee->prev= invoke->calledMethod;
	invoke->calledMethod= callee;
}

/** stack related **/
void pushStack(native_call *caller, native_called_method_list *invoke)
{
	invoke->prev = caller->stack;
	caller->stack = invoke;
}

native_called_method_list* popStack(native_call *caller)
{
	native_called_method_list* invoke = caller->stack;
	caller->stack= invoke->prev;
	return invoke;
}

//temp method - called during exception handling
//invoke->calledMethod != NULL
//means we need to handle the case for exception
void removeStackTop(struct _method_trace *callerTrace, int lastPC)
{
	native_call *caller = getNativeCallForInstruction(callerTrace, lastPC);
	if(caller == NULL)
	{
		printf("error: nativeHandle.c: remove: native call slot should not be null\n");
	}
	native_called_method_list *invoke= popStack(caller);
	if(invoke==NULL || invoke->calledMethod != NULL)
	{
		printf("error: nativeHandle.c: remove: stack is null or contain java method\n");
	}
}

native_called_method_list* getStackTop(native_call *caller)
{
	return caller->stack;
}

/** native_call related ***/

//add a new native_call in meth, for a new instruction
native_call* addNativeCallSlotForInstruction(struct _method_trace *methodTrace, int pc)
{
	native_call *nativecall= (native_call*)cleanMalloc(sizeof(native_call));
	nativecall->pc= pc;
	nativecall->prev= methodTrace->nativecall;
	methodTrace->nativecall= nativecall;
	return nativecall;
}

//get the specified catch_inst of inst (first of catch block) from meth
native_call* getNativeCallForInstruction(struct _method_trace *methodTrace, int pc)
{
	native_call *curr = methodTrace->nativecall;
	while(curr!=NULL) 
	{
		if(curr->pc == pc)
		{
			return curr;
		}
		curr= curr->prev;
	}
	return NULL;
}

native_called_method_list* getNativeCalledJavaMethodListForInstruction(struct _method_trace *methodTrace, int pc)
{
	native_call *called=getNativeCallForInstruction(methodTrace, pc);
	if(called != NULL)
		return called->calledMethods;
	return NULL;
}

/******* others *********/
void dumpNativeCall(struct _method_trace *methodTrace)
{
	native_call *nativecall = methodTrace->nativecall;
	if(nativecall == NULL)
		return;
	printf("***begin of nativecall***\n");
	while(nativecall != NULL)
	{
		printf("inst: %d\n", nativecall->pc);
		
		native_called_method_list* invoke = nativecall->calledMethods;
		while(invoke!=NULL)
		{
			printf("\tone invoke\n");
			native_called_method* callee = invoke->calledMethod;
			printf("\t\tcalled java method:");
			while(callee != NULL)
			{
				if(callee->classID == -1)
				{
					printf(" -1.-1(-1)");
				}
				else
				{
					printf(" %s.%s(%s)", getClassNameFromTraceAt(callee->classID), getMethodNameFromTraceAt(callee->methodID), getSigNameFromTraceAt(callee->sigID));
				}
				callee = callee->prev;
			}
			printf("\n");
			
			invoke= invoke->prev;
		}
		nativecall = nativecall->prev;
	}
	printf("***end of nativecall***\n");
}

