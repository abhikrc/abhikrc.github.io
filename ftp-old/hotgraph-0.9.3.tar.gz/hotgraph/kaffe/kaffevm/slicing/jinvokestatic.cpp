#include "slicing.h"
#include "jinvokestatic.h"
#include "signature.h"
#include "bytecodelist.h"
#include "jclass.h"
#include "cnamelist.h"

JInvokeStatic::JInvokeStatic(JMethod *meth, int operation, int pc, int classNameId, int methodNameId, int methodSigId, const char *sig):
JBytecode(meth, operation, pc, InvokeStaticBytecode)
{
	this->classNameId= classNameId;
	this->methodNameId= methodNameId;
	this->methodSigId= methodSigId;
	signature= new Signature(sig);
    argsNum= signature->getNargs();
    if (argsNum >0)
    {
        argsUseOperNum= (int *)cleanMalloc(sizeof(int) * argsNum);
        argsLocalVarPos= (int *)cleanMalloc(sizeof(int) * argsNum);
    }
    else
    {
        argsUseOperNum= NULL;
        argsLocalVarPos= NULL;
    }

    defOperNum=0;
    allArgsUseOperNum=0;
	staticInit= NULL;
	javaMethods= NULL;
}

JInvokeStatic::~JInvokeStatic()
{
	delete signature;
	signature=NULL;
	free(argsUseOperNum);
    free(argsLocalVarPos);
	argsUseOperNum=NULL;
}

int JInvokeStatic::getnArgsLocalPos(int index)
{
	return argsLocalVarPos[index];
}

void JInvokeStatic::setnUseOperNum(int index, int operNum)
{
	argsUseOperNum[index]= operNum;
    allArgsUseOperNum+= operNum;
}
	
int JInvokeStatic::getnUseOperNum(int index)
{
	return argsUseOperNum[index];
}

int JInvokeStatic::getAllArgsUseOperNum()
{
	return allArgsUseOperNum;
}

void JInvokeStatic::setDefOperNum(int operNum)
{
	defOperNum= operNum;
}
	
int JInvokeStatic::getDefOperNum()
{
	return defOperNum;
}

JClass* JInvokeStatic::getInvokeJClass()
{
	int i;
	JClass *current=classes;
	while(current!=NULL)
	{
		if(current->getNameId() == classNameId)
			return current;
		current= current->nextClass;
	}
	return NULL;
}

void JInvokeStatic::initCalls()
{
	int i;
	JClass * currClass = getInvokeJClass();

	while(currClass!= NULL && invokeMethod.size()==0)
	{		//printf("build static: class %s\n", currClass->getClassName());
	    int j, methodCount;
	    JMethod *meths= currClass->getMethods();

	    methodCount= currClass->getMethodCount();

	    for (j=0; j<methodCount; j++)
	    {
	    	//printf("build static: method %s\n", meths[j].getMethodName());
		    if (meths[j].getNameId()== methodNameId && meths[j].getSigId()== methodSigId)
		    {
			    invokeMethod.addTail(&(meths[j]));
		    }
	    }
	    currClass= currClass->getSuperJClass();
    }


    /*if (invokeMethod.size()==0)
    {
        printf("warning: %s.%s invoke static method not found: %s.%s\n", meth->getParentClass()->getClassName(), meth->getMethodName(), classNames->getCNameAt(classNameId), 
        	methodNames->getCNameAt(methodNameId));
        //exit(1);
    }*/

	return;	
}

LinkList<JMethod*>* JInvokeStatic::getInvokeMethod()
{
	return &invokeMethod;
}

int JInvokeStatic::getArgsCount()
{
	return argsNum;
}

void JInvokeStatic::dumpCallGraph()
{
	printf("pc: %d, instruction: %s, call \n", pc, bytecodeName[operation]);
	JMethod *ite;

	for(ite= invokeMethod.getHead(); invokeMethod.hasNext(); ite=invokeMethod.getNext())
	{
		printf("	%s %s %s\n", classNames->getCNameAt(ite->getParentClass()->getNameId()),
					methodNames->getCNameAt(ite->getNameId()), sigs->getCNameAt(ite->getSigId()));
	}

}

JMethod* JInvokeStatic::getStaticInit()
{
    if (!staticInit)
	{
		JClass *pclass= getJClass(classNameId);
		if (!pclass)
			return NULL;
		staticInit= pclass->getStaticInit();
	}
	return staticInit;
}

Signature* JInvokeStatic::getSig()
{
	return signature;
}

native_called_method_list* JInvokeStatic::getNextNativeCalledMethodList()
{
	native_called_method_list *curr = javaMethods;
	if(curr!=NULL)
	{
		javaMethods = curr->prev;
		return curr;
	}
	return NULL;
}
