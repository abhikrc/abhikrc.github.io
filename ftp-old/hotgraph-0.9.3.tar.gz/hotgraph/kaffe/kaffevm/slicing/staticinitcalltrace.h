#ifndef	STATICINITCALLTRACE_H
#define STATICINITCALLTRACE_H

#include "arraylist.h"

class JMethod;

class StaticInitCallTrace
{
	typedef struct
	{
		char *className;
		char *methodName;
		char *sig;
		int pc;
		int count;
		JMethod *staticInit;
	}InitCallTraceEntry;

	int visited;
	ArrayList<InitCallTraceEntry*> initCallHistory;
public:
	JMethod* getNext();
	StaticInitCallTrace();
	JMethod* encounter(char*, char*, char*, int, int);
	int hasMore();


};

#endif
