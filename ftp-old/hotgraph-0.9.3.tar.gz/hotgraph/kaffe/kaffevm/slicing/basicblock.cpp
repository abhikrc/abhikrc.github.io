#include "basicblock.h"
#include "jbytecoderef.h"
#include "jmethod.h"
#include "jdefinearray.h"
#include "jdefinelocal.h"
#include "jdefinefield.h"
#include "jdefinestatic.h"
#include "jinvokenonstatic.h"
#include "jinvokestatic.h"
#include "callframe.h"
#include "jnew.h"
#include "jnewarray.h"
#include "jnewmultiarray.h"

BasicBlock::BasicBlock()
{
	control= NULL;
	id= startInst= endInst= 0;
	meth=NULL;	
	controlListSize= 0;
}

BasicBlock::~BasicBlock()
{
	free(control);
}

void BasicBlock::dumpCallGraph()
{
	int pc;
	JBytecodeRef *jBytecodeRef;

	for (pc= startInst; pc<=endInst; pc++)
	{
		jBytecodeRef= meth->getBytecodeRefAt(pc);
		if (!jBytecodeRef)
			continue;

		JBytecode *jBytecode= jBytecodeRef->getBytecode();

		{
			JInvokeNonStatic *jInvokeNonStatic= dynamic_cast<JInvokeNonStatic *>(jBytecode);
			if (jInvokeNonStatic)
			{
				jInvokeNonStatic->dumpCallGraph();
				continue;
			}
		}

		{
			JInvokeStatic *jInvokeStatic= dynamic_cast<JInvokeStatic *>(jBytecode);
			if (jInvokeStatic)
			{
				jInvokeStatic->dumpCallGraph();
				continue;
			}
		}
	}
}
