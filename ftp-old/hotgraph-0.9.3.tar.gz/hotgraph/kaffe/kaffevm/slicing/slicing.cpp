#include <time.h>
#include "slicing.h"
#include "jmethod.h"
#include "jclass.h"
#include "cnamelist.h"
#include "jmethod.h"
#include "jclass.h"
#include "bytecodelist.h"
#include "jbytecoderef.h"
#include "callframe.h"
#include "readtrace.h"
#include "criterions.h"
#include "index2intlist.h"


int classCount=0;
JClass *classes=NULL;

//CNameList *staticFieldNames= new CNameList();
//CNameList *instanceFieldNames= new CNameList();
//CNameList *fileNames=new CNameList();
//CNameList *classNames= NULL;
//CNameList *methodNames= NULL;
//CNameList *sigs= NULL;


CNameList *staticFieldNames= new CNameList();
CNameList *instanceFieldNames= new CNameList();
CNameList *fileNames=new CNameList();
CNameList *classNames= new CNameList();
CNameList *methodNames= new CNameList();
CNameList *sigs= new CNameList();

Index2IntList *instanceFields= new Index2IntList();
Index2IntList *staticFields= new Index2IntList();
Index2IntList *arrayElements= new Index2IntList();
Index2IntList *arrayCounts= new Index2IntList();


ReadTrace *compressedTrace=NULL;

CallFrame *callStack= NULL;
//Index2IntList *instanceFields= NULL;
//Index2IntList *staticFields= NULL;
//Index2IntList *arrayElements= NULL;
//
//Index2IntList *arrayCounts=NULL;
Criterions *sliceCriterions=NULL;

#ifdef _collect_Info
int branchInstance=0;
int userBranchInstance=0;
int dynamicCall=0;
int userDynamicCall=0;
#endif

int allBytecodeCount=0;
int slicedBytecodeCount=0;
int executedBytecodeCount=0;
int executedBytecodeInstanceCount=0;

#ifdef _export_debug
FILE	*flowTrace=NULL;
#endif

char *outputSliceFileName=NULL;

extern "C" int performSlicing()
{
    int i;
	time_t preproseccor, begin, end;

    startSlicing=1;
	preproseccor= time(NULL);

#ifdef _export_debug
	flowTrace= fopen("export", "w");
#endif
	
	compressedTrace= new ReadTrace();

    classNames=compressedTrace->getClassNames();
    methodNames= compressedTrace->getMethodNames();
    sigs= compressedTrace->getSigNames();
    
    classCount=getTracedClassCount();

    classes= new JClass[classCount];
	// init the class
    class_trace   *classTraceIte=getTrace();
    for (i=0; i<classCount; i++)
    {
    	if(classTraceIte==NULL)
    		printf("error: class trace is null\n");
		(classes[i]).init(classTraceIte , i);
        classTraceIte=classTraceIte->next;
    }
	for (i=0; i<classCount; i++)
    {
		classes[i].buildCallGraph();
    }

#ifdef _collect_Info
	begin= time(NULL);
	printTimer(preproseccor, begin);
#endif

	initSlice();

#ifdef _collect_Info
	printf("executed instance: %d\n", compressedTrace->getExecutedInstCount());
	printf("all bytecode: %d\n", getBytecodeCount(1));
	printf("all traced bytecode: %d\n", getTracedBytecodeCount(1));
#endif

	begin= time(NULL);
	getSlice();	
	end= time(NULL);    
	dumpSlice();

#ifdef _collect_Info
    printf("slicing time:");
    printTimer(begin, end);

	printf("executed bytecode: %d\n", getExecutedBytecode(1));
    printf("branch instance: %d, user branch instance: %d\n", branchInstance, userBranchInstance);
    printf("dynamic call: %d, user dynamic call: %d\n", dynamicCall, userDynamicCall);
#endif    
	
	freeSource();

#ifdef _export_debug
	fclose(flowTrace);
#endif

	return 1;
}



///////////////////////////////////////////////////////////////////////////////////
/// global functions
///////////////////////////////////////////////////////////////////////////////////

int string2int(char *p)
{
	int ret=0;
	int positive;
	int position=0;

	if (p[0]== '-')
	{
		positive= -1;
		position++;
	}
	else
	{
		positive= 1;
	}

	while( p[position] != '\0' && p[position] != '\n')
	{
		char ch= p[position];
		if (ch<'0' || ch>'9')
			return -1;
		ret= ret*10+ (int)(ch-'0');
		position++;
	}
	return ret*positive;
}

long string2long(char *p)
{
	long ret=0;
	int position=0;
	int length= strlen(p);

	while(position< length)
	{
		char ch= p[position];
		if (ch<'0' || ch>'9')
		{
			printf("string2long error\n");
			return -1;
		}
		ret= ret*10+ (long)(ch-'0');
		position++;
	}
	return ret;
}

int get4Byte(unsigned char *code)
{
	unsigned int a,b,c,d;

	a= 0x000000ff&code[0];
	b= 0x000000ff&code[1];
	c= 0x000000ff&code[2];
	d= 0x000000ff&code[3];

	return ((a<<24)|(b<<16)|(c<<8)|(d));
}

unsigned int get1Byte(unsigned char *code)
{
	return 0x000000ff&code[0];
}


short get2SignedByte(unsigned char *code)
{
	unsigned int a,b;

	a= code[0];
	b= 0x000000ff&code[1];

	return (short)((a<<8)|(b));
}

unsigned short get2UnsignedSignedByte(unsigned char *code)
{
	unsigned int a,b;

	a= code[0];
	b= 0x000000ff&code[1];

	return (unsigned short)((a<<8)|(b));
}

void dumpSlice()
{
	int i;
    FILE *fp=fopen(outputSliceFileName, "w");

    if (fp ==NULL)
    {
        printf("error, cannot open outputfile file %s \n", outputSliceFileName);
        exit(1);
    }    

	for (i=0; i<classCount; i++)
	{
		if ( ! classes[i].isSystemClass)
			classes[i].dumpSlice(fp);
	}
    fclose(fp);

#ifdef _collect_Info
	printf("all bytecode num: %d, executed: %d, executed instance: %d, bytecode in slice: %d\n", 
		allBytecodeCount, executedBytecodeCount, executedBytecodeInstanceCount, slicedBytecodeCount);
#endif
	executedBytecodeCount= allBytecodeCount= slicedBytecodeCount= 0;
}

int beginWith(char *src, char *begin)
{
	int length= strlen(begin);

	int length2= strlen(src);
	if (length>length2)
		return 0;

	int i;

	for (i=0; i<length; i++)
		if (src[i] != begin[i])
			return 0;

	return 1;
}

int ifSystemClass(char* className)
{
	if ( beginWith(className, "java") ||  beginWith(className, "kaffe") )
		return 1;

	return 0;
}


JClass* getJClass(int classNameId)
{
	int i;

	for (i=0; i<classCount; i++)
	{
		if (classes[i].getNameId()== classNameId)
			return (&classes[i]);
	}
	return NULL;
}

JClass* getJClass(const char *className)
{
	int i;

	for (i=0; i<classCount; i++)
	{
		if ( strcmp( classNames->getCNameAt(classes[i].getNameId()), className) ==0)
			return (&classes[i]);
	}
	return NULL;
}

JMethod *getJMethod(const char *className, const char *methodName, const char *sig)
{
    int i;
    int classNameId= classNames->getNameId(className);
    int methodNameId= methodNames->getNameId( methodName );				    
	int methodSigId= sigs->getNameId(sig);	

    assert(classNameId>=0);
    assert(methodNameId>=0);
    assert(methodSigId>=0);

    for (i=0; i<classCount; i++)
    {
        if (classes[i].getNameId() != classNameId)
            continue;

        int j, methodCount;
        JMethod *meths= classes[i].getMethods();

	   	methodCount= classes[i].getMethodCount();

	   	for (j=0; j<methodCount; j++)
        {
    	     if (meths[j].getNameId()== methodNameId && meths[j].getSigId()== methodSigId)
    		 {
			     return(&(meths[j]));
		     }
        }
	}
    return NULL;
}

void freeSource()
{
    return;
}




void formatClassName(char *className)
{
	int i=0;
	
	while(true)
	{
		if (className[i] == '\0')
			return;

		if (className[i] == '\n')
		{
			className[i]= '\0';
			return;
		}

		if (className[i] == '.')
			className[i] = '/';

		i++;
	}
}

void printTimer(time_t  begin, time_t end)
{
	time_t sec= end- begin;

    printf("used time min: %u, sec: %u, all: %u\n", sec/60, sec%60, sec);
}


int getBytecodeCount(int all)
{
	int i;
	int count=0;

	for(i=0; i<classCount; i++)
	{
		if ( all || !classes[i].isSystemClass )
			count+= classes[i].getBytecodeCount();
	}
	return count;
}

int getTracedBytecodeCount(int all)
{
	int i;
	int count=0;

	for(i=0; i<classCount; i++)
	{
		if ( all || !classes[i].isSystemClass )
			count+= classes[i].getTracedBytecodeCount();
	}
	return count;
}

int getExecutedBytecode(int all)
{
	int i;
	int count=0;

	for(i=0; i<classCount; i++)
	{
		if ( all || !classes[i].isSystemClass )
			count+= classes[i].getExecutedBytecode();
	}

	return count;
}

void dumpExecutedBytecode()
{
	int i;
    printf("============== executed bytecode =============\n");

	for(i=0; i<classCount; i++)
	{
        if ( !classes[i].isSystemClass )
    		classes[i].dumpExecutedBytecode();
	}
}

