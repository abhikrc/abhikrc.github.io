#ifndef LINENUMBER_H
#define LINENUMBER_H

class LineTable;

class LineNumber
{
	int length;
	LineTable *lineTab;
public:
	LineNumber(int);
	~LineNumber();	
};

#endif
