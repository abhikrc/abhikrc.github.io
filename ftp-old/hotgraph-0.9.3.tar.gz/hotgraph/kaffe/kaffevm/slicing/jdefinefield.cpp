// JDefineField.cpp: implementation of the JDefineField class.
//
//////////////////////////////////////////////////////////////////////

#include "jdefinefield.h"
#include "slicing.h"
#include "bytecodelist.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

JDefineField::JDefineField(JMethod *meth, int operation, int pc, int field, int fieldSize): 
JBytecode(meth, operation, pc, DefineFieldBytecode)
{
	this->field= field;
    this->fieldSize= fieldSize;
}

JDefineField::~JDefineField()
{

}

int JDefineField::getField()
{
	return field;
}
