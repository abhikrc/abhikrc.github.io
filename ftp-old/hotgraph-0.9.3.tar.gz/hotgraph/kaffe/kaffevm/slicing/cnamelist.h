/***************************************************************************
                          cnamelist.h  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef CNAMELIST_H
#define CNAMELIST_H

#include "arraylist.h"

/**
  *@author wt
  */
class CName;
  
class CNameList
{
	ArrayList<char*> names;
public:
	CNameList(int);
	CNameList();
	~CNameList();
	char* getCNameAt(int);
	int update(const char*);  
	int getNameId(const char*);
	int size();
};

#endif
