#include "slicing.h"
#include "staticinitcalltrace.h"
#include "jmethod.h"
#include "jclass.h"
#include "cnamelist.h"

StaticInitCallTrace::StaticInitCallTrace()
{
	int classNameId, methodNameId, sigId;	

	InitCallTraceEntry *newEntry;
	int invokedClassNameId;
	JClass *jclass;
	visited=0;

    staticInitCallTraceEntry *staticInitCallTraceEntryIte=getStaticInitTrace();

	while (staticInitCallTraceEntryIte!=NULL)
	{
		newEntry= (InitCallTraceEntry*)cleanMalloc(sizeof(InitCallTraceEntry));
		
		classNameId=staticInitCallTraceEntryIte->classNameId;
        methodNameId=staticInitCallTraceEntryIte->methodNameId; 
        sigId= staticInitCallTraceEntryIte->sigId;
	    newEntry->pc= staticInitCallTraceEntryIte->lastPC;
        newEntry->count= staticInitCallTraceEntryIte->count;
        invokedClassNameId= staticInitCallTraceEntryIte->invokedClassNameId;
        
		if (classNameId>=0)
		{
			newEntry->className= classNames->getCNameAt(classNameId);
			newEntry->methodName= methodNames->getCNameAt(methodNameId);
			newEntry->sig= sigs->getCNameAt(sigId);
		}
		else
		{
			newEntry->className= NULL;
			newEntry->methodName= NULL;
			newEntry->sig= NULL;
		}
		 
		/*printf("add static init: %s, %s, %s, %d, %d\n", 
			newEntry->className, newEntry->methodName, newEntry->sig,
			staticInitCallTraceEntryIte->lastPC, 
			staticInitCallTraceEntryIte->count);
*/	
		jclass= getJClass(classNames->getCNameAt(invokedClassNameId));
		newEntry->staticInit= jclass->getStaticInit();
		initCallHistory.addTail(newEntry);
        staticInitCallTraceEntryIte=staticInitCallTraceEntryIte->next;
		visited++;
	}
}

JMethod* StaticInitCallTrace::encounter(char *currentClassName, char *currentMethodName, char *currentSig, int pc, int executedInstCount)
{
	if (visited<=0)
		return NULL;
		//printf("dump static init: %s, %s, %s, %d, %d\n", currentClassName, currentMethodName, currentSig, pc, executedInstCount);

	InitCallTraceEntry *entry= initCallHistory.getAt(visited-1);	
		//printf("222 dump static init: %s, %s, %s, %d, %d\n", entry->className, entry->methodName, entry->sig, entry->pc, entry->count);
	
	if (entry->pc == pc && entry->count== executedInstCount	
		&& strcmp( currentMethodName, entry->methodName) ==0 
		&& strcmp( currentClassName, entry->className) ==0 
		&& strcmp( currentSig, entry->sig)==0 )
	{
		visited--;
		return entry->staticInit;
	}

	return NULL;
}

int StaticInitCallTrace::hasMore()
{
	if (visited)
		return 1;
	else
		return 0;
}


JMethod* StaticInitCallTrace::getNext()
{
	visited--;
	InitCallTraceEntry *entry= initCallHistory.getAt(visited);
	return entry->staticInit;
}
