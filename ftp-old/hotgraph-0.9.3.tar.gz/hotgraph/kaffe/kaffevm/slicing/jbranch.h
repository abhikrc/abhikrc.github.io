/***************************************************************************
                          jdefinelocal.h  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef JBRANCH_H
#define JBRANCH_H

#include "jbytecode.h"

/**
  *@author wt
  */
class BytecodeList;
class CNameList;
class JBytecodeRef;
class JMethod;

class JBranch : public JBytecode
{
private:
	BytecodeList *control;
public: 
	virtual void dumpType();
	BytecodeList* getControl();
	void addControl(JBytecodeRef*);
	JBranch(JMethod*, int, int);
	~JBranch();
};

#endif
