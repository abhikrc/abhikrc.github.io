#ifndef CRITERION_H
#define CRITERION_H

//#define MethodCriterion

class JBytecode;

class Criterions
{
public:
	int count;
	int *classNameIds, *methNameIds, *pcs, *sigNameIds, *fileNameIds;
    int *isSingleOccurrence;
    char **classNames;
    char **methodNames;
    char **sigs;
    
    void init();
    
#ifdef MethodCriterion
	int mcCount;
	int *mcClassNameIds, *mcMethNameIds;
	int currentMCClassId, currentMCMethodId;
	void initMethodCriterion();
	int containMethod(int, int);
#endif

	void Criterions::getCriterion(int i, char** className, char** methodName, char** sig, int *pc);
    int contain(int, JBytecode *);
	int contain(int, int, int, JBytecode*);
	Criterions();
	~Criterions();
#ifdef MethodCriterion	void mcPushCallFrame(int, int);
	void mcPopCallFrame(int, int);
	int inMethodCriterion();
#endif

};

extern int foreclipse;

#endif
