#ifndef LINKLIST_H
#define LINKLIST_H

#include "slicing.h"

template <class OBJTYPE> class LinkList
{
protected:
	typedef struct _Node
	{
		_Node *prev;
		_Node *next;
		OBJTYPE p;
	}Node;
protected:
	int k;
	int count;
	Node *list, *next;

	Node *createNewNode(OBJTYPE);
	void freeNode(Node *);
public:
	LinkList();
	~LinkList();
	void addTail(OBJTYPE);
	OBJTYPE getHead();
	OBJTYPE getHeadAndRemove();
	OBJTYPE getNext();
	int hasNext();		// one list cannot be traversed by two loop at the same time
	int contain(OBJTYPE);
	int remove(OBJTYPE);
	int empty();
	int uniqueInsert(OBJTYPE p);
	int uniqueMergeAndRemove(LinkList<OBJTYPE>*);
	void removeAll();
	int size();
};

template <class OBJTYPE>
LinkList<OBJTYPE>::LinkList()
{
	k= count=0;
	next= list= NULL;
}

template <class OBJTYPE>
LinkList<OBJTYPE>::~LinkList()
{
	removeAll();
}


template<class OBJTYPE> 
void LinkList<OBJTYPE>::freeNode(Node *p) 
{
	count--;

	Node *prev, *next;
	prev= p->prev;
	next= p->next;
	prev->next= next;
	next->prev= prev;
	free(p);
}

template<class OBJTYPE> 
void LinkList<OBJTYPE>::addTail(OBJTYPE p) 
{
	count++;

	Node *newNode=(Node *)malloc(sizeof(Node));
	memset(newNode, 0, sizeof(Node));

	newNode->prev= newNode->next= newNode;
	newNode->p= p;
	

	if (!list)
	  {
	    list= newNode;
	  }
	else
	{
		Node *tail= list->prev;
		Node *newTail= newNode;
		tail->next= newTail;
		newTail->next= list;
		list->prev= newTail;
		newTail->prev= tail;
	}
}

template<class OBJTYPE> 
OBJTYPE LinkList<OBJTYPE>::getHead()
{
	if (list)
	{
		next= list;
		k=0;
		return list->p;
	}
	else
	{
		return NULL;
	}
}

template<class OBJTYPE> 
OBJTYPE LinkList<OBJTYPE>::getHeadAndRemove()
{
	if (!list)
		return NULL;

	Node *head= list;
	OBJTYPE ret= head->p;

	if (list->next == list)
		list= NULL;
	else
		list= list->next;

	freeNode(head);
	return ret;
}



template<class OBJTYPE> 
OBJTYPE LinkList<OBJTYPE>::getNext()
{
	next= next->next;
	return next->p;
}

template<class OBJTYPE> 
int LinkList<OBJTYPE>::hasNext()
{
	int ret;

	if (list ==NULL)
		return 0;
	else
	{	
		if (list != next)
			return 1;
		else
		{
			ret= (k==0);
			k=(k+1)%2;
			return ret;
		}
	}
}

template<class OBJTYPE>
int LinkList<OBJTYPE>::contain(OBJTYPE p)
{
	int i;
	Node *ite=list;

	for (i=0; i<count; i++)
	{
		if (ite->p == p)
			return 1;
		ite= ite->next;
	}

	return 0;
}

template<class OBJTYPE> 
int LinkList<OBJTYPE>::remove(OBJTYPE p)
{
	int i;
	Node *ite=list;

	for (i=0; i<count; i++)
	{
		if (ite->p == p)
		{
			if (i==0)
				getHeadAndRemove();
			else
				freeNode(ite);
			return 1;
		}
		ite= ite->next;
	}

	return 0;
}

template<class OBJTYPE> 
int LinkList<OBJTYPE>::empty()
{
	return (count==0);
}

template<class OBJTYPE> 
int LinkList<OBJTYPE>::uniqueInsert(OBJTYPE p)
{
	int i;
	Node *ite=list;

	for (i=0; i<count; i++)
	{
		if (ite->p == p)
		{
			return 0;
		}
		ite= ite->next;
	}
	addTail(p);
	return 1;
}

template<class OBJTYPE> 
int LinkList<OBJTYPE>::uniqueMergeAndRemove(LinkList<OBJTYPE>* list2)
{

	if (!list2)
		return 0;

	int i, ret=0;
	Node *ite= list2->list, *freeIte;
	int list2Count= list2->count;

	for (i=0; i<list2Count; i++)
	{
		if (uniqueInsert(ite->p))
			ret=1;
		freeIte=ite;		
		ite= ite->next;
		free(freeIte);
	}

	list2->list= list2->next=NULL;
	list2->count=0;

	return ret;
}

template<class OBJTYPE> 
void LinkList<OBJTYPE>::removeAll()
{
	Node *p, *nextNode;

	nextNode= list;
	while(count)
	{
		p= nextNode;
		nextNode=nextNode->next;
		free(p);
		count--;
	}
}

template<class OBJTYPE> 
int LinkList<OBJTYPE>::size()
{
	return count;
}

#endif
