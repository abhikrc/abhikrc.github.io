#ifndef SIGNATURE_H
#define SIGNATURE_H

class Signature
{
public:
	const char* sig;
	int nargs;
	int *retAndArgs;	// the size of each parameters, the first is return,
						// the following is the formal parameters

	int countArgsInSig(const char *);
	int* parseSig(const char *, int);
public:
	int getSizeOfRet();
	int getSizeOfNArgs(int);
	Signature(const char*);
	int sizeofSigItem(const char **);
	static int sizeofSigChar(const char);
	int getNargs();
	~Signature();
};

#endif

