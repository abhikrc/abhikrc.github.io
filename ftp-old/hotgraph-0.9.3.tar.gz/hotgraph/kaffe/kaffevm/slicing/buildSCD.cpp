#include <time.h>
#include <vector>
#include "buildSCD.h"
#include "jmethod.h"
#include "jclass.h"
#include "cnamelist.h"
#include "bytecodelist.h"
#include "jbytecoderef.h"
#include "index2intlist.h"

using std::vector;

//int classCount=0;
//JClass *classes=NULL;

//CNameList *staticFieldNames= new CNameList();
//CNameList *instanceFieldNames= new CNameList();
//CNameList *fileNames=new CNameList();
//CNameList *classNames= new CNameList();
//CNameList *methodNames= new CNameList();
//CNameList *sigs= new CNameList();
//
//Index2IntList *instanceFields= new Index2IntList();
//Index2IntList *staticFields= new Index2IntList();
//Index2IntList *arrayElements= new Index2IntList();
//Index2IntList *arrayCounts= new Index2IntList();

void formatClassNameSCD(char *className);
JMethod *getJMethodSCD(const char *className, const char *methodName, const char *sig);

extern "C" void updateClassNames(const char* name, int traceid)
{
	int id= classNames->update(name);
	formatClassNameSCD(classNames->getCNameAt(id));
	/*if(id!=traceid)
	{
		printf("error: wrong class name id: %d,%d %s\n", traceid, id, name);
	}*/
}

extern "C" void updateMethodNames(const char* name, int traceid)
{
	int id= methodNames->update(name);
	/*if(id!=traceid)
	{
		printf("error: wrong method name id: %d,%d %s\n", traceid, id, name);
	}*/
}

extern "C" void updateSigs(const char* name, int traceid)
{
	int id= sigs->update(name);
	/*if(id!=traceid)
	{
		printf("error: wrong sig name id: %d,%d %s\n", traceid, id, name);
	}*/
}


extern "C" int buildCDG(class_trace *ctrace)
{
    int i, nameid;
	//time_t preproseccor, begin, end;
	JClass *currentClass= new JClass();

	//preproseccor= time(NULL);

#ifdef _export_debug
	flowTrace= fopen("export", "w");
#endif

    currentClass->nextClass= classes;
    classes= currentClass;
    
    //nameid= classNames->getNameId(getClassNameFromTrace(ctrace));
    /*if(classCount != ctrace->classID)
    {
    	printf("error: class id not match %d %s, %d %s\n", classCount,  ctrace->classID, getClassNameFromTrace(ctrace));
    	exit(1);
    }*/
	
    // init the class
	//currentClass->init(ctrace , classCount);
    currentClass->init(ctrace, ctrace->classID);
	classCount++;

	currentClass->buildCallGraph();
	
	//printf("build SCD for %s\n", getClassNameFromTrace(ctrace));

#ifdef _collect_Info
	begin= time(NULL);
	printTimer(preproseccor, begin);
#endif

#ifdef _collect_Info
	printf("executed instance: %d\n", compressedTrace->getExecutedInstCount());
	printf("all bytecode: %d\n", getBytecodeCount(1));
	printf("all traced bytecode: %d\n", getTracedBytecodeCount(1));
#endif


	//begin= time(NULL);

	//getSlice();	
	//end= time(NULL);    
	//dumpSlice();

#ifdef _collect_Info
    printf("slicing time:");
    printTimer(begin, end);

	printf("executed bytecode: %d\n", getExecutedBytecode(1));
    printf("branch instance: %d, user branch instance: %d\n", branchInstance, userBranchInstance);
    printf("dynamic call: %d, user dynamic call: %d\n", dynamicCall, userDynamicCall);
#endif

#ifdef _export_debug
	fclose(flowTrace);
#endif

	return 1;
}

extern "C" int* getStaticDependence(inst_trace *instTrace, const char *className, const char *methodName, const char *sig, int pc, int *size)
{
	JMethod *target= NULL;
	if(instTrace->jmethod == NULL)
	{
		target = getJMethodSCD(className, methodName, sig);
		instTrace->jmethod= (void*)target;
	}
	else
	{
		target= (JMethod*)instTrace->jmethod;
	}
	//return all PCs on which current pc SCD 
	//JMethod *target = getJMethodSCD(className, methodName, sig);
	
	if(target == NULL)
	{
		printf("error: cannot find jmethod %s.%s%s):%d\n", className, methodName, sig, pc);
		exit(1);
	}
	
	JBytecode *bc = target->getJBytecodeAt(pc);
	int totalBB= target->getBasicBlockCount();
	//printf("total bb: %d\n", totalBB);
	BasicBlock *basicBlocks= target->basicBlocks;
	
	int currentBBid= bc->getBasicBlockId();
	
	vector<int> pcs;
	
	int j;
	for(j=0; j<totalBB; j++)
	{
		BasicBlock *currentBasicBlock=& (basicBlocks[j]);
		if (currentBasicBlock->control)
		{
			int controlCount= currentBasicBlock->control[0];
			int *control= currentBasicBlock->control;
			int i;
	
			for (i=0; i<controlCount; i++)
			{
				//BasicBlock *nextBasicBlocks= &(basicBlocks[control[i+1]]);
				int dependentBBid= control[i+1];
	            if (dependentBBid == currentBBid)
				{
	            	pcs.push_back(currentBasicBlock->endInst);
	            	//printf("push: %d, %d\n", currentBBid, currentBasicBlock->endInst);
					break;
				}
			}
		}
	}
	
	*size= pcs.size();
	int* result = (int*)cleanMalloc(sizeof(int)* (*size));
	int x;
	for(x=0;x<*size;x++)
	{
		result[x]= pcs[x];
	}
	pcs.clear();
	return result;
}

void formatClassNameSCD(char *className)
{
	int i=0;
	
	while(true)
	{
		if (className[i] == '\0')
			return;

		if (className[i] == '\n')
		{
			className[i]= '\0';
			return;
		}

		if (className[i] == '.')
			className[i] = '/';

		i++;
	}
}

JClass* getJClassSCD(const char *className)
{
	JClass *current= classes;
	while(current != NULL)
	{
		//printf("bbb: %d %s\n", current->getNameId(), classNames->getCNameAt(current->getNameId()));
		if ( strcmp( classNames->getCNameAt(current->getNameId()), className) ==0)
			return current;
		current=current->nextClass;
	}
	return NULL;
}

JMethod *getJMethodSCD(const char *className, const char *methodName, const char *sig)
{
    int i;
    int classNameId= classNames->getNameId(className);
    int methodNameId= methodNames->getNameId( methodName );				    
	int methodSigId= sigs->getNameId(sig);	

    assert(classNameId>=0);
    assert(methodNameId>=0);
    assert(methodSigId>=0);
    
    JClass *target = getJClassSCD(className);
    //printf("aa: find jclass: %s, %p\n", className, target);
    if(target != NULL)
    {
        int j, methodCount;
        JMethod *meths= target->getMethods();

	   	methodCount= target->getMethodCount();

	   	for (j=0; j<methodCount; j++)
        {
    	     if (meths[j].getNameId()== methodNameId && meths[j].getSigId()== methodSigId)
    		 {
			     return(&(meths[j]));
		     }
        }
	}
    return NULL;
}

int ifSystemClassSCD(char* className)
{
	if ( beginWith(className, "java") ||  beginWith(className, "kaffe") )
		return 1;

	return 0;
}

void freeSourceSCD()
{
    return;
}

