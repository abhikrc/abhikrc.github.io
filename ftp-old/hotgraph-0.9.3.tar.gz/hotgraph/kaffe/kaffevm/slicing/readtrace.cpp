#include "readtrace.h"
#include "jclass.h"
#include "jbytecoderef.h"
#include "jbytecode.h"
#include "cnamelist.h"
#include "trace.h"

ReadTrace::ReadTrace()
{	
	allocObjCount= getAllocObjectNumFromKaffe();
	executedInstCount= getExecutedInstCountFromKaffe();    

    class_trace *classTraceIte= getTrace();
    int tracedClassCount=0;

	while(classTraceIte != NULL)
	{
	  tracedClassCount++;
	  classTraceIte= classTraceIte->next;
	}

    classTraceIte= getTrace();
    tracedClassNames= new CNameList(tracedClassCount);    

    int i;

	for (i=0; i<tracedClassCount; i++)
	{
        tracedClassNames->update(getClassNameFromTrace(classTraceIte)  );
		formatClassName( tracedClassNames->getCNameAt(i) );
        classTraceIte= classTraceIte->next;
	}

	//****** get the class names, method names..  in the trace  ****/	
    int classNameCount, methodNameCount, sigNameCount;
	classNameCount= getClassNameCountFromTrace();
	classNamesInTrace= new CNameList(classNameCount);
    

	for (i=0; i<classNameCount; i++)
	{		
		classNamesInTrace->update(getClassNameFromTraceAt(i));
		formatClassName( classNamesInTrace->getCNameAt(i) );
	}
	
	methodNameCount= getMethodNameCountFromTrace();
	methodNamesInTrace= new CNameList(methodNameCount);
	for (i=0; i<methodNameCount; i++)
	{
		methodNamesInTrace->update(getMethodNameFromTraceAt(i));
	}
	
	sigNameCount= getSigNameCountFromTrace();
	sigNamesInTrace= new CNameList(sigNameCount);
	for (i=0; i<sigNameCount; i++)
	{
        sigNamesInTrace->update(getSigNameFromTraceAt(i));
	}
}

int ReadTrace::getTracedClassCount()
{
    return tracedClassNames->size();
}
CNameList *ReadTrace::getClassNames()
{
    return classNamesInTrace;
}

CNameList *ReadTrace::getMethodNames()
{
    return methodNamesInTrace;
}

CNameList *ReadTrace::getSigNames()
{
    return sigNamesInTrace;
}

CNameList *ReadTrace::getTracedClassNames()
{
    return tracedClassNames;
}

ReadTrace::~ReadTrace()
{
    delete tracedClassNames;
	delete classNamesInTrace;
	delete methodNamesInTrace;
	delete sigNamesInTrace;

	classNamesInTrace=NULL;
	methodNamesInTrace=NULL;
	sigNamesInTrace=NULL;
}


RLESe *ReadTrace::getRLESe(RLESe *rl, oper_trace *opTrace)
{   
    rl->s = opTrace-> s;
	initRLESe4Search(rl);
    return rl;
}

void ReadTrace::fillTrace()
{
#ifdef _RLESE
	char nextCh;
	int analizedInst, classNameID, methodNameID, sigID;
	JClass *jclass;
	JMethod *jmeth;	
    class_trace   *classTraceIte;
    method_trace *methTraceIte;
    int i, instCount;
    inst_trace* instTrace;

    classTraceIte= getTrace();
    while(classTraceIte != NULL)
    {
        classNameID= classTraceIte->classID;
        jclass= getJClass( this->classNamesInTrace->getCNameAt(classNameID) );
        if ( !jclass )
		{
			printf("read trace file error, cannot find class %s\n", this->classNamesInTrace->getCNameAt(classNameID));
			abort();
		}

        methTraceIte= classTraceIte->methodTrace;
        while(methTraceIte != NULL)
        {
            if (! methTraceIte->hasExecuted)
             {
                    methTraceIte= methTraceIte->next;
                    continue;
             }

            methodNameID= methTraceIte->methodID;
			sigID= methTraceIte->sigID;

            jmeth= jclass->getMethod( this->methodNamesInTrace-> getCNameAt(methodNameID), 
                                                    this->sigNamesInTrace-> getCNameAt(sigID));
            if ( !jmeth )
			{
				printf("read trace file error, cannot find method, %s.%s, %s\n", 
                              this->classNamesInTrace->getCNameAt(classNameID),
                              this->methodNamesInTrace-> getCNameAt(methodNameID),
                              this->sigNamesInTrace-> getCNameAt(sigID));
				abort();
			}

            jmeth->callInfo = (RLESe *)cleanMalloc(sizeof(RLESe));

            if (methTraceIte->callInfo->s)
            {
                getRLESe(jmeth->callInfo, methTraceIte->callInfo);
            }

            instCount= methTraceIte->instTracingNumber;
            for (i=0; i<instCount; i++)
            {
                instTrace= &(methTraceIte->instTrace[i]);
                JBytecode *jbytecode= jmeth->getJBytecodeAt(instTrace->pc);

                int opNum=instTrace->operand_num;
                jbytecode->dOperNum= opNum;

                if (NULL !=  instTrace->controlTrace )
                {   
                    jbytecode->prev= (RLESe *)cleanMalloc(sizeof(RLESe));

                    getRLESe(jbytecode->prev,  instTrace->controlTrace);

                }

                if (opNum)
					jbytecode->dOper= (RLESe *)cleanMalloc(sizeof(RLESe)*opNum);       

                for (int i=0; i<opNum; i++)
				{
					getRLESe(&(jbytecode->dOper[i]), &(instTrace->operTrace[i]) );
				}
				
				if(NULL != instTrace->valueTrace)
				{
					jbytecode->specialValue= (RLESe *)cleanMalloc(sizeof(RLESe));
					getRLESe(jbytecode->specialValue, instTrace->valueTrace);
				}
            }
            methTraceIte= methTraceIte->next;
        }
        classTraceIte= classTraceIte->next;
    }
#endif
	return;
}


int ReadTrace::getExecutedInstCount()
{
	return executedInstCount;
}

int ReadTrace::getAllocObjCount()
{
	return allocObjCount;
}
