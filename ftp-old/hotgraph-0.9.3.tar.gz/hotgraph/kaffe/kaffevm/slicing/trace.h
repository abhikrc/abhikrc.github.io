/*
 * trace.h
 *
 * collect compact trace.
 * 
 *
 * Written by Tao Wang <wangtao@comp.nus.edu.sg> 
 */

#ifndef __trace_h
#define __trace_h


/*======== 	begin of definitions that apply to Kaffe 	     ========*/
#include <stdio.h>
#include "native.h"
#include "bytecode.h"
#include "nativeHandle.h"
#include "exceptionHandle.h"

#define _RLESE
//#define _CT_DEBUG
//#define CollectFlowTrace


#define GUARD_SYMBOL		1
#define TERMINAL_SYMBOL		2
#define NON_TERMINAL_SYMBOL	3

struct _ct_symbol;
struct _gnode;
typedef char SymbolType;

//extern Utf8Const **classNameList, **methodNameList, **sigList;

// head of a grammar rule
typedef struct _ct_rule
{
	struct _ct_symbol *guard;
	short int count;
	short int index;
	struct _ct_rule *next;
    struct _ct_rule *prev;
}ct_rule;

// a grammar node in the right hand side of a grammar rule
typedef struct _ct_symbol
{
	SymbolType type;
	struct _ct_symbol *prev, *next;
	union
	{
		int offset;
		ct_rule *rule;
	}value[1];
	int count;		/* how many times it has */
}ct_symbol;

struct _Node;
typedef struct _Node DigramIndex;

typedef struct
{
	int			lastBase;
	ct_rule 	*s;
	DigramIndex	*index;
}oper_trace;

/* trace for each instruction
 * different instruction will store different number of operands
 */

typedef struct _inst_trace
{
	int		pc;
	int		operand_num;
	//struct _gnode	*instance;
	void	*instances;//set<GNode> instances;
	int		latestTimestamp;
	void	*jmethod;
	struct _method_trace  *methodTrace;
#ifdef _RLESE
	oper_trace	*controlTrace;
	oper_trace	*operTrace;
	oper_trace	*valueTrace;//free slot for storing information
#endif
}inst_trace;

struct _class_trace;
/* execution trace for each method
 * methods executed in different thread has differen trace
 * but they point the same hashTable to save storage
 */
typedef struct _method_trace
{
    short int		        methodID;
    short int	        	sigID;
    int			            *hash;	    /*map pc with instruction trace slot*/
    inst_trace      		*instTrace;
    struct _method_trace	*next;
    int                     instTracingNumber;  /*how many instructions need tracing*/    
    int                     hasExecuted;
    oper_trace		        *callInfo;
    catch_inst				*catchinst; // by GL //a list for all first inst of catch block
    native_call				*nativecall; // bridge for native call to java method
    struct _class_trace		*classTrace;
}method_trace;

/* organize method trace of the same class together to speed up
 * locating a method trace
 */

struct Hjava_lang_Class;

typedef struct _class_trace
{
    struct Hjava_lang_Class *javaClass;
	int			        classID;
	method_trace		*methodTrace;
	struct _class_trace	*next;
}class_trace;

/* store the method called by each thread
 * on reverse order of the calling order
 * which means that the first element is the current call method
 */
typedef struct _call_frame
{
	int                 classID;
	method_trace		*methodTrace;
	struct _call_frame	*prev;
	int		            lastPC;
    short               isStaticInit;
    int*				spBaseAddr; //the base addr of current oper stack// by GL
    int*				spCurrAddr; //the current addr of oper stack
    short				needTracing; //store the value corresponding to currentNeedTracing in runVirtualMachine, this is needed when exception is thrown within lib, or the catch block will be considered as not need tracing
    short				executingNativeMethod; //1 - current bytecode in current frame is invoking a native method
    int					localCount;
    int*				locals;
    short				callingArgCount;
    int*				callingArgs;
    int					stackSize;
    int					operStackTop;
    int*				operStack;
    method_trace*		retMethodTrace;
    int					retPC;
    short				inCatch;
    short				executedJava;
}call_frame;

typedef struct _method_hash
{
	struct _method_hash 	*next;
	short int	         	methodID;
	short int	        	sigID;
	int			            count;		/*number of instructions which need tracing*/
	int 		        	*hash;
    int                     **allocSites;
}method_hash;


#define Max_Oper	20

typedef struct _inst_info
{
	int pc;
	int instruction;
	int operand_num;
	int operands[Max_Oper];
	int *depclassid;
	int *depmethodid;
	int *depsigid;
	int *deppc;
	int depsize;
}inst_info;

extern struct _trace_Options traceOptions;

typedef struct _object_id_entry
{
	unsigned int addr;
    int number;
	struct _object_id_entry *next;
}objectIDEntry;

extern int executedInstCount;


struct _methods;

void traceMethodCall(struct _methods *);
void exitMethod(struct _methods*, int exitDueToException);
void traceInstruction (inst_info*);
void traceControlInfo(inst_trace*, int);
void traceSpecialValue(int, int);

int isCallFrameMatch(struct _methods* meth); //by GL

int ifNeedTracing(struct _methods *meth);
objectIDEntry*  getObjectID(void* addr);
objectIDEntry* insertObjectID(void* addr);
void* getAddrFromObjectID(int objID);




extern int traceMultiArrayAllocation;
extern inst_info multiNewInfo;

extern int startSlicing;
extern int reflectCall;
extern inst_info reflectCallInfo;

typedef char* charRef;
extern charRef bytecodeName[];
extern const unsigned short int instOper[];
extern const unsigned short int controlInfo[];
extern const unsigned short int instLen[];

/// utility
int getByte2(unsigned char *code);
unsigned int getByte(unsigned char *code);
int getByte1(unsigned char *code);
void* cleanMalloc(unsigned int);

//// interface to slicing;
struct identity_info
{
    const char *cname;
    const char *name;
    const char *signature;
};

typedef struct _staticInitCallTraceEntry
{
	int classNameId;
	int methodNameId;
    int sigId;
	int lastPC;
	int count;
    int invokedClassNameId;
    struct _staticInitCallTraceEntry *next;
}staticInitCallTraceEntry;

class_trace* getClassTrace(struct _methods *meth, int classID);
const char *getClassNameFromTrace(class_trace *);
class_trace	*getTrace(void);
int getClassNameCountFromTrace(void);
int getMethodNameCountFromTrace(void);
int getSigNameCountFromTrace(void);
const char *getClassNameFromTraceAt(int);
const char *getMethodNameFromTraceAt(int);
const char *getSigNameFromTraceAt(int);
int *getObjAllocSiteMapFromTrace(void);

int getTracedClassCount(void);
struct Hjava_lang_Class* getSuperClassInKaffe(struct Hjava_lang_Class *);
const char * getClassNameInKaffe(struct Hjava_lang_Class *);
int getInterfaceCountInKaffe(struct Hjava_lang_Class *);
const char *getInterfaceNameAtInKaffe(struct Hjava_lang_Class *, int);
const char* getFileNameInKaffe(struct Hjava_lang_Class *);
int getMethodCountInKaffe(struct Hjava_lang_Class *);
struct _methods *getMethodAtInKaffe(struct Hjava_lang_Class *, int);
int getStaticFieldCountInKaffe(struct Hjava_lang_Class *);
int getNonStaticFieldCountInKaffe(struct Hjava_lang_Class *);
const char *getFieldNameInKaffe(struct Hjava_lang_Class *, int);
struct _method_trace *getTraceOfMethod(struct _methods *);
const char * getMethodNameInKaffe(struct _methods *);
int getMethodStackSizeInKaffe(struct _methods *);
int getLocalVariableCountInKaffe(struct _methods *);
int getCodelenOfMethodInKaffe(struct _methods *);
unsigned char *getCodeOfMethodInKaffe(struct _methods *);
void getFieldFromConstantPool(unsigned int, struct _methods* , int, struct identity_info *);
void getMethodCallInfoFromConstantPool(unsigned int, struct _methods* , int, int, struct identity_info *);
const char* getClassNameFromConstantPoolInKaffe(unsigned int, struct _methods*);

int getAllocObjectNumFromKaffe(void);
int getExecutedInstCountFromKaffe(void);
staticInitCallTraceEntry *getStaticInitTrace(void);
int isNativeMethod(struct _methods*);
const char * getMethodSigInKaffe(struct _methods *);
struct Hjava_lang_Class* getJavaClassInKaffe(const char *);
struct _methods* getJavaMethodInKaffe(struct Hjava_lang_Class *, const char *, const char *);
const char * getClassNameOfMethInKaffe(struct _methods *);
void prints(ct_rule *s, FILE *fp);
int getFieldCountInKaffe(struct Hjava_lang_Class *);
struct Hjava_lang_Class *getAnInterfaceInKaffe(struct Hjava_lang_Class *, int );
int getLineNumCountInKaffe(struct _methods*);
void getLineNumAtInKaffe(struct _methods* meth, unsigned int , int *, int *);
int getExceptionsCountInKaffe(struct _methods* );
int getExceptionsTargetInKaffe(struct _methods* , int);
call_frame* getTracingCallStack(void);
const char* getClassNameofTracingCallFrame(call_frame *);
const char* getMethodNameofTracingCallFrame(call_frame *);
const char* getSigofTracingCallFrame(call_frame *);

int insertFieldName(const char * fldName);
int insertClassName(Utf8Const * name);
char* getFieldName(int idx);
int getClassNameID(struct Hjava_lang_Class* cl);
char* copyString(const char *);

void defineLocal(call_frame *currentCallFrame, int localIndex, int pc);
int useLocal(call_frame *currentCallFrame, int localIndex);
void pushOperStack(call_frame *currentCallFrame, int size, int pc);
void popOperStack(call_frame *currentCallFrame, int size, int* defpc);

void traceLoadArray(inst_info* instInfo, int pc, int instruction, objectIDEntry* objectId, int index, int pushsize);
void traceLoadLocal(inst_info* instInfo, int pc, int instruction, int idx, int pushsize);
void traceDefineLocal(inst_info* instInfo, int pc, int instruction, int idx, int depsize);
void traceDefineArray(inst_info *instInfo, int pc, int instruction, objectIDEntry* objectId, int index, int depsize);
void traceCommon(inst_info* instInfo, int pc, int instruction, int pushsize, int popsize);
void traceIINC(inst_info* instInfo, int pc, int instruction, int idx);
void traceStackPop(inst_info* instInfo, int popsize, int depexist);
void updateCallingArgs(inst_info* instInfo, int argCount, int hasObject);

#endif

