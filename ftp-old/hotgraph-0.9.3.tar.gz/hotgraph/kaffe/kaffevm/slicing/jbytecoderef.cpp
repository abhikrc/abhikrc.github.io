/***************************************************************************
                          jbytecoderef.cpp  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "jbytecoderef.h"
#include "slicing.h"

JBytecodeRef::JBytecodeRef(JBytecode *bytecode){
    this->bytecode= bytecode;
    next= prev= this;
}

JBytecodeRef::~JBytecodeRef(){
    prev->next= next;
    next->prev= prev;    
}

JBytecode* JBytecodeRef::getBytecode(){
    return bytecode;
}


JBytecodeRef* JBytecodeRef::getPrev(){
    return prev;
}

JBytecodeRef* JBytecodeRef::getNext(){
    return next;
}

void JBytecodeRef::connect(JBytecodeRef *ref){
	next= ref;
	ref->prev= this;
}

void JBytecodeRef::append(JBytecodeRef *ref)
{
	JBytecodeRef *nextRef= next;

	nextRef->prev= ref;
	ref->next= nextRef;

	next= ref;
	ref->prev= this;
}

void JBytecodeRef::around()
{
	prev= next= this;
}

JBytecodeRef::JBytecodeRef()
{
	bytecode= NULL;
	prev= next= this;
}

int JBytecodeRef::hasNext()
{
	if (bytecode== NULL || next== this)
		return 0;
	else
		return 1;
}

