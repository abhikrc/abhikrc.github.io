#include "slicing.h"

void initRLESe4Search(RLESe *rl)
{
	Rule 	*iter, *rule;
	Symbol	*symbol;


	iter= rl->s;

	GetLastTerminal( rl->s->guard->prev, rl);
	rl->lastValue= rl->footpoint->symbol->value->offset;


	return;
}
Footpoint* mallocFootpoint(Symbol *symbol)
{
	Footpoint	*newFootpoint;

	newFootpoint= (Footpoint *)cleanMalloc(sizeof(Footpoint));

	newFootpoint->symbol= symbol;
	newFootpoint->count= 0;
	newFootpoint->prev= NULL;

	return newFootpoint;
}

Footpoint* GetLastTerminal(Symbol *symbol, RLESe *rl)
{
	Footpoint *newFootpoint, *lastFootpoint;

	lastFootpoint= rl->footpoint= mallocFootpoint(symbol);

	while( NON_TERMINAL_SYMBOL == symbol->type)
	{
		symbol= symbol->value->rule->guard->prev;

		newFootpoint= mallocFootpoint(symbol);
		newFootpoint->prev= rl->footpoint;
		rl->footpoint= newFootpoint;
	}
	return (lastFootpoint);
}

int MoveFootpoint(RLESe *rl)
{
	Footpoint *oldFootpoint, *footpoint;
	Symbol *symbol;

	while(1)
	{
		oldFootpoint= rl->footpoint;
		oldFootpoint->count++;
		symbol= oldFootpoint->symbol;

		if (oldFootpoint->count < symbol->count)
		{
			if (symbol->type== NON_TERMINAL_SYMBOL)
			{
				footpoint= GetLastTerminal(symbol->value->rule->guard->prev, rl);
				footpoint->prev= oldFootpoint;
			}

			return 1;
		}

		if (symbol->prev->type != GUARD_SYMBOL)
		{
			footpoint= GetLastTerminal(symbol->prev, rl);
			footpoint->prev= oldFootpoint->prev;

			free(oldFootpoint);
			return 1;
		}

		rl->footpoint= oldFootpoint->prev;
		free(oldFootpoint);

		if ( !rl->footpoint)
			return 0;
	}

	return 1;
}

int hasMoreValue(RLESe *rl)
{

}

int GetLastValue(RLESe *rl)
{
	int value;

	value= rl->lastValue;


	MoveFootpoint(rl);

	if ( rl->footpoint != NULL)
	{
		rl->lastValue= rl->lastValue- rl->footpoint->symbol->value->offset;

	}
	else
	{
		rl->lastValue= 0;
	}

	return (value);
}

int GetLastValueNoMove(RLESe *rl)
{
	int value;

	value= rl->lastValue;

	return (value);
}



void OutputRLESe (RLESe *rl)
{
	Rule	*s;
	Symbol 	*sym;
	Footpoint *footpoint;
	footpoint= rl->footpoint;
	while(footpoint != NULL)
	{
		if (footpoint->symbol->next->type != GUARD_SYMBOL)
		{
			printf("footpoint error\n");
		}
		footpoint= footpoint->prev;
	}
}

