#include "slicing.h"
#include "readtrace.h"
#include "callframe.h"
#include "jmethod.h"
#include "jclass.h"
#include "jbytecode.h"
#include "bytecodelist.h"
#include "jloadlocal.h"
#include "jloadstatic.h"
#include "jloadarray.h"
#include "jloadfield.h"
#include "jdefinelocal.h"
#include "jdefinestatic.h"
#include "jdefinearray.h"
#include "jdefinefield.h"
#include "jcommon.h"
#include "jbranch.h"
#include "cnamelist.h"
#include "signature.h"
#include "jinvokenonstatic.h"
#include "jinvokestatic.h"
#include "linetable.h"
#include "jbytecoderef.h"
#include "criterions.h"
#include "staticinitcalltrace.h"
#include "index2intlist.h"
#include "jnew.h"
#include "jnewarray.h"
#include "jnewmultiarray.h"
#include <time.h>
#include "exceptionHandle.h"
#include "access.h"
void pushCallFrame(JMethod*, int, int, int);
int checkCriterions(JBytecodeRef*);
void cloneTracingCallFrame();
CallFrame* popCallFrame(int, int);
int isArrayNewArray(JMethod*);
int isMethodInvoke0(JMethod*);
int isFieldSet0(JMethod*);
int isFieldGet0(JMethod*);
int isSystemExit(JMethod*);
int processFieldReflection(JMethod* invokedMethod, JBytecode *jBytecode, int *isSlice);
int processNativeMethodCall(native_called_method*, JMethod*, int, int);
const char *mainClass=NULL;

struct _methods;void pushOperStackForException(catch_handler *, catch_instance *);
JMethod* searchJMethod(struct _methods *);

const unsigned short int instUseOper[256] = {    
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2,
	2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2,
    2, 2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 3,
    4, 3, 4, 3, 3, 3, 3, 1, 2, 100, 100, 100, 100, 100, 100, 100,
    2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4,
    2, 4, 2, 4, 1, 2, 1, 2,  2, 3, 2, 3, 2, 3, 2, 4,
    2, 4, 2, 4, 0, 1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2,
    2, 1, 1, 1, 4, 2, 2, 4, 4, 1, 1, 1, 1, 1, 1, 2,
    2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 1, 1, 1, 2, 1, 2,
    1, 0, 100, 100, 100, 100, 100, 100, 100, 100, 100, 0, 1, 1, 1, 1, 
    1, 1, 1, 1, 0, 100, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

// instDefOper for instruction like Dup is not correct here, since we handle them specially
// also getstatic...., whose instDefOper shows as 100
// should now handl athrow
const unsigned short int instDefOper[256] = {
    0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2, 2,
    1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 2,
    2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 
    1, 2, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 100, 100, 100, 100, 100,
    1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 
    1, 2, 1, 2, 1, 2, 1, 2,  1, 2, 1, 2, 1, 2, 1, 2,
    1, 2, 1, 2, 0, 2, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 
    1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 100, 100, 100, 100, 100, 100, 100, 100, 100, 1, 1, 1, 1, 1, 
    1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

CallFrame *oldCall=NULL;
StaticInitCallTrace *staticInitCallTrace= NULL;

#define new_propagateSlice()                                                              \
callStack->slice= IncludedSlice;                                                          \
callStack->basicBlockIsSlice[jBytecode->getBasicBlockId()]= IncludedSlice;


void outputSlice()
{
	int i;   
	//printf("+++++++++begin output slice+++++++++++\n");
	for (i=0; i<classCount; i++)
	{
		//if ( ! classes[i].isSystemClass)
			classes[i].dumpSlice(stdout);
	}  
	//printf("---------end output slice------------\n");
}

void outputSliceDifference()
{
	int i;   
	//printf("+++++++++begin output slice+++++++++++\n");
	for (i=0; i<classCount; i++)
	{
		//if ( ! classes[i].isSystemClass)
			classes[i].dumpSliceDifference(stdout);
	}  
	//printf("---------end output slice------------\n");
}

/***************  for compressed trace*************/
void initSlice()
{
	/****** read trace to fill the trace entry *********/
	time_t begin, end;

	begin= time(NULL);
	compressedTrace->fillTrace();
	end= time(NULL);

#ifdef _collect_Info
	printf("read trace:");
	printTimer(begin, end);
#endif

	sliceCriterions= new Criterions();
	instanceFields= new Index2IntList();
	staticFields= new Index2IntList();
	arrayElements= new Index2IntList();

	arrayCounts= new Index2IntList();
	staticInitCallTrace= new StaticInitCallTrace();
}

void getSlice()
{
	time_t  time1, time2;

	time1= time(NULL);

    JMethod *jmeth=NULL;
	int executedInstCount= compressedTrace->getExecutedInstCount();

    call_frame* tracedCallStack= getTracingCallStack();

	int inException = 0; //1 - the next bytecode should not operate oper stack as it threw the exception

    if (tracedCallStack != NULL)
    {
    	//program not exit at main, build all unpoped call stack
        cloneTracingCallFrame();
    }
    else
    {
    	//program exit at main, build initial "main" call stack
        jmeth= getMainMethod();
	    int prevPC= GetLastValue(jmeth->callInfo);
    	pushCallFrame(jmeth, prevPC, 0, executedInstCount);
    }
	//main part of slicing algo
	while(callStack || staticInitCallTrace->hasMore())
	{     
		JMethod *staticInit;

		if (!callStack)
		{
			//static init before entering main
			staticInit= staticInitCallTrace->getNext();
			pushCallFrame(staticInit, GetLastValue(staticInit->callInfo), 0, executedInstCount);
			continue;
		}
 
 		//currentPC - current analyzing byte code "pc 9"
		//nextPC - previous (next) byte code "pc 8"
		int currentPC= callStack->nextPC;
		callStack->currentPC= currentPC;

		int slice=NotIncludedSlice;
		JBytecode *currentBytecode;
		JBytecodeRef *currentBytecodeRef;
		currentBytecodeRef= callStack->meth->getBytecodeRefAt(currentPC);

#ifdef _slicing_debug
    	printf("=====process %d, %d, %s, %d, %d, %d, %d, %d==\n", executedInstCount, currentPC, bytecodeName[currentBytecodeRef->getBytecode()->getOperation()], callStack->getOperStackTop(), instUseOper[currentBytecodeRef->getBytecode()->getOperation()], 
instDefOper[currentBytecodeRef->getBytecode()->getOperation()], currentBytecodeRef->getBytecode()->lineNum, currentBytecodeRef->getBytecode()->slice);
        outputSliceDifference();
#endif
		int isCriterion= checkCriterions(currentBytecodeRef);

		currentBytecode= currentBytecodeRef->getBytecode();

		currentBytecode->executed= 1;
		
		JBytecodeRef *ite=NULL;
		JMethod *meth= callStack->meth;

		//isSystemClass -> begin with java or kaffe
		if ( ! meth->getParentClass()->isSystemClass)
			executedBytecodeInstanceCount++;


		executedInstCount--;


#ifdef _export_debug
		fprintf(flowTrace, "%d:%d,%s\n", executedInstCount, currentPC, bytecodeName[currentBytecode->getOperation()]);
#endif

		//identify whether current bytecode is in slice according to control and data
		switch (currentBytecode->type)
		{
			case CommonBytecode:
			{
				//if ( WIDE == currentBytecode->getOperation())
				//{
					//executedInstCount++;
				//}                

				JCommon *jBytecode= (JCommon*)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                switch(operation)
                {
                    case  DUP:
                    {
                    	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
                    		callStack->updateOperStack(1, isSlice);
                    		inException = 0;
                    	}
                    	else
						{
                        	isSlice= callStack->popOperStack(2) || isCriterion;
                        	callStack->pushOperStack(1, isSlice);
                        }
                    }
    	   			break;

        			case  DUP_X1:
                    {
                    	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
                    		callStack->updateOperStack(2, isSlice);
							inException = 0;
                    	}
                    	else
						{
                       		int isSlice1= callStack->popOperStack(1);
                        	int isSlice2= callStack->popOperStack(1);
                        	isSlice1= callStack->popOperStack(1) || isSlice1;
                        	callStack->pushOperStack(1, isSlice1);
                        	callStack->pushOperStack(1, isSlice2);
                        	isSlice= isSlice1 || isSlice2 || isCriterion;
                        }
                    }
    				break;

	           		case  DUP_X2:
                    {
                    	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
                    		callStack->updateOperStack(3, isSlice);
							inException = 0;
                    	}
                    	else
						{
                        	int isSlice1= callStack->popOperStack(1);
                        	int isSlice3= callStack->popOperStack(1);
                        	int isSlice2= callStack->popOperStack(1);
                        	isSlice1= callStack->popOperStack(1) || isSlice1;
                        	callStack->pushOperStack(1, isSlice1);
                        	callStack->pushOperStack(1, isSlice2);
                        	callStack->pushOperStack(1, isSlice3);
                        	isSlice= isSlice1 || isSlice2 || isSlice3 || isCriterion;
                        }
                    }							
    				break;

        			case  DUP2:
                    {
                    	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
                    		callStack->updateOperStack(2, isSlice);
							inException = 0;
                    	}
                    	else
						{
                        	int isSlice2= callStack->popOperStack(1);
                        	int isSlice1= callStack->popOperStack(1);
                        	isSlice2= callStack->popOperStack(1) || isSlice2;
                        	isSlice1= callStack->popOperStack(1) || isSlice1;
                        	callStack->pushOperStack(1, isSlice1);
                        	callStack->pushOperStack(1, isSlice2);
                        	isSlice= isSlice1 || isSlice2 || isCriterion;
                        }
                    }						
    				break;

			         case  DUP2_X1:
                     {
                     	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
							callStack->updateOperStack(3, isSlice);
							inException = 0;
                    	}
                    	else
						{
                        	int isSlice2= callStack->popOperStack(1);
                        	int isSlice1= callStack->popOperStack(1);
                        	int isSlice3= callStack->popOperStack(1);
                        	isSlice2= callStack->popOperStack(1) || isSlice2;
                        	isSlice1= callStack->popOperStack(1) || isSlice1;
                        	callStack->pushOperStack(1, isSlice1);
                        	callStack->pushOperStack(1, isSlice2);
                        	callStack->pushOperStack(1, isSlice3);
                        	isSlice= isSlice1 || isSlice2 || isSlice3 || isCriterion;
                        }
                    }
    				break;

        			case  DUP2_X2:
                    {
                    	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
                    		callStack->updateOperStack(4, isSlice);
							inException = 0;
                    	}
                    	else
						{
                        	int isSlice2= callStack->popOperStack(1);
                        	int isSlice1= callStack->popOperStack(1);
                        	int isSlice4= callStack->popOperStack(1);
                        	int isSlice3= callStack->popOperStack(1);
                        	isSlice2= callStack->popOperStack(1) || isSlice2;
                        	isSlice1= callStack->popOperStack(1) || isSlice1;
                        	callStack->pushOperStack(1, isSlice1);
                        	callStack->pushOperStack(1, isSlice2);
                        	callStack->pushOperStack(1, isSlice3);
                        	callStack->pushOperStack(1, isSlice4);
                        	isSlice= isSlice1 ||isSlice2 || isSlice3 ||isSlice4 || isCriterion;
                        }
                    }
    				break;
                    case  SWAP:
                    {
                    	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
                    		callStack->updateOperStack(2, isSlice);
							inException = 0;
                    	}
                    	else
						{
                        	int isSlice1= callStack->popOperStack(1);
                        	int isSlice2= callStack->popOperStack(1);                        
                        	callStack->pushOperStack(1, isSlice1);
                        	callStack->pushOperStack(1, isSlice2);
                       		isSlice= isSlice1 || isSlice2 || isCriterion;
                        }
                    }
                    break;

                    case  IRETURN:
        			case  FRETURN:
		          	case  ARETURN:
		      		case  LRETURN:
        			case  DRETURN:
                    {
                        if (callStack->slice== IncludedSlice)
                            isSlice=1;
                        else
                            isSlice=isCriterion;
                        
                        if(inException)
                    	{
							inException = 0;
							callStack->updateOperStack(instUseOper[ operation ], isSlice);
                    	}
                    	else
						{
                        	callStack->pushOperStack( instUseOper[ operation ], isSlice);
                        }
                    }
				    break;  

                    default:
                    {
                    	if(inException)
                    	{
                    		isSlice= isCriterion || callStack->slice;
                    		callStack->updateOperStack( instUseOper[ operation ], isSlice);
							inException = 0;
                    	}
                    	else
						{
                       		isSlice=callStack->popOperStack(instDefOper[operation]) || isCriterion;
                       		callStack->pushOperStack(instUseOper[ operation ], isSlice);
                       	}
                    }
                    break;
                }
                if (isSlice)
                {
                    jBytecode->slice= IncludedSlice;
                    new_propagateSlice();
                }
				break;//goto Loop;
			}

			case NewObj:
			{
				JNew *jBytecode= (JNew *)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
					inException = 0;
                }
                else
				{
                	isSlice= callStack->popOperStack(instDefOper[ operation ]) || isCriterion;
				}           

				int addr= GetLastValue(&(jBytecode->dOper[0]));//addr of object
				ArrayList<int> *fields= jBytecode->getFields();
				int fieldCount= fields->size();
				int i;

				for (i=0; i<fieldCount; i++)
				{
					int field= fields->getAt(i);
					//check whether current field in unexplained object filed variables
					int count= instanceFields->remove(addr, field);
					if (count)
					{						
						isSlice =1;						
					}
				}
				if (isSlice)
				{
					jBytecode->slice= IncludedSlice;
                    new_propagateSlice();
				}
				break;//goto Loop;
			}
			
			case NewArray:
			{
				JNewArray *jBytecode= (JNewArray *)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
					isSlice= callStack->popOperStack(instDefOper[ operation ]) || isCriterion;
				}

				int addr= GetLastValue(&(jBytecode->dOper[0]));

				if (arrayCounts->remove(addr, 0))
                    isSlice=1;
				
				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(instUseOper[ operation ], isSlice);
                }
                else
				{
                	callStack->pushOperStack(instUseOper[ operation ], isSlice);
                }
				if (isSlice)
				{					
					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}
				break;//goto Loop;
			}
		
			case NewMultiArray:
			{
				JNewMultiArray *jBytecode= (JNewMultiArray *)(currentBytecode);

                int operation= jBytecode->getOperation();
                int isSlice;
                
				if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
					isSlice= callStack->popOperStack(instDefOper[ operation ]) || isCriterion;
				}

                int dimension= jBytecode->getDimension();

				int objNum=0;
				int i;
                int lastDimension=dimension;
				for (i=dimension-1; i>0; i--)
				{
                    int last= GetLastValue(&(jBytecode->dOper[0]));
               
					objNum= (objNum+1)*last;
                    if (last ==0)
                        lastDimension=i;
				}
				objNum++;

                if (lastDimension<=0)
                    printf("error, NewMultiArray should malloc something\n");

				for (i=0; i<objNum; i++)
				{
					int addr= GetLastValue(&(jBytecode->dOper[0]));
                    if (arrayCounts->remove(addr, 0))
                    {
                        isSlice=1;
                    }
				}
								if(inException)
                {
					inException = 0;
					callStack->updateOperStack(dimension, isSlice);
                }
                else
				{
					callStack->pushOperStack(dimension, isSlice);
				}
				
				if (isSlice)
				{					
					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}

				break;//goto Loop;
			}
		
			case DefineArrayBytecode:
			{
				JDefineArray *jBytecode= (JDefineArray*)(currentBytecode);	

                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= callStack->popOperStack(instDefOper[ operation ]);
                }
            	//the following assert may not be correct in exception, but not change for now
                assert(isSlice==0 && instDefOper[ operation ]==0);
    			isSlice= isCriterion;

				int baseObj=GetLastValue(&(jBytecode->dOper[0]));	
				int index=GetLastValue(&(jBytecode->dOper[1]));	
                int count;			

				if ( count= arrayElements->remove(baseObj, index) || isSlice)
				{                    
                    isSlice=1;
					//arrayCounts->removeCount(baseObj, 0, count);
                    arrayCounts->insertObj(baseObj, 0);

					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}

				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(instUseOper[ operation ], isSlice);
                }
                else
				{
                	callStack->pushOperStack(instUseOper[ operation ], isSlice);
                }
				break;//goto Loop;
			}

			case DefineFieldBytecode:
			// JDefineField
			{
				JDefineField *jBytecode= (JDefineField*)(currentBytecode);
                int operation= jBytecode->getOperation();
                
                int isSlice;
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= isCriterion;
                }

				int baseObj=GetLastValue(&(jBytecode->dOper[0]));				

				if ( instanceFields->remove(baseObj, jBytecode->getField()) || isSlice)
				{
                    isSlice=1;					
					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}
				
				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(jBytecode->fieldSize+1, isSlice);
                }
                else
				{
                	callStack->pushOperStack(jBytecode->fieldSize+1, isSlice);
                }
                
				break;//goto Loop;
			}
		
			case DefineLocalBytecode:
			{
				JDefineLocal *jBytecode= (JDefineLocal*)(currentBytecode);
                
                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= callStack->popOperStack(instDefOper[ operation ]);
                }
            	//the following assert may not be correct with exception, but leave it for now
                assert(isSlice==0 && instDefOper[ operation ]==0);
    			isSlice= isCriterion;

				AccessLocal *accessLocal= dynamic_cast<AccessLocal*>(currentBytecode);
				if ( callStack->hasUseLocal(accessLocal->getOperand()) || isSlice)
				{
					if (jBytecode->getOperation() == IINC)
						callStack->useLocal(accessLocal->getOperand());
                    isSlice=1;
					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}

				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(instUseOper[ operation ], isSlice);
                }
                else
				{
                	callStack->pushOperStack(instUseOper[ operation ], isSlice);
                }
				break;//goto Loop;
			}
		
			case DefineStaticBytecode:
			{
				JDefineStatic *jBytecode= (JDefineStatic*)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= isCriterion;
                }

    			if ( staticFields->remove(jBytecode->getClassNameId(), jBytecode->getOperand()) || isSlice)
				{
                    isSlice=1;
					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}
				
				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(jBytecode->fieldSize, isSlice);
                }
                else
				{
                	callStack->pushOperStack(jBytecode->fieldSize, isSlice);
                }
				break;//goto Loop;
			}
		
			case InvokeNonStaticBytecode:
			// JInvokeNonStatic
			{
                
				JInvokeNonStatic *jBytecode= (JInvokeNonStatic*)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                int isFieldStaticInSlice=0;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= callStack->popOperStack(jBytecode->getDefOperNum()) ||isCriterion;
                }
                
				int foundMeth=0;
				JMethod *invokedMethod;
				if(!inException)
				{
					//printf("invokenonstatic: not exception\n");
					LinkList<JMethod*> *invokedMethods= jBytecode->getInvokeMethod();

					if ( !invokedMethods->empty())
					{
						//printf("invokenonstatic: invoked list not empty\n");
						if ( jBytecode->getOperation() == INVOKESPECIAL )
						{
							//printf("invokenonstatic: enter invokespecial\n");
							invokedMethod= invokedMethods->getHead();
							//printf("inovkenonstatic: invoked meth: %s.%s-%s\n", invokedMethod->getParentClass()->getClassName(), invokedMethod->getMethodName(), invokedMethod->getMethodSig());
							foundMeth=1;
						}
						else 
						{
							int classNameId= GetLastValue(&(jBytecode->dOper[0]));

							for (invokedMethod= invokedMethods->getHead(); invokedMethods->hasNext(); invokedMethod= invokedMethods->getNext())
							{
								if ( strcmp(classNames->getCNameAt(invokedMethod->getParentClass()->getNameId()), classNames->getCNameAt(classNameId))==0
									&& invokedMethod->getNameId()== jBytecode->getInvokedMethodNameId()
									&& invokedMethod->getSigId()== jBytecode->getInvokedMethodSigId())
								{
									foundMeth=1;
									break;
								}
							}
						}
					}
				}

				if (foundMeth)
				{
					if(!invokedMethod->isNativeMeth())
					{
						//printf("normal non static method\n");
						pushCallFrame(invokedMethod, GetLastValue(invokedMethod->callInfo), isSlice, executedInstCount);
						continue;
					}
					else
					{
						//printf("native non static method\n");
						//printf("invokenonstatic: native %s.%s\n", invokedMethod->getParentClass()->getClassName(), invokedMethod->getMethodName());
						native_called_method_list *calledlist= jBytecode->getNextNativeCalledMethodList();
						if(calledlist == NULL)
							printf("error: expect a real or dummy native called java method list at %s:%d\n", meth->getMethodName(), jBytecode->getPC());
						
#ifdef _slicing_debug
						printf("native: called native method at: %s.%s(%s) \n", meth->getParentClass()->getClassName(), meth->getMethodName(), meth->getMethodSig());
#endif
					
						int framePushed= processNativeMethodCall(calledlist->calledMethod, invokedMethod, isSlice, executedInstCount);
						
						free(calledlist);
						if(framePushed)
						{
							continue;
						}
						else
						{
							if(isFieldGet0(invokedMethod) || isFieldSet0(invokedMethod))
							{
								isFieldStaticInSlice= processFieldReflection(invokedMethod, jBytecode, &isSlice);
							}
							goto nonstaticnoinvoke;
						}
					}
					break; //goto Loop
				}
				else
				{
nonstaticnoinvoke:	if ( isSlice)
					{					
						jBytecode->slice= IncludedSlice;						
						new_propagateSlice();
					}
					//printf("method not found\n");
					if(inException)
                	{
						inException = 0;
						callStack->updateOperStack(jBytecode->getAllArgsUseOperNum()+1, isSlice);
                	}
               		else
					{
                    	callStack->pushOperStack(jBytecode->getAllArgsUseOperNum()+1, isSlice);
                    }
                    
                    if(isFieldStaticInSlice)
                    {
                    	//since field is static and in slice
                    	//the obj ref passed to it (if any) should not be in slice
                    	callStack->updateOperStackMiddle(jBytecode->getAllArgsUseOperNum()-1, jBytecode->getAllArgsUseOperNum()-1, 0);
                    }

					break;//goto Loop;
				}		
			}
		case InvokeStaticBytecode:
			// JInvokeStatic
			{
				JInvokeStatic *jBytecode= (JInvokeStatic*)(currentBytecode);
                int operation= jBytecode->getOperation();
				int isSlice;
				
				if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
					isSlice= callStack->popOperStack(jBytecode->getDefOperNum()) ||isCriterion;
				}

				//jBytecode->dumpCallGraph();
				JMethod *invokedMeth= jBytecode->getInvokeMethod()->getHead();
				if(inException)
				{
					invokedMeth=NULL;
				}
				
				if (!invokedMeth || invokedMeth->isNativeMeth() || isSystemExit(invokedMeth))
				{
					//printf("invokestatic: enter native or no method\n");
					if(!invokedMeth || isSystemExit(invokedMeth))
					{
						//printf("invokestatic: enter no method\n");
						if ( isSlice )
						{
							jBytecode->slice= IncludedSlice;
							new_propagateSlice();
						}
					
						if(inException)
                		{
							inException = 0;
							callStack->updateOperStack(jBytecode->getAllArgsUseOperNum(), isSlice);
                		}
                		else
						{
                   		 	callStack->pushOperStack(jBytecode->getAllArgsUseOperNum(), isSlice);
                   		}
                    
						break;//goto Loop;
					}
					else//if(invokedMeth->isNativeMeth())// by GL
					{
						//printf("invokestatic: enter native %s.%s\n", invokedMeth->getParentClass()->getClassName(), invokedMeth->getMethodName());
						native_called_method_list *calledlist= jBytecode->getNextNativeCalledMethodList();
						if(calledlist == NULL)
							printf("error: expect a real or dummy native called java method list %s:%d\n", meth->getMethodName(), jBytecode->getPC());

#ifdef _slicing_debug
						printf("native: called native method at: %s.%s(%s), %d\n", meth->getParentClass()->getClassName(), meth->getMethodName(), meth->getMethodSig(), jBytecode->getPC());
#endif
						if(inException)
						{
#ifdef _slicing_debug
							printf(" error ------ exception\n");
#endif
							inException=0;
							break; //goto Loop
						}
						
						int framePushed= processNativeMethodCall(calledlist->calledMethod, invokedMeth, 0, executedInstCount);
						free(calledlist);
						if(framePushed)
						{
							continue;
						}
						else
						{
							if(isArrayNewArray(invokedMeth))
							{
								//reflection
								//Array.newArray()
								int addr= GetLastValue(&(jBytecode->dOper[0]));
								if (arrayCounts->remove(addr, 0))
								{
                    				isSlice=1;
                    			}
							}
							if ( isSlice )
							{
								jBytecode->slice= IncludedSlice;
								new_propagateSlice();
							}
					
							if(inException)
                			{
								inException = 0;
								callStack->updateOperStack(jBytecode->getAllArgsUseOperNum(), isSlice);
                			}
                			else
							{
                   		 		callStack->pushOperStack(jBytecode->getAllArgsUseOperNum(), isSlice);
                   			}
                   			break;//goto Loop
						}
						break; //goto Loop
					}
				}
				else
				{
					//printf("invokestatic: enter non native\n");
					if(inException)
                	{
						inException = 0;
						break;//goto Loop;
                	}
                	/*else if(strcmp(invokedMeth->getParentClass()->getClassName(), "java/lang/System")==0
                		&& strcmp(invokedMeth->getMethodName(), "exit")==0)
                	{
                		callStack->pushOperStack(1, isSlice);
                		printf("after push oper stack for exit\n");
                	}*/
                	else
					{
						//printf("before push static call frame:\n");
						//printf("\t %s\n", invokedMeth->getMethodName());
						pushCallFrame(invokedMeth, GetLastValue(invokedMeth->callInfo), isSlice, executedInstCount);
						continue;
					}
				}
			}
		case LoadArrayBytecode:
			// JLoadArray
			{
				JLoadArray *jBytecode= (JLoadArray*)(currentBytecode);

                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= callStack->popOperStack(instDefOper[ operation ]) || isCriterion;
                }
						
				int baseObj=GetLastValue(&(jBytecode->dOper[0]));
				int index=GetLastValue(&(jBytecode->dOper[1]));

				if (isSlice)
				{
					arrayElements->insertObj(baseObj, index);
					arrayCounts->insertObj(baseObj, 0);
					
					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}
				
				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(instUseOper[ operation ], isSlice);
                }
                else
				{
                	callStack->pushOperStack(instUseOper[ operation ], isSlice);
                }
				break;//goto Loop;
			}
		case LoadFieldBytecode:
			// load field
			{
				JLoadField *jBytecode= (JLoadField*)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= callStack->popOperStack(jBytecode->fieldSize) || isCriterion;
                }

				int baseObj=GetLastValue(&(jBytecode->dOper[0]));				

				if (isSlice)
				{
					instanceFields->insertObj(baseObj, jBytecode->getField());

					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}
				
				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(1, isSlice);
                }
                else
				{
                	callStack->pushOperStack(1, isSlice);
                }
                
				break;//goto Loop;
			}
		case LoadLocalBytecode:
			{
				JLoadLocal *jBytecode= (JLoadLocal*)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
                }
                else
				{
                	isSlice= callStack->popOperStack(instDefOper[ operation ]) || isCriterion;
                }

				AccessLocal *accessLocal= dynamic_cast<AccessLocal*>(currentBytecode);
				if ( isSlice)
				{
					callStack->useLocal(accessLocal->getOperand());

					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}
				
				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(instUseOper[ operation ], isSlice);
                }
                else
				{
                	callStack->pushOperStack(instUseOper[ operation ], isSlice);
                }
				break;//goto Loop;
			}
		case LoadStaticBytecode:
			{
				JLoadStatic *jBytecode= (JLoadStatic*)(currentBytecode);
                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= isCriterion || callStack->slice;
					inException = 0;
                }
                else
				{
					isSlice= callStack->popOperStack(jBytecode->fieldSize) || isCriterion;
				}
			
				if (isSlice)
				{
					staticFields->insertObj(jBytecode->getClassNameId(), jBytecode->getOperand());
					jBytecode->slice= IncludedSlice;
					new_propagateSlice();
				}

				break;//goto Loop;
			}
		case BranchBytecode:
			{
				JBranch *jBytecode= (JBranch*)(currentBytecode);

                int operation= jBytecode->getOperation();
                int isSlice;
                
                if(inException)
                {
                	isSlice= callStack->slice;
                }
                else
				{
                	isSlice= callStack->popOperStack(instDefOper[ operation ]);
                }
                //the following assert may not be valid in exception, but leave it for now
                //assert(isSlice==0);
                isSlice= isSlice || isCriterion;
				BasicBlock *basicBlocks= meth->basicBlocks;
				BasicBlock *currentBasicBlock=& (basicBlocks[jBytecode->getBasicBlockId()]);
				
				if (currentBasicBlock->control)
				{
					int controlCount= currentBasicBlock->control[0];
					int *control= currentBasicBlock->control;
					int i;

					for (i=0; i<controlCount; i++)
					{
						BasicBlock *nextBasicBlocks= &(basicBlocks[control[i+1]]);
                        if (callStack->basicBlockIsSlice[nextBasicBlocks->id])
						{
							isSlice=1;
                            callStack->basicBlockIsSlice[nextBasicBlocks->id]=NotIncludedSlice;
						}
					}
					if (isSlice )
					{
						jBytecode->slice= IncludedSlice;
						new_propagateSlice();
					}
				}
				
				if(inException)
                {
					inException = 0;
					callStack->updateOperStack(instUseOper[ operation ], isSlice);
                }
                else
				{
                	callStack->pushOperStack(instUseOper[ operation ], isSlice);
                }
				break;//goto Loop;
			}		
		}

//Loop:

		/* process to handle exception
		if(current bytecode is in catch_inst)//first of catch handler
		{
			change the next pc of current frame (with catch) to "invoke" in "try" (stored as lastpc in call_handler);
			store and pop the stack oper of current frame (exception) (maintain value);
			
			slicing:
			if 2)any inst in catch block in slice 3)last inst in new top call frame is criterion
				(if the poped stack oper is in slice => the first inst of catch block is in slice, thus no need to test the the stack oper)
			then
			last inst in (top) new call frame is in slice
			[for 2, need to check all inst falling in the catch block,
			whether any inst is in slice]
			
			push oper stack for current frame (with value 0)
			push call frame for poped methods (repeat)
			if(exception's type is external)
			{			
				push exception to oper stack of new current call frame (maintain value);
			}
			inform the next bytecode of new current call frame not to operate oper stack (e.g. athrow);
		} */
		

		catch_inst *catchinst=NULL;
		catchinst=getCatchInstForInstruction(meth->catchinst, currentBytecode->getPC());
		if(catchinst!=NULL)
		{
			catch_handler *handler = getNextCatchHandler(catchinst);
			callStack->nextPC = handler->lastPC;
			callStack->currentPC = handler->lastPC;
			int callFramePushed = 0;
			
			//check for xxxxxx
			//wrongCallStack = callStack;
			//wrongBytecode= (JInvokeNonStatic*)wrongCallStack->meth->getJBytecodeAt(handler->lastPC);
			
			int isExceptionInSlice= callStack->popOperStack(1);

			assert(callStack->getOperStackTop()==-1);
			
			//check whether any inst in the catch block is in slice
			//this is done through the checking of basic block
			int isCatchInSlice = 0;
			int catchPC = currentPC;
			JBytecode *currentCatch;
			JBytecodeRef *currentCatchRef;
			BasicBlock *basicBlocks= meth->basicBlocks;			
			BasicBlock *currentBasicBlock;
			currentCatchRef= callStack->meth->getBytecodeRefAt(catchPC);
			

			for(;currentCatchRef->hasNext();currentCatchRef=currentCatchRef->getNext())
			{
				currentCatch= currentBytecodeRef->getBytecode();
				if(strcmp(bytecodeName[currentCatch->getOperation()], "return")==1)
				{
					//reach end of the catch block, stop checking
					break;
				}
				currentBasicBlock=& (basicBlocks[currentCatch->getBasicBlockId()]);
				if(callStack->basicBlockIsSlice[currentBasicBlock->id])
				{
					//current basic block is in slice
					isCatchInSlice = 1;					
				}
                callStack->basicBlockIsSlice[currentBasicBlock->id] = 0;
			}			
		
			//get the first catch instance
			//and push oper stack for current frame (with catch block)
			catch_instance *instance= handler->instance;
			if(instance==NULL)
			{
				printf("error: getslice.cpp: there must be at least one catch_instance\n");
			}

			//if the exception is external, we should push 1 less items into oper stack
			//because in execution, athrow will actually pop 1 item from current oper stack
			//during slicing, we do not operate oper stack for athrow (although athrow operates actually)
			
			pushOperStackForException(handler, instance);
            
            if(instance->prev==NULL)
            {
            	//try - catch at the same method
            	callStack->nextPCExplicit=1;
            }
            
			//start from the second (if any) catch instance
			//and push the rest to call stack
			instance= instance->prev;
			while(instance != NULL)
			{
				//locate the method to be pushed
				JMethod* targetMethod=searchJMethod(instance->meth);

#ifdef _slicing_debug            
    			printf("=====process %d, %d, %s, %d, %d, %d, %d, %d==exp\n", executedInstCount, callStack->nextPC, bytecodeName[callStack->meth->getBytecodeRefAt(callStack->nextPC)->getBytecode()->getOperation()], callStack->getOperStackTop(), instUseOper[callStack->meth->getBytecodeRefAt(callStack->nextPC)->getBytecode()->getOperation()], 
instDefOper[callStack->meth->getBytecodeRefAt(callStack->nextPC)->getBytecode()->getOperation()], callStack->meth->getBytecodeRefAt(callStack->nextPC)->getBytecode()->lineNum, callStack->meth->getBytecodeRefAt(callStack->nextPC)->getBytecode()->slice);
             	outputSliceDifference();               
#endif
				executedInstCount--;

				//push the method
				if(instance->prev ==NULL)
				{
					//if the top most frame, set inSlice accoringly
					pushCallFrame(targetMethod, GetLastValue(targetMethod->callInfo), isCatchInSlice, executedInstCount);
				}
				else
				{
					//if not the top frame, set inSlice as 0
					pushCallFrame(targetMethod, GetLastValue(targetMethod->callInfo), 0, executedInstCount);
				}
				callStack->currentPC = callStack->nextPC;
				//push oper stack for newly pushed call frame
				pushOperStackForException(handler, instance);
            
				callFramePushed = 1;
				
				instance= instance->prev;
			}
			
			//push exception into oper stack according to exception type
			if(handler->type==External)
			{
				callStack->pushOperStack(1, isExceptionInSlice);
			}

			inException = 1;

			if(callFramePushed)
				continue;
		}
		
		JMethod *currentMeth= callStack->meth;
		
		staticInit = staticInitCallTrace->encounter(
			classNames->getCNameAt(currentMeth->getParentClass()->getNameId()),
			methodNames->getCNameAt(currentMeth->getNameId()),
			sigs->getCNameAt(currentMeth->getSigId()),
			currentPC, executedInstCount);

		if (staticInit)
		{
			pushCallFrame(staticInit, GetLastValue(staticInit->callInfo), 0, executedInstCount);
			continue;
		}
		
    	while (true)
		{
			currentPC= callStack->currentPC;
			currentBytecode= callStack->meth->getJBytecodeAt(currentPC);
			//printf("current pc: %d\n", currentPC);
			if ( 0 != currentPC)
			{
				
				if(callStack->nextPCExplicit)
				{
					callStack->nextPCExplicit= 0;
					break;
				}
				//change to the next (previous) pc
				if (currentBytecode->prev)
				{
					callStack->nextPC= GetLastValue(currentBytecode->prev);
				}
				else
				{
					callStack->nextPC= currentBytecode->prevBytecode->getPC();
				}

				break;
			}
			else
			{

				//at the beginning of a method, process to previous method
				if ( currentBytecode->prev )
				{
					int nextPC= GetLastValue(currentBytecode->prev);
					if (nextPC >= 0)
					{
						callStack->nextPC= nextPC;
						break;
					}
				}

//				JMethod *prevMethod;
				/*if (callStack->meth->isStaticInit() && callStack-> invokedByNonStaticInitNative)
				{
					printf("warning: effective\n");
				}*/
				//printf("check for static init %s\n", callStack->meth->getMethodName());
				if (callStack->meth->isStaticInit())// && !callStack-> invokedByNonStaticInitNative)
				{
					//printf("    ---- yes\n");
					//callStack->invokedByNonStaticInitNative= 0;
					free(popCallFrame(1, executedInstCount));

					if ( !callStack )
					{
						break;
					}
					
					//check if we should execute another static init immediately
					//for case: B extends A
					//B.<clinit> then A.<clinit>
					
					JMethod *currentMeth = callStack->meth;										staticInit = staticInitCallTrace->encounter(
						classNames->getCNameAt(currentMeth->getParentClass()->getNameId()),
						methodNames->getCNameAt(currentMeth->getNameId()),
						sigs->getCNameAt(currentMeth->getSigId()),
						callStack->currentPC, executedInstCount);

					if (staticInit)
					{
						//printf("static init after another!\n");
						pushCallFrame(staticInit, GetLastValue(staticInit->callInfo), 0, executedInstCount);
						break;
					}
					
					continue;
				}
				else
				{
					//printf("    ---- no\n");
					//callStack->invokedByNonStaticInitNative= 0;
					
					CallFrame *oldCall= popCallFrame(0, executedInstCount);
					
					if (!callStack)
						break;

					if(callStack->invokeList !=NULL)
					{
						//process previous java method called in native method
						int framePushed= processNativeMethodCall(callStack->invokeList, NULL, 0, executedInstCount);
						if(framePushed)
							break;
					}					
					currentPC= callStack->currentPC;

					JBytecode *jBytecode= callStack->meth->getJBytecodeAt(currentPC);
					
					JInvokeStatic *jInvokeStatic;
					JInvokeNonStatic *jInvokeNonStatic;

					
					if ( jBytecode->getOperation() == INVOKESTATIC)
						jInvokeStatic = (JInvokeStatic*)(jBytecode);
					else
						jInvokeNonStatic= (JInvokeNonStatic*)(jBytecode);

                    int oldCallSlice=0;
                    meth= callStack->meth;
                    Signature *sig= oldCall->meth->getSig();
                    int i;

                    if (oldCall->slice)
                    {
                        oldCallSlice=1;
                        jBytecode->slice= IncludedSlice;
                        new_propagateSlice();
                    }

                    if ( jBytecode->getOperation() != INVOKESTATIC)
                    {
                        callStack->pushOperStack(1, oldCallSlice);//push base object
                    	
						//process invoke0
                    	if(strcmp(callStack->meth->getParentClass()->getClassName(), "java/lang/reflect/Method")==0
                    		&& jInvokeNonStatic->getInvokedMethodNameId()==methodNames->getNameId("invoke0")
							&& jInvokeNonStatic->getInvokedMethodSigId()==sigs->getNameId("(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;"))
						{
							//push the real base object of invoked java method
							callStack->pushOperStack(1, oldCallSlice);
							//process the array of args
							int arrayObj=GetLastValue(jInvokeNonStatic->specialValue);
							int isArrayInSlice= 0;
							//printf("invoke0: propogating parameter slice info: %s nargs %d, arrayObj: %d\n", oldCall->meth->getMethodName(), oldCall->meth->getSig()->getNargs(), arrayObj);
							for(i=0;i<oldCall->meth->getSig()->getNargs(); i++)
							{
								if(oldCallSlice && oldCall->locals[oldCall->meth->getnArgsLocalPos(i)])
								{
									isArrayInSlice= 1;
									//printf("invoke0: %d-th para is in slice\n", i);
									arrayElements->insertObj(arrayObj, i);
									arrayCounts->insertObj(arrayObj, 0);
								}
							}
							//push the array of args used in invoke
							callStack->pushOperStack(1, isArrayInSlice);
						}
                    	else
                    	{
							for(i=0; i<=jInvokeNonStatic->getArgsCount()-1; i++)
                       		{
                            	callStack->pushOperStack(jInvokeNonStatic->getnUseOperNum(i), 
                                	oldCallSlice && oldCall->locals[ jInvokeNonStatic->getnArgsLocalPos(i) ]);
                        	}
                        }
                    }
                    else
                    {
                        for(i=0; i<=jInvokeStatic->getArgsCount()-1; i++)
                        {
                            callStack->pushOperStack(jInvokeStatic->getnUseOperNum(i), 
                                    oldCallSlice && oldCall->locals[jInvokeStatic->getnArgsLocalPos(i)]);
                        }
                    }                    

					delete oldCall;                    

					JMethod *currentMeth= callStack->meth;
					//printf("before check static init\n");
					staticInit = staticInitCallTrace->encounter(
						classNames->getCNameAt(currentMeth->getParentClass()->getNameId()),
						methodNames->getCNameAt(currentMeth->getNameId()),
						sigs->getCNameAt(currentMeth->getSigId()),
						currentPC, executedInstCount);

					if (staticInit)
					{
						//printf("static init!\n");
						pushCallFrame(staticInit, GetLastValue(staticInit->callInfo), 0, executedInstCount);
						break;
					}
					if ( !callStack)
						break;
					continue;
				}
			}
		}
	}

	printf("finishing: %d\n", executedInstCount);
}

int isArrayNewArray(JMethod* meth)
{
	if(	strcmp(meth->getMethodName(), "newArray")==0
		&& strcmp(meth->getParentClass()->getClassName(), "java/lang/reflect/Array")==0
		&& strcmp(sigs->getCNameAt(meth->getSigId()), "(Ljava/lang/Class;I)Ljava/lang/Object;")==0)
	{
		return 1;
	}
	return 0;
}

int isSystemExit(JMethod* meth)
{
	if(strcmp(meth->getParentClass()->getClassName(), "java/lang/System")==0
		&& strcmp(meth->getMethodName(), "exit")==0)
	{
		return 1;
	}
	return 0;
}

int isMethodInvoke0(JMethod* meth)
{
	if(meth == NULL)
		return 0;

	//printf("invoke0: %s.%s:%s\n", meth->getParentClass()->getClassName(), meth->getMethodName(), sigs->getCNameAt(meth->getSigId()));
	if ( strcmp(meth->getParentClass()->getClassName(), "java/lang/reflect/Method")==0
		&& strcmp(meth->getMethodName(), "invoke0")==0
		&& strcmp(sigs->getCNameAt(meth->getSigId()), "(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;")==0)
	{
		return 1;
	}
	return 0;
}

int isFieldGet0(JMethod *meth)
{
	const char *methName=meth->getMethodName();
	if ( strcmp(meth->getParentClass()->getClassName(), "java/lang/reflect/Field")==0
		&& strncmp(methName, "get", 3)==0
		&& methName[strlen(methName)-1]=='0')
	{
		//printf("field: get0: %s.%s:%s\n", meth->getParentClass()->getClassName(), meth->getMethodName(), sigs->getCNameAt(meth->getSigId()));
		return 1;
	}
	return 0;
}

int isFieldSet0(JMethod *meth)
{
	const char *methName=meth->getMethodName();
	//printf("set0: %s.%s:%s\n", meth->getParentClass()->getClassName(), meth->getMethodName(), sigs->getCNameAt(meth->getSigId()));
	if ( strcmp(meth->getParentClass()->getClassName(), "java/lang/reflect/Field")==0
		&& strncmp(methName, "set", 3)==0
		&& methName[strlen(methName)-1]=='0')
	{
		//printf("field: set0: %s.%s:%s\n", meth->getParentClass()->getClassName(), meth->getMethodName(), sigs->getCNameAt(meth->getSigId()));
		return 1;
	}
	return 0;
}

int processFieldReflection(JMethod* invokedMethod, JBytecode *jBytecode, int *isSlice)
{
	//invokedMethod - the native method invoked -> setXXX0 / getXXX0
	//jBytecode - the bytecode calling the native method
	int isFieldStaticInSlice=0;
	if(isFieldGet0(invokedMethod) || isFieldSet0(invokedMethod))
	{
		//special case for Field.getXXX0()
		int baseClassId=GetLastValue(&(jBytecode->dOper[1]));
		int fldNameId=GetLastValue(&(jBytecode->dOper[2]));
		int isStatic=GetLastValue(&(jBytecode->dOper[3]));
		int baseObjId=GetLastValue(&(jBytecode->dOper[4]));
		const char* fldName=getFieldName(fldNameId);
		const char* baseClassName=getClassNameFromTraceAt(baseClassId);
		//printf("field: get0/set0: read %s.%s %d\n", baseClassName, fldName, isStatic);
		if(isStatic)
		{
			int staticFldClassNameId= classNames->update(baseClassName);
		    int staticFldOperand= staticFieldNames->update(fldName);
			//load static
        	if(*isSlice && isFieldGet0(invokedMethod))
			{
				staticFields->insertObj(staticFldClassNameId, staticFldOperand);
				isFieldStaticInSlice=1;
			}
			//put static
			else if(isFieldSet0(invokedMethod))
			{
				if ( staticFields->remove(staticFldClassNameId, staticFldOperand) || *isSlice)
				{
        		    *isSlice=1;
					isFieldStaticInSlice=1;
				}
        	}
		}
		else
		{
			//non static
			//load non static
			int fieldOperand= instanceFieldNames->update(fldName);
			if (*isSlice && isFieldGet0(invokedMethod))
			{
				instanceFields->insertObj(baseObjId, fieldOperand);
			}
			//define non static
			else if(isFieldSet0(invokedMethod))
			{
				if ( instanceFields->remove(baseObjId, fieldOperand) || *isSlice)
				{
			        *isSlice=1;
				}
			}
		}
	}
	return isFieldStaticInSlice;
}

int processNativeMethodCall(native_called_method *called, JMethod *invokedMethod, int isSlice, int executedInstCount)
{
	int framePushed= 0;
	if(called != NULL)
	{
#ifdef _slicing_debug
		printf(" ----- called java method: %s.%s(%s)\n", getClassNameFromTraceAt(called->classID), getMethodNameFromTraceAt(called->methodID), getSigNameFromTraceAt(called->sigID));
#endif
		JClass *jClass= getJClass(getClassNameFromTraceAt(called->classID));
      	int methodNameId= methodNames->getNameId(getMethodNameFromTraceAt(called->methodID));
       	int sigId= sigs->getNameId(getSigNameFromTraceAt(called->sigID));
       	JMethod *invokedJavaMethod= jClass->getMethod(methodNameId, sigId);
       	
		//When a native called several java methods
		//keep the called method list, such that when pushed call frame is poped, we can push previous call frames again.
		callStack->invokeList= called->prev;

		if(isMethodInvoke0(invokedMethod))
		{
			//for reflection
			//special case for Method.invoke0() to propogate isSlice
			pushCallFrame(invokedJavaMethod, GetLastValue(invokedJavaMethod->callInfo), isSlice, executedInstCount);
		}
		else{
       		pushCallFrame(invokedJavaMethod, GetLastValue(invokedJavaMethod->callInfo), 0, executedInstCount);//isSlice=0 since we cannot analyze across general native method;
       	}
       					
		/*if(invokedMethod != NULL && !invokedMethod->isStaticInit())
       	{
       		callStack->invokedByNonStaticInitNative= 1;
       	}
       	else if(invokedMethod != NULL)
       	{
       		printf("warning: getslice: not expected to enter here\n");
       	}*/

		free(called);
		framePushed=1;
	}
	else
	{
#ifdef _slicing_debug
		printf(" ----- no java method called\n");
#endif
	}
	return framePushed;
}

JMethod* searchJMethod(struct _methods *meth)
{
	const char *methodName= getMethodNameInKaffe(meth);
	const char *methodSig= getMethodSigInKaffe(meth);
	const char *className= getClassNameOfMethInKaffe(meth);

	JClass *targetClass= getJClass(className);
	int methodNameID= methodNames->getNameId(methodName);
	int sigID= sigs->getNameId(methodSig);

	JMethod* targetMethod= targetClass->getMethod(methodNameID, sigID);
	       						
	if(targetMethod == NULL)
	{
		printf("error: getslice.cpp: cannot find target method %s.%s(%s)\n", className, methodName, methodSig);
	}
	return targetMethod;
}

void pushOperStackForException(catch_handler* handler, catch_instance* instance)
{
	if(instance->prev == NULL)
	{
		//the instance corresponds to the toppest frame
		if(handler->type == External)
		{
			if(instance->spSize<=0)
				printf("error: getslice.cpp: external exception should have at least 1 item in oper stack at athrow\n");

			callStack->pushOperStack(instance->spSize-1, 0);
		}
		else //Internal
		{
			callStack->pushOperStack(instance->spSize, 0);
		}
	}
	else
	{
		//other intermediate frames
		int sizeToPush = instance->spSize;// - (sig->getSizeOfArgs()+1);
		int lastPC = instance->lastPC;
		JBytecode *jBytecode = searchJMethod(instance->meth)->getJBytecodeAt(lastPC);
		JInvokeStatic *jInvokeStatic;
		JInvokeNonStatic *jInvokeNonStatic;

		if ( jBytecode->getOperation() == INVOKESTATIC)
			jInvokeStatic = (JInvokeStatic*)(jBytecode);
		else
			jInvokeNonStatic= (JInvokeNonStatic*)(jBytecode);

		if ( jBytecode->getOperation() != INVOKESTATIC)
		{
			sizeToPush -= 1;
			for(int i=0; i<=jInvokeNonStatic->getArgsCount()-1; i++)
            {
            	sizeToPush -= jInvokeNonStatic->getnUseOperNum(i);
            }
		}
		else
		{
			for(int i=0; i<=jInvokeStatic->getArgsCount()-1; i++)
            {
            	sizeToPush -= jInvokeStatic->getnUseOperNum(i);
            }
		}

		callStack->pushOperStack(sizeToPush, 0);
	}
}

JMethod *getMainMethod()
{
	int i, methodCount;
	JMethod *meths;

	for (i=0; i<classCount; i++)
	{
		if ( strcmp(mainClass, classNames->getCNameAt(classes[i].getNameId())) !=0)
			continue;

		methodCount=classes[i].getMethodCount();
		meths= classes[i].getMethods();
		for (int j=0; j<methodCount; j++)
		{
			if ( meths[j].isMainMethod())
				return (&(meths[j]));
		}
	}
	return NULL;
}

void cloneTracingCallFrame()
{
    call_frame *tracedCallStack= getTracingCallStack();
    CallFrame *tempCallFrame=NULL;

    while(tracedCallStack)
    {
        int lastPC= tracedCallStack->lastPC;
        const char *className= getClassNameofTracingCallFrame(tracedCallStack);
        const char *methodName= getMethodNameofTracingCallFrame(tracedCallStack);
        const char *sig= getSigofTracingCallFrame(tracedCallStack);       

        JMethod *meth= getJMethod(className, methodName, sig);        

        tempCallFrame= new CallFrame(meth, tempCallFrame, 0);

    	tempCallFrame->currentPC= lastPC;
        tracedCallStack=tracedCallStack->prev;
    }

    CallFrame *tmp;
    while(tempCallFrame)
    {
        tmp= tempCallFrame->prev;
        tempCallFrame->prev=callStack;

        callStack= tempCallFrame;
        tempCallFrame= tmp;
    }
    callStack->nextPC=callStack->currentPC;
}

void pushCallFrame(JMethod *meth, int prevPC, int isSlice, int executedInstCount)
{
#ifdef _slicing_debug
    printf("exit method:  ");
#endif 

    CallFrame *prevCallFrame= callStack;

#ifdef _slicing_debug
    printf("%s.%s  %s %d\n",   classNames->getCNameAt(meth->getParentClass()->getNameId()),
                            methodNames->getCNameAt(meth->getNameId()), 
                            sigs->getCNameAt(meth->getSigId()), executedInstCount);
#endif

#ifdef _export_debug
	fprintf(flowTrace, "exit %s.%s %s\n",  classNames->getCNameAt(meth->getParentClass()->getNameId()),
                                           methodNames->getCNameAt(meth->getNameId()), 
                                           sigs->getCNameAt(meth->getSigId()));
#endif


#ifdef _collect_Info
        dynamicCall++;
        if (! (meth->getParentClass()->isSystemClass))
            userDynamicCall++;
#endif

	#ifdef MethodCriterion
	sliceCriterions->mcPushCallFrame(meth->getParentClass()->getNameId(), meth->getNameId());
	#endif

	callStack= new CallFrame(meth, callStack, isSlice);
	callStack->nextPC= prevPC;	
}

CallFrame* popCallFrame(int isStaticInit, int executedInstCount)
{
#ifdef _slicing_debug
    printf("enter method, %s.%s-%s %d\n", classNames->getCNameAt(callStack->meth->getParentClass()->getNameId()), 
                                      methodNames->getCNameAt(callStack->meth->getNameId()),						
                                      sigs->getCNameAt(callStack->meth->getSigId()), executedInstCount);
#endif

#ifdef _export_debug				
	fprintf(flowTrace, "enter %s.%s %s\n", classNames->getCNameAt(callStack->meth->getParentClass()->getNameId()), 
						methodNames->getCNameAt(callStack->meth->getNameId()),						
						sigs->getCNameAt(callStack->meth->getSigId()));
#endif
    if (callStack->getOperStackTop()!= -1)
    {
        printf("error, the oper stack pos should be -1, when enter a methodm, but it is %d \n", callStack->getOperStackTop());
        exit(1);
    }
    
	#ifdef MethodCriterion
	sliceCriterions->mcPopCallFrame(callStack->meth->getParentClass()->getNameId(), callStack->meth->getNameId());
	#endif
    
	CallFrame *oldCallFrame= callStack;
	callStack= callStack->getPrev();
	return oldCallFrame;
}

int checkCriterions(JBytecodeRef *currentBytecodeRef)
{
	JBytecode *jBytecode= currentBytecodeRef->getBytecode();

	int currentPC= callStack->nextPC;
    assert(jBytecode->getPC()==currentPC);

    int flag;
    
#ifdef MethodCriterion
	if(sliceCriterions->inMethodCriterion())
		return 1;
#endif

    if (foreclipse)
    {
        flag= sliceCriterions->contain(callStack->meth->getParentClass()->getFileNameId(), jBytecode);
    }
    else
    {
    	JMethod *meth= callStack->meth;
	    int classNameId= meth->getParentClass()->getNameId();
	    int methodNameId= meth->getNameId();
	    int sigNameId= meth->getSigId();
    
        flag= sliceCriterions->contain(classNameId, methodNameId, sigNameId, jBytecode);
    }

    jBytecode->hasCheckedCriterion=1;
    return flag;
}

