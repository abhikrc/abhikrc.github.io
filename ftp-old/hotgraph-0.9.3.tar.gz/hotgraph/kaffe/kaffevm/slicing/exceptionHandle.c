/*
 * exceptionHandle.c
 *
 * maintain information during exception
 * 
 *
 * Written by Liang Guo <guol@comp.nus.edu.sg> 
 */

#include "classMethod.h"
#include "exceptionHandle.h"
#include "trace.h"

exception_type exceptionType= Internal;

catch_inst* addCatchInst(struct _method_trace *meth, int inst);
catch_inst* getCatchInstForInstruction(catch_inst * catchinst, int inst);

/** maintain temp catch handler **/

//meth is the one poped during looking for catch handler
void insertTempCatchInstance(catch_handler *handler, methods *meth, int stacksize, int lastPC)
{
	catch_instance* instance= (catch_instance*)cleanMalloc(sizeof(catch_instance));
	instance->meth= meth;
	instance->spSize = stacksize;
	instance->lastPC = lastPC;
	instance->prev= handler->instance;
	handler->instance= instance;
}

//meth - the one containing catch block
//inst - the first inst of catch block
//eoid - the object id of exception generated
//lastpc - the pc of the same "meth" in corresponding try block
void endTempCatchHandler(catch_handler *handler, struct _method_trace *methodTrace, int inst, int eoid, int lastpc)
{
	catch_inst *catchinst = getCatchInstForInstruction(methodTrace->catchinst, inst);
	if(catchinst==NULL)
	{
		catchinst= addCatchInst(methodTrace, inst);
	}
	handler->prev = catchinst->handler;
	catchinst->handler= handler;
	catchinst->latest= handler; //update the marker of "latest" for slicing
	handler->eoid= eoid;
	handler->lastPC= lastpc;
	handler->type = exceptionType;
	exceptionType=Internal;
}

/** catch_inst related ***/

//add a new catch_inst in meth, for a new inst (first inst of catch block)
catch_inst* addCatchInst(struct _method_trace *methodTrace, int inst)
{
	catch_inst *catchinst;
	catchinst=(catch_inst*)cleanMalloc(sizeof(catch_inst));
	catchinst->inst= inst;
	catchinst->prev= methodTrace->catchinst;
	methodTrace->catchinst= catchinst;
	return catchinst;
}

//get the specified catch_inst of inst (first of catch block) from meth
catch_inst* getCatchInstForInstruction(catch_inst *catchinst, int inst)
{
	while(catchinst!=NULL) 
	{
		if(catchinst->inst == inst)
		{
			return catchinst;
		}
		catchinst= catchinst->prev;
	}
	return NULL;
}

/*** traverse related ***/

catch_handler* getNextCatchHandler(catch_inst* catchinst)
{
	catch_handler* handler = catchinst->latest;
	
	if(handler == NULL)
		return NULL;

	catchinst->latest = handler->prev;
	return handler;
}



/******* others *********/
void dumpCatchInst(struct _method_trace *methodTrace)
{
	catch_inst *catchinst = methodTrace->catchinst;
	if(catchinst == NULL)
		return;
	printf("***begin of catchinst***\n");
	while(catchinst !=NULL)
	{
		printf("inst: %d\n", catchinst->inst);
		catch_handler* handler = catchinst->handler;
		while(handler!=NULL)
		{
			printf("\tcatch_handler: eoid %d, lastpc %d, type %d\n", handler->eoid, handler->lastPC, handler->type);
			catch_instance *instance = handler->instance;
			if(instance == NULL)
			{
				printf("error: expect catch_handler with at least one instance\n");			
			}
			printf("\t\tmeth:");
			while(instance != NULL)
			{
				printf(" %s(%d)", instance->meth->name->data, instance->spSize);
				instance = instance->prev;
			}
			printf("\n");
			handler = handler->prev;
		}
		catchinst = catchinst->prev;
	}
	printf("***end of catchinst***\n");
}



