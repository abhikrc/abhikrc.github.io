#ifndef HOTGRAPH_H_
#define HOTGRAPH_H_
//#include "hotgraphcomp.h"
#include <set>
#include <vector>
using namespace std;

struct _method_trace;
struct _inst_trace;

typedef enum
{
	NormalNode= 0,
	SuperNode=1,
} GNodeType;

class GNode;
class GEdge;
class GRule;

class GNodeComp
{
public:
	//diff instances
	bool operator()(GNode* s1, GNode* s2);
};

class GEdgeOutgoingComp
{
public:
	bool operator()(GEdge* e1, GEdge* e2);
};

class GEdgeIncomingComp
{
public:
	bool operator()(GEdge* e1, GEdge* e2);
};

class GEdgeTotalComp
{
public:
	bool operator()(GEdge* e1, GEdge* e2);
};

class GNode
{
public:
	set<GEdge*, GEdgeOutgoingComp>* outgoing;
	set<GEdge*, GEdgeIncomingComp>* incoming;
	GNodeType nodetype;
	void *parent;//normal - inst_trace; super - grule
	GRule* containBy;
	int timestamp;
	union mtype{
		int marked;
		GNode* ruleNode;//the corresponding rule node
	} m;
	set<int>* sntimestamp;
	
	GNode(GNodeType type, void* p, int t);
	~GNode();
	bool operator==(GNode n1);
};

class GEdge
{
private:
	GNode* from;
	GNode* to;
public:
	GNode* fromLabel;
	GNode* toLabel;
	int marked;
	
	GEdge(GNode* f, GNode* t);
	GNode* getFrom();
	GNode* getTo();
};

class GRule
{
public:
	int id;
	GNode* root;
	int frequency;
	vector<GNode*>* instances;
};


extern "C" void createNode(int classid, struct _method_trace *methodTrace, int pc, int* defclsid, int* defmethid, int* defsigid, int* defpc, int defsize, int, int, int, int);
extern "C" void dumpInstHotgraph(struct _inst_trace* instTrace);
extern "C" void dumpRule();
extern "C" void initHotgraph();

extern "C" void compressRuleList();
extern "C" void countNodeEdge(void *nodelist, int *nodecount, int *edgecount);
extern "C" int countRuleSize();
extern "C" void countRuleOverhead(int *nodecount, int* edgecount);
extern "C" void createReturnEdge(struct _method_trace* fromTrace, int frompc, struct _method_trace* toTrace, int topc);
extern "C" void slicing();

#endif /*HOTGRAPH_H_*/
