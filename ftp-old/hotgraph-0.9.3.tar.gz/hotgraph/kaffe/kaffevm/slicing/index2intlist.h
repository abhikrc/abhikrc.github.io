#ifndef INDEX2INTLIST_H
#define INDEX2INTLIST_H

#include "btree.h"

class Index2IntList
{
	BTreeNode *root;
public:
	int remove(unsigned int, unsigned int);
	int removeCount(unsigned int, unsigned int, int);
	void dump();
	int size();
	void insertObj(unsigned int, unsigned int);
	Index2IntList();
	~Index2IntList();
	int ifContain(longint);
};



#endif

