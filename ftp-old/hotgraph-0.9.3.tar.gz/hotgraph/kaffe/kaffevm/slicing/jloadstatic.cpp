/***************************************************************************
                          jloadlocal.cpp  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "jloadstatic.h"
#include "jclass.h"

JLoadStatic::JLoadStatic(JMethod *meth, int operation, int pc, int operand, int accessClassNameId, int fieldSize): 
JBytecode(meth, operation, pc, LoadStaticBytecode)
{
    this->operand= operand;
	this->accessClassNameId= accessClassNameId;
	staticInit= NULL;
    this->fieldSize=fieldSize;
}

JLoadStatic::~JLoadStatic(){
}
int JLoadStatic::getOperand(){
    return operand;
}

JMethod* JLoadStatic::getStaticInit(){
    if (!staticInit)
	{
		JClass *pclass= getJClass(accessClassNameId);
		if (pclass)
			staticInit= pclass->getStaticInit();
	}
	return staticInit;
}

int JLoadStatic::getClassNameId()
{
    return accessClassNameId;
}

