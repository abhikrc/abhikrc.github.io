extern "C"
{
#include "trace.h"
}
#include "stdlib.h"
#include "hotgraph.h"
#include "buildSCD.h"
#include "criterions.h"
#include <set>
#include <vector>
#include <list>
#include <new>

using namespace std;

struct _method_trace;
struct _inst_trace;
struct _class_trace;
extern "C" void dumpHotgraph(void);

class Criterions;
class GNode;
class GEdge;

class GNodeComp;
class GEdgeOutgoingComp;
class GEdgeIncomingComp;

int tempenable=0;
int getNodeID(GNode* v);
int getNodeTimestamp(GNode* v);
void dumpEdge(GEdge* edge);
//================

bool GNodeComp::operator()(GNode* s1, GNode* s2)
{
	return s1->timestamp >= s2->timestamp;
}

bool GEdgeOutgoingComp::operator()(GEdge* e1, GEdge* e2)
{
	//sorting criterion: to's parent > to's timestamp > toLabel('s parent)
	GNode *n1= e1->getTo();
	GNode *n2= e2->getTo();
	/*if(tempenable)
	{
		printf("----\n");
		printf("e1: %d.%d->%d.%d\n", getNodeID(e1->getFrom()), getNodeTimestamp(e1->getFrom()),
				getNodeID(e1->getTo()), getNodeTimestamp(e1->getTo()));
		printf("e2: %d.%d->%d.%d\n", getNodeID(e2->getFrom()), getNodeTimestamp(e2->getFrom()),
				getNodeID(e2->getTo()), getNodeTimestamp(e2->getTo()));
	}	*/	
	if(n1->parent < n2->parent)	{
		//printf("aaa\n");
		return true;
	}
	else if(n1->parent > n2->parent) {
		//printf("bbb\n");
		return false;
	}
	else {
		//printf("ccc\n");
		//return n1->timestamp < n2->timestamp;
		if(n1->timestamp < n2->timestamp) {
			return true;
		}
		else if(n1->timestamp > n2->timestamp) {
			return false;
		}
		else {
//			if(e1->toLabel != NULL && e2->toLabel != NULL) {
//				return e1->toLabel->parent < e2->toLabel->parent;
//			}
//			else {
			if(e1->toLabel == e2->toLabel) {
				return e1->fromLabel < e2->fromLabel;
			}
			else {
				return e1->toLabel < e2->toLabel;
			}
//			}
		}
	}
}

bool GEdgeIncomingComp::operator()(GEdge* e1, GEdge* e2)
{
	GNode *n1= e1->getFrom();
	GNode *n2= e2->getFrom();
	if(tempenable)
	{
		printf("----\n");
		printf("e1: ");
		dumpEdge(e1);
		printf("\n");
		printf("e2: ");
		dumpEdge(e2);
		printf("\n");
	}
	if(n1->parent < n2->parent)	{
		if(tempenable)
			printf("aaa\n");
		return true;
	}
	else if(n1->parent > n2->parent) {
		if(tempenable)
			printf("bbb\n");
		return false;
	}
	else {
		//return n1->timestamp < n2->timestamp;
		if(n1->timestamp < n2->timestamp) {
			if(tempenable)
				printf("ccc\n");
			return true;
		}
		else if(n1->timestamp > n2->timestamp) {
			if(tempenable)
				printf("ddd\n");
			return false;
		}
		else {
//			if(e1->fromLabel != NULL && e2->fromLabel != NULL) {
//				return e1->fromLabel->parent < e2->fromLabel->parent;
//			}
//			else {
			if(tempenable) {
				if(e1->fromLabel < e2->fromLabel)
					printf("eee %p, %p\n", e1->fromLabel, e2->fromLabel);
				else
					printf("fff %p, %p\n", e1->fromLabel, e2->fromLabel);
			}
			if(e1->fromLabel == e2->fromLabel) {
				return e1->toLabel < e2->toLabel;
			}
			else {
				return e1->fromLabel < e2->fromLabel;
			}
//			}
		}
	}
}

bool GEdgeTotalComp::operator()(GEdge* e1, GEdge* e2)
{
	GNode *n1= e1->getFrom();
	GNode *n2= e2->getFrom();
	if(n1->parent < n2->parent) {
		return true;
	}
	else if(n1->parent > n2->parent) {
		return false;
	}
	else if(n1->timestamp < n2->timestamp) {
		return true;
	}
	else if(n1->timestamp > n2->timestamp){
		return false;
	}
	else if(e1->fromLabel < e2->fromLabel) {//n1->timstamp == n2->timstamp
		return true;
	}
	else if(e1->fromLabel > e2->fromLabel) {
		return false;
	}
	else {
		GNode* to1= e1->getTo();
		GNode* to2= e2->getTo();
		if(to1->parent < to2->parent) {
			return true;
		}
		else if(to1->parent > to2->parent) {
			return false;
		}
		else if(to1->timestamp < to2->timestamp) {
			return true;
		}
		else if(to1->timestamp > to2->timestamp) {
			return false;
		}
		else {
			//return to1->timestamp < to2->timestamp;
			return e1->toLabel < e2->toLabel;
		}
	}
}


GNode::GNode(GNodeType type, void* p, int t)
{
	nodetype= type;
	parent= p;
	timestamp= t;
	//marked= 0;
	m.ruleNode= NULL;
}

GNode::~GNode() {
	if(outgoing!=NULL)
		delete outgoing;
	if(incoming!=NULL)
		delete incoming;
	if(sntimestamp != NULL)
		delete sntimestamp;
}

GEdge::GEdge(GNode* f, GNode* t)
{
	from= (GNode*)f;
	to= (GNode*)t;
	fromLabel= NULL;
	toLabel= NULL;
	marked= 0;
}

GNode* GEdge::getFrom()
{
	return from;
}

GNode* GEdge::getTo()
{
	return to;
}

//================


list<GRule*> ruleList;
int gRuleCount=0;

void compressNode(GNode* latestNode);
void isIsomorphicGraph(GNode* ruleRootNode, GNode *latestNode, int similarityMax);
void intersectOutgoingEdges(GNode* otherNode, GNode* latestNode);
GRule* createRule(GEdge** commonEdges,GEdge** otherEdges, int commonEdgesCount);
void substitute(GEdge** commonEdges, int commonEdgesCount, GNode *v, GRule* rule);
void createEdge(GNode* source, GNode* target);
struct _inst_trace* getInstTrace(method_trace*, int classid, int methodid, int sigid, int pc, int* isLocal);
//const GNode* getRealDepNode(vector<GNode*>* depSet, const GNode* latestNode);
GNode* getDepNode(vector<GNode*>* depSet, GNode* latestnode);
GNode* getSuperNode(GNode* node);

/*void printTimer(time_t  begin, time_t end)
{
	time_t sec= end- begin;

    printf("used time min: %u, sec: %u, all: %u\n", sec/60, sec%60, sec);
}*/


GEdge* *commonEdgesLatest= NULL;//edges to be substitute for latest node
GEdge* *commonEdgesOther= NULL;//edges to be substitute for the partner node (if any)
GEdge* *tempCommonEdgesLatest= NULL;//temp edges for latest node
GEdge* *tempCommonEdgesOther= NULL;//temp edges for the partner node (if any)
int commonEdgesLatestCount= 0;
int commonEdgesOtherCount= 0;
int tempCommonEdgesLatestCount= 0;
int tempCommonEdgesOtherCount= 0;

GEdge* *edgeSortArray= NULL;//temp storage when re-sorting edge set
int edgeSortArrayCount= 0;

#define MAXEDGECOUNT 50

extern "C" void initHotgraph()
{
	commonEdgesLatest= (GEdge**)cleanMalloc(sizeof(GEdge*) * MAXEDGECOUNT);
	commonEdgesOther= (GEdge**)cleanMalloc(sizeof(GEdge*) * MAXEDGECOUNT);
	tempCommonEdgesLatest= (GEdge**)cleanMalloc(sizeof(GEdge*) * MAXEDGECOUNT);
	tempCommonEdgesOther= (GEdge**)cleanMalloc(sizeof(GEdge*) * MAXEDGECOUNT);
	edgeSortArray= (GEdge**)cleanMalloc(sizeof(GEdge*) * MAXEDGECOUNT);
}

//*****
//note: the count of bytecode must start from 1 (executedInstCount)
//*****
extern "C" void createNode(int classid, struct _method_trace *methodTrace, int pc,
		int* defclsid, int* defmethid, int* defsigid, int* defpc, int defsize,
		int calldepclassid, int calldepmethodid, int calldepsigid, int calldeppc)
{
	int index= ((methodTrace->hash[pc])&0x7FFFFFFF)-1;
	if(index== -1)
	{
		printf("error: no inst trace slot a\n");
		exit(1);
	}
	struct _inst_trace *instTrace= &(methodTrace->instTrace[index]);
	vector<GNode*> *instSet;
	if(instTrace->instances == NULL)
	{
		instSet= new vector<GNode*>;
		//instSet->clear();
		instTrace->instances= (void*)(instSet);
	}
	else
	{
		instSet= (vector<GNode*> *)instTrace->instances;
	}

	//create node and link to its bytecode
	GNode* latestnode= new GNode(NormalNode, (void*)instTrace, executedInstCount);
	latestnode->containBy= NULL;
	latestnode->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
	latestnode->incoming= new set<GEdge*, GEdgeIncomingComp>;
	latestnode->m.ruleNode= NULL;
	latestnode->sntimestamp= NULL;
	
	//latest node is always put in the end for efficiency
	instSet->push_back(latestnode);
	
	//build control dependence edge
	const char* className= getClassNameFromTraceAt(classid);
	const char* methodName= getMethodNameFromTraceAt(methodTrace->methodID);
	const char* sig= getSigNameFromTraceAt(methodTrace->sigID);

	//printf("create node %s.%s(%s) %d (%d)\n", className, methodName, sig, instTrace->pc, executedInstCount);
	
	int scdsize=0;
	int* scds= getStaticDependence(instTrace, className, methodName, sig, pc, &scdsize);

	int maxTimestamp=0;
	struct _inst_trace *dependentInstTrace= NULL;
	int i;
	for(i=0; i<scdsize; i++)
	{
		int current= scds[i];
		index= ((methodTrace->hash[current])&0x7FFFFFFF)-1;
		if(index== -1)
		{
			printf("error: no inst trace slot b\n");
			exit(1);
		}
		struct _inst_trace *currInstTrace= &(methodTrace->instTrace[index]);
		//printf("\tctrl: %d, %d\n", currInstTrace->pc, currInstTrace->latestTimestamp);
		if(currInstTrace->latestTimestamp > maxTimestamp)
		{
			maxTimestamp= currInstTrace->latestTimestamp;
			dependentInstTrace= currInstTrace;
		}
	}
	if(scdsize>0)
	{
		free(scds);
	}
	if(dependentInstTrace != NULL)
	{
		//we found control dependence, create edge
		vector<GNode*> *depSet= (vector<GNode*>*)dependentInstTrace->instances;
		//const GNode* dependentNode= getRealDepNode(depSet, latestnode);
		GNode* dependentNode= getDepNode(depSet, latestnode);
		//dependent edge: latest -> old
		createEdge(latestnode, dependentNode);
	}
	
	//build data dependence edge
	int foundlocal= 0;//if a local data dep is found curr->local inst
	int j;
	for(j=0; j<defsize; j++)
	{
		struct _inst_trace* depinst= 
			getInstTrace(methodTrace, defclsid[j], defmethid[j], defsigid[j], defpc[j], &foundlocal);
		vector<GNode*> *depSet= (vector<GNode*>*)depinst->instances;
		//const GNode* dependentNode= getRealDepNode(depSet, latestnode);
		GNode* dependentNode= getDepNode(depSet, latestnode);
		//dependent edge: latest->old
		createEdge(latestnode, dependentNode);
	}
	
	if(scdsize==0 && foundlocal==0)
	{
		//no dep to another inst in curr meth, create one for method invoke / exception
		if(calldepclassid != -1)
		{
			dependentInstTrace=
				getInstTrace(methodTrace, calldepclassid, calldepmethodid, calldepsigid, calldeppc, &foundlocal);
		
			if(dependentInstTrace != NULL)
			{
				//we found crossing dependence, create edge
				vector<GNode*> *depSet= (vector<GNode*>*)dependentInstTrace->instances;
				//const GNode* dependentNode= getRealDepNode(depSet, latestnode);
				GNode* dependentNode= getDepNode(depSet, latestnode);
				//dependent edge: latest -> old
				createEdge(latestnode, dependentNode);
			}
		}
	}

	
	compressNode(latestnode);
	
	/*printf("=============begin============\n");
	dumpHotgraph();
	printf("==============end=============\n");*/
}

extern "C" void createReturnEdge(struct _method_trace* fromTrace, int frompc, struct _method_trace* toTrace, int topc)
{
    /*if(fromTrace==NULL || frompc==-1)
    {
        printf("error: createReturnEdge: para from is not valid\n");
        exit(1);
    }
    if(toTrace==NULL || topc==-1)
    {
        printf("error: createReturnEdge: para to is not valid\n");
        exit(1);
    }
    int temp=0;
    struct _inst_trace* from= getInstTrace(fromTrace, fromTrace->classTrace->classID, fromTrace->methodID, fromTrace->sigID, frompc, &temp);
    struct _inst_trace* to= getInstTrace(toTrace, toTrace->classTrace->classID, toTrace->methodID, toTrace->sigID, topc, &temp);
    vector<GNode*>* fromIn= (vector<GNode*>*)from->instances;
    vector<GNode*>* toIn= (vector<GNode*>*)to->instances;
    //GNode* realFrom= (GNode*)getRealDepNode(fromIn, NULL);
    //GNode* realTo= (GNode*)getRealDepNode(toIn, NULL);
    GNode* realFrom= getDepNode(fromIn, NULL);
    GNode* realTo= getDepNode(toIn, NULL);
    createEdge(realFrom, realTo);*/
}


GNode* getDepNode(vector<GNode*>* depSet, GNode* latestnode)
{
	if(depSet == NULL || depSet->empty())
	{
		printf("error: null para getDepNode\n");
		exit(1);
	}
	
	vector<GNode*> *theset= depSet;
	vector<GNode*>::reverse_iterator ite= theset->rbegin();
	//in case it depends on a previous instance of same bc
	while(ite != theset->rend() && (*ite) == latestnode)
	{
		ite++;
	}
	if(ite == theset->rend()) {
		printf("error: getDepNode: no dep node\n");
	}
	return (GNode*)(*ite);
}

GNode* getSuperNode(GNode* node)
{
	assert(node->nodetype == NormalNode);
	if(node->containBy == NULL)
		return node;
	
	vector<GNode*>* theset= node->containBy->instances;
	vector<GNode*>::reverse_iterator ite= theset->rbegin();
	
	while(ite != theset->rend() && (*ite)->containBy !=NULL)
	{
		theset= (*ite)->containBy->instances;
		if(theset == NULL)
		{
			printf("error: rule has no instances\n");
			exit(1);
		}
		ite= theset->rbegin();
	}
	if(ite == theset->rend())
	{
		printf("error: no dependent node a\n");
		exit(1);
	}
	return (*ite);
}

/*const GNode* getRealDepNode(vector<GNode*>* depSet, const GNode* latestnode)
{
	if(depSet == NULL || depSet->empty())
	{
		printf("error: null para getRealDepNode\n");
		exit(1);
	}
	
	vector<GNode*> *theset= depSet;
	vector<GNode*>::reverse_iterator ite= theset->rbegin();
	const GNode* dependentNode= *ite;
	//in case it depends on a previous instance of same bc
	while(ite != theset->rend() && dependentNode == latestnode)
	{
		//dependentNode= dependentNode->next;
		ite++;
		dependentNode= *ite;
	}
	//get the real super node that is in DDG, if it is in rule
	if(ite != depSet->end() && dependentNode->containBy != NULL)
	{
		depSet= &(dependentNode->containBy->instances);
		ite= depSet->begin();
		dependentNode= *ite;
	}
	while(ite != theset->rend() && dependentNode->containBy !=NULL)
	{
		theset= dependentNode->containBy->instances;
		if(theset == NULL)
		{
			printf("error: rule has no instances\n");
			exit(1);
		}
		ite= theset->rbegin();
		dependentNode= *ite;
	}
	if(ite == theset->rend())
	{
		printf("error: no dependent node a\n");
		exit(1);
	}
	return dependentNode;
}*/

struct _inst_trace* getInstTrace(method_trace* methodTrace, int classid, int methodid, int sigid, int pc, int* isLocal)
{
	if(methodTrace->methodID == methodid && methodTrace->sigID == sigid 
			&& methodTrace->classTrace->classID == classid)
	{
		method_trace* meth= methodTrace;
		int index= ((meth->hash[pc])&0x7FFFFFFF)-1;
		if(index== -1)
		{
			printf("error: no inst trace slot c\n");
			exit(1);
		}
		*isLocal= (*isLocal) | 1;
		return &(meth->instTrace[index]);
	}
	struct _class_trace* trace= getTrace();
	for(; trace!=NULL; trace= trace->next)
	{
		if(trace->classID == classid)
		{
			struct _method_trace* meth= trace->methodTrace;
			for(; meth!=NULL; meth= meth->next)
			{
				if(meth->methodID == methodid && meth->sigID == sigid)
				{
					int index= ((meth->hash[pc])&0x7FFFFFFF)-1;
					if(index== -1)
					{
						printf("error: no inst trace slot c\n");
						exit(1);
					}
					return &(meth->instTrace[index]);
				}
			}
		}
	}
	return NULL;
}


void compressNode(GNode *latestNode)
{
	int debug= 0;
	if(debug)
		printf("start compress\n");
	//all instances of the same bytecode
	vector<GNode*> *allNodes= NULL;
	if(latestNode->nodetype == NormalNode)
	{
		allNodes= (vector<GNode*>*)((struct _inst_trace*)(latestNode->parent))->instances;
	}
	else
	{
		printf("error: latest node is not normal\n");
		exit(1);
	}
	vector<GNode*>::iterator itenode= allNodes->begin();
	vector<GNode*>::reverse_iterator itenodervs= allNodes->rbegin();
	if(allNodes->empty() || (*itenodervs)!=latestNode)
	{
		printf("error: latestNode is not in bytecode list or not first\n");
		exit(1);
	}
	int itecount= 0;
	int halfsize= allNodes->size() / 2 + 1;
	bool checkend= true;
	GNode *similarNode= NULL;
	int similarityMax= 0;
	int similarNodeInRule= -1;
	int count=0;
	
	//for now, we can only test the first and last node 
	itenodervs++;
	while((itenode != allNodes->end() || itenodervs != allNodes->rend())
			&& itecount <= halfsize)
	{
		
		if(itecount>2)//TO CHECK against all nodes, remove this
		{
			break;
		}
		//start from back
		GNode* commonNode= NULL;
		if(checkend)
		{
			checkend = !checkend;
			if(itenodervs == allNodes->rend())
			{
				continue;
			}
			commonNode= *itenodervs;
			itenodervs++;
		}
		else
		{
			checkend = !checkend;
			if(itenode == allNodes->end())
			{
				continue;
			}
			commonNode= *itenode;
			itenode++;
		}
		itecount++;
		

		if(commonNode != latestNode)
		{
			if(commonNode->containBy != NULL)//in rule, not in DDG
			{
				if(commonNode == commonNode->containBy->root)
				{
					count++;
					//the root
					//tempCommonEdgesLatest->clear();
					tempCommonEdgesLatestCount= 0;
					isIsomorphicGraph(commonNode, latestNode, similarityMax);
					if(tempCommonEdgesLatestCount > similarityMax)
					{
						similarityMax= tempCommonEdgesLatestCount;
						similarNode= commonNode;
						similarNodeInRule= 1;
						//store max by exchange
						GEdge* *temp= commonEdgesLatest;
						commonEdgesLatest= tempCommonEdgesLatest;
						tempCommonEdgesLatest= temp;
						int tempCount= commonEdgesLatestCount;
						commonEdgesLatestCount= tempCommonEdgesLatestCount;
						tempCommonEdgesLatestCount= tempCount;
						break;//test
					}
				}
			}
			else
			{
				//printf("ddg\n");
				//node is in DDG
				count++;
				tempCommonEdgesLatestCount= 0;
				tempCommonEdgesOtherCount= 0;
				intersectOutgoingEdges(commonNode, latestNode);
				if(tempCommonEdgesLatestCount > similarityMax)
				{
					similarityMax= tempCommonEdgesLatestCount;
					similarNode= commonNode;
					similarNodeInRule= 0;
					//store max of latest by exchange
					GEdge **temp= commonEdgesLatest;
					commonEdgesLatest= tempCommonEdgesLatest;
					tempCommonEdgesLatest= temp;
					int tempCount= commonEdgesLatestCount;
					commonEdgesLatestCount= tempCommonEdgesLatestCount;
					tempCommonEdgesLatestCount= tempCount;
					
					//store max of other by exchange
					temp= commonEdgesOther;
					commonEdgesOther= tempCommonEdgesOther;
					tempCommonEdgesOther= temp;
					tempCount= commonEdgesOtherCount;
					commonEdgesOtherCount= tempCommonEdgesOtherCount;
					tempCommonEdgesOtherCount= tempCount;
					break;//test
				}
			}
		}
	}
	
	//DO NOT remove, this is to check # of nodes accessed, to be analyzed after complete
	///printf("exp %d %d\n", count, allNodes->size());
	
	if(similarNode != NULL)
	{
		if(similarNodeInRule == 1)
		{
			GRule* currentRule= similarNode->containBy;
			if(debug)
				printf("rule %d exists, substitute latest node\n", currentRule->id);
			currentRule->frequency++;
			substitute(commonEdgesLatest, commonEdgesLatestCount, latestNode, currentRule);
		}
		else if(similarNodeInRule == 0)
		{
			GRule* currentRule= createRule(commonEdgesLatest, commonEdgesOther, commonEdgesLatestCount);
			if(debug)
				printf("create rule %d and substitute both nodes\n", currentRule->id);
			currentRule->frequency= 2;
			//fixed sequence!
			substitute(commonEdgesOther, commonEdgesOtherCount, similarNode, currentRule);
			substitute(commonEdgesLatest, commonEdgesLatestCount, latestNode, currentRule);
		}
	}
}

inline void ensureCommonEdgesSize(int count)
{
	if(count >= MAXEDGECOUNT)
	{
		printf("error: MAXEDGECOUNT exceeds\n");
		exit(1);
	}
}

void clearEdgeMark(GEdge** edgeList, int edgeCount)
{
	int i=0;
	for(; i<edgeCount; i++) {
		edgeList[i]->marked= 0;
		edgeList[i]->getTo()->m.ruleNode= NULL;
	}
}

void isIsomorphicGraph(GNode* ruleRootNode, GNode *latestNode, int similarMax)
{
	int debug= 0;

	//now: 2n
	//put common edges outgoing from latestnode in the vector
	//if there is an isomorphic graph rooted at latestNode as rule.graph rooted at ruleRootNode
	//note: no edge between two outgoing nodes is detected, for speedup
	//identified common edges are marked as 1
	//correspoinding rule node is linked to the ddg node
	if(ruleRootNode->parent != latestNode->parent) {
		printf("error: latestNode is not the same bc as root of rule\n");
		exit(1);
	}
	
	if(latestNode->outgoing == NULL)
	{
		return;
	}
	if(ruleRootNode->outgoing == NULL)
	{
		printf("error: rule root has no outgoing\n");
		exit(1);
	}
	
	if(ruleRootNode->outgoing->size() <= similarMax)
	{
		return;
	}
	
	//if root has large size of outgoing, no isomorphic graph, just return
	if(ruleRootNode->outgoing->size() > latestNode->outgoing->size()) {
		return;
	}
	
	if(debug)
		printf("check isomorphic: root %d.%d, latest %d.%d, %d\n",
				getNodeID(ruleRootNode), getNodeTimestamp(ruleRootNode),
				getNodeID(latestNode), getNodeTimestamp(latestNode),
				similarMax);
	
	//enumerate both sets once
	set<GEdge*, GEdgeOutgoingComp>::iterator rootite= ruleRootNode->outgoing->begin();
	set<GEdge*, GEdgeOutgoingComp>::iterator latestite= latestNode->outgoing->begin();
	while(rootite != ruleRootNode->outgoing->end()
			&& latestite != latestNode->outgoing->end())
	{
		if(debug)
		printf("\tchecking root %d.%d->%d.%d and latest %d.%d->%d.%d\n",
				getNodeID((*rootite)->getFrom()), getNodeTimestamp((*rootite)->getFrom()),
				getNodeID((*rootite)->getTo()), getNodeTimestamp((*rootite)->getTo()),
				getNodeID((*latestite)->getFrom()), getNodeTimestamp((*latestite)->getFrom()),
				getNodeID((*latestite)->getTo()), getNodeTimestamp((*latestite)->getTo()));
		
		if((*rootite)->getTo()->parent < (*latestite)->getTo()->parent) {
			//rootite++;
			//since every rule edge must have a correspoinding edge in latest
			//commonEdges->clear();
			if(debug)
				printf("aaa: root less than latest, return 0\n");
			clearEdgeMark(tempCommonEdgesLatest, tempCommonEdgesLatestCount);
			tempCommonEdgesLatestCount= 0;
			return;
		}
		else if((*rootite)->getTo()->parent > (*latestite)->getTo()->parent) {
			if(debug)
				printf("bbb: root greater than latest, advance latest\n");
			latestite++;
		}
		else {
			if((*rootite)->getTo()->timestamp < ruleRootNode->timestamp
					&& (*latestite)->getTo()->timestamp > latestNode->timestamp) {
				//rootite++;
				//since every rule edge must have a correspoinding edge in latest
				//commonEdges->clear();
				if(debug)
					printf("ccc: root less than latest, return 0\n");
				clearEdgeMark(tempCommonEdgesLatest, tempCommonEdgesLatestCount);
				tempCommonEdgesLatestCount= 0;
				return;
			}
			else if((*rootite)->getTo()->timestamp > ruleRootNode->timestamp
					&& (*latestite)->getTo()->timestamp < latestNode->timestamp) {
				if(debug)
					printf("ddd: root greater than latest, advance latest\n");
				latestite++;
			}
			else {
				if((*rootite)->getTo()->timestamp == ruleRootNode->timestamp
						|| (*latestite)->getTo()->timestamp == latestNode->timestamp) {
					printf("error: timestamps equal isomorphic\n");
					exit(1);
				}
				if((*rootite)->toLabel < (*latestite)->toLabel) {
					assert((*rootite)->toLabel != NULL);
					clearEdgeMark(tempCommonEdgesLatest, tempCommonEdgesLatestCount);
					tempCommonEdgesLatestCount= 0;
					return;
				}
				else if((*rootite)->toLabel > (*latestite)->toLabel) {
					assert((*latestite)->toLabel != NULL);
					latestite++;
				}
				else {
					if(debug)
						printf("eee: found common\n");
					//commonEdges->push_back(*latestite);
					ensureCommonEdgesSize(tempCommonEdgesLatestCount);
					tempCommonEdgesLatest[tempCommonEdgesLatestCount]= *latestite;
					tempCommonEdgesLatest[tempCommonEdgesLatestCount]->marked= 1;
					tempCommonEdgesLatest[tempCommonEdgesLatestCount]->getTo()->m.ruleNode= (*rootite)->getTo();
					tempCommonEdgesLatestCount++;
					latestite++;
					rootite++;
				}
			}
		}
	}
	
	//since some edge in root has no common in latest
	if(rootite != ruleRootNode->outgoing->end())
	{
		clearEdgeMark(tempCommonEdgesLatest, tempCommonEdgesLatestCount);
		tempCommonEdgesLatestCount= 0;
	}
	
	latestNode->m.ruleNode= ruleRootNode;
}


void intersectOutgoingEdges(GNode* otherNode, GNode* latestNode)
{
	//now: 2n, before: n^2
	//put common edges outgoing from latestnode in the vector
	//if there is an isomorphic graph rooted at latestNode as rule.graph rooted at ruleRootNode
	//note: no edge between two outgoing nodes is detected, for speedup
	//identified common edges are marked as 1
	int debug= 0;
	if(otherNode->parent != latestNode->parent) {
		printf("error: v1 is not the same bc as v2\n");
		exit(1);
	}
	
	if(otherNode->outgoing == NULL || latestNode->outgoing == NULL)
	{
		return;
	}
	
	//printf("%d %d\n", v1->outgoing->size(), v2->outgoing->size());
	
	//enumerate both sets once
	set<GEdge*, GEdgeOutgoingComp>::iterator otherite= otherNode->outgoing->begin();
	set<GEdge*, GEdgeOutgoingComp>::iterator latestite= latestNode->outgoing->begin();
	
	GNode* otherfrom= NULL;
	GNode* latestfrom= NULL;
	if(otherite != otherNode->outgoing->end())
	{
		otherfrom= (*otherite)->getFrom();
	}
	if(latestite != latestNode->outgoing->end())
	{
		latestfrom= (*latestite)->getFrom();
	}
	
	if(debug)
		printf("check intersect: other %d.%d, latest %d.%d\n",
				getNodeID(otherNode), getNodeTimestamp(otherNode),
				getNodeID(latestNode), getNodeTimestamp(latestNode));
	
	while(otherite != otherNode->outgoing->end()
			&& latestite != latestNode->outgoing->end())
	{
		if(debug)
			printf("\tchecking other %d.%d->%d.%d and latest %d.%d->%d.%d\n",
					getNodeID((*otherite)->getFrom()), getNodeTimestamp((*otherite)->getFrom()),
					getNodeID((*otherite)->getTo()), getNodeTimestamp((*otherite)->getTo()),
					getNodeID((*latestite)->getFrom()), getNodeTimestamp((*latestite)->getFrom()),
					getNodeID((*latestite)->getTo()), getNodeTimestamp((*latestite)->getTo()));
				
		if((*otherite)->getFrom() != otherfrom)
		{
			printf("error: other froms are not equal\n");
			exit(1);
		}
		if((*latestite)->getFrom() != latestfrom)
		{
			printf("error: latest froms are not equal\n");
			exit(1);
		}
		if((*otherite)->getTo()->parent < (*latestite)->getTo()->parent)
		{
			if(debug)
				printf("\t\taaa: latest > other, adv other\n");
			otherite++;
		}
		else if((*otherite)->getTo()->parent > (*latestite)->getTo()->parent)
		{
			if(debug)
				printf("\t\tbbb: latest < other, adv latest\n");
			latestite++;
		}
		else
		{
			if((*otherite)->getTo()->timestamp < otherNode->timestamp
					&& (*latestite)->getTo()->timestamp > latestNode->timestamp)
			{
				if(debug)
					printf("\t\tccc: latest > other, adv other\n");
				otherite++;
			}
			else if((*otherite)->getTo()->timestamp > otherNode->timestamp
					&& (*latestite)->getTo()->timestamp < latestNode->timestamp)
			{
				if(debug)
					printf("\t\tddd: latest < other, adv latest\n");
				latestite++;
			}
			else
			{
				if((*otherite)->getTo()->timestamp == otherNode->timestamp
						|| (*latestite)->getTo()->timestamp == latestNode->timestamp)
				{
					//self edge
					printf("error: timestamps equal intersect\n");
					exit(1);
				}
				if((*otherite)->getTo() == (*latestite)->getTo())
				{
					//pointing to same node
					//skip
					otherite++;
					latestite++;
				}
				else if((*latestite)->getTo() == otherNode)
				{
					//latest point to other
					//skip
					otherite++;
					latestite++;
				}
				else if((*otherite)->getTo() == latestNode)
				{
					printf("warning: other points to latest\n");
					otherite++;
					latestite++;
				}
				else
				{
					if((*otherite)->toLabel < (*latestite)->toLabel) {
						assert((*otherite)->toLabel != NULL);
						otherite++;
					}
					else if((*otherite)->toLabel > (*latestite)->toLabel) {
						assert((*latestite)->toLabel != NULL);
						latestite++;
					}
					else {
						if(debug)
							printf("\t\teee: latest == other\n");
						//common1->push_back(*v1ite);
						//common2->push_back(*v2ite);
						ensureCommonEdgesSize(tempCommonEdgesOtherCount);
						ensureCommonEdgesSize(tempCommonEdgesLatestCount);
						tempCommonEdgesOther[tempCommonEdgesOtherCount]= *otherite;
						tempCommonEdgesLatest[tempCommonEdgesLatestCount]= *latestite;
						tempCommonEdgesOther[tempCommonEdgesOtherCount]->marked= 1;
						tempCommonEdgesLatest[tempCommonEdgesLatestCount]->marked= 1;
						tempCommonEdgesOtherCount++;
						tempCommonEdgesLatestCount++;
						otherite++;
						latestite++;
					}
				}
			}
		}
	}
	
	if(tempCommonEdgesOtherCount != tempCommonEdgesLatestCount)
	{
		printf("error: resulting vectors have diff size\n");
		exit(1);
	}
}

void safeDeleteNode(GNode* p)
{
	if(p == NULL)
	{
		printf("error: trying to delete null node\n");
		exit(1);
	}
	delete p;
}

void safeDeleteEdge(GEdge* p)
{
	if(p == NULL)
	{
		printf("error: trying to delete null edge\n");
		exit(1);
	}
	delete p;
}


int removeNodeFromInst(GNode *n)
{
	/*if(n->containBy != NULL)
	{
		printf("error: try to delete node in rule\n");
		exit(1);
	}*/
	vector<GNode*>* v= NULL;
	if(n->nodetype == NormalNode)
	{
		inst_trace* inst= (inst_trace*)n->parent;
		v= (vector<GNode*>*)inst->instances;
	}
	else
	{
		GRule* rule= (GRule*)n->parent;
		v= (vector<GNode*>*)rule->instances;
	}
	
	vector<GNode*>::iterator ite= v->begin();
	for(; ite!= v->end(); ite++)
	{
		GNode* curr= (*ite);
		if(curr == n)
			break;
	}
	if(ite == v->end())
	{
		printf("error: node is not in its parent list\n");
		exit(1);
	}
	v->erase(ite);
	safeDeleteNode(n);
	return 1;
}

void dumpEdge(GEdge* edge)
{
	if(edge->getFrom()->nodetype==NormalNode) {
		printf("%d.%d ", getNodeID(edge->getFrom()), getNodeTimestamp(edge->getFrom()));
	}
	else {
		printf("<%d.%d> ", getNodeID(edge->getFrom()), getNodeTimestamp(edge->getFrom()));
	}
	if(edge->fromLabel == NULL) {
		printf("(null) -> ");
	}
	else {
		printf("(%d.%d) -> ", getNodeID(edge->fromLabel), getNodeTimestamp(edge->fromLabel));
	}
	if(edge->getTo()->nodetype == NormalNode) {
		printf("%d.%d", getNodeID(edge->getTo()), getNodeTimestamp(edge->getTo()));
	}
	else {
		printf("<%d.%d>", getNodeID(edge->getTo()), getNodeTimestamp(edge->getTo()));
	}
	if(edge->toLabel == NULL) {
		printf("(null)");
	}
	else {
		printf("(%d.%d)", getNodeID(edge->toLabel), getNodeTimestamp(edge->toLabel));
	}
}

void createEdge(GNode* source, GNode* target)
{
	//source and target are real node of bc, not instance of rule
	//thus first we find the super node containing (if any)
	//then we create edge between super node, and set real node as label
	if(source == NULL || target == NULL)
	{
		printf("error: node is null when creating edge\n");
		exit(1);
	}
	assert(source->nodetype == NormalNode && target->nodetype==NormalNode);
	if(source == target)
	{
		//one edge in an isomorphic graph is missing in the other
		//printf("warning: same node %d(%d)\n", getNodeID(source), getNodeTimestamp(source));
		//exit(1);
		//for now do not create loop edge;
		return;
	}
	
	GNode* srcSN= source;
	GNode* tgtSN= target;
	GNode* srcReal= NULL;
	GNode* tgtReal= NULL;
	if(source->containBy != NULL) {
		srcSN= getSuperNode(source);
		srcReal= source;
	}
	if(target->containBy != NULL) {
		tgtSN= getSuperNode(target);
		tgtReal= target;
	}
	
	GEdge* edge= new GEdge(srcSN, tgtSN);
	edge->fromLabel= srcReal;
	edge->toLabel= tgtReal;
	
//	if(source->outgoing == NULL)
//		source->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
//	if(target->incoming == NULL)
//		target->incoming= new set<GEdge*, GEdgeIncomingComp>;
	
	if(srcSN->outgoing == NULL)
		srcSN->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
	if(tgtSN->incoming == NULL)
		tgtSN->incoming= new set<GEdge*, GEdgeIncomingComp>;

	//bool result1= source->outgoing->insert(edge).second;
	//bool result2= target->incoming->insert(edge).second;
	bool result1= srcSN->outgoing->insert(edge).second;
	bool result2= tgtSN->incoming->insert(edge).second;
	if(result1 != result2)
	{
		/*if(result1)
		{
			//re-sort the set if not found
			edgeSortArrayCount= 0;
			set<GEdge*, GEdgeOutgoingComp>::iterator itetemp= source->outgoing->begin();
			for(; itetemp != source->outgoing->end(); itetemp++)
			{
				ensureCommonEdgesSize(edgeSortArrayCount);
				edgeSortArray[edgeSortArrayCount]= *itetemp;
				edgeSortArrayCount++;
			}
			source->outgoing->clear();
			int i=0;
			for(; i<edgeSortArrayCount; i++)
			{
				source->outgoing->insert(edgeSortArray[i]);
			}
			edgeSortArrayCount= 0;
		}
		else
		{
			//re-sort the set if not found
			edgeSortArrayCount= 0;
			set<GEdge*, GEdgeIncomingComp>::iterator itetemp= target->incoming->begin();
			for(; itetemp != target->incoming->end(); itetemp++)
			{
				ensureCommonEdgesSize(edgeSortArrayCount);
				edgeSortArray[edgeSortArrayCount]= *itetemp;
				edgeSortArrayCount++;
			}
			target->incoming->clear();
			int i=0;
			for(; i<edgeSortArrayCount; i++)
			{
				target->incoming->insert(edgeSortArray[i]);
			}
			edgeSortArrayCount= 0;
		}
	}
	result1= source->outgoing->insert(edge).second;
	result2= target->incoming->insert(edge).second;
	if(result1 != false || result2 != false)
	{*/
		printf("error: edge ");
		dumpEdge(edge);
		printf(" in one list but not in the other list\n");
		printf("edges in src out:\n");
		set<GEdge*, GEdgeOutgoingComp>::iterator outite= srcSN->outgoing->begin();
		for(; outite != srcSN->outgoing->end(); outite++) {
			dumpEdge(*outite);
			printf("\n");
		}
		printf("edges in tgt inc\n");
		set<GEdge*, GEdgeIncomingComp>::iterator incite= tgtSN->incoming->begin();
		for(; incite != tgtSN->incoming->end(); incite++) {
			dumpEdge(*incite);
			printf("\n");
		}
		exit(1);
	}
}

void createRuleEdge(GNode* source, GNode* target, GNode* fromLabel, GNode* toLabel)
{
	//create duplicate between two nodes in a rule
	//thus we donot search for super node / label
	//also set the given label
	if(source == NULL || target == NULL)
	{
		printf("error: node is null when creating edge\n");
		exit(1);
	}
	if(source == target)
	{
		//one edge in an isomorphic graph is missing in the other
		//printf("warning: same node %d(%d)\n", getNodeID(source), getNodeTimestamp(source));
		//exit(1);
		//for now do not create loop edge;
		return;
	}
	
	GEdge* edge= new GEdge(source, target);
	edge->fromLabel= fromLabel;
	edge->toLabel= toLabel;
	if(edge->getFrom()->nodetype == SuperNode) {
		assert(fromLabel != NULL);
	}
	else {
		assert(fromLabel == NULL);
	}
	if(target->nodetype==SuperNode) {
		assert(toLabel != NULL);
	}
	else {
		assert(toLabel == NULL);
	}
	
	if(source->outgoing == NULL)
		source->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
	if(target->incoming == NULL)
		target->incoming= new set<GEdge*, GEdgeIncomingComp>;

	bool result1= source->outgoing->insert(edge).second;
	bool result2= target->incoming->insert(edge).second;
	if(result1 != result2)
	{
		printf("error: edge in one list but not in the other list b\n");
		exit(1);
	}
}


GNode* createRuleNode(GNodeType type, void* p, int t, GRule* rule)
{
	assert(p != NULL);
	GNode* n= new GNode(type, p, t);
	n->incoming= new set<GEdge*, GEdgeIncomingComp>;
	n->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
	n->containBy= rule;
	n->sntimestamp= new set<int>;
	
	vector<GNode*>* list= NULL;
	if(type == NormalNode)
	{
		struct _inst_trace *inst= (struct _inst_trace*)n->parent;
		list= (vector<GNode*>*)inst->instances;
	}
	else
	{
		GRule* inst= (GRule*) n->parent;
		list= inst->instances;
	}
	list->push_back(n);
	
	return n;
}

GRule* createRule(GEdge** commonEdges, GEdge** otherEdges, int commonEdgesCount)
{
	//link corresponding rule node to both DDG nodes
	int debug= 0;
	
	if(debug)
	{
		printf("createrule: edge count %d\n", commonEdgesCount);
	}
	
	if(commonEdgesCount == 0)
	{
		printf("error: encounter no edges to create rule\n");
		exit(1);
	}
	
	GRule* newrule= new GRule;
	newrule->id= gRuleCount;
	newrule->instances= new vector<GNode*>;
	newrule->frequency= 0;
	newrule->root= NULL;
	
	gRuleCount++;
	//link to global list
	ruleList.push_front(newrule);
	
	GNode* frombase= commonEdges[0]->getFrom();
	
	GNode* from= createRuleNode(frombase->nodetype, 
			frombase->parent, frombase->timestamp, newrule);
	newrule->root= from;
	
	//link the rule node to ddg node
	commonEdges[0]->getFrom()->m.ruleNode= from;
	otherEdges[0]->getFrom()->m.ruleNode= from;

	if(debug)
	{
		printf("from: %d %d\n", getNodeID(from), getNodeTimestamp(from));
	}
	
	int i=0;
	for(; i< commonEdgesCount; i++)
	{
		if(debug)
		{
			printf("from: %d %d\n", getNodeID(commonEdges[i]->getFrom()), getNodeTimestamp(commonEdges[i]->getFrom()));
		}
		if(commonEdges[i]->getFrom() != frombase)
		{
			printf("error: edges have no common from node\n");
			exit(1);
		}
		GNode* tobase= commonEdges[i]->getTo();
		GNode* to= createRuleNode(tobase->nodetype, 
				tobase->parent, tobase->timestamp, newrule);
		createRuleEdge(from, to, commonEdges[i]->fromLabel, commonEdges[i]->toLabel);
		//link the rule node to ddg node
		commonEdges[i]->getTo()->m.ruleNode= to;
		otherEdges[i]->getTo()->m.ruleNode= to;
	}
	
	return newrule;
}

void removeSingleEdge(GEdge* edge)
{
	if(edge == NULL)
	{
		printf("error: try to remove a null edge\n");
		exit(1);
	}
	GNode* f= edge->getFrom();
	set<GEdge*, GEdgeOutgoingComp>::iterator ite= f->outgoing->find(edge);
	if(ite== f->outgoing->end())
	{
		printf("error: the edge %d.%d -> %d.%d is not in outgoing list\n", 
				getNodeID(edge->getFrom()), getNodeTimestamp(edge->getFrom()), 
				getNodeID(edge->getTo()), getNodeTimestamp(edge->getTo()));
		
		printf("possible edges are:\n");
		ite= f->outgoing->begin();
		for(; ite != f->outgoing->end(); ite++)
		{
			GNode* from= (*ite)->getFrom();
			GNode* to= (*ite)->getTo();
			printf("\t%d.%d->%d.%d\n", getNodeID(from), getNodeTimestamp(from), getNodeID(to), getNodeTimestamp(to));
			printf("\t\tto %p, %p\n", edge->getTo()->parent, to->parent);
			printf("\t\tfrom %p, %p\n", edge->getFrom()->parent, from->parent);
		}
		
		tempenable= 1;
		ite= f->outgoing->find(edge);
		
		exit(1);
	}
	f->outgoing->erase(ite);
	GNode* t= edge->getTo();
	set<GEdge*, GEdgeIncomingComp>::iterator ite2= t->incoming->find(edge);
	if(ite2 == t->incoming->end())
	{
		printf("error: the edge %d.%d->%d.%d is not in incoming list\n",
				getNodeID(edge->getFrom()), getNodeTimestamp(edge->getFrom()),
				getNodeID(edge->getTo()), getNodeTimestamp(edge->getTo()));
		printf("possible edges are:\n");
		ite= t->incoming->begin();
		for(; ite != t->incoming->end(); ite++)
		{
			GNode* from= (*ite)->getFrom();
			GNode* to= (*ite)->getTo();
			printf("\t%d.%d->%d.%d\n", getNodeID(from), getNodeTimestamp(from), getNodeID(to), getNodeTimestamp(to));
			printf("\t\tto %p, %p\n", edge->getTo()->parent, to->parent);
			printf("\t\tfrom %p, %p\n", edge->getFrom()->parent, from->parent);
		}
		tempenable= 1;
		ite= t->incoming->find(edge);
		exit(1);
	}
	t->incoming->erase(ite2);
	safeDeleteEdge(edge);
}

int getNodeID(GNode* v)
{
	if(v == NULL)
	{
		printf("error: getnodeid v is null\n");
		exit(1);
	}
	if(v->parent == NULL)
	{
		printf("error: getnodeid parent is null, node %p\n", v);
		exit(1);
	}
	if(v->nodetype == NormalNode)
	{
		int pc= ((inst_trace*)(v->parent))->pc;
		if(pc > 10000) {
			printf("warning: too large pc\n");
			exit(1);
		}
		return pc;
	}
	else
	{
		int id= ((GRule*)(v->parent))->id;
		if(id > 10000) {
			printf("warning: too large id\n");
			exit(1);
		}
		return id;
	}
}

int getNodeTimestamp(GNode* v)
{
	return v->timestamp;
}

void substituteGraph(GEdge** commonEdges, int commonEdgesCount, GNode* sn)
{
		
	//printf("%d %d\n", edgesSize(v->incoming), edgesSize(v->outgoing));
	int debug= 0;
	
	//******* pre-cond checking *******
	if(commonEdgesCount == 0)
	{
		printf("error: empty common edge\n");
		exit(1);
	}
	if(debug)
		printf("start to substitute graph\n");
	//mark the instance being substitute and check froms
	if(commonEdges == NULL || commonEdges[0] == NULL)
	{
		printf("error: first from node is null\n");
		exit(1);
	}
	GNode* checking= commonEdges[0]->getFrom();
	if(checking == NULL)
	{
		printf("error: from reference to null\n");
		exit(1);
	}
	assert(checking->nodetype==NormalNode);
	//checking->marked= 1;
	int i=0;
	for(; i<commonEdgesCount; i++)
	{
		if(commonEdges[i] == NULL)
		{
			printf("error: common edges at %d is null\n", i);
			exit(1);
		}
		if(debug)
		{
			GNode* tempf= commonEdges[i]->getFrom();
			GNode* tempt= commonEdges[i]->getTo();
			if(tempf->nodetype == SuperNode)
			{
				printf("tempf is super\n");
			}
			printf("bbb %d.%d\n", getNodeID(tempf), getNodeTimestamp(tempf));
			if(tempt->nodetype == SuperNode)
			{
				printf("tempt is super\n");
			}
			printf("ccc %d.%d\n", getNodeID(tempt), getNodeTimestamp(tempt));
			printf("curr edge: %d.%d->%d.%d\n", getNodeID(tempf), getNodeTimestamp(tempf),
					getNodeID(tempt), getNodeTimestamp(tempt));
		}
		if(checking != commonEdges[i]->getFrom())
		{
			printf("error: some edge not from the same node\n");
			exit(1);
		}
		//commonEdges[i]->getTo()->marked= 1;
	}
	
	//****** re-direct edges ********
	//set<GEdge*, GEdgeTotalComp> toRemove;
	//vector<GNode*> fromNodes;//store nodes not in graph to be connected with sn
	//vector<GNode*> toNodes;
	
	//*****new: process: delete old edge -> create new edge from/to sn -> delete old node***
	//mark of edge:
	//1 - common edges identified earlier
	//2 - old edge found to be deleted later
	//0 - none of the above
	vector<GEdge*> oldEdges;
	vector<GEdge*> newEdges;//edges created but not linked to node
	//1. process all incoming first
	GNode* from= commonEdges[0]->getFrom();
	if(debug)
		printf("\tcheck incoming of %d.%d\n", getNodeID(from), getNodeTimestamp(from));
	if(from->incoming != NULL) {
		set<GEdge*, GEdgeIncomingComp> *frominc= from->incoming;
		set<GEdge*, GEdgeIncomingComp>::iterator fromincite= frominc->begin();
		for(; fromincite != frominc->end(); fromincite++)
		{
			GEdge* curr= (*fromincite);
			if(curr->marked != 2) {
				//edge not processed
				oldEdges.push_back(curr);
				if(debug) {
					printf("\tmark old edge ");
					dumpEdge(curr);
					printf("\n");
				}
				if(curr->marked == 0) { //edge not common, to be re-connected
					//create the new edge
					GEdge* temp= NULL;
					if(curr->getFrom()->m.ruleNode != NULL) {
						//curr->from is to be substituted
						temp= new GEdge(sn, sn);
						if(curr->fromLabel==NULL) {//curr->from is normal node
							assert(curr->getFrom()->nodetype == NormalNode);
							temp->fromLabel= curr->getFrom()->m.ruleNode;
						}
						else {
							assert(curr->getFrom()->nodetype == SuperNode);
							temp->fromLabel= curr->fromLabel;
						}
					}
					else {
						temp= new GEdge(curr->getFrom(), sn);
						temp->fromLabel= curr->fromLabel;
					}
					assert(curr->toLabel==NULL);
					temp->toLabel= from->m.ruleNode;
					newEdges.push_back(temp);
					if(debug) {
						printf("\tcreate new edge ");
						dumpEdge(temp);
						printf("\n");
					}
				}
				curr->marked= 2;
			}
		}
	}
	//process incoming for other nodes
	i=0;
	for(; i <commonEdgesCount; i++)
	{
		GNode* f= commonEdges[i]->getTo();
		if(debug)
		{
			printf("\tcheck incoming of %d.%d\n", getNodeID(f), getNodeTimestamp(f));
		}
		assert(f->incoming != NULL);
		
		set<GEdge*, GEdgeIncomingComp> *inc= f->incoming;
		set<GEdge*, GEdgeIncomingComp>::iterator incite= inc->begin();
		for(; incite != inc->end(); incite++)
		{
			GEdge* curr= (*incite);
			if(curr->marked != 2) {
				oldEdges.push_back(curr);
				if(debug) {
					printf("\tmark old edge ");
					dumpEdge(curr);
					printf("\n");
				}
				if(curr->marked == 0) {
					//edge not common, to be re-connected
					//create the new edge
					GEdge* temp= NULL;
					if(curr->getFrom()->m.ruleNode != NULL) {
						temp= new GEdge(sn, sn);
						if(curr->fromLabel==NULL) {//curr->from is normal node
							assert(curr->getFrom()->nodetype == NormalNode);
							temp->fromLabel= curr->getFrom()->m.ruleNode;
						}
						else {
							assert(curr->getFrom()->nodetype == SuperNode);
							temp->fromLabel= curr->fromLabel;
						}
					}
					else {
						temp= new GEdge(curr->getFrom(), sn);
						temp->fromLabel= curr->fromLabel;
					}
					if(f->nodetype == NormalNode) {
						assert(curr->toLabel == NULL);
						temp->toLabel= f->m.ruleNode;
					}
					else {
						assert(curr->toLabel != NULL);
						temp->toLabel= curr->toLabel;
					}
					newEdges.push_back(temp);
					if(debug) {
						printf("\tcreate new edge ");
						dumpEdge(temp);
						printf("\n");
					}
				}
				curr->marked= 2;
			}
		}
	}
	
	//2. process all outgoing now
	//process outgoing for base node
	assert(from->outgoing != NULL);
	if(debug)
	{
		printf("\tcheck outgoing of %d.%d\n", getNodeID(from), getNodeTimestamp(from));
	}
	set<GEdge*, GEdgeOutgoingComp> *fromout= from->outgoing;
	set<GEdge*, GEdgeOutgoingComp>::iterator fromoutite= fromout->begin();
	for(; fromoutite != fromout->end(); fromoutite++)
	{
		GEdge* curr= (*fromoutite);
		if(curr->marked != 2) {
			oldEdges.push_back(curr);
			if(debug) {
				printf("\tmark old edge ");
				dumpEdge(curr);
				printf("\n");
			}
			if(curr->marked == 0) {
				GEdge* temp= NULL;
				if(curr->getTo()->m.ruleNode != NULL) {
					temp= new GEdge(sn, sn);
					if(curr->toLabel == NULL) {
						//curr->to is normal node
						assert(curr->getTo()->nodetype == NormalNode);
						temp->toLabel= curr->getTo()->m.ruleNode;
					}
					else {
						assert(curr->getTo()->nodetype == SuperNode);
						temp->toLabel= curr->toLabel;
					}
				}
				else {
					temp= new GEdge(sn, curr->getTo());
					temp->toLabel= curr->toLabel;
				}
				assert(curr->fromLabel == NULL);
				temp->fromLabel= from->m.ruleNode;
				newEdges.push_back(temp);
				if(debug) {
					printf("\tcreate new edge ");
					dumpEdge(temp);
					printf("\n");
				}
			}
			curr->marked= 2;
		}
	}
	//process outgoing edges of all other nodes
	i=0;
	for(; i<commonEdgesCount; i++)
	{
		GNode* to= commonEdges[i]->getTo();
		if(debug)
		{
			printf("\tcheck outgoing of %d.%d\n", getNodeID(to), getNodeTimestamp(to));
		}
		if(to->outgoing != NULL)
		{
			set<GEdge*, GEdgeOutgoingComp> *out= to->outgoing;
			set<GEdge*, GEdgeOutgoingComp>::iterator outite= out->begin();
			for(; outite != out->end(); outite++)
			{
				GEdge* curr= (*outite);
				if(curr->marked != 2) {
					oldEdges.push_back(curr);
					if(debug) {
						printf("\tmark old edge ");
						dumpEdge(curr);
						printf("\n");
					}
					if(curr->marked == 0) {
						GEdge* temp= NULL;
						if(curr->getTo()->m.ruleNode != NULL) {
							temp= new GEdge(sn, sn);
							if(curr->toLabel == NULL) {
								assert(curr->getTo()->nodetype == NormalNode);
								temp->toLabel= curr->getTo()->m.ruleNode;
							}
							else {
								assert(curr->getTo()->nodetype == SuperNode);
								temp->toLabel= curr->toLabel;
							}
						}
						else {
							temp= new GEdge(sn, curr->getTo());
							temp->toLabel= curr->toLabel;
						}
						if(to->nodetype == NormalNode) {
							assert(curr->fromLabel ==NULL);
							temp->fromLabel= to->m.ruleNode;
						}
						else {
							assert(curr->fromLabel !=NULL);
							temp->fromLabel= curr->fromLabel;
						}
						newEdges.push_back(temp);
						if(debug) {
							printf("\tcreate new edge ");
							dumpEdge(temp);
							printf("\n");
						}
					}
					curr->marked= 2;
				}
			}
		}
	}
	
	//****** delete edges and nodes *******
	vector<GNode*> nodeRemove;
	nodeRemove.push_back(commonEdges[0]->getFrom());
	i=0;
	for(; i<commonEdgesCount; i++)
	{
		if(nodeRemove.back() != commonEdges[i]->getTo())
			nodeRemove.push_back(commonEdges[i]->getTo());
	}
	vector<GEdge*>::iterator removeite= oldEdges.begin();
	for(; removeite != oldEdges.end(); removeite++)
	{
		/*if(debug)
		{
			GEdge* curr= *removeite;
			printf("\tdelete edge %d.%d->%d.%d\n", 
					getNodeID(curr->getFrom()), getNodeTimestamp(curr->getFrom()),
					getNodeID(curr->getTo()), getNodeTimestamp(curr->getTo()));
		}*/
		removeSingleEdge(*removeite);
	}
	vector<GNode*>::iterator nodeite= nodeRemove.begin();
	for(; nodeite != nodeRemove.end(); nodeite++)
	{
		GNode* node= *nodeite;
		if(node != NULL)
		{
			if(debug)
			{
				printf("\tdelete node %d.%d\n", getNodeID(node), getNodeTimestamp(node));
			}
			//delete node;
			removeNodeFromInst(node);
		}
		else
		{
			printf("warning: node is null when delete\n");
		}
	}
	
	//link newly created edges
	vector<GEdge*>::iterator createite= newEdges.begin();
	for(; createite != newEdges.end(); createite++) {
		GEdge* e= (*createite);
		if(e->getFrom()->outgoing == NULL) {
			e->getFrom()->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
		}
		bool result1= e->getFrom()->outgoing->insert(e).second;
		if(e->getTo()->incoming == NULL) {
			e->getTo()->incoming= new set<GEdge*, GEdgeIncomingComp>;
		}
		bool result2= e->getTo()->incoming->insert(e).second;
		if(result1 != result2) {
			printf("error: edge in one but no in another b\n");
			exit(1);
		}
	}
	//******new end******
	
	
	/*
	//1. process all incoming first
	//check the from node
	//since all edges starting from the same node, we just check once
	GNode* from= commonEdges[0]->getFrom();
	if(debug)
	{
		printf("\tcheck incoming of %d.%d\n", getNodeID(from), getNodeTimestamp(from));
	}
	if(from->incoming !=NULL)
	{
		set<GEdge*, GEdgeIncomingComp> *frominc= from->incoming;
		set<GEdge*, GEdgeIncomingComp>::iterator fromincite= frominc->begin();
		for(; fromincite != frominc->end(); fromincite++)
		{
			GEdge* curr= (*fromincite);			
			if(curr->getFrom()->marked == 0)//no duplicate and self edge for now
			{
				//if the node is not visited yet and not in sub-graph
				//curr->to= sn;
				//sn->incoming->insert(curr);
				curr->getFrom()->marked= 2;
				fromNodes.push_back(curr->getFrom());
				if(debug)
				{
					printf("\t\tfound new node %d.%d, put edge toremove and store node\n",
							getNodeID(curr->getFrom()), getNodeTimestamp(curr->getFrom()));
				}
			}
			else
			{
				if(debug)
				{
					printf("\t\tfound visited node %d.%d mark %d, put edge toremove\n", 
							getNodeID(curr->getFrom()), getNodeTimestamp(curr->getFrom()), curr->getFrom()->marked);
				}
			}
			toRemove.insert(curr);
		}
	}
	//process incoming for other nodes
	i=0;
	for(; i <commonEdgesCount; i++)
	{
		GNode* f= commonEdges[i]->getTo();
		if(debug)
		{
			printf("\tcheck incoming of %d.%d\n", getNodeID(f), getNodeTimestamp(f));
		}
		if(f->incoming != NULL)
		{
			set<GEdge*, GEdgeIncomingComp> *inc= f->incoming;
			set<GEdge*, GEdgeIncomingComp>::iterator incite= inc->begin();
			for(; incite != inc->end(); incite++)
			{
				GEdge* curr= (*incite);
				if(curr->getFrom()->marked == 0)
				{
					//curr->to= sn;
					//sn->incoming->insert(curr);
					fromNodes.push_back(curr->getFrom());
					curr->getFrom()->marked= 2;
					if(debug)
					{
						printf("\t\tfound new node %d.%d, put edge toremove and store node\n",
								getNodeID(curr->getFrom()), getNodeTimestamp(curr->getFrom()));
					}
				}
				else
				{
					if(debug)
					{
						printf("\t\tfound visited node %d.%d mark %d, put edge toremove\n", 
								getNodeID(curr->getFrom()), getNodeTimestamp(curr->getFrom()), curr->getFrom()->marked);
					}
				}
				toRemove.insert(curr);
			}
		}
		else
		{
			printf("error: other node's incoming is null\n");
			exit(1);
		}
	}
	//clear mark 2 for sn's incoming nodes
	if(debug)
	{
		printf("clear mark 2\n");
	}
	vector<GNode*>::iterator snincite= fromNodes.begin();
	//set<GEdge*, GEdgeIncomingComp> *sninc= sn->incoming;
	//set<GEdge*, GEdgeIncomingComp>::iterator snincite= sninc->begin();
	for(; snincite != fromNodes.end(); snincite++)
	{
		GNode* curr= (*snincite);
		if(curr->marked != 2)
		{
			printf("error: expect mark 2 for sn's incoming\n");
			exit(1);
		}
		curr->marked= 0;
	}
	
	
	//2. process all outgoing now
	//process outgoing for base node
	if(from->outgoing == NULL)
	{
		printf("error: from->outgoing null\n");
		exit(1);
	}
	if(debug)
	{
		printf("\tcheck outgoing of %d.%d\n", getNodeID(from), getNodeTimestamp(from));
	}
	set<GEdge*, GEdgeOutgoingComp> *fromout= from->outgoing;
	set<GEdge*, GEdgeOutgoingComp>::iterator fromoutite= fromout->begin();
	for(; fromoutite != fromout->end(); fromoutite++)
	{
		GEdge* target= (*fromoutite);
		if(target->getTo()->marked == 0)
		{
			//not in the sub-graph
			//target->from= sn;
			//sn->outgoing->insert(target);
			target->getTo()->marked= 2;
			toNodes.push_back(target->getTo());
			if(debug)
			{
				printf("\t\tfound new node %d.%d, put edge toremove and store node\n",
						getNodeID(target->getTo()), getNodeTimestamp(target->getTo()));
			}
		}
		else
		{
			if(debug)
			{
				printf("\t\tfound visited node %d.%d mark %d, put edge toremove\n", 
						getNodeID(target->getTo()), getNodeTimestamp(target->getTo()), target->getTo()->marked);
			}
		}
		toRemove.insert(target);
	}
	//process outgoing edges of all other nodes
	i=0;
	for(; i<commonEdgesCount; i++)
	{
		GNode* to= commonEdges[i]->getTo();
		if(debug)
		{
			printf("\tcheck outgoing of %d.%d\n", getNodeID(to), getNodeTimestamp(to));
		}
		if(to->outgoing != NULL)
		{
			set<GEdge*, GEdgeOutgoingComp> *out= to->outgoing;
			set<GEdge*, GEdgeOutgoingComp>::iterator outite= out->begin();
			for(; outite != out->end(); outite++)
			{
				GEdge* curr= (*outite);
				if(curr->getTo()->marked == 0)
				{
					//curr->from= sn;
					//sn->outgoing->insert(curr);
					toNodes.push_back(curr->getTo());
					curr->getTo()->marked= 2;
					if(debug)
					{
						printf("\t\tfound new node %d.%d, push edge toremove and store node\n",
								getNodeID(curr->getTo()), getNodeTimestamp(curr->getTo()));
					}
				}
				else
				{
					if(debug)
					{
						printf("\t\tfound visited node %d.%d mark %d, put edge toremove\n", 
								getNodeID(curr->getTo()), getNodeTimestamp(curr->getTo()), curr->getTo()->marked);
					}
				}
				toRemove.insert(curr);
			}
		}
	}
	//clear mark 2 for sn's outgoing nodes
	if(debug)
	{
		printf("clear mark 2\n");
	}
	//set<GEdge*, GEdgeOutgoingComp> *snout= sn->outgoing;
	//set<GEdge*, GEdgeOutgoingComp>::iterator snoutite= snout->begin();
	vector<GNode*>::iterator snoutite= toNodes.begin();
	for(; snoutite != toNodes.end(); snoutite++)
	{
		GNode* curr= (*snoutite);
		if(curr->marked != 2)
		{
			printf("error: expect mark 2 for sn's incoming\n");
			exit(1);
		}
		curr->marked= 0;
	}

	
	//****** delete edges and nodes *******
	vector<GNode*> nodeRemove;
	nodeRemove.push_back(commonEdges[0]->getFrom());
	i=0;
	for(; i<commonEdgesCount; i++)
	{
		nodeRemove.push_back(commonEdges[i]->getTo());
	}
	set<GEdge*, GEdgeTotalComp>::iterator removeite= toRemove.begin();
	for(; removeite != toRemove.end(); removeite++)
	{
		if(debug)
		{
			GEdge* curr= *removeite;
			printf("\tdelete edge %d.%d(%d)->%d.%d(%d)\n", 
					getNodeID(curr->getFrom()), getNodeTimestamp(curr->getFrom()), curr->getFrom()->marked,
					getNodeID(curr->getTo()), getNodeTimestamp(curr->getTo()), curr->getTo()->marked);
		}
		removeSingleEdge(*removeite);
	}
	vector<GNode*>::iterator nodeite= nodeRemove.begin();
	for(; nodeite != nodeRemove.end(); nodeite++)
	{
		GNode* node= *nodeite;
		if(node != NULL)
		{
			if(debug)
			{
				printf("\tdelete node %d.%d(%d)\n", getNodeID(node), getNodeTimestamp(node), node->marked);
			}
			if(node->incoming != NULL)
			{
				delete node->incoming;
				node->incoming= NULL;
			}
			if(node->outgoing != NULL)
			{
				delete node->outgoing;
				node->outgoing= NULL;
			}
			//delete node;
			removeNodeFromInst(node);
		}
		else
		{
			printf("warning: node is null when delete\n");
		}
	}
	
	//******* create edges from/to sn *******
	vector<GNode*>::iterator createite= fromNodes.begin();
	for(; createite != fromNodes.end(); createite++)
	{
		createEdge(*createite, sn);
	}
	createite= toNodes.begin();
	for(; createite != toNodes.end(); createite++)
	{
		createEdge(sn, *createite);
	}*/
}

void substitute(GEdge** commonEdges, int commonEdgesCount, GNode *v, GRule* rule)
{
	int debug= 0;
	//commonEdges - the set of edges together with nodes to be replaced
	if(debug)
		printf("start to substitute %d.%d with %d edges\n", getNodeID(v), getNodeTimestamp(v), commonEdgesCount);
	
	if(v->containBy != NULL)
	{
		printf("error: the starting node to be substituted is in a rule\n");
		exit(1);
	}
	assert(rule != NULL);
	
	//struct _inst_trace *aaa= (struct _inst_trace*)(v->inst);
	//printf("substitute node (inst %d) with rule %d\n", aaa->pc, rule->id);
	
	//create super node instance of rule
	GNode* sn= new GNode(SuperNode, rule, v->timestamp);
	sn->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
	sn->incoming= new set<GEdge*, GEdgeIncomingComp>;
	sn->containBy= NULL;
	sn->m.ruleNode= NULL;
	sn->sntimestamp= NULL;

	rule->instances->push_back(sn);
	
	if(debug)
		printf("rule instance created\n");
	
	substituteGraph(commonEdges, commonEdgesCount, sn);
	
	//label edge - not done for now
	
	//re-compression
	
	/*int incsize= edgesSize(sn->incoming);
	if(incsize > 0)
	{
		gnode *temp= (gnode*)cleanMalloc(sizeof(gnode)*incsize);
		int i= 0;
		gedge* tempedge= sn->incoming;
		for(; tempedge !=NULL; tempedge= tempedge->next)
		{
			temp[i]= tempedge->target;
		}
		gnode* tempnode= temp[0];
		for(; tempnode!=NULL; tempnode= tempnode->next)
		{
			compressNode(tempnode);
		}
		free(temp);
	}*/
}

//extern "C" void countNodeEdge(struct _inst_trace *instTrace, int *nodecount, int *edgecount)
extern "C" void countNodeEdge(void *nodelist, int *nodecount, int *edgecount)
{
	//vector<GNode*> *nodes= (vector<GNode*> *)instTrace->instances;
	vector<GNode*> *nodes= (vector<GNode*> *)nodelist;
	if(nodes == NULL)
	{
		return;
	}
	vector<GNode*>::reverse_iterator ite= nodes->rbegin();
	//gnode* curr=node;
	for(; ite != nodes->rend(); ite++)
	{
		(*nodecount) = (*nodecount)+1;
		GNode* n=*ite;
		set<GEdge*, GEdgeOutgoingComp> *temp= n->outgoing;
		if(temp == NULL)
		{
			continue;
		}
		(*edgecount) = (*edgecount) + temp->size();//curr->incomingCount + curr->outgoingCount;
	}
}

int ruleUnused(GRule *rule)
{
	//only consider that the rule has one instance which is in another rule
	//gnode* curr= rule->instances;
	if(rule->instances->empty())
	//if(curr == NULL)
	{
		printf("error: the rule has no instance\n");
		exit(1);
	}
	//printf("rule: %d, instances %d\n", rule->id, nodesSize(curr));
	if(rule->instances->size() == 1 && rule->instances->front()->containBy != NULL)
	//if(nodesSize(curr)==1 && curr->containBy != NULL)
	{
		if(rule->instances->front()->containBy->frequency != rule->frequency)
		//if(curr->containBy->frequency != rule->frequency)
		{
			printf("error: super rule has diff freq %d.%d %d.%d\n",
					rule->instances->front()->containBy->id,
					rule->instances->front()->containBy->frequency,
					rule->id,
					rule->frequency);
			exit(1);
		}
		return 1;
	}
	return 0;
}

void updateContainBy(GNode* oldroot, GRule* targetrule)
{
	if(oldroot->containBy != targetrule)
	{
		oldroot->containBy= targetrule;
		set<GEdge*, GEdgeOutgoingComp>::iterator temp= oldroot->outgoing->begin();
		for(; temp != oldroot->outgoing->end(); temp++)
		{
			updateContainBy((*temp)->getTo(), targetrule);
		}
		/*
		oldroot->containBy= targetrule;
		gedge* curr= oldroot->outgoing;
		for(; curr != NULL; curr= curr->next)
		{
			updateContainBy(curr->target, targetrule);
		}*/
	}
}

GNode* getTopSuper(GNode* realNode, GRule* currRule) {
	//printf("\t checking instances of rule %d\n", realNode->containBy->id);
	vector<GNode*>* instances= realNode->containBy->instances;
	vector<GNode*>::reverse_iterator instance= instances->rbegin();
	for(; instance!=instances->rend(); instance++) {
		if((*instance)->containBy != NULL) {
			//printf("\t\t node %d.%d\n", getNodeID(*instance), getNodeTimestamp(*instance));
			if((*instance)->containBy == currRule) {
				//printf("found\n");
				return (GNode*)(*instance);
			}
			else if((*instance)->containBy->id > currRule->id) {
				//printf("exceed %d > %d\n", (*instance)->containBy->id, currRule->id);
				continue;
			}
			else {
				GNode* temp= getTopSuper(*instance, currRule);
				if(temp != NULL) {
					return temp;
				}
			}
		}
	}
	//printf("not found for %d\n", realNode->containBy->id);
	return NULL;
}

extern "C" void compressRuleList()
{
	int debug= 0;
	if(debug)
		dumpHotgraph();
	printf("start to compress rule list\n");
	
	if(ruleList.empty())
		return;
	
	list<GRule*>::iterator curr= ruleList.begin();
	if((*curr)->instances == NULL)
	{
		printf("warning: first rule has no instance\n");
		exit(1);
	}
	
	vector<GRule*> ruleToRemove;
	
	for(; curr != ruleList.end(); curr++)
	{
		if(ruleUnused(*curr))
		{
			if(debug)
				printf("find unused rule %d\n", (*curr)->id);
			//current rule is not used -> combine
			vector<GNode*> *instances= (*curr)->instances;
			vector<GNode*>::iterator instance= instances->begin();
			//for now, only consider instance without outgoing edge
			if((*instance)->outgoing->size() > 0)
			{
				continue;
			}
			
			//update incoming edges of the instance
			set<GEdge*, GEdgeIncomingComp> *incset= (*instance)->incoming;
			set<GEdge*, GEdgeIncomingComp>::iterator edge= incset->begin();
			vector<GEdge*> edgeToRemove;
			//vector<GNode*> fromNodes;
			vector<GEdge*> newEdges;
			for(; edge != incset->end(); edge++)
			{
				//fromNodes.push_back((*edge)->getFrom());
				assert((*edge)->toLabel != NULL);
				if(debug) {
					printf("process edge ");
					dumpEdge(*edge);
					printf("\n");
				}
				assert((*edge)->toLabel->containBy != NULL);
				//printf("tolabel %d, curr %d\n", (*edge)->toLabel->containBy->id, (*curr)->id);
				if((*edge)->toLabel->containBy != (*curr)) {
					if(debug)
						printf("further node\n");
					//edge actually point to node in another rule
					//create new edge pointing to the corresponding super node in curr while retain toLabel
					GNode* toNode= getTopSuper((*edge)->toLabel, (*curr));
					assert(toNode != NULL);
					GEdge* temp= new GEdge((*edge)->getFrom(), toNode);
					temp->fromLabel= (*edge)->fromLabel;
					temp->toLabel= (*edge)->toLabel;
					newEdges.push_back(temp);
				}
				else {
					//edge point to a node in rule curr
					//create new edge pointing to the real node
					assert((*edge)->toLabel->nodetype == NormalNode);
					GEdge* temp= new GEdge((*edge)->getFrom(), (*edge)->toLabel);
					temp->fromLabel= (*edge)->fromLabel;
					temp->toLabel= NULL;
					newEdges.push_back(temp);
				}
				edgeToRemove.push_back(*edge);
			}
			
			//update containBy
			updateContainBy((*curr)->root, (*instance)->containBy);
			
			vector<GEdge*>::iterator temp= edgeToRemove.begin();
			for(; temp != edgeToRemove.end(); temp++)
			{
				removeSingleEdge(*temp);
			}
			removeNodeFromInst(*instance);
			
			//re-create edges
			/*vector<GNode*>::iterator from= fromNodes.begin();
			for(; from != fromNodes.end(); from++)
			{
				createRuleEdge((*from), (*curr)->root, NULL, NULL);
			}*/
			
			temp= newEdges.begin();
			for(; temp != newEdges.end(); temp++) {
				if((*temp)->getFrom()->outgoing==NULL)
					(*temp)->getFrom()->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
				if((*temp)->getTo()->incoming==NULL)
					(*temp)->getTo()->incoming= new set<GEdge*, GEdgeIncomingComp>;
				bool result1= (*temp)->getFrom()->outgoing->insert(*temp).second;
				bool result2= (*temp)->getTo()->incoming->insert(*temp).second;
				if(result1 != result2) {
					printf("error: in one but not another\n");
					exit(1);
				}
			}
			
			//free rule
			ruleToRemove.push_back(*curr);
		}
	}
	
	vector<GRule*>::iterator rule= ruleToRemove.begin();
	for(; rule!=ruleToRemove.end(); rule++)
	{
		ruleList.remove(*rule);
	}
}

void countRuleGraph(GNode *node, int* nodecount, int* edgecount)
{         
	if(node == NULL)
    {                 
		printf("error: node is null\n");
        exit(1);
    }
    (*nodecount)= (*nodecount) + 1;
    set<GEdge*, GEdgeOutgoingComp> *oset= node->outgoing;
    set<GEdge*, GEdgeOutgoingComp>::iterator curr= oset->begin();
    for(; curr!=oset->end(); curr++)
    {
        (*edgecount)= (*edgecount) + 1;
        countRuleGraph((*curr)->getTo(), nodecount, edgecount);
    }
}

void dumpRuleGraph(GNode *node)
{
	if(node == NULL)
	{
		printf("error: node is null\n");
		exit(1);
	}
	set<GEdge*, GEdgeOutgoingComp> *oset= node->outgoing;
	set<GEdge*, GEdgeOutgoingComp>::iterator curr= oset->begin();
	for(; curr!=oset->end(); curr++)
	{
		dumpRuleGraph((*curr)->getTo());
		printf("\t\t\t");
		if(node->nodetype==NormalNode)
		{
			printf("%d(%d)", getNodeID(node), node->timestamp);
		}
		else
		{
			printf("<%d>(%d)", getNodeID(node), node->timestamp);
		}
		printf("-->");
		if((*curr)->getTo()->nodetype==NormalNode)
		{
			printf("%d(%d)", getNodeID((*curr)->getTo()), (*curr)->getTo()->timestamp);
		}
		else
		{
			printf("<%d>(%d)", getNodeID((*curr)->getTo()), (*curr)->getTo()->timestamp);
		}
		printf("\n");
	}
}

extern "C" void dumpRule()
{
	printf("RULE list:\n");
	list<GRule*>::iterator currRule= ruleList.begin();
	for(; currRule!=ruleList.end(); currRule++)
	{
		printf("\trule %d, %d, %d:\n", (*currRule)->id, (*currRule)->frequency, (*currRule)->instances->size());
		dumpRuleGraph((*currRule)->root);
	}
}
/*
int countOneRule(gnode* root)
{
	int count= 1;
	root->timestamp= 1;
	gedge* curr= root->outgoing;
	for(; curr !=NULL; curr= curr->next)
	{
		gnode* target= curr->target;
		if(target->timestamp == 0)
		{
			count+= countOneRule(target);
		}
	}
	root->timestamp= 0;
	return count;
}
*/
int distinctrulecount= 0;

extern "C" void countRuleOverhead(int *nodecount, int* edgecount)
{
	//int count=0;
	list<GRule*>::iterator curr= ruleList.begin();
	for(; curr != ruleList.end(); curr++)
	{
		//int subgraphnodesize= 0;
		//int subgraphedgesize= 0;
		countNodeEdge((*curr)->instances, nodecount, edgecount);
		distinctrulecount++;
		//countRuleGraph((*curr)->root, &subgraphnodesize, &subgraphedgesize);
		//printf("cost %d %d %d\n", subgraphnodesize, subgraphedgesize, (*curr)->frequency);
	}
}

extern "C" int countRuleSize()
{
	return distinctrulecount;
}

extern "C" void dumpInstHotgraph(inst_trace* instTrace)
{
	vector<GNode*>* s= (vector<GNode*>*)instTrace->instances;
	if(s == NULL)
	{
		return;
	}
	vector<GNode*>::iterator ite= s->begin();
	
	for(; ite!=s->end(); ite++)
	{
		if((*ite)->containBy == NULL)
		{
			printf("\t\t\tnode (%d): outgoing:", (*ite)->timestamp);
		}
		else
		{
			printf("\t\t\tnode (%d) (in rule): outgoing:", (*ite)->timestamp);
		}
		if((*ite)->outgoing != NULL)
		{
			const set<GEdge*, GEdgeOutgoingComp> *currEdge= (*ite)->outgoing;
			set<GEdge*, GEdgeOutgoingComp>::iterator iteedge= currEdge->begin();
			for(; iteedge != currEdge->end(); iteedge++)
			{
				if((*iteedge)->getTo()->nodetype == NormalNode)
				{
					printf(" %d(%d)", getNodeID((*iteedge)->getTo()), (*iteedge)->getTo()->timestamp);
				}
				else
				{
					printf(" <%d>(%d)", getNodeID((*iteedge)->getTo()), (*iteedge)->getTo()->timestamp);
				}
			}
		}
		printf(";\n \t\t\t\tincoming:");
		if((*ite)->incoming !=NULL)
		{
			const set<GEdge*, GEdgeIncomingComp> *currEdge2= (*ite)->incoming;
			set<GEdge*, GEdgeIncomingComp>::iterator iteedge2= currEdge2->begin();
			for(; iteedge2 != currEdge2->end(); iteedge2++)
			{
				if((*iteedge2)->getTo()->nodetype == NormalNode)
				{
					printf(" %d(%d)", getNodeID((*iteedge2)->getFrom()), (*iteedge2)->getFrom()->timestamp);
				}
				else
				{
					printf(" <%d>(%d)", getNodeID((*iteedge2)->getFrom()), (*iteedge2)->getFrom()->timestamp);
				}
			}
		}
		printf("\n");
	}
}

//=============== slicing ================
class Element{
public:
	GNode* realNode;
	GNode* sn;
	Element(GNode* real, GNode* sn);
};

Element::Element(GNode* real, GNode* sn) {
	this->realNode= real;
	this->sn= sn;
}

list<Element*> slicequeue;
vector<GNode*> sliceresult;

void pushInitNodes(char *className, char *methodName, char *sig, int pc, int mark) {
	struct _class_trace* trace= getTrace();
	for(; trace!=NULL; trace= trace->next)
	{
		//printf("checking class: %s\n", getClassNameFromTrace(trace));
		if(strcmp(getClassNameFromTrace(trace), className)==0)
		{
			struct _method_trace* meth= trace->methodTrace;
			for(; meth!=NULL; meth= meth->next)
			{
				//printf("checking method %s %s\n", getMethodNameFromTraceAt(meth->methodID),
				//		getSigNameFromTraceAt(meth->sigID));
				if(strcmp(getMethodNameFromTraceAt(meth->methodID), methodName)==0
						&& strcmp(getSigNameFromTraceAt(meth->sigID), sig)==0)
				{
					int index= ((meth->hash[pc])&0x7FFFFFFF)-1;
					if(index== -1)
					{
						printf("error: no inst trace slot c\n");
						exit(1);
					}
					struct _inst_trace* instTrace= &(meth->instTrace[index]);
					assert(instTrace->instances != NULL);
					vector<GNode*>* instances= (vector<GNode*>*)instTrace->instances;
					//for now just start from the latest instance
					GNode* real= instances->back();
					Element *ele= NULL;
					if(real->containBy == NULL) {
						ele= new Element(real, NULL);
					}
					else {
						GNode* sntop= getSuperNode(real);
						ele= new Element(real, sntop);
						//mark (supernode, realnode) pair by
						//inserting timestamp of supernode to list of realnode
						real->sntimestamp->insert(sntop->timestamp);
					}
					//mark the node as being visited
					real->m.marked= mark;
					slicequeue.push_back(ele);
					sliceresult.push_back(real);
					return;
				}
			}
		}
	}
}

void traverse(int mark) {
	while(!slicequeue.empty()) {
		Element* curr= slicequeue.front();
		assert(curr!=NULL);
		slicequeue.pop_front();
		GNode* real= curr->realNode;
		assert(real != NULL);
		//sliceresult.push_back(real);
		//process direct outgoing edges
		if(real->outgoing != NULL) {
			set<GEdge*, GEdgeOutgoingComp> *out= real->outgoing;
			set<GEdge*, GEdgeOutgoingComp>::iterator outite= out->begin();
			for(; outite != out->end(); outite++) {
				assert((*outite)->getTo()!=NULL);
				if((*outite)->getTo()->nodetype == SuperNode) {
					if(curr->sn == NULL) {
						assert((*outite)->getTo()->containBy == NULL);
						//curr node is in ddg
						assert((*outite)->toLabel!=NULL);
						set<int> *sntt= (*outite)->toLabel->sntimestamp;
						assert(sntt != NULL);
						if(sntt->find((*outite)->getTo()->timestamp) == sntt->end()) {
							//if the realnode (w.r.t super node) is not visited
							if((*outite)->toLabel->m.marked != mark) {
								sliceresult.push_back((*outite)->toLabel);
							}
							Element *temp= new Element((*outite)->toLabel, (*outite)->getTo());
							(*outite)->toLabel->m.marked= mark;
							sntt->insert((*outite)->getTo()->timestamp);
							slicequeue.push_back(temp);
						}
						else {
							assert((*outite)->toLabel->m.marked == mark);
						}
					}
					else {
						assert((*outite)->getTo()->containBy != NULL);
						//curr node is in rule
						assert((*outite)->toLabel != NULL);
						set<int> *sntt= (*outite)->toLabel->sntimestamp;
						assert(sntt!= NULL);
						if(sntt->find(curr->sn->timestamp)!= sntt->end()) {
							//if the realnode (w.r.t super node) is not visited
							if((*outite)->toLabel->m.marked != mark) {
								sliceresult.push_back((*outite)->toLabel);
							}
							Element *temp= new Element((*outite)->toLabel, curr->sn);
							(*outite)->toLabel->m.marked= mark;
							sntt->insert(curr->sn->timestamp);
							slicequeue.push_back(temp);
						}
					}
				}
				else {//pointing to normal node
					assert((*outite)->getTo() != NULL);
					if(curr->sn == NULL) {
						if((*outite)->getTo()->m.marked != mark) {
							//in ddg
							Element *temp= new Element((*outite)->getTo(), NULL);
							sliceresult.push_back((*outite)->getTo());
							(*outite)->getTo()->m.marked= mark;
							slicequeue.push_back(temp);
						}
					}
					else {//in rule
						set<int> *sntt= (*outite)->getTo()->sntimestamp;
						assert(sntt!=NULL);
						if(sntt->find(curr->sn->timestamp) != sntt->end()) {
							if((*outite)->getTo()->m.marked != mark) {
								sliceresult.push_back((*outite)->getTo());
							}
							Element *temp= new Element((*outite)->getTo(), curr->sn);
							(*outite)->getTo()->m.marked= mark;
							sntt->insert(curr->sn->timestamp);
							slicequeue.push_back(temp);
						}
					}
				}
				//slicequeue.push_back(temp);
			}
		}
		//process outgoing edge from top super node
		if(curr->sn != NULL && curr->sn->outgoing != NULL) {
			assert(curr->sn->containBy == NULL);
			set<GEdge*, GEdgeOutgoingComp> *out= curr->sn->outgoing;
			set<GEdge*, GEdgeOutgoingComp>::iterator outite= out->begin();
			for(; outite != out->end(); outite++) {
				assert((*outite)->fromLabel != NULL);
				if((*outite)->fromLabel == curr->realNode) {
					//find outgoing edge from super node
					if((*outite)->getTo()->nodetype == SuperNode) {
						assert((*outite)->toLabel != NULL);
						assert((*outite)->toLabel->containBy != NULL);
						set<int> *sntt= (*outite)->toLabel->sntimestamp;
						if(sntt->find((*outite)->getTo()->timestamp) != sntt->end()) {
							if((*outite)->toLabel->m.marked != mark) {
								sliceresult.push_back((*outite)->toLabel);
								(*outite)->toLabel->m.marked= mark;
							}
							Element *temp= new Element((*outite)->toLabel, (*outite)->getTo());
							sntt->insert((*outite)->getTo()->timestamp);
							slicequeue.push_back(temp);
						}
					}
					else {
						if((*outite)->getTo()->m.marked != mark) {
							Element *temp= new Element((*outite)->getTo(), NULL);
							(*outite)->getTo()->m.marked= mark;
							sliceresult.push_back((*outite)->getTo());
							slicequeue.push_back(temp);
						}
					}
				}
			}
		}
		delete curr;
	}
}

void outputResult() {
	vector<GNode*>::iterator ite= sliceresult.begin();
	for(; ite!=sliceresult.end(); ite++) {
		GNode* curr= *ite;
		assert(curr->nodetype == NormalNode);
		struct _inst_trace *t= (struct _inst_trace*)curr->parent;
		const char *className= getClassNameFromTraceAt(t->methodTrace->classTrace->classID);
		const char *methodName= getMethodNameFromTraceAt(t->methodTrace->methodID);
		const char *sig= getSigNameFromTraceAt(t->methodTrace->sigID);
		int pc= t->pc;
		printf("%s %s %s %d\n", className, methodName, sig, pc);
	}
}

extern "C" void slicing() {
	Criterions *criteria= new Criterions();
	int i=0;
	for(; i< criteria->count; i++) {
		char *className= NULL;
		char *methodName= NULL;
		char *sig= NULL;
		int pc=-1;
		int mark= -(100+i);
		criteria->getCriterion(i, &className, &methodName, &sig, &pc);
		printf("criterion: %s %s %s %d\n", className, methodName, sig, pc);
		pushInitNodes(className, methodName, sig, pc, mark);
		assert(!slicequeue.empty());
		traverse(mark);
		outputResult();
	}
}


