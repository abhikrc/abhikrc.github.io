/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=state name=CMGetSuccessInit
*/
public class State_CMGetSuccessInit extends AState {
	private CM baseClass;
	
	public State_CMGetSuccessInit (CM baseClass) {
		this.parentRegionName = "CM";
		this.baseClass = baseClass;

		
	}
	
	public State_CMGetSuccessInit (CM baseClass, AState[] children) {
		this.parentRegionName = "CM";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=CMGetSuccessInit subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		WeatherSystem.WC.postInit();baseClass.currClient.useNewWthr();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_CMAfterPostInit:
				
				
				
				CMWaitClientUseInitBefore_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=CMWaitClientUseInitBefore subtype=take
	*/
	private void CMWaitClientUseInitBefore_Taken() {
		
		AState target = new State_CMWaitClientUseInit(this.baseClass);
		
		this.parentRegion.processTransition("CM", target);
	}
	
	
}