/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

import java.util.*;

public class WeatherSystem {

	public static WC WC = new WC();
	public static CM CM = new CM();
	public static ArrayList AllClients = new ArrayList();

	

}