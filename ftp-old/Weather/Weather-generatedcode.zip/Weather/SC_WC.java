/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

import java.util.*;

/**
* @model type=statechart name=WC
*/
public class SC_WC {
	private Region_WC region;
	private LinkedList eventQueue = new LinkedList();
	private boolean isProcessing = false;
	
	public SC_WC(WC baseClass) {
		baseClass.statechart = this;
		region = new Region_WC(baseClass);
		region.entryActivity();
	}
	
	public void trigger(Events event) {
		eventQueue.add(event);
		if(!isProcessing) {
			processEvent();
		}
	}
	
	private void processEvent() {
		isProcessing = true;
		while(!eventQueue.isEmpty()) {
			Events currentEvent = (Events)eventQueue.removeFirst();
			this.region.trigger(currentEvent);
		}
		isProcessing = false;
	}
}