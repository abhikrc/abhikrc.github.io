/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;


public class WC {


	//The associated statechart
	public SC_WC statechart;

	public void gen_event(Events event) {
		this.statechart.trigger(event);
	}
	
	
	
	
	/**
	* @model type=trigger name=WCPreInit
	*/	
	
	public void preInit() {
		
		
		
		Events events = new Events(Events.EVENT_WCPreInit);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=WCInit
	*/	
	
	public void init() {
		
		
		
		Events events = new Events(Events.EVENT_WCInit);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=WCDone
	*/	
	
	public void done() {
		
		
		
		Events events = new Events(Events.EVENT_WCDone);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=WCPostInit
	*/	
	
	public void postInit() {
		
		
		
		Events events = new Events(Events.EVENT_WCPostInit);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=WCPreUpdate
	*/	
	
	public void preUpdate() {
		
		
		
		Events events = new Events(Events.EVENT_WCPreUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=WCUpdate
	*/	
	
	public void update() {
		
		
		
		Events events = new Events(Events.EVENT_WCUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=WCPostUpdate
	*/	
	
	public void postUpdate() {
		
		
		
		Events events = new Events(Events.EVENT_WCPostUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=WCPostRevert
	*/	
	
	public void postRevert() {
		
		
		
		Events events = new Events(Events.EVENT_WCPostRevert);
		
		gen_event(events);
		
	}
	

	
	/**
	* @model type=class name=WC
	*/
	
	
	
	public  WC() {
		
		statechart = new SC_WC(this);
		
		
		
	}
	


}