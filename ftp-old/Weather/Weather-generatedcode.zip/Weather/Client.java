/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;


public class Client {


	//The associated statechart
	public SC_Client statechart;

	public void gen_event(Events event) {
		this.statechart.trigger(event);
	}
	
	
	
	
	/**
	* @model type=trigger name=ClientPreInit
	*/	
	
	public void preInit() {
		
		
		
		Events events = new Events(Events.EVENT_ClientPreInit);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientGetNewWthr
	*/	
	
	public void getNewWthr() {
		
		
		
		Events events = new Events(Events.EVENT_ClientGetNewWthr);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientGetSuccess
	*/	
	
	public void getSuccess() {
		
		
		
		Events events = new Events(Events.EVENT_ClientGetSuccess);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientGetFail
	*/	
	
	public void getFail() {
		
		
		
		Events events = new Events(Events.EVENT_ClientGetFail);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientDisconnect
	*/	
	
	public void disconnect() {
		
		
		
		Events events = new Events(Events.EVENT_ClientDisconnect);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientPreUpdate
	*/	
	
	public void preUpdate() {
		
		
		
		Events events = new Events(Events.EVENT_ClientPreUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientUseNewWthr
	*/	
	
	public void useNewWthr() {
		
		
		
		Events events = new Events(Events.EVENT_ClientUseNewWthr);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientUseSuccess
	*/	
	
	public void useSuccess() {
		
		
		
		Events events = new Events(Events.EVENT_ClientUseSuccess);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientUseFail
	*/	
	
	public void useFail() {
		
		
		
		Events events = new Events(Events.EVENT_ClientUseFail);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientDone
	*/	
	
	public void done() {
		
		
		
		Events events = new Events(Events.EVENT_ClientDone);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=ClientUseOldWthr
	*/	
	
	public void useOldWthr() {
		
		
		
		Events events = new Events(Events.EVENT_ClientUseOldWthr);
		
		gen_event(events);
		
	}
	

	
	/**
	* @model type=class name=Client
	*/
	
	
	
	public  Client() {
		
		statechart = new SC_Client(this);
		
		
		
	}
	


}