/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=region name=WC
*/
public class Region_WC extends ARegion {
	public WC baseClass;

	public Region_WC(WC baseClass) {
		this.elementName = "WC";
		this.baseClass = baseClass;
		
		
		AState currState = new State_WCDone(this.baseClass);
		this.activeState = currState;
		currState.parentRegion = this;
		
	}

	public Region_WC(WC baseClass, AState[] children) {
		this.elementName = "WC";
		this.baseClass = baseClass;
		
		for(int i=0; i<children.length; i++) {
			if(children[i].parentRegionName.equals(this.elementName)) {
				this.activeState = children[i];
				children[i].parentRegion = this;
				this.isEnterByDefault = false;
				break;
			}
		}
		if(this.isEnterByDefault) {
			
			AState currState = new State_WCDone(this.baseClass);
			this.activeState = currState;
			currState.parentRegion = this;
			
		}
	}
	
	public void entryActivity() {
		if(this.isEnterByDefault) {
			defaultActivity();
		}
		this.activeState.entryActivity();
	}

	
	/**
	* @model type=region name=WC subtype=defaultaction
	*/
	
	private void defaultActivity() {
		
	}
	
	public void trigger(Events event) {
		this.activeState.trigger(event);
	}
}