/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=region name=CM
*/
public class Region_CM extends ARegion {
	public CM baseClass;

	public Region_CM(CM baseClass) {
		this.elementName = "CM";
		this.baseClass = baseClass;
		
		
		AState currState = new State_CMDefault(this.baseClass);
		this.activeState = currState;
		currState.parentRegion = this;
		
	}

	public Region_CM(CM baseClass, AState[] children) {
		this.elementName = "CM";
		this.baseClass = baseClass;
		
		for(int i=0; i<children.length; i++) {
			if(children[i].parentRegionName.equals(this.elementName)) {
				this.activeState = children[i];
				children[i].parentRegion = this;
				this.isEnterByDefault = false;
				break;
			}
		}
		if(this.isEnterByDefault) {
			
			AState currState = new State_CMDefault(this.baseClass);
			this.activeState = currState;
			currState.parentRegion = this;
			
		}
	}
	
	public void entryActivity() {
		if(this.isEnterByDefault) {
			defaultActivity();
		}
		this.activeState.entryActivity();
	}

	
	/**
	* @model type=region name=CM subtype=defaultaction
	*/
	
	private void defaultActivity() {
		
	}
	
	public void trigger(Events event) {
		this.activeState.trigger(event);
	}
}