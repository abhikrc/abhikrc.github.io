/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=events
*/
public class Events {
	public static final int EVENT_WCPreInit=0;
	public static final int EVENT_WCInit=1;
	public static final int EVENT_WCDone=2;
	public static final int EVENT_WCPostInit=3;
	public static final int EVENT_WCPreUpdate=4;
	public static final int EVENT_WCUpdate=5;
	public static final int EVENT_WCPostUpdate=6;
	public static final int EVENT_WCPostRevert=7;
	public static final int EVENT_CMConnect=8;
	public static final int EVENT_CMAfterPreInit=9;
	public static final int EVENT_CMAfterInit=10;
	public static final int EVENT_CMClientUseResultYes=11;
	public static final int EVENT_CMClientUseResultNo=12;
	public static final int EVENT_CMAfterPostInit=13;
	public static final int EVENT_CMAfterPreUpdate=14;
	public static final int EVENT_CMAfterUpdate=15;
	public static final int EVENT_CMAfterPostUpdate=16;
	public static final int EVENT_CMAfterPostRevert=17;
	public static final int EVENT_CMPerformUpdate=18;
	public static final int EVENT_CMProgress=19;
	public static final int EVENT_CMClientGetResultYes=20;
	public static final int EVENT_CMClientGetResultNo=21;
	public static final int EVENT_ClientPreInit=22;
	public static final int EVENT_ClientGetNewWthr=23;
	public static final int EVENT_ClientGetSuccess=24;
	public static final int EVENT_ClientGetFail=25;
	public static final int EVENT_ClientDisconnect=26;
	public static final int EVENT_ClientPreUpdate=27;
	public static final int EVENT_ClientUseNewWthr=28;
	public static final int EVENT_ClientUseSuccess=29;
	public static final int EVENT_ClientUseFail=30;
	public static final int EVENT_ClientDone=31;
	public static final int EVENT_ClientUseOldWthr=32;

	public int event = -1;
	
	public Events(int v) {
		this.event = v;
	}
	
	Object parameter = null;
}