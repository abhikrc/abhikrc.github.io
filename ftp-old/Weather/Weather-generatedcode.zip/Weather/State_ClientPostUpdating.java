/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=state name=ClientPostUpdating
*/
public class State_ClientPostUpdating extends AState {
	private Client baseClass;
	
	public State_ClientPostUpdating (Client baseClass) {
		this.parentRegionName = "Client";
		this.baseClass = baseClass;

		
	}
	
	public State_ClientPostUpdating (Client baseClass, AState[] children) {
		this.parentRegionName = "Client";
		this.baseClass = baseClass;		

		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_ClientUseFail:
				
				
				
				ClientFailedUseUpdBefore_Taken();
				
				
				
				break;
			
			case Events.EVENT_ClientUseSuccess:
				
				
				
				ClientSuccessedUseUpdBefore_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=ClientFailedUseUpdBefore subtype=take
	*/
	private void ClientFailedUseUpdBefore_Taken() {
		
		AState target = new State_ClientFailedUseUpd(this.baseClass);
		
		this.parentRegion.processTransition("Client", target);
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=ClientSuccessedUseUpdBefore subtype=take
	*/
	private void ClientSuccessedUseUpdBefore_Taken() {
		
		AState target = new State_ClientSuccessedUseUpd(this.baseClass);
		
		this.parentRegion.processTransition("Client", target);
	}
	
	
}