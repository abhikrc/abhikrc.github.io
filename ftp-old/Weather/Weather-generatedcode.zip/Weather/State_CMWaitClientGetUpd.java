/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=state name=CMWaitClientGetUpd
*/
public class State_CMWaitClientGetUpd extends AState {
	private CM baseClass;
	
	public State_CMWaitClientGetUpd (CM baseClass) {
		this.parentRegionName = "CM";
		this.baseClass = baseClass;

		
	}
	
	public State_CMWaitClientGetUpd (CM baseClass, AState[] children) {
		this.parentRegionName = "CM";
		this.baseClass = baseClass;		

		
	}
	
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_CMClientGetResultNo:
				
				
				
				CMWaitClientGetUpdResultNo_Taken();
				
				
				
				break;
			
			case Events.EVENT_CMClientGetResultYes:
				
				
				CMWaitClientGetUpdResultYes_Action(event.parameter);
				
				
				if(CMWaitClientGetUpdResultCompletechoice_Condition()) {
					
					CMWaitClientGetUpdResultCompletechoice_Taken();
				} else
				
				{
				
					
					
					CMWaitClientGetUpdResultNotCompletechoice_Taken();
				
				}
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=CMWaitClientGetUpdResultNo subtype=take
	*/
	private void CMWaitClientGetUpdResultNo_Taken() {
		
		AState target = new State_CMProgressGet(this.baseClass);
		
		this.parentRegion.processTransition("CM", target);
	}
	
	
	
	/**
	* @model type=transition name=CMWaitClientGetUpdResultYes subtype=action
	*/
	private void CMWaitClientGetUpdResultYes_Action(Object parameter) {
		baseClass.msgRcvCount++;
	}
	
	
	
	
	
	/**
	* @model type=transition name=CMWaitClientGetUpdResultCompletechoice subtype=condition
	*/
	private boolean CMWaitClientGetUpdResultCompletechoice_Condition() {
		return baseClass.msgRcvCount>=WeatherSystem.AllClients.size();
	}
	/**
	* @model type=transition name=CMWaitClientGetUpdResultCompletechoice subtype=take
	*/
	private void CMWaitClientGetUpdResultCompletechoice_Taken() {
		
		AState target = new State_CMPostUpdating(this.baseClass);
		
		this.parentRegion.processTransition("CM", target);
	}
	
	
	
	
	
	/**
	* @model type=transition name=CMWaitClientGetUpdResultNotCompletechoice subtype=take
	*/
	private void CMWaitClientGetUpdResultNotCompletechoice_Taken() {
		
		AState target = new State_CMWaitClientGetUpd(this.baseClass);
		
		this.parentRegion.processTransition("CM", target);
	}
	
	
	
	
}