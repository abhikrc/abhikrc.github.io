/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;


public class CM {

	public int msgRcvCount = 0;
	public int numClients = 0;
	public Client currClient;

	//The associated statechart
	public SC_CM statechart;

	public void gen_event(Events event) {
		this.statechart.trigger(event);
	}
	
	
	
	
	/**
	* @model type=trigger name=CMConnect
	*/	
	
	public void connect(Client client) {
		
		
		
		Events events = new Events(Events.EVENT_CMConnect);
		
		events.parameter = client;
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMAfterPreInit
	*/	
	
	public void afterPreInit() {
		
		
		
		Events events = new Events(Events.EVENT_CMAfterPreInit);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMAfterInit
	*/	
	
	public void afterInit() {
		
		
		
		Events events = new Events(Events.EVENT_CMAfterInit);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMClientUseResultYes
	*/	
	
	public void clientUseResultYes() {
		
		
		
		Events events = new Events(Events.EVENT_CMClientUseResultYes);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMClientUseResultNo
	*/	
	
	public void clientUseResultNo() {
		
		
		
		Events events = new Events(Events.EVENT_CMClientUseResultNo);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMAfterPostInit
	*/	
	
	public void afterPostInit() {
		
		
		
		Events events = new Events(Events.EVENT_CMAfterPostInit);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMAfterPreUpdate
	*/	
	
	public void afterPreUpdate() {
		
		
		
		Events events = new Events(Events.EVENT_CMAfterPreUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMAfterUpdate
	*/	
	
	public void afterUpdate() {
		
		
		
		Events events = new Events(Events.EVENT_CMAfterUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMAfterPostUpdate
	*/	
	
	public void afterPostUpdate() {
		
		
		
		Events events = new Events(Events.EVENT_CMAfterPostUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMAfterPostRevert
	*/	
	
	public void afterPostRevert() {
		
		
		
		Events events = new Events(Events.EVENT_CMAfterPostRevert);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMPerformUpdate
	*/	
	
	public void performUpdate() {
		
		
		
		Events events = new Events(Events.EVENT_CMPerformUpdate);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMProgress
	*/	
	
	public void progress() {
		
		
		
		Events events = new Events(Events.EVENT_CMProgress);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMClientGetResultYes
	*/	
	
	public void clientGetResultYes() {
		
		
		
		Events events = new Events(Events.EVENT_CMClientGetResultYes);
		
		gen_event(events);
		
	}
	

	
	
	
	/**
	* @model type=trigger name=CMClientGetResultNo
	*/	
	
	public void clientGetResultNo() {
		
		
		
		Events events = new Events(Events.EVENT_CMClientGetResultNo);
		
		gen_event(events);
		
	}
	

	
	/**
	* @model type=class name=CM
	*/
	
	
	
	public  CM() {
		
		statechart = new SC_CM(this);
		
		
		
	}
	


}