/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=state name=WCPostInit
*/
public class State_WCPostInit extends AState {
	private WC baseClass;
	
	public State_WCPostInit (WC baseClass) {
		this.parentRegionName = "WC";
		this.baseClass = baseClass;

		
	}
	
	public State_WCPostInit (WC baseClass, AState[] children) {
		this.parentRegionName = "WC";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=WCPostInit subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		WeatherSystem.CM.afterPostInit();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_WCDone:
				
				
				
				WCPostInitDone_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=WCPostInitDone subtype=take
	*/
	private void WCPostInitDone_Taken() {
		
		AState target = new State_WCDone(this.baseClass);
		
		this.parentRegion.processTransition("WC", target);
	}
	
	
}