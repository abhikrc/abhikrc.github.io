/**
* This class is generated automatically.
* Created on: Sep 17, 2007 6:23:40 PM
*/

package Weather;

/**
* @model type=state name=ClientSuccessedGetUpd
*/
public class State_ClientSuccessedGetUpd extends AState {
	private Client baseClass;
	
	public State_ClientSuccessedGetUpd (Client baseClass) {
		this.parentRegionName = "Client";
		this.baseClass = baseClass;

		
	}
	
	public State_ClientSuccessedGetUpd (Client baseClass, AState[] children) {
		this.parentRegionName = "Client";
		this.baseClass = baseClass;		

		
	}
	
	
	/**
	* @model type=state name=ClientSuccessedGetUpd subtype=entry
	*/
	
	public void entryActivity() {
		//start execute entry activity from composite state down to its substates
		//in-state event (if any) is generated in the same sequence and after entry activity
		//this method should only be called by the composite state
		//when entering itself or its sub-state
		WeatherSystem.CM.clientGetResultYes();
		
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.entryActivity();
		}
	}

	
	public void exitActivity() {
		for(int i=0; i<this.regions.size(); i++) {
			ARegion r = (ARegion)this.regions.get(i);
			r.activeState.exitActivity();
		}
		
	}

	public void trigger(Events event)
	{
		switch(event.event) {
			
			case Events.EVENT_ClientUseNewWthr:
				
				
				
				ClientPostUpdatingBefore_Taken();
				
				
				
				break;
			
			case Events.EVENT_ClientUseOldWthr:
				
				
				
				ClientSuccessedGetUpd2Revert_Taken();
				
				
				
				break;
			
			default:
				for(int i=0; i<this.regions.size(); i++) {
					ARegion r = (ARegion)this.regions.get(i);
					r.trigger(event);
				}
		}
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=ClientPostUpdatingBefore subtype=take
	*/
	private void ClientPostUpdatingBefore_Taken() {
		
		AState target = new State_ClientPostUpdating(this.baseClass);
		
		this.parentRegion.processTransition("Client", target);
	}
	
	
	
	
	
	
	
	/**
	* @model type=transition name=ClientSuccessedGetUpd2Revert subtype=take
	*/
	private void ClientSuccessedGetUpd2Revert_Taken() {
		
		AState target = new State_ClientPostReverting(this.baseClass);
		
		this.parentRegion.processTransition("Client", target);
	}
	
	
}