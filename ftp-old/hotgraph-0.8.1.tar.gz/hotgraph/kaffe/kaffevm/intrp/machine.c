 /* 
 * machine.c
 * Java virtual machine interpreter.
 *  
 * Copyright (c) 1996, 1997
 *	Transvirtual Technologies, Inc.  All rights reserved.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file.
 */  

#include "debug.h"
#define	CDBG(s) 	DBG(INT_VMCALL, s)
#define	RDBG(s) 	DBG(INT_RETURN, s)
#define	NDBG(s) 	DBG(INT_NATIVE, s)
#define	IDBG(s)		DBG(INT_INSTR, s)
#define	CHDBG(s)	DBG(INT_CHECKS, s)

#include "config.h" 
#include "config-std.h"
#include "config-math.h"
#include "config-mem.h"
#include "config-setjmp.h"
#include "classMethod.h"
#include "gtypes.h"
#include "bytecode.h"
#include "slots.h"
#include "icode.h"
#include "access.h"
#include "object.h"
#include "constants.h"
#include "gc.h"
#include "machine.h"
#include "lookup.h"
#include "code-analyse.h"
#include "soft.h"
#include "exception.h"
#include "external.h"
#include "baseClasses.h"
#include "thread.h"
#include "jthread.h"
#include "locks.h"
#include "checks.h"
#include "errors.h"
#include "md.h"
#include "trace.h"
//#include "accessfields.h"
#include "java_lang_reflect_Field.h"

void dumpTrace(void);
int findName(Utf8Const**, Utf8Const*, int*);
extern Utf8Const **classNameList,  **sigList;
extern int classNameCount, sigCount;
extern call_frame *tracingCallStack;
extern inst_info multiNewInfo;

void insertStaticField(int classid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc);
void insertObjectField(int objectid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc);
void insertArrayElement(int objectid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc);
int getStaticFieldDefine(int classid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc);
int getObjectFieldDefine(int objectid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc);
int getArrayElementDefine(int objectid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc);
void createReturnEdge(struct _method_trace* fromTrace, int frompc, struct _method_trace* toTrace, int topc);

/*
 * Define information about this engine.
 */
char* engine_name = "Interpreter";
char* engine_version = KVER;

#define	define_insn(code)	break;					\
				case code:				\
				IDBG( dprintf("%03d: %s\n", pc, #code); )
#define	define_insn_alias(code)	case code:				\
				IDBG( dprintf("%03d: %s\n", pc, #code); )
#define	define_wide_insn(code)	break;					\
				case code:				\
				IDBG( dprintf("%03d: %s\n", pc, #code); )

#define EXPLICIT_CHECK_NULL(_i, _s, _n)                       \
      cbranch_ref_const_ne((_s), 0, reference_label(_i, _n)); \
      softcall_nullpointer();                                 \
      set_label(_i, _n)
/* Define CREATE_NULLPOINTER_CHECKS in md.h when your machine cannot use the
 * MMU for detecting null pointer accesses */
#if defined(CREATE_NULLPOINTER_CHECKS)
#define CHECK_NULL(_i, _s, _n)                                  \
    EXPLICIT_CHECK_NULL(_i, _s, _n)
#else
#define CHECK_NULL(_i, _s, _n)
#endif

/* For JIT3 compatibility */
#define check_array_store(a,b)		softcall_checkarraystore(a,b)
#define explicit_check_null(x,obj,y)	EXPLICIT_CHECK_NULL(x,obj,y)
#define check_null(x,obj,y)		CHECK_NULL(x,obj,y)
#define check_div(x,obj,y)
#define check_div_long(x,obj,y)


#if defined(KAFFE_PROFILER)
int profFlag;			 /* flag to control profiling */
#endif 
 

extern int traceMultiArrayAllocation;
//extern int enterLib;
extern int creatingInternalException; // by GL
extern int startTracing;

#ifdef CollectFlowTrace
extern FILE *collectedflowTrace;
#endif

void endTracing(void);
int performSlicing(void);
extern int ifTracingAndSlicing;

//if we are entering catch block, we should avoid to push a new call frame for tracing
int inException = 0; // by GL

extern int* defineclassid;
extern int* definemethodid;
extern int* definesigid;
extern int* definepc;

/******** compact trace ***********/

void runVirtualMachine(methods *meth, slots *lcl, slots *sp, uintp npc, slots *retval, volatile vmException *mjbuf, Hjava_lang_Thread *tid);
 
void
virtualMachine(methods*volatile meth, slots* volatile arg, slots* volatile retval, Hjava_lang_Thread* volatile tid)
{
	methods *volatile const vmeth = meth;
	Hjava_lang_Object* volatile mobj;
	vmException mjbuf;
	accessFlags methaccflags;

	slots* volatile lcl;
	slots* volatile sp; 
	uintp volatile npc;

	int32 idx;
	jint low;

	errorInfo einfo;
	Hjava_lang_Throwable* overflow;
	jint *needOnStack;

	if (tid != 0)  {
		/* implement stack overflow check */
		needOnStack = &unhand(tid)->needOnStack;

		//dprintf ("needOnStack [%p] %p -> %d\n", &needOnStack, needOnStack, *needOnStack);

		if (jthread_stackcheck(*needOnStack) == false) {
			overflow = (Hjava_lang_Throwable*)
				unhand(tid)->stackOverflowError;
			if (overflow != 0) {
				if (*needOnStack == STACK_LOW) {
					dprintf(
					    "Panic: unhandled StackOverflowError()\n");
					ABORT();
				}
				*needOnStack = STACK_LOW;
				throwException(overflow);
			}
		}
	}   

CDBG(	dprintf("Call: %s.%s%s.\n", meth->class->name->data, meth->name->data, METHOD_SIGD(meth)); )

	/* If this is native, then call the real function */
	methaccflags = meth->accflags;
	if (methaccflags & ACC_NATIVE) {
NDBG(		dprintf("Call to native %s.%s%s.\n", meth->class->name->data, meth->name->data, METHOD_SIGD(meth)); )
		
		if(startTracing)
		{
			int classID= findName(classNameList, meth->class->name, &classNameCount);
			getClassTrace(meth, classID);
		}
		
		if (methaccflags & ACC_STATIC) {
			callMethodA(meth, meth, 0, (jvalue*)arg, (jvalue*)retval, 1);
		}
		else {
			callMethodA(meth, meth, ((jvalue*)arg)[0].l, &((jvalue*)arg)[1], (jvalue*)retval, 1);
		} 
		return;
	}
 
	/* Verify method if required */
	if ((methaccflags & ACC_VERIFIED) == 0) {
		codeinfo* codeInfo;
		bool success = verifyMethod(meth, &codeInfo, &einfo);
		tidyVerifyMethod(&codeInfo);
		if (success == false) {
			throwError(&einfo);
		}
	}

	/* Allocate stack space and locals. */
	lcl = alloca(sizeof(slots) * (meth->localsz + meth->stacksz));

#if defined(DEBUG)
	{
	    int32 *p = (int32 *) &lcl[meth->localsz + meth->stacksz];
	    while (p-- > (int32*)lcl)
		*p = 0x00c0ffee;
	}
#endif

	mobj = 0;
	npc = 0;

	/* If we have any exception handlers we must prepare to catch them.
	 * We also need to catch if we are synchronised (so we can release it).
	 */
	mjbuf.pc = 0;
	mjbuf.mobj = mobj;
	mjbuf.meth = meth;
	mjbuf.instinfo = cleanMalloc(sizeof(inst_info)); // by GL
	if (tid != NULL && unhand(tid)->PrivateInfo != 0) {
		mjbuf.prev = (vmException*)unhand(tid)->exceptPtr;
		unhand(tid)->exceptPtr = (struct Hkaffe_util_Ptr*)&mjbuf;
	}

	if (meth->exception_table != 0) {
		if (JTHREAD_SETJMP(mjbuf.jbuf) != 0) {
			meth = vmeth;
			unhand(tid)->exceptPtr = (struct Hkaffe_util_Ptr*)&mjbuf;
			npc = mjbuf.pc;
			sp = &lcl[meth->localsz];
#if defined(DEBUG)
			{
			    int32 *p = (int32 *) &lcl[meth->localsz + meth->stacksz];
			    while (p-- > (int32*)sp)
				*p = 0xdeadbeef;
			}
#endif
			sp->v.taddr = (void*)unhand(tid)->exceptObj;
			unhand(tid)->exceptObj = 0;
			inException = 1; // by GL
			runVirtualMachine(meth, lcl, sp, npc, retval, &mjbuf, tid);
			goto end;
		}
	}

	/* Calculate number of arguments */
	idx = sizeofSigMethod(meth, false);
	if (idx == -1) {
		throwError(&einfo);
	}
	idx += (methaccflags & ACC_STATIC ? 0 : 1);

	/* Copy in the arguments */
	sp = lcl;
	for (low = 0; low < idx; low++) {
		*(sp++) = *(arg++);
	}

	/* Sync. if required */
	if (methaccflags & ACC_SYNCHRONISED) {
		if (methaccflags & ACC_STATIC) {
			mobj = &meth->class->head;
		}
		else {
			mobj = (Hjava_lang_Object*)lcl[0].v.taddr;
		}
		/* this lock is safe for Thread.stop() */
		lockObject(mobj);
		/* We must store the object on which we synchronized in
		 * the mjbuf chain or else the exception handler routine
		 * won't find it.
		 */
		mjbuf.mobj = mobj;
	}

	sp = &lcl[meth->localsz - 1]; //base addr of oper stack

	runVirtualMachine(meth, lcl, sp, npc, retval, &mjbuf, tid);
 
 end:
	/* Unsync. if required */
	if (mobj != 0) {
		unlockObject(mobj);
	}
	if (tid != NULL && unhand(tid)->PrivateInfo != 0) {
		unhand(tid)->exceptPtr = (struct Hkaffe_util_Ptr*)mjbuf.prev;
	}

RDBG(	dprintf("Returning from method %s%s.\n", meth->name->data, METHOD_SIGD(meth)); )

}

void runVirtualMachine(methods *meth, slots *lcl, slots *sp, uintp npc, slots *retval, volatile vmException *mjbuf, Hjava_lang_Thread *tid) {
	bytecode *code = (bytecode*)meth->c.bcode.code;
   
	/* Misc machine variables */
	jlong lcc;
	jvalue tmpl;
	slots tmp[1]; 
	slots tmp2[1]; 
	slots mtable[1];

	/* Variables used directly in the machine */
	int32 idx;
	jint low;
	jint high;
 
	/* Call, field and creation information */
	callInfo cinfo;  
	fieldInfo finfo;
	Hjava_lang_Class* crinfo; 
	errorInfo einfo;
   
/*	accessFlags methaccflags;*/  

	inst_info *instInfo = mjbuf->instinfo;
	instInfo->depclassid= defineclassid;
	instInfo->depmethodid= definemethodid;
	instInfo->depsigid= definesigid;
	instInfo->deppc= definepc;
	
	//int traceforerror= 0;
	
	int i, j;  
	  
	int ifsystem;
	int returnsize=0;
	int pushsize=0;
	int popsize=0;
	int depexist=0;
	
	int *hash;  
	method_trace *methodTrace= NULL;
	inst_trace *instTrace= NULL;
	int index;  
	const char *signature;
	short unsigned nargs, *arglist= NULL;
	methods	*callMeth= NULL;
	objectIDEntry *objectId= NULL;
	int currentNeedTracing;

#ifdef CollectFlowTrace
      int lastPC;
#endif

	currentNeedTracing= ifNeedTracing(meth);
 
	if(creatingInternalException==1)//creation process of internal exception is not traced
	{
		currentNeedTracing= 0;
	}
	
#ifdef CollectFlowTrace
	if(startTracing)           
		//fprintf(collectedflowTrace, "currentNeedTracing: %d (%d),%s \n",currentNeedTracing, creatingInternalException, meth->name->data);
#endif
	
	if (currentNeedTracing && inException == 0) // by GL //donot create method if in catch block
	{ 

	    /*if ( reflectCall)
	    {
	      reflectCall=0;
	      reflectCallInfo.operand_num=1;

	      reflectCallInfo.operands[0]= findName(classNameList, meth->class->name, &classNameCount);
	      traceInstruction(&reflectCallInfo);

	      reflectCallInfo.operands[0]= findName(sigList, meth->parsed_sig->signature, &sigCount);
	      traceInstruction(&reflectCallInfo);
	    }*/

		traceMethodCall(meth);

		methodTrace= tracingCallStack->methodTrace;
		hash=methodTrace->hash;
		
		tracingCallStack->spBaseAddr = (int32 *)&lcl[meth->localsz - 1];// by GL
		tracingCallStack->spCurrAddr= (int32 *)sp;// by GL

		if ( (hash[0]&0x80000000) !=0)
		{
		  
			index= (hash[0]&0x7FFFFFFF)-1;
#ifndef _optimize
			if (index== -1)
			{
				printf("error! no instruction trace slot\n"); 
				return;
			}
#endif 
				instTrace= &(methodTrace->instTrace[index]);
				traceControlInfo(instTrace, -1);
			}
	}
	
	if(currentNeedTracing)
	{
		//store the value of currentNeedTracing for current method
		tracingCallStack->needTracing = 1;
	}
	
	if(inException)// by GL
	{
		//execution of catch block
		inException = 0;
		
	}
  
	/* Finally we get to actually execute the machine */
	for (;;) {
	  register uintp pc = npc; 
#ifdef CollectFlowTrace
      lastPC=pc;
#endif

		assert(npc < meth->c.bcode.codelen);
		mjbuf->pc = pc;
		npc = pc + insnLen[code[pc]];		

		if (currentNeedTracing) 
		{
            tracingCallStack->lastPC= pc;
            executedInstCount++;
		}		

		switch (code[pc]) {
		default:
			dprintf("Unknown bytecode %d\n", code[pc]);
			throwException(NEW_LANG_EXCEPTION(VerifyError));
			break;
#include "kaffe.def" 
		}


		if (currentNeedTracing)
		{
		    
#ifdef CollectFlowTrace
            fprintf(collectedflowTrace, "%d:%d,%s \n",executedInstCount, lastPC, bytecodeName[code[lastPC]]);
#endif
			//printf("%d:%d, %s \n",executedInstCount, lastPC, bytecodeName[code[lastPC]]);
 		    //record current oper stack top addr  
			tracingCallStack->spCurrAddr= (int32 *)sp;// by GL
			
			//executedInstCount++;
 

			methodTrace= tracingCallStack->methodTrace;
			hash=methodTrace->hash;
			
			if ( (hash[npc]&0x80000000) !=0)
			{
			  
				index= (hash[npc]&0x7FFFFFFF)-1;
#ifndef _optimize
				if (index== -1)
				{
					printf("error! no instruction trace slot\n");
					return;
				}
#endif 

				instTrace= &(methodTrace->instTrace[index]);
				traceControlInfo(instTrace, tracingCallStack->lastPC);

			}
		} 
	}
  
end:
 
	if (currentNeedTracing)
	{
#ifdef CollectFlowTrace
        fprintf(collectedflowTrace, "%d:%d,%s\n",executedInstCount, lastPC, bytecodeName[code[lastPC]]);
#endif
		//printf("%d:%d, %s \n",executedInstCount, lastPC, bytecodeName[code[lastPC]]);

 		executedInstCount++;
	  	exitMethod(meth, 0);
	}
 	return;
}

/*
 * say what engine we're using
 */
char*
getEngine()
{
	return "kaffe.intr";
}
