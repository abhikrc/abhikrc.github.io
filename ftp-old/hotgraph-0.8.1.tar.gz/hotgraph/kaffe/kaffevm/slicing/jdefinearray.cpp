#include "jdefinearray.h"
#include "slicing.h"
#include "bytecodelist.h"

JDefineArray::JDefineArray(JMethod* meth,int operation, int pc)//, int baseObj, int index=-1): 
:JBytecode(meth, operation, pc, DefineArrayBytecode)
{
	//this->baseObj= baseObj;
//	this->index= index;
}

JDefineArray::~JDefineArray()
{
}
