#ifndef JDEFINESTATIC_H
#define JDEFINESTATIC_H

#include "jbytecode.h"
#include "accessstatic.h"

/**
  *@author wt
  */

class BytecodeList;
class JMethod;

class JDefineStatic : public JBytecode, public AccessStatic
{
private:
	int accessClassNameId;
    int operand;
public: 
    int fieldSize;
	JDefineStatic(JMethod*, int, int, int, int, int);
	~JDefineStatic();
    int getOperand();
    int getClassNameId();
	virtual JMethod *getStaticInit();
};

#endif

