/*
 * native.h
 *
 * store native call information.
 * 
 */

#ifndef __nativeHandle_h
#define __nativeHandle_h

struct _method_trace;
struct _call_frame;

/* structure to store information related to native calls
 * for a bytecode invoking native method, it stores
 * NULL - for the case native method does not call any java method
 * meth1 - for the case native method eventually calls java method: meth1
 */
typedef struct _native_called_method
{
	int 							classID;
	short int						methodID;
	short int						sigID;
	struct _native_called_method 	*prev;
}native_called_method;

//this store a list of java method called in one native call
//i.e. a native call may call several java method sequentially
typedef struct _native_called_method_list
{
	native_called_method				*calledMethod;
	struct _native_called_method_list	*prev;
	int									callFrameLevel;
}native_called_method_list;

typedef struct _native_call
{
	int							pc;
	native_called_method_list	*calledMethods;
	struct _native_call			*prev;
	native_called_method_list	*stack;
}native_call;

/***************
* Example of native call handler: //m*:java methods
* method1()
*	inst 8: //invoke native method
*		first invoke: m1()
*		second invoke: m2(), m3()
*	inst 15:
*		first invoke: m4()
*	inst 20:
*		first invoke: -1
*/

void enterNativeCalledJavaMethod(struct _call_frame *callerFrame, int calleeFrameLevel);
void exitNativeCalledJavaMethod(struct _call_frame *callerFrame, struct _call_frame *calleeFrame, int calleeFrameLevel);
void initNativeCall(struct _method_trace *callerTrace, int lastPC);
void finalizeNativeCall(struct _method_trace *callerTrace, int lastPC);
native_called_method_list* getNativeCalledJavaMethodListForInstruction(struct _method_trace *methodTrace, int pc);
void removeStackTop(struct _method_trace *callerTrace, int lastPC);
void dumpNativeCall(struct _method_trace *methodTrace);

#endif
