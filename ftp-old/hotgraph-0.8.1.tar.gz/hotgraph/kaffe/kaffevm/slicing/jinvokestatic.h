#ifndef JINVOKESTATIC_H
#define JINVOKESTATIC_H

#include "jbytecode.h"
#include "linklist.h"
#include "jmethod.h"
#include "callframe.h"
#include "jclass.h"
#include "accessstatic.h"

class Signature;
class BytecodeList;


class JInvokeStatic: public JBytecode, public AccessStatic
{
	int classNameId;
	int methodNameId;
	int methodSigId;
	Signature *signature;	
	LinkList<JMethod*> invokeMethod;
	JMethod *staticInit;
    int *argsUseOperNum;
    int *argsLocalVarPos;        
    int argsNum;
    int allArgsUseOperNum;
    int defOperNum;
    JClass* getInvokeJClass();

public:
	native_called_method_list *javaMethods;//by GL //the java method transitively called
	native_called_method_list* getNextNativeCalledMethodList();
	Signature* getSig();
	int getArgsCount();
	JInvokeStatic(JMethod*, int, int, int, int, int, const char*);
	~JInvokeStatic();
	LinkList<JMethod*>* getInvokeMethod();
	void initCalls();
	void dumpCallGraph();
	virtual JMethod* getStaticInit();
  	void setnUseOperNum(int, int);
	int getnUseOperNum(int);
    void setDefOperNum(int);
	int getDefOperNum();
    int getAllArgsUseOperNum();    
    int getnArgsLocalPos(int);
};

#endif //JINVOKESTATIC_H

