#ifndef JCOMMON_H
#define JCOMMON_H

#include "jbytecode.h"

class JMethod;
class BytecodeList;

class JCommon: public JBytecode 
{
public:
	virtual void dumpType();
	JCommon(JMethod*, int, int);
	~JCommon();

};

#endif 
