/***************************************************************************
                          jbytecoderef.h  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef JBYTECODEREF_H
#define JBYTECODEREF_H


/**
  *@author wt
  */
class JBytecode;
  
class JBytecodeRef {
private:
    JBytecode* bytecode;
    JBytecodeRef *next, *prev;
public: 
	int hasNext();
	JBytecodeRef();
	void around();
	void append(JBytecodeRef*);
    JBytecodeRef(JBytecode*);
    ~JBytecodeRef();
    JBytecode* getBytecode();
    JBytecodeRef* getNext();
    JBytecodeRef* getPrev();
    void connect(JBytecodeRef *ref);
};

#endif
