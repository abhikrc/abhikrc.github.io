#include "btree.h"
#include "string.h"
#include <assert.h>

int check(BTreeNodeType *n, int *low, int *high);
/*

main()
{
	int *inputKey, **input;
	int i;

	inputKey=(int *)malloc(sizeof(int)*N);
	input= (int**)malloc(sizeof(int*)*N);

	inputKey[0]=0;
	inputKey[1]=1;
	inputKey[2]=3;
	inputKey[3]=6;
	inputKey[4]=10;
	inputKey[5]=12;
	inputKey[6]=15;
	inputKey[7]=19;
	inputKey[8]=20;
	inputKey[9]=22;
	inputKey[10]=25;
	inputKey[11]=29;
	inputKey[12]=31;
	inputKey[13]=34;
	inputKey[14]=38;


	for(i=0; i<N; i++)
	{
		inputKey[i]= rand();
		input[i]= (int*)malloc(sizeof(int));
		*input[i]= inputKey[i];
	}

	tree= createNewNode(LeafNode);
	int low, high;

	for (i=0; i<N; i++)
	{
		
		insertNode(&tree, inputKey[i], input[i]);
//		printf("insert %d\n", inputKey[i]);
//		printf("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
//		outputTree(tree);
		check(tree, &low, &high);
	}
//	outputTree(tree);

	for(i=0; i<N; i++)
	{
		deleteNode(&tree, inputKey[i], input[i]);
		//printf("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
		//outputTree(tree);
		check(tree, &low, &high);
	}

	return 1;
}
*/
/*void treeError()
{
	printf("tree error\n");
	outputTree(tree);
	exit(1);
}

int check(Node *n, int *low, int *high)
{
	int nextLow, nextHigh;
	int nextLow1, nextHigh1;
	int i;

	if (n->type == InternalNode)
	{
		if (n->count<0 || n->count>FANOUT)
			treeError();

		if (n->count == 0 )
		{
			*low= *high= -1;
			return 1;
		}

		for(i=0; i<n->count-1; i++)
		{
			if (n->key[i]>= n->key[i+1])
			{
				treeError();
			}
		}

		if ( ((Node *)(n->child[0]))->parent!= n)
			treeError();

		check((Node *)(n->child[0]), &nextLow, &nextHigh);
		*low= nextLow;

		if (((Node *)(n->child[0]))->count!= 0 && (nextLow>= n->key[0] || nextHigh>= n->key[0]))
			treeError();

		for(i=0; i<n->count-1; i++)
		{
			if ( ((Node *)n->child[i+1])->parent!= n)
				treeError();

			check((Node *)(n->child[i+1]), &nextLow1, &nextHigh1);
			if (((Node *)(n->child[i+1]))->count!= 0  && 
				(( nextLow1!= -1 && nextLow1< n->key[i]) 
					|| (nextHigh1!= -1 && nextHigh1>=  n->key[i+1])))
				treeError();
		}
		check((Node *)(n->child[n->count]), &nextLow1, &nextHigh1);
		*high= nextHigh1;
		if (((Node *)(n->child[n->count]))->count!= 0 && nextLow1!= -1 && nextLow1< n->key[n->count-1])
		{
			treeError();
		}
	}
	else
	{
		*low= (n->key[0]);
		*high= (n->key[n->count-1]);

		for(i=0; i<n->count-1; i++)
		{
			if (n->key[i]>= n->key[i+1] || n->key[i] != *((int*)(n->child[i+1])))
			{
				treeError();
			}
		}
	}
	return 1;
}
*/



void outputTree(BTreeNode *n)
{
	int i;
	PContent ite;

	printf("this: %x --- parent: %x, %d\n", (unsigned int)n, (unsigned int)(n->parent), n->childCount);

	if (n)
	{
		int childCount= n->childCount;
		if (n->type == InternalNode)
		{
			for (i=0; i<childCount; i++)
			{
				printf("%u ", n->key[i]);
			}
			printf("\n----------------------\n");
			for (i=0; i<=childCount; i++)
			{
				outputTree((BTreeNode *)n->child[i]);
			}
			printf("=======================\n");
		}
		else 
		{
			for (i=0; i<childCount; i++)
			{
				printf("%u:", n->key[i]);
				ite= (PContent)(n->child[i+1]);
				printf("%d %d", ite->op1, ite->op2);
			}			
			printf("\n* * * * * * * * \n");
		}
	}
}

void freeBTreeNode(BTreeNode *root)
{
	int childCount= root->childCount, i;

	if (root->type == InternalNode)
	{
		for (i=0; i<=childCount; i++)
		{
			freeBTreeNode((BTreeNode *)(root->child[i]));
		}
	}
	else
	{
		for(i=0; i<childCount; i++)
			free((PContent)(root->child[i+1]));
	}
	free(root);
}

int getBTreeSize(BTreeNode *n)
{
	int childCount= n->childCount, i, size=0;

	if (n->type == InternalNode)
	{
		for (i=0; i<=childCount; i++)
		{
			size+= getBTreeSize((BTreeNode *)(n->child[i]));
		}
	}
	else
	{
		return n->childCount;
	}
	return size;
}



BTreeNode* createNewBTreeNode(BTreeNodeType type)
{
	BTreeNode *n;

	n = (BTreeNode *)cleanMalloc(sizeof(BTreeNode));
	n->type = type;

	return n;
}

void insertNode(BTreeNode **root, KeyType key, void* p) /* lowerbound <= key <upperbound */
{
	int i, location, childCount;
	BTreeNode *current;

	/*  find the place to insert new entry */
	current = *root;

	while (InternalNode == current->type)
	{
		childCount= location= current->childCount;
		for (i=0; i<childCount; i++)
		{
			if ( key < current->key[i])
			{
				location = i ;
				break;
			}
		}
 		current = (BTreeNode *)(current->child[location]);
	}
	/*  Insert new entry to the tree */
	insertEntry(root, key, p, current);
}

void insertEntry(BTreeNode **root, KeyType key, void *p, BTreeNode *current)
{
	int i;
	KeyType newKey;
	BTreeNode *newNode, *newRoot;

	// move right in case of current entry has been split before insertion

	if (current->childCount < FANOUT)  // there is enough space, simply insert it
	{
		simpleInsert(key, p, current);
	}
	else  // must split
	{
		/* create new node  */
		if (current->type != InternalNode) //  leaf node
		{
			newNode = createNewBTreeNode(LeafNode);
			newKey = current->key[FANOUT/2];

			/* move last [fanout/2] entries to the new node */
			newNode->child[0] = NULL;
			newNode->childCount= FANOUT- FANOUT/2;
			current->childCount= FANOUT/2;

			for (i=FANOUT/2; i<FANOUT; i++)
			{
				newNode->key[i-FANOUT/2] = current->key[i];
				current->key[i] = 0;
				newNode->child[i-FANOUT/2+1] = current->child[i+1];
				current->child[i+1] = NULL;
			}
			/* Insert new entry */
			if (key < newKey)
				simpleInsert(key, p, current);
			else
				simpleInsert(key, p, newNode);
//			Entrycount ++;
		}
		else // non-leaf node
		{
			/* pick up the new key & set the first child of new node*/
			newNode = createNewBTreeNode(InternalNode);
			current->childCount= FANOUT/2;
			newNode->childCount= FANOUT- FANOUT/2-1;

			newKey = current->key[FANOUT/2];
			current->key[FANOUT/2] = 0;
			newNode->child[0] = current->child[FANOUT/2+1];
			((BTreeNode *)(newNode->child[0]))->parent= newNode;
			current->child[FANOUT/2+1] = NULL;
			
			/* move last [fanout/2]-1 entries to the new node and modify parents*/
			for (i=FANOUT/2+1; i<FANOUT; i++)
			{
				newNode->key[i-FANOUT/2-1] = current->key[i];
				current->key[i] = 0;
				newNode->child[i-FANOUT/2] = current->child[i+1];
				((BTreeNode *)(current->child[i+1]))->parent= newNode;				
				/*
				do not need this parent pointer if using recursive algorithm,
				therefore, we did not consider its cost here
				*/
				current->child[i+1] = NULL;				
			}

			/* Insert new entry */
			if (key < newKey)
				simpleInsert(key, p, current);	
			else
				simpleInsert(key, p, newNode);
			//Entrycount ++;
		}
		
		/* adjust right link */
#ifdef wt_debug
		newNode->right = current->right;
		current->right = newNode;
#endif
		/* back up to the parents */
		
		if (current->parent != NULL) // not root level
		{
			insertEntry(root, newKey, (void *)newNode, current->parent);
		}
		else  // root level
		{
			newRoot = createNewBTreeNode(InternalNode);
			
			newRoot->childCount = 1;
			newRoot->key[0] = newKey;
			newRoot->child[0] = current;
			newRoot->child[1] = newNode;
			current->parent = newRoot;
			newNode->parent = newRoot;
			*root = newRoot;		
		}
	}
}


void simpleInsert(KeyType key, void *p, BTreeNode *current)
{
	int i, location, childCount;

	childCount= location = current->childCount;
	for (i=0; i<childCount; i++)
	{
		if ( key < current->key[i])
		{
			location = i;
			break;
		}
		else
		{
			if ( key == current->key[i] && InternalNode != current->type )
			{
				((PContent)(current->child[i+1]))->count += ((PContent)p)->count;
				free((PContent)p);
				return;
			}
		}

	}

	for (i=childCount; i>location; i--)
	{
		current->key[i] = current->key[i-1];
		current->child[i+1] = current->child[i];			
	}

	current->key[location] = key;

	if ( InternalNode == current->type )
	{
		current->child[location+1] = p;
		((BTreeNode *)p)->parent= current;		
	}
	else
	{
		current->child[location+1] = p;
	}
	current->childCount ++;
}


// if deleteType is 1, consider the count in Content, if is it 0, do not consider
int simpleDelete(KeyType key, void *p, BTreeNode *current, int count)
{
	int i, j, childCount, ret;

	childCount= current->childCount;

	for (i=0; i<childCount; i++)
	{
		if (key == current->key[i])
		{
			if (InternalNode != current->type)
			{
				ret= ((PContent)(current->child[i+1]))->count;
				
				((PContent)(current->child[i+1]))->count-= count;

				if ( count==0 || (((PContent)(current->child[i+1]))->count <= 0))
				{
					free((PContent)(current->child[i+1]));
					current->key[i] = 0;
					for (j=i+1; j<childCount; j++)
					{
						current->key[j-1] = current->key[j];
						current->child[j] = current->child[j+1];
					}
					current->childCount --;					
				}
				return ret;
			}
			else
			{
				current->key[i] = 0;
				for (j=i+1; j<childCount; j++)
				{
					current->key[j-1] = current->key[j];
					current->child[j] = current->child[j+1];
				}
				current->childCount --;
				return 1;
			}

		}
	}

	return 0;
}

int deleteNode(BTreeNode **root, KeyType key, void *p, int count)
{
	int i, location, childCount, ret; 
	BTreeNode *current;
	
	/*  find the leaf node that contains p */
	current = *root;
	while (InternalNode == current->type)
	{
		childCount= location = current->childCount;
		for (i=0; i<childCount; i++)
		{
			if (key < current->key[i])
			{
				location = i ;
				break;
			}
		}
 		current = (BTreeNode *)current->child[location];				
	}

	ret= deleteEntry(root, key, p, current, count);

	if (*root == NULL)
		*root = createNewBTreeNode(LeafNode);

	return ret;
}

int deleteEntry(BTreeNode **root, KeyType key, void *p, BTreeNode *current, int count)
{
	int i, location, left, right, ok, ret;
	BTreeNode *left_sibling, *right_sibling;
	BTreeNode *parent;

	ret= simpleDelete(key, p, current, count);
	if (!ret)
		return 0;
	
	// modify the root if necessary 
	if (current->parent == NULL)
	{
		if (current->childCount == 0 && InternalNode == current->type ) // only one child
		{
			*root = (BTreeNode *)current->child[0];
			assert(*root!=NULL);
			if (*root)
				(*root)->parent = NULL;
			free(current);
		}
	}
	else 
	{
		if (current->childCount < FANOUT/2) // underflow
		{
			ok = 0;
			//find siblings
			parent = (BTreeNode*)current->parent;
			location = parent->childCount;
			for (i=0; i<parent->childCount; i++)
			{
				if (key < parent->key[i])
				{
					location = i;
					break;
				}
			}
			left = location -1; // key place
			right = location;

			/* try left sibling */
			if (left >=0)
				left_sibling = (BTreeNode *)parent->child[left];
			else 
				left_sibling = NULL;

			if (left_sibling != NULL && left_sibling->childCount + current->childCount <=FANOUT-1)
			{
				// merge two nodes
				if (current->type == InternalNode) // non leaf node
				{
					left_sibling->key[left_sibling->childCount] = parent->key[left];
					for (i=0; i<current->childCount; i++)
					{
						left_sibling->key[left_sibling->childCount+i+1] = current->key[i];
						left_sibling->child[left_sibling->childCount+i+1] = current->child[i];
						((BTreeNode *)(current->child[i]))->parent = left_sibling;  // better to use recursive way
					}
					left_sibling->childCount += 1 + current->childCount;
					left_sibling->child[left_sibling->childCount] = current->child[current->childCount];
					 ((BTreeNode *)(current->child[current->childCount]))->parent= left_sibling;  
				}
				else
				{
					for (i=0; i<current->childCount; i++)
					{
						left_sibling->key[left_sibling->childCount+i] = current->key[i];
						left_sibling->child[left_sibling->childCount+i+1] = current->child[i+1];
					}
					left_sibling->childCount +=current->childCount;
				}

			 
				deleteEntry(root, parent->key[left], (void *)current, parent, count);
				free(current);
				ok = 1;
			}
			else /* try right sibling */
			{
				if (right < parent->childCount)
					right_sibling = (BTreeNode *)parent->child[right+1];
				else 
					right_sibling = NULL;
				if (right_sibling != NULL && right_sibling->childCount + current->childCount <=FANOUT-1)
				{
					// merge two nodes
					if (current->type== InternalNode) // non leaf node
					{
						current->key[current->childCount] = parent->key[right];
						for (i=0; i<right_sibling->childCount; i++)
						{
							current->key[current->childCount+i+1] = right_sibling->key[i];
							current->child[current->childCount+i+1] = right_sibling->child[i];
							((BTreeNode *)(right_sibling->child[i]))->parent= current;  
						}
						current->childCount += 1 + right_sibling->childCount;
						current->child[current->childCount] = right_sibling->child[right_sibling->childCount];
						((BTreeNode *)(right_sibling->child[right_sibling->childCount]))->parent = current;  
					}
					else
					{
						for (i=0; i<right_sibling->childCount; i++)
						{
							current->key[current->childCount+i] = right_sibling->key[i];
							current->child[current->childCount+i+1] = right_sibling->child[i+1];
						}
						current->childCount += right_sibling->childCount;
					}
					//modify right link
					deleteEntry(root, parent->key[right], (void *)right_sibling, parent, count);
					free(right_sibling);
					ok = 1;
				}
			}
		}
	}
	return ret;
}


int queryNode(BTreeNode *root, KeyType key)
{
	int i, location, childCount;
	BTreeNode *current;

	/*  find the place to insert new entry */
	current = root;

	while (InternalNode == current->type)
	{
		childCount= location= current->childCount;
		for (i=0; i<childCount; i++)
		{
			if ( key < current->key[i])
			{
				location = i ;
				break;
			}
		}
 		current = (BTreeNode *)(current->child[location]);
	}

	childCount= current->childCount;

	for (i=0; i<childCount; i++)
	{
		if ( key == current->key[i])
		{
			return 1;
		}		
	}
	return 0;	
}

