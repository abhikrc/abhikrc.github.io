// JDefineField.h: interface for the JDefineField class.
//
//////////////////////////////////////////////////////////////////////

#ifndef JDEFINEFIELD_H
#define JDEFINEFIELD_H

#include "jbytecode.h"

class BytecodeList;

class JDefineField: public JBytecode
{
private:
	int field;
public:
    int fieldSize;
	int getField();
	JDefineField(JMethod*, int, int, int, int);//, int);
	~JDefineField();

};

#endif 
