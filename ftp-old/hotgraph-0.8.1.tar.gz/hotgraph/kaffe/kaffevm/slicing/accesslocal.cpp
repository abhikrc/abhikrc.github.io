#include "accesslocal.h"

AccessLocal::AccessLocal(int operand)
{
	this->operand= operand;
}

AccessLocal::~AccessLocal()
{
	;
}

void AccessLocal::setOperand(int operand)
{
	this->operand= operand;
}

int AccessLocal::getOperand()
{
	return operand;
}


