#include "slicing.h"
#include "signature.h"


Signature::Signature(const char *sig)
{
	this->sig= sig;
	nargs= countArgsInSig(sig);
	retAndArgs= parseSig(sig, nargs);
}

Signature::~Signature()
{
	free(retAndArgs);
	sig=NULL;
	retAndArgs=NULL;
}

int Signature::countArgsInSig(const char *sig)
{
	int nargs=0;

	while( sizeofSigItem(&sig) != -1)
	{
		++nargs;
	}

	return nargs;
}

int Signature::sizeofSigItem(const char **strp)
{
	int count;
	const char *str;

	for (str = *strp; ;str++)
	{
		count= Signature::sizeofSigChar(*str);
		if (count == -1)
		{
			switch (*str)
			{
				case '(': continue;
				case 0:
				case ')':
					break;
				default:
					count= -1;
					abort();
			}
		}
		else
		{
			while(*str== '[')
				++str;
			if (*str=='L')
			{
				while( (*str)!=';')
				{
					str++;
				}
			}
		}

		*strp= str+1;
		return count;
	}
}

int Signature::sizeofSigChar(const char ch)
{
	switch (ch)
	{
		case '[':
		case 'L':
			return 1;
		case 'I':
		case 'Z':
		case 'S':
		case 'B':
		case 'C':
		case 'F':
			return 1;
		case 'V':
			return 0;
		case 'D':
		case 'J':
			return 2;
	}
	return (-1);
}

int* Signature::parseSig(const char *sig, int nargs)
{
	int *regs, count;
	char ch;
	const char *sig_iter;

	regs= (int *)cleanMalloc(sizeof(int)*(nargs+1));
	sig_iter= &(sig[1]);

	for (count=0; count<nargs; count++)
	{
		ch= sig[(unsigned int)sig_iter - (unsigned int)sig];		
		regs[count+1]= Signature::sizeofSigChar(ch);
		sizeofSigItem(&sig_iter);
	}

	++sig_iter;
	ch= sig[(unsigned int)sig_iter - (unsigned int)sig];
	regs[0]= Signature::sizeofSigChar(ch);

	return (regs);
}


int Signature::getNargs()
{
	return nargs;
}

int Signature::getSizeOfNArgs(int n)
{
	return retAndArgs[n+1];
}

int Signature::getSizeOfRet()
{
	return retAndArgs[0];
}
