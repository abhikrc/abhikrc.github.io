// JLoadArray.h: interface for the JLoadArray class.
//
//////////////////////////////////////////////////////////////////////

#ifndef JLOADARRAY_H
#define JLOADARRAY_H

#include "jbytecode.h"

class BytecodeList;
class JMethod;

class JLoadArray: public JBytecode 
{
public:
	JLoadArray(JMethod *, int, int);
	~JLoadArray();

};

#endif // !defined(AFX_JLOADFIELD_H__B8DB419D_681D_476B_B219_643BFEE3F464__INCLUDED_)
