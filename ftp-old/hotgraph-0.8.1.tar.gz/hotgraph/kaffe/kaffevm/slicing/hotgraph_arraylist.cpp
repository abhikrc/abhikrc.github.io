extern "C"
{
#include "trace.h"
}
#include "stdlib.h"
#include "hotgraph.h"
//#include "hotgraphcomp.h"
#include "buildSCD.h"
#include "arraylist.h"
#include <set>
#include <vector>
#include <new>

using namespace std;

//#include "buildSCD.h"
struct _method_trace;
struct _inst_trace;
struct _class_trace;

class GNode;
class GEdge;

class GNodeComp;
class GEdgeOutgoingComp;
class GEdgeIncomingComp;

//================

bool GNodeComp::operator()(GNode* s1, GNode* s2)
{
	return s1->timestamp > s2->timestamp;
}

bool GEdgeOutgoingComp::operator()(GEdge* e1, GEdge* e2)
	{
		GNode *n1= e1->to;
		GNode *n2= e2->to;
		if(n1->parent < n2->parent)
		{
			return 0 < 1;
		}
		else if(n1->parent > n2->parent)
		{
			return 0 > 1;
		}
		else
		{
			return n1->timestamp < n2->timestamp;
		}
	}

bool GEdgeIncomingComp::operator()(GEdge* e1, GEdge* e2)
	{
		GNode *n1= e1->from;
		GNode *n2= e2->from;
		if(n1->parent < n2->parent)
		{
			return 0 < 1;
		}
		else if(n1->parent > n2->parent)
		{
			return 0 > 1;
		}
		else
		{
			return n1->timestamp < n2->timestamp;
		}
	}


GNode::GNode(GNodeType type, void* p, int t)
{
	nodetype= type;
	parent= p;
	timestamp= t;
}

GNode::GNode()
{
}

GEdge::GEdge()
{
}

GEdge::GEdge(GNode* f, GNode* t)
{
	from= (GNode*)f;
	to= (GNode*)t;
}

//================


vector<GRule> ruleList;
int gRuleCount=0;

void compressNode(GNode* latestNode);
void isIsomorphicGraph(ArrayList<GEdge*> *commonEdges, GNode* ruleRootNode, GNode *latestNode, int similarityMax);
void intersectOutgoingEdges(ArrayList<GEdge*>* common1, ArrayList<GEdge*>* common2, GNode* v1, GNode* v2);
//GRule createRule(GNode v1, GNode v2);
//void substitute(GNode v, GRule rule);
void createEdge(GNode* source, GNode* target);
struct _inst_trace* getInstTrace(method_trace*, int classid, int methodid, int sigid, int pc);
const GNode* getRealDepNode(vector<GNode*>* depSet, const GNode* latestNode);




/*void printTimer(time_t  begin, time_t end)
{
	time_t sec= end- begin;

    printf("used time min: %u, sec: %u, all: %u\n", sec/60, sec%60, sec);
}*/

//*****
//note: the count of bytecode must start from 1 (executedInstCount)
//*****
extern "C" void createNode(int classid, struct _method_trace *methodTrace, int pc, int* defclsid, int* defmethid, int* defsigid, int* defpc, int defsize)
{
	int index= ((methodTrace->hash[pc])&0x7FFFFFFF)-1;
	if(index== -1)
	{
		printf("error: no inst trace slot a\n");
		exit(1);
	}
	struct _inst_trace *instTrace= &(methodTrace->instTrace[index]);
	vector<GNode*> *instSet;
	if(instTrace->instances == NULL)
	{
		instSet= new vector<GNode*>;
		//instSet->clear();
		instTrace->instances= (void*)(instSet);
	}
	else
	{
		instSet= (vector<GNode*> *)instTrace->instances;
	}

	//create node and link to its bytecode
	GNode* latestnode= new GNode(NormalNode, (void*)instTrace, executedInstCount);
	latestnode->containBy= NULL;
	latestnode->outgoing= NULL;
	latestnode->incoming= NULL;
	
	//latest node is always put in the end for efficiency
	instSet->push_back(latestnode);
	
	//build control dependence edge
	const char* className= getClassNameFromTraceAt(classid);
	const char* methodName= getMethodNameFromTraceAt(methodTrace->methodID);
	const char* sig= getSigNameFromTraceAt(methodTrace->sigID);

	//printf("create node %s.%s(%s) %d\n", className, methodName, sig, instTrace->pc);
	
	int scdsize=0;
	int* scds= getStaticDependence(instTrace, className, methodName, sig, pc, &scdsize);

	int maxTimestamp=0;
	struct _inst_trace *dependentInstTrace= NULL;
	int i;
	for(i=0; i<scdsize; i++)
	{
		int current= scds[i];
		index= ((methodTrace->hash[current])&0x7FFFFFFF)-1;
		if(index== -1)
		{
			printf("error: no inst trace slot b\n");
			exit(1);
		}
		struct _inst_trace *currInstTrace= &(methodTrace->instTrace[index]);
		//printf("\tctrl: %d, %d\n", currInstTrace->pc, currInstTrace->latestTimestamp);
		if(currInstTrace->latestTimestamp > maxTimestamp)
		{
			maxTimestamp= currInstTrace->latestTimestamp;
			dependentInstTrace= currInstTrace;
		}
	}
	if(scdsize>0)
	{
		free(scds);
	}
	if(dependentInstTrace != NULL)
	{
		//we found control dependence, create edge
		vector<GNode*> *depSet= (vector<GNode*>*)dependentInstTrace->instances;
		const GNode* dependentNode= getRealDepNode(depSet, latestnode);
		//dependent edge: latest -> old
		createEdge((GNode*)latestnode, (GNode*)dependentNode);
	}
	
	//build data dependence edge
	int j;
	for(j=0; j<defsize; j++)
	{
		struct _inst_trace* depinst= 
			getInstTrace(methodTrace, defclsid[j], defmethid[j], defsigid[j], defpc[j]);
		vector<GNode*> *depSet= (vector<GNode*>*)depinst->instances;
		const GNode* dependentNode= getRealDepNode(depSet, latestnode);
		//dependent edge: latest->old
		createEdge((GNode*)latestnode, (GNode*)dependentNode);
	}
	
	compressNode(latestnode);
	
	//printf("=============begin============\n");
	//dumpHotgraph();
	//printf("==============end=============\n");
}

const GNode* getRealDepNode(vector<GNode*>* depSet, const GNode* latestnode)
{
	if(depSet == NULL || latestnode == NULL || depSet->empty())
	{
		printf("error: null para getRealDepNode\n");
		exit(1);
	}
	
	vector<GNode*> *theset= depSet;
	vector<GNode*>::reverse_iterator ite= theset->rbegin();
	const GNode* dependentNode= *ite;
	//in case it depends on a previous instance of same bc
	while(ite != theset->rend() && dependentNode == latestnode)
	{
		//dependentNode= dependentNode->next;
		ite++;
		dependentNode= *ite;
	}
	//get the real super node that is in DDG, if it is in rule
	/*if(ite != depSet->end() && dependentNode->containBy != NULL)
	{
		depSet= &(dependentNode->containBy->instances);
		ite= depSet->begin();
		dependentNode= *ite;
	}*/
	while(ite != theset->rend() && dependentNode->containBy !=NULL)
	{
		theset= dependentNode->containBy->instances;
		if(theset == NULL)
		{
			printf("error: rule has no instances\n");
			exit(1);
		}
		ite= theset->rbegin();
		dependentNode= *ite;
	}
	if(ite == theset->rend())
	{
		printf("error: no dependent node a\n");
		exit(1);
	}
	return dependentNode;
}

struct _inst_trace* getInstTrace(method_trace* methodTrace, int classid, int methodid, int sigid, int pc)
{
	if(methodTrace->methodID == methodid && methodTrace->sigID == sigid 
			&& methodTrace->classTrace->classID == classid)
	{
		method_trace* meth= methodTrace;
		int index= ((meth->hash[pc])&0x7FFFFFFF)-1;
		if(index== -1)
		{
			printf("error: no inst trace slot c\n");
			exit(1);
		}
		return &(meth->instTrace[index]);
	}
	struct _class_trace* trace= getTrace();
	for(; trace!=NULL; trace= trace->next)
	{
		if(trace->classID == classid)
		{
			struct _method_trace* meth= trace->methodTrace;
			for(; meth!=NULL; meth= meth->next)
			{
				if(meth->methodID == methodid && meth->sigID == sigid)
				{
					int index= ((meth->hash[pc])&0x7FFFFFFF)-1;
					if(index== -1)
					{
						printf("error: no inst trace slot c\n");
						exit(1);
					}
					return &(meth->instTrace[index]);
				}
			}
		}
	}
}

ArrayList<GEdge*> commonEdgesLatest;//edges to be substitute for latest node
ArrayList<GEdge*> commonEdgesOther;//edges to be substitute for the partner node (if any)
ArrayList<GEdge*> tempCommonEdgesLatest;//temp edges for latest node
ArrayList<GEdge*> tempCommonEdgesOther;//temp edges for the partner node (if any)

void compressNode(GNode *latestNode)
{
	//all instances of the same bytecode
	vector<GNode*> *allNodes= (vector<GNode*>*)((struct _inst_trace*)(latestNode->parent))->instances;
	vector<GNode*>::reverse_iterator itenode= allNodes->rbegin();
	if(allNodes->empty() || (*itenode)!=latestNode)
	{
		printf("error: latestNode is not in bytecode list or not first\n");
		exit(1);
	}
	
	GNode *similarNode= NULL;
	int similarityMax= 0;
	int similarNodeInRule= -1;
	int count=0;

//	vector<GEdge*> commonEdgesLatest;//edges to be substitute for latest node
//	vector<GEdge*> commonEdgesOther;//edges to be substitute for the partner node (if any)
//	vector<GEdge*> tempCommonEdgesLatest;//temp edges for latest node
//	vector<GEdge*> tempCommonEdgesOther;//temp edges for the partner node (if any)
	////ignore the first node which is latest node itself
	//commonNode= commonNode->next;
	for(; itenode != allNodes->rend(); itenode++)
	{
		GNode* commonNode= *itenode;
		if(commonNode != latestNode)
		{
			if(commonNode->containBy != NULL)//in rule, not in DDG
			{
				if(commonNode == commonNode->containBy->root)
				{
					//printf("root\n");
					//the root
					tempCommonEdgesLatest.removeAll();
					isIsomorphicGraph(&tempCommonEdgesLatest, commonNode, latestNode, similarityMax);
					if(!(tempCommonEdgesLatest.empty()))
					{
						if(tempCommonEdgesLatest.size() > similarityMax)
						{
							similarityMax= tempCommonEdgesLatest.size();
							similarNode= commonNode;
							similarNodeInRule= 1;
							commonEdgesLatest.removeAll();
							//commonEdgesLatest.insert(commonEdgesLatest.begin(), 
							//		tempCommonEdgesLatest.begin(), tempCommonEdgesLatest.end());
							//break;//test
						}
					}
					//tempCommonEdgesLatest.clear();
					break;
				}
			}
			else
			{
				//printf("ddg\n");
				//node is in DDG
				count++;
				tempCommonEdgesLatest.removeAll();
				tempCommonEdgesOther.removeAll();
				intersectOutgoingEdges(&tempCommonEdgesOther, &tempCommonEdgesLatest, commonNode, latestNode);
				if(tempCommonEdgesLatest.size() > similarityMax)
				{
					similarityMax= tempCommonEdgesLatest.size();
					similarNode= commonNode;
					similarNodeInRule= 0;
					commonEdgesLatest.removeAll();
					commonEdgesOther.removeAll();
//					commonEdgesLatest.insert(commonEdgesLatest.begin(), 
//							tempCommonEdgesLatest.begin(), tempCommonEdgesLatest.end());
//					commonEdgesOther.insert(commonEdgesOther.begin(), 
//							tempCommonEdgesOther.begin(), tempCommonEdgesOther.end());
					break;//test
				}
				//tempCommonEdgesLatest.clear();
				//tempCommonEdgesOther.clear();
				//break;
			}
		}
	}
	
	//printf("%d, %d\n", count, allNodes->size());
	
	/*if(similarNode != NULL)
	{
		if(similarNodeInRule == 1)
		{
			//printf("rule exists, substitute latest node\n");
			GRule* currentRule= similarNode->containBy;
			currentRule->frequency++;
			substitute(commonEdgesLatest, latestNode, currentRule);
		}
		else if(similarNodeInRule == 0)
		{
			//printf("create rule and substitute both nodes\n");
			GRule* currentRule= createRule(commonEdgesLatest, similarNode, latestNode);
			currentRule->frequency= 2;
			//fixed sequence!
			substitute(commonEdgesOther, similarNode, currentRule);
			substitute(commonEdgesLatest, latestNode, currentRule);
		}
	}*/
}

void isIsomorphicGraph(ArrayList<GEdge*> *commonEdges, GNode* ruleRootNode, GNode *latestNode, int similarMax)
{
	//now: 2n, before: n^2
	//put common edges outgoing from latestnode in the vector
	//if there is an isomorphic graph rooted at latestNode as rule.graph rooted at ruleRootNode
	//note: no edge between two outgoing nodes is detected, for speedup
	/*if(ruleRootNode->parent != latestNode->parent) {
		printf("error: latestNode is not the same bc as root of rule\n");
		exit(1);
	}
	
	if(latestNode->outgoing == NULL)
	{
		return;
	}
	if(ruleRootNode->outgoing == NULL)
	{
		printf("error: rule root has no outgoing\n");
		exit(1);
	}
	
	if(ruleRootNode->outgoing->size() <= similarMax)
	{
		return;
	}
	
	//if root has large size of outgoing, no isomorphic graph, just return
	if(ruleRootNode->outgoing->size() > latestNode->outgoing->size()) {
		return;
	}
	
	//enumerate both sets once
	set<GEdge*, GEdgeOutgoingComp>::iterator rootite= ruleRootNode->outgoing->begin();
	set<GEdge*, GEdgeOutgoingComp>::iterator latestite= latestNode->outgoing->begin();
	while(rootite != ruleRootNode->outgoing->end()
			&& latestite != latestNode->outgoing->end())
	{
		if((*rootite)->to->parent < (*latestite)->to->parent) {
			//rootite++;
			//since every rule edge must have a correspoinding edge in latest
			commonEdges->clear();
			return;
		}
		else if((*rootite)->to->parent > (*latestite)->to->parent) {
			latestite++;
		}
		else {
			if((*rootite)->to->timestamp < ruleRootNode->timestamp
					&& (*latestite)->to->timestamp > latestNode->timestamp)
			{
				//rootite++;
				//since every rule edge must have a correspoinding edge in latest
				commonEdges->clear();
				return;
			}
			else if((*rootite)->to->timestamp > ruleRootNode->timestamp
					&& (*latestite)->to->timestamp < latestNode->timestamp)
			{
				latestite++;
			}
			else
			{
				if((*rootite)->to->timestamp == ruleRootNode->timestamp
						|| (*latestite)->to->timestamp == latestNode->timestamp)
				{
					printf("error: timestamps equal isomorphic\n");
					exit(1);
				}
				commonEdges->push_back(*latestite);
				latestite++;
				rootite++;
			}
		}
	}*/
	
	/*gedge* currRootEdge= root->outgoing;
	for(;currRootEdge != NULL;currRootEdge= currRootEdge->next)
	{
		gnode* target= currRootEdge->target;
		gedge* currLatestEdge= latestNode->outgoing;
		gnode* found= NULL;
		for(;currLatestEdge != NULL; currLatestEdge= currLatestEdge->next)
		{
			if(currLatestEdge->target->inst == target->inst
					&& currLatestEdge->target != target)
			{
				//two edges pointing to diff instances of same bc
				found= currLatestEdge->target;
				break;
			}
		}
		if(found != NULL)
		{
			int ok= isIsomorphicGraph(target, found);
			if(ok == 0)
				return 0;
		}
		else
		{
			return 0;
		}
	}
	return 1;*/
}


void intersectOutgoingEdges
(ArrayList<GEdge*>* common1, ArrayList<GEdge*>* common2, GNode* v1, GNode* v2)
{
	//now: 2n, before: n^2
	//put common edges outgoing from latestnode in the vector
	//if there is an isomorphic graph rooted at latestNode as rule.graph rooted at ruleRootNode
	//note: no edge between two outgoing nodes is detected, for speedup
	if(v1->parent != v2->parent) {
		printf("error: v1 is not the same bc as v2\n");
		exit(1);
	}
	
	if(v1->outgoing == NULL || v2->outgoing == NULL)
	{
		return;
	}
	
	//printf("%d %d\n", v1->outgoing->size(), v2->outgoing->size());
	
	//enumerate both sets once
	set<GEdge*, GEdgeOutgoingComp>::iterator v1ite= v1->outgoing->begin();
	set<GEdge*, GEdgeOutgoingComp>::iterator v2ite= v2->outgoing->begin();
	while(v1ite != v1->outgoing->end()
			&& v2ite != v2->outgoing->end())
	{
		if((*v1ite)->to->parent < (*v2ite)->to->parent)
		{
			v1ite++;
		}
		else if((*v1ite)->to->parent > (*v2ite)->to->parent)
		{
			v2ite++;
		}
		else
		{
			if((*v1ite)->to->timestamp < v1->timestamp
					&& (*v2ite)->to->timestamp > v2->timestamp)
			{
				v1ite++;
			}
			else if((*v1ite)->to->timestamp > v1->timestamp
					&& (*v2ite)->to->timestamp < v2->timestamp)
			{
				v2ite++;
			}
			else
			{
				if((*v1ite)->to->timestamp == v1->timestamp
						|| (*v2ite)->to->timestamp == v2->timestamp)
				{
					printf("error: timestamps equal insersect\n");
					exit(1);
				}
				common1->addTail(*v1ite);
				common2->addTail(*v2ite);
				v1ite++;
				v2ite++;
			}
		}
	}
	
	if(common1->size() != common2->size())
	{
		printf("error: resulting vectors have diff size\n");
		exit(1);
	}
	
	/*int count= 0;
	gedge* curr1= v1->outgoing;
	for(;curr1!=NULL; curr1= curr1->next)
	{
		gedge* curr2= v2->outgoing;
		for(; curr2 != NULL; curr2= curr2->next)
		{
			if(curr1->target->inst == curr2->target->inst
					&& curr1->target != curr2->target)
			{
				count++;
				break;
			}
		}
	}
	return count;*/
}

/*
void freeGEdge(gedge* edge)
{
	free(edge);
}

void freeGNode(gnode* node)
{
	free(node);
}

int removeNodeFromInst(gnode *n)
{
	if(n->containBy != NULL)
	{
		printf("error: try to delete node in rule\n");
		exit(1);
	}
	if(n->nodetype == NormalNode)
	{
		inst_trace* inst= (inst_trace*)n->inst;
		gnode* previous= NULL;
		gnode* list= inst->instance;
		while(list != NULL)
		{
			if(list == n)
			{
				if(previous== NULL)
				{
					inst->instance= inst->instance->next;
				}
				else
				{
					previous->next= list->next;
				}
				freeGNode(n);
				return 1;
			}
			previous= list;
			list= list->next;
		}
	}
	else
	{
		grule* rule= (grule*)n->inst;
		gnode* previous= NULL;
		gnode* list= rule->instances;
		while(list != NULL)
		{
			if(list == n)
			{
				if(previous== NULL)
				{
					rule->instances= rule->instances->next;
				}
				else
				{
					previous->next= list->next;
				}
				freeGNode(n);
				return 1;
			}
			previous= list;
			list= list->next;
		}
	}
	return 0;
}*/

void createEdge(GNode* source, GNode* target)
{
	if(source == NULL || target == NULL)
	{
		printf("error: node is null when creating edge\n");
		exit(1);
	}
	if(source == target)
	{
		//one edge in an isomorphic graph is missing in the other
		//printf("warning: same node %d(%d)\n", getNodeID(source), getNodeTimestamp(source));
		//exit(1);
		//for now do not create loop edge;
		return;
	}
	
	GEdge* edge= new GEdge(source, target);
	if(source->outgoing == NULL)
		source->outgoing= new set<GEdge*, GEdgeOutgoingComp>;
	if(target->incoming == NULL)
		target->incoming= new set<GEdge*, GEdgeIncomingComp>;

	source->outgoing->insert(edge);
	target->incoming->insert(edge);
	
	/*//create an edge from source to target
	gedge* edge= (gedge*)cleanMalloc(sizeof(gedge));
	edge->target= target;
	edge->next= source->outgoing;
	source->outgoing= edge;
	source->outgoingCount++;
	
	gedge* edge2= (gedge*)cleanMalloc(sizeof(gedge));
	edge2->target= source;
	edge2->next= target->incoming;
	target->incoming= edge2;
	target->incomingCount++;*/
}

/*gnode* createRuleNode(gnode* v, grule* rule)
{
	gnode* root= (gnode*)cleanMalloc(sizeof(gnode));
	root->nodetype = v->nodetype;
	root->inst= v->inst;
	if(root->nodetype == NormalNode)
	{
		root->next= ((struct _inst_trace*)(root->inst))->instance;
		((struct _inst_trace*)(root->inst))->instance= root;
	}
	else
	{
		root->next= ((grule*)(root->inst))->instances;
		((grule*)(root->inst))->instances= root;
	}
	root->containBy= rule;
	return root;
}

gnode* getSameFromOutgoingNode(gnode* v, gnode* target)
{
	//target - the node in rule
	//v - the base node
	//get the node of the same bc of target from v's outgoing node
	gedge* currV= v->outgoing;
	for(; currV!=NULL; currV= currV->next)
	{
		if(currV->target->inst == target->inst)
		{
			if(currV->target == target)
			{
				printf("error: v in DDG points to target in rule\n");
				exit(1);
			}
			return currV->target;
		}
	}
	return NULL;
}

int edgeExist(gnode* source, gnode* target)
{
	//1 - if there exists an edge from source to target
	if(source==NULL || target == NULL)
	{
		printf("error: edgeExist: NULL node\n");
		exit(1);
	}
	//printf("XX\t\t    check edge %d(%d)->%d(%d) - ", getNodeID(source), getNodeTimestamp(source), getNodeID(target), getNodeTimestamp(target));
	
	gedge* temp= source->outgoing;
	for(; temp != NULL; temp= temp->next)
	{
		if(temp->target == target)
		{
			//printf("yes\n");
			return 1;
		}
	}
	//printf("no\n");
	return 0;
}

grule* createRule(gnode* v1, gnode* v2)
{
	int debug= 0;
	if(v1->inst != v2->inst)
	{
		printf("error: expect two nodes of the same bc, createrule\n");
		exit(1);
	}
	grule* newrule= (grule*)cleanMalloc(sizeof(grule));
	//link to global list
	newrule->next= ruleList;
	ruleList= newrule;
	newrule->id= gRuleCount;
	gRuleCount++;
	
	//here we only create a graph of length 1 (edges)
	
	//create a new rule node
	gnode* root= createRuleNode(v1, newrule);
	//create outgoing edges and corresponding nodes
	gedge* curr1= v1->outgoing;
	for(;curr1!=NULL; curr1= curr1->next)
	{
		gedge* curr2= v2->outgoing;
		for(; curr2 != NULL; curr2= curr2->next)
		{
			if(curr1->target->inst == curr2->target->inst)
			{
				if(curr1->target != curr2->target)
				{
					//printf("warning: nodes pointing to same node\n");
					
				}
				//if(not loop edge && not pointing to same node)
				if(curr1->target != v1 && curr1->target != curr2->target)
				{
					gnode* target= createRuleNode(curr1->target, newrule);
					createEdge(root, target);
					if(debug)
					{
						printf("X\tcreated edge a %d(%d)->%d(%d)\n", getNodeID(root), getNodeTimestamp(root), getNodeID(target), getNodeTimestamp(target));
					}
					break;
				}
			}
		}
	}
	
	//check all connecting edges within rule
	gedge* currRoot= root->outgoing;
	for(; currRoot!=NULL; currRoot= currRoot->next)
	{
		gnode* sourceNodeR= currRoot->target;
		gnode* sourceNodeV1= getSameFromOutgoingNode(v1, sourceNodeR);
		gnode* sourceNodeV2= getSameFromOutgoingNode(v2, sourceNodeR);
		gedge* currRoot2= root->outgoing;
		for(; currRoot2!=NULL; currRoot2= currRoot2->next)
		{
			gnode* sourceNodeR2= currRoot2->target;
			gnode* sourceNodeV12= getSameFromOutgoingNode(v1, sourceNodeR2);
			gnode* sourceNodeV22= getSameFromOutgoingNode(v2, sourceNodeR2);
			if(edgeExist(sourceNodeV1, sourceNodeV12) && edgeExist(sourceNodeV2, sourceNodeV22))
			{
				//there should be an edge sourceNodeR->sourceNodeR2
				//since it exists in both of the isomorphic graphs
				createEdge(sourceNodeR, sourceNodeR2);
				if(debug)
				{
					printf("X\tcreated edge b %d(%d)->%d(%d)\n", getNodeID(sourceNodeR), getNodeTimestamp(sourceNodeR), getNodeID(sourceNodeR2), getNodeTimestamp(sourceNodeR2));
				}
				break;
			}
		}
	}
	
	newrule->root= root;
	gnode* xxx= root->incoming->target;
	xxx= root->outgoing->target;
	return newrule;
}

void removeSingleEdge(gnode* v, int type, gedge* e)
{
	//type: 0 - outgoing, 1 - incoming
	gedge* list= NULL;
	if(type == 0)
	{
		//outgoing
		list= v->outgoing;
		if(list == e)
		{
			v->outgoing= v->outgoing->next;
			v->outgoingCount--;
			free(e);
			return;
		}
	}
	else
	{
		//incoming
		list= v->incoming;
		if(list == e)
		{
			v->incoming= v->incoming->next;
			v->incomingCount--;
			free(e);
			return;
		}
	}
	gedge *previous= list;
	list= list->next;
	while(list!=NULL)
	{
		if(list == e)
		{
			previous->next= list->next;
			if(type == 0)
			{
				v->outgoingCount--;
			}
			else
			{
				v->incomingCount--;
			}
			free(list);
			return;
		}
		previous= list;
		list= list->next;
	}
	printf("error: cannot find edge in v to remove\n");
	exit(1);
}

void removeAllEdges(gnode* v)
{
	gedge* previous= NULL;
	while(v->incoming!=NULL)
	{
		//remove the outgoing edge from target as well
		gnode* target= v->incoming->target;
		gedge* temp= target->outgoing;
		for(; temp!=NULL; temp= temp->next)
		{
			if(temp->target == v)
			{
				removeSingleEdge(target, 0, temp);
				break;
			}
		}
		
		previous= v->incoming;
		v->incoming= v->incoming->next;
		v->incomingCount--;
		freeGEdge(previous);
	}
	previous= NULL;
	while(v->outgoing != NULL)
	{
		//remove the incoming edge from target as well
		gnode* target= v->outgoing->target;
		gedge* temp= target->incoming;
		for(; temp != NULL; temp= temp->next)
		{
			if(temp->target == v)
			{
				removeSingleEdge(target, 1, temp);
				break;
			}
		}
		
		previous= v->outgoing;
		v->outgoing= v->outgoing->next;
		v->outgoingCount--;
		freeGEdge(previous);
	}
}*/

int getNodeID(GNode* v)
{
	if(v->nodetype == NormalNode)
	{
		return ((inst_trace*)(v->parent))->pc;
	}
	else
	{
		return ((GRule*)(v->parent))->id;
	}
}

/*
int getNodeTimestamp(gnode* v)
{
#ifdef GNODETIMESTAMP
	return v->timestamp;
#else
	return 0;
#endif
}

void substituteGraph(gnode* v, gnode* root, gnode* sn)
{
	//printf("%d %d\n", edgesSize(v->incoming), edgesSize(v->outgoing));
	int debug= 0;
	int pc= getNodeID(v);
	//mark the instance being substitute
	//this is necessary for two instances of same bc pointing to v
	root->timestamp= v->timestamp;
	//check incoming edge
	gedge* incV= v->incoming;
	if(debug)
	{
		printf("a\tchecking %d(%d)'s incoming\n", pc, getNodeTimestamp(v));
		for(; incV !=NULL; incV= incV->next)
		{
			printf("b\t incoming %d(%d)\n", getNodeID(incV->target), getNodeTimestamp(incV->target));
		}
	}
	incV= v->incoming;
	for(; incV != NULL; incV= incV->next)
	{
		if(debug)
			printf("a\t\tsearching for edge pointing to %d(%d)\n", getNodeID(incV->target), getNodeTimestamp(incV->target));
		gedge* incR= root->incoming;
		int found= 0;
		for(; incR!=NULL; incR= incR->next)
		{
			if(debug)
			{
				printf("c\t\t  testing %d(%d)'s incoming %d(%d)\n", getNodeID(root), getNodeTimestamp(root), getNodeID(incR->target), getNodeTimestamp(incR->target));
			}
			//in case two instances of same bc pointing to v
			if(incR->target->inst == incV->target->inst)
			{
				if(incR->target == incV->target)
				{
					printf("error: incR in rule points to incV in DDG\n");
					exit(1);
				}
				if(incR->target->timestamp == 0 || incR->target->timestamp==incV->target->timestamp)
				{
					found=1;
					if(debug)
						printf("a\t\tfound same in rule %d\n", getNodeID(incR->target));
					break;
				}
			}
		}
		if(found==0)
		{
			//incV points to a non-g node, update its edge
			gnode* nonG= incV->target;
			gedge* temp= nonG->outgoing;
			for(; temp != NULL; temp= temp->next)
			{
				if(temp->target == v)
				{
					removeSingleEdge(nonG, 0, temp);
					//temp->target= sn;
					found= 1;
					break;
				}
			}
			//adding incoming edge pointing to non-g in sn
			//gedge* newedge= (gedge*)cleanMalloc(sizeof(gedge));
			//newedge->target= nonG;
			//newedge->next= sn->incoming;
			//sn->incoming= newedge;
			createEdge(nonG, sn);
			if(debug)
				printf("a\t\tcreated edge from %d(%d) to %d(%d)\n", getNodeID(nonG), getNodeTimestamp(nonG), getNodeID(sn), getNodeTimestamp(sn));
			if(found==0)
			{
				if(nonG->containBy!=NULL)
				{
					grule* aaa= (grule*)(nonG->inst);
					printf("error: cannot find v at target's (rule %d) outgoing edge\n", aaa->id);
				}
				else
				{
					struct _inst_trace *aaa=(struct _inst_trace*)(nonG->inst);
					printf("error: cannot find v at target's (inst %d) outgoing edge\n", aaa->pc);
				}
				exit(1);
			}
		}
	}
	
	//check outgoing edge and proceed to next g node if any
	gedge* currV= v->outgoing;
	if(debug)
	{
		printf("a\tchecking outgoing edge for %d(%d)\n", pc, getNodeTimestamp(v));
		for(; currV !=NULL; currV= currV->next)
		{
		
			printf("b\t outgoing ");
			printf(" %d(%d)\n", getNodeID(currV->target), getNodeTimestamp(currV->target));
			printf("b\t outgoing ==\n");
			printf("b\t outgoing --\n");
			
		}
	}
	currV= v->outgoing;
	for(; currV !=NULL; currV= currV->next)
	{
		if(debug)
			printf("a\t\tsearching for edge pointing to %d(%d)\n", getNodeID(currV->target), getNodeTimestamp(currV->target));
		gedge* currR= root->outgoing;
		int found= 0;
		for(; currR != NULL; currR= currR->next)
		{
			if(currR->target->inst == currV->target->inst)
			{
				if(currR->target == currV->target)
				{
					printf("error: currR in rule points to currV in DDG\n");
				}
				//same edge / target node
				//retain cross edge
				
				//in case two instances of same bc pointing to v
				if(currR->target->timestamp==0 || currR->target->timestamp==currV->target->timestamp)
				{
					found= 1;
					if(currR->target->timestamp == 0)
					{
						if(debug)
							printf("a\t\tfound same in rule %d\na\t\tsubstitute next node\n", getNodeID(currR->target));
						substituteGraph(currV->target, currR->target, sn);
					}
					else
					{
						if(debug)
							printf("a\t\tfound same in rule %d\na\t\tnot substitute due to loop\n", getNodeID(currR->target));						
					}
					break;
				}
			}
		}
		if(found == 0)
		{
			//currV points to a non-g node
			//update the edge in non-g node
			gnode* nonG = currV->target;
			gedge* temp= nonG->incoming;
			for(; temp != NULL; temp=temp->next)
			{
				if(temp->target == v)
				{
					removeSingleEdge(nonG, 1, temp);
					//temp->target= sn;
					found= 1;
					break;
				}
			}
			//add edge pointing to nonG in super node sn
			//gedge* newedge= (gedge*)cleanMalloc(sizeof(gedge));
			//newedge->target= nonG;
			//newedge->next= sn->outgoing;
			//sn->outgoing= newedge;
			createEdge(sn, nonG);
			if(debug)
			{
				printf("before create\n");
			
				printf("a\t\tcreated edge from %d(%d) to %d(%d)\n", getNodeID(sn), getNodeTimestamp(sn), getNodeID(nonG), getNodeTimestamp(nonG));
				printf("after create\n");
			}
			if(found == 0)
			{
				if(nonG->containBy!=NULL)
				{
					grule* aaa= (grule*)(nonG->inst);
					printf("error: cannot find v at target's (rule %d) incoming edge\n", aaa->id);
				}
				else
				{
					struct _inst_trace *aaa=(struct _inst_trace*)(nonG->inst);
					printf("error: cannot find v at target's (inst %d) incoming edge\n", aaa->pc);
				}
				exit(1);
			}
		}
	}
	root->timestamp= 0;
	//delete v and all edges
	removeAllEdges(v);
	int result= removeNodeFromInst(v);
	if(debug)
		printf("a\tremoving all edges and v %d\n", pc);
	if(result == 0)
	{
		printf("error: cannot find v in its inst list\n");
		exit(1);
	}
}

void substitute(gnode *v, grule* rule)
{
	if(v->containBy != NULL)
	{
		//grule* aaa= (grule*)(v->inst);
		//printf("substitute node (rule %d) with rule %d\n", aaa->id, rule->id);
	}
	else
	{
		//struct _inst_trace *aaa= (struct _inst_trace*)(v->inst);
		//printf("substitute node (inst %d) with rule %d\n", aaa->pc, rule->id);
	}
	//create super node instance of rule
	gnode* sn= (gnode*)cleanMalloc(sizeof(gnode));
	sn->nodetype= SuperNode;
	sn->inst= rule;
	sn->next= rule->instances;
	rule->instances= sn;
#ifdef GNODETIMESTAMP
	sn->timestamp= v->timestamp;
#endif
	
	gnode* root= rule->root;
	
	substituteGraph(v, root, sn);
	
	//label edge - not done for now
	
	//re-compression
	
	int incsize= edgesSize(sn->incoming);
	if(incsize > 0)
	{
		gnode *temp= (gnode*)cleanMalloc(sizeof(gnode)*incsize);
		int i= 0;
		gedge* tempedge= sn->incoming;
		for(; tempedge !=NULL; tempedge= tempedge->next)
		{
			temp[i]= tempedge->target;
		}
		gnode* tempnode= temp[0];
		for(; tempnode!=NULL; tempnode= tempnode->next)
		{
			compressNode(tempnode);
		}
		free(temp);
	}
}

int nodesSize(gnode* node)
{
	int count=0;
	gnode* curr= node;
	while(curr!=NULL)
	{
		curr= curr->next;
		count++;
	}
	return count;
}*/

extern "C" void countNodeEdge(struct _inst_trace *instTrace, int *nodecount, int *edgecount)
{
	vector<GNode*> *nodes= (vector<GNode*> *)instTrace->instances;
	if(nodes == NULL)
	{
		return;
	}
	vector<GNode*>::reverse_iterator ite= nodes->rbegin();
	//gnode* curr=node;
	for(; ite != nodes->rend(); ite++)
	{
		(*nodecount) = (*nodecount)+1;
		GNode* n=*ite;
		set<GEdge*, GEdgeOutgoingComp> *temp= n->outgoing;
		if(temp == NULL)
		{
			continue;
		}
		(*edgecount) = (*edgecount) + temp->size();//curr->incomingCount + curr->outgoingCount;
	}
}
/*
int ruleUnused(grule *rule)
{
	//only consider that the rule has one instance which is in another rule
	gnode* curr= rule->instances;
	if(curr == NULL)
	{
		printf("error: the rule has no instance\n");
		exit(1);
	}
	//printf("rule: %d, instances %d\n", rule->id, nodesSize(curr));
	if(nodesSize(curr)==1 && curr->containBy != NULL)
	{
		if(curr->containBy->frequency != rule->frequency)
		{
			printf("error: super rule has diff freq\n");
			exit(1);
		}
		return 1;
	}
	return 0;
}

void updateContainBy(gnode* oldroot, grule* targetrule)
{
	if(oldroot->containBy != targetrule)
	{
		oldroot->containBy= targetrule;
		gedge* curr= oldroot->outgoing;
		for(; curr != NULL; curr= curr->next)
		{
			updateContainBy(curr->target, targetrule);
		}
	}
}

void compressRuleList()
{
	printf("start to compress rule list\n");
	
	if(ruleList == NULL)
		return;
	
	grule* current= ruleList;
	
	if(current->instances == NULL)
	{
		printf("warning: first rule has no instance\n");
		exit(1);
	}
	
	grule* previous= current;
	current= current->next;
	
	while(current != NULL)
	{
		if(ruleUnused(current))
		{
			//current rule is not used -> combine
			gnode* instance= current->instances;
			
			//for now, only consider instance without outgoing edge
			//if(edgesSize(instance->outgoing) > 0)
			if(instance->outgoingCount > 0)
			{
				previous= current;
				current= current->next;
				continue;
			}
			
			//update containBy
			updateContainBy(current->root, instance->containBy);
			
			gedge* inc= instance->incoming;
			
			for(;inc!=NULL; inc= inc->next)
			{
				int found= 0;
				gnode* target= inc->target;
				gedge* temp= target->outgoing;
				for(; temp!=NULL; temp= temp->next)
				{
					if(temp->target == instance)
					{
						found= 1;
						temp->target= current->root;
						break;
					}
				}
				if(found==0)
				{
					printf("error: cannot find instance from incoming node's edge\n");
					exit(1);
				}
			}
			
			//delete rule
			previous->next= current->next;
			free(current);
			current= previous->next;
		}
		else
		{
			previous= current;
			current= current->next;
		}
	}
}

int edgesSize(gedge* edge)
{
	int count= 0;
	while(edge != NULL)
	{
		count++;
		edge= edge->next;
	}
	return count;
}*/

void dumpRuleGraph(GNode *node)
{
	if(node == NULL)
	{
		printf("error: node is null\n");
		exit(1);
	}
	set<GEdge*, GEdgeOutgoingComp> *oset= node->outgoing;
	set<GEdge*, GEdgeOutgoingComp>::iterator curr= oset->begin();
	for(; curr!=oset->end(); curr++)
	{
		dumpRuleGraph((*curr)->to);
		printf("\t\t\t");
		if(node->nodetype==NormalNode)
		{
			printf("%d(%d)", getNodeID(node), node->timestamp);
		}
		else
		{
			printf("<%d>(%d)", getNodeID(node), node->timestamp);
		}
		printf("-->");
		if((*curr)->to->nodetype==NormalNode)
		{
			printf("%d(%d)", getNodeID((*curr)->to), (*curr)->to->timestamp);
		}
		else
		{
			printf("<%d>(%d)", getNodeID((*curr)->to), (*curr)->to->timestamp);
		}
		printf("\n");
	}
}

extern "C" void dumpRule()
{
	/*printf("RULE list:\n");
	vector<GRule>::iterator currRule= ruleList.begin();
	for(; currRule!=ruleList.end(); currRule++)
	{
		printf("\trule %d, %d:\n", currRule->id, currRule->frequency);
		dumpRuleGraph(currRule->root);
	}*/
}
/*
int countOneRule(gnode* root)
{
	int count= 1;
	root->timestamp= 1;
	gedge* curr= root->outgoing;
	for(; curr !=NULL; curr= curr->next)
	{
		gnode* target= curr->target;
		if(target->timestamp == 0)
		{
			count+= countOneRule(target);
		}
	}
	root->timestamp= 0;
	return count;
}

int distinctrulecount= 0;

void countRuleOverhead(int * nodecount, int* edgecount)
{
	//int count=0;
	grule* curr= ruleList;
	for(; curr != NULL; curr= curr->next)
	{
		//printf("rule %d: ", curr->id);
		//count+= countOneRule(curr->root);
		//printf("graph %d ", countOneRule(curr->root));
		//count+= nodesSize(curr->instances);
		countNodeEdge(curr->instances, nodecount, edgecount);
		distinctrulecount++;
		//printf("nodes %d\n", nodesSize(curr->instances));
	}
	//return count;
}

int countRuleSize()
{
	return distinctrulecount;
}*/

extern "C" void dumpInstHotgraph(inst_trace* instTrace)
{
	vector<GNode*>* s= (vector<GNode*>*)instTrace->instances;
	if(s == NULL)
	{
		return;
	}
	vector<GNode*>::iterator ite= s->begin();
	
	for(; ite!=s->end(); ite++)
	{
		if((*ite)->containBy == NULL)
		{
			printf("\t\t\tnode (%d): outgoing:", (*ite)->timestamp);
		}
		else
		{
			printf("\t\t\tnode (%d) (in rule): outgoing:", (*ite)->timestamp);
		}
		const set<GEdge*, GEdgeOutgoingComp> *currEdge= (*ite)->outgoing;
		set<GEdge*, GEdgeOutgoingComp>::iterator iteedge= currEdge->begin();
		for(; iteedge != currEdge->end(); iteedge++)
		{
			if((*iteedge)->to->nodetype == NormalNode)
			{
				printf(" %d(%d)", getNodeID((*iteedge)->to), (*iteedge)->to->timestamp);
			}
			else
			{
				printf(" <%d>(%d)", getNodeID((*iteedge)->to), (*iteedge)->to->timestamp);
			}
		}
		printf(";\n \t\t\t\tincoming:");
		const set<GEdge*, GEdgeIncomingComp> *currEdge2= (*ite)->incoming;
		set<GEdge*, GEdgeIncomingComp>::iterator iteedge2= currEdge2->begin();
		for(; iteedge2 != currEdge2->end(); iteedge2++)
		{
			if((*iteedge2)->to->nodetype == NormalNode)
			{
				printf(" %d(%d)", getNodeID((*iteedge2)->from), (*iteedge2)->from->timestamp);
			}
			else
			{
				printf(" <%d>(%d)", getNodeID((*iteedge2)->from), (*iteedge2)->from->timestamp);
			}
		}
		printf("\n");
	}
}

