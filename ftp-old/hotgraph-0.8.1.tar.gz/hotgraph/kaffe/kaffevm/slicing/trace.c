#include "classMethod.h"
#include "constants.h"
#include "lookup.h"
#include "access.h"
#include "stackTrace.h"
#include "code.h" 
#include "trace.h"
#include "gtypes.h"
//#include "buildSCD.h"
//#include "hotgraph.h"
#include <string.h>

#include "java_lang_reflect_Field.h"
 
// declaration for B+-tree
#define             FANOUT	16
#define 	        InternalNode	0
#define		        LeafNode		1
typedef long long   KeyType;
typedef short int	NodeType;

typedef struct _Content
{
	ct_symbol		*p;
	struct _Content *next;
}Content;

typedef struct _Node
{
	struct{
	short int count;
	NodeType type;	// 0 for internal, 1 for leaf node
	};
	KeyType key[FANOUT];
	void *child[FANOUT+1];
  	struct _Node *parent;
}Node;

typedef Node*		PNodeChild;
typedef Content*	PContent;



const unsigned short int instLen[256] = {
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	2, 3, 2, 3, 3, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3,
	3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 0, 0, 1, 1, 1, 1,
	1, 1, 3, 3, 3, 3, 3, 3, 3, 5, 1, 3, 2, 3, 1, 1,
	3, 3, 1, 1, 1, 4, 3, 3, 5, 5, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
};

const unsigned short int instOper[256] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2,
	2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2,
	2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1,
	0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

const unsigned short int controlInfo[256] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 3, 3, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};


charRef bytecodeName[203]={
				"nop",
				"aconst_null",
				"iconst_m1",
				"iconst_0",
				"iconst_1",
				"iconst_2",
				"iconst_3",
				"iconst_4",
				"iconst_5",
				"lconst_0",
				"lconst_1",
				"fconst_0",
				"fconst_1",
				"fconst_2",
				"dconst_0",
				"dconst_1",
				"bipush",
				"sipush",
				"ldc",
				"ldc_w",
				"ldc2_w",
				"iload",
				"lload",
				"fload",
				"dload",
				"aload",
				"iload_0",
				"iload_1",
				"iload_2",
				"iload_3",
				"lload_0",
				"lload_1",
				"lload_2",
				"lload_3",
				"fload_0",
				"fload_1",
				"fload_2",
				"fload_3",
				"dload_0",
				"dload_1",
				"dload_2",
				"dload_3",
				"aload_0",
				"aload_1",
				"aload_2",
				"aload_3",
				"iaload",
				"laload",
				"faload",
				"daload",
				"aaload",
				"baload",
				"caload",
				"saload",
				"istore",
				"lstore",
				"fstore",
				"dstore",
				"astore",
				"istore_0",
				"istore_1",
				"istore_2",
				"istore_3",
				"lstore_0",
				"lstore_1",
				"lstore_2",
				"lstore_3",
				"fstore_0",
				"fstore_1",
				"fstore_2",
				"fstore_3",
				"dstore_0",
				"dstore_1",
				"dstore_2",
				"dstore_3",
				"astore_0",
				"astore_1",
				"astore_2",
				"astore_3",
				"iastore",
				"lastore",
				"fastore",
				"dastore",
				"aastore",
				"bastore",
				"castore",
				"sastore",
				"pop",
				"pop2",
				"dup",
				"dup_x1",
				"dup_x2",
				"dup2",
				"dup2_x1",
				"dup2_x2",
				"swap",
				"iadd",
				"ladd",
				"fadd",
				"dadd",
				"isub",
				"lsub",
				"fsub",
				"dsub",
				"imul",
				"lmul",
				"fmul",
				"dmul",
				"idiv",
				"ldiv",
				"fdiv",
				"ddiv",
				"irem",
				"lrem",
				"frem",
				"drem",
				"ineg",
				"lneg",
				"fneg",
				"dneg",
				"ishl",
				"lshl",
				"ishr",
				"lshr",
				"iushr",
				"lushr",
				"iand",
				"land",
				"ior",
				"lor",
				"ixor",
				"lxor",
				"iinc",
				"i2l",
				"i2f",
				"i2d",
				"l2i",
				"l2f",
				"l2d",
				"f2i",
				"f2l",
				"f2d",
				"d2i",
				"d2l",
				"d2f",
				"i2b",
				"i2c",
				"i2s",
				"lcmp",
				"fcmpl",
				"fcmpg",
				"dcmpl",
				"dcmpg",
				"ifeq",
				"ifne",
				"iflt",
				"ifge",
				"ifgt",
				"ifle",
				"if_icmpeq",
				"if_icmpne",
				"if_icmplt",
				"if_icmpge",
				"if_icmpgt",
				"if_icmple",
				"if_acmpeq",
				"if_acmpne",
				"goto",
				"jsr",
				"ret",
				"tableswitch",
				"lookupswitch",
				"ireturn",
				"lreturn",
				"freturn",
				"dreturn",
				"areturn",
				"return",
				"getstatic",
				"putstatic",
				"getfield",
				"putfield",
				"invokevirtual",
				"invokespecial",
				"invokestatic",
				"invokeinterface",
				"xxxunusedxxx1",
				"new",
				"newarray",
				"anewarray",
				"arraylength",
				"athrow",
				"checkcast",
				"instanceof",
				"monitorenter",
				"monitorexit",
				"wide",
				"multianewarray",
				"ifnull",
				"ifnonnull",
				"goto_w",
				"jsr_w",
				"breakpoint"
};
#define OBJIDMASK		4096
#define OBJIDOFFSET  		4

//====
#define MaxDepSize 10

int *defineclassid= NULL;
int *definemethodid= NULL;
int *definesigid= NULL;
int *definepc= NULL;

inst_info multiNewInfo;

/**** some global count ****/
int startTracing= 0;
int startSlicing= 0;
int ifinited=0;
int currentCallFrameLevel=0;
int ifTracingAndSlicing=0;
int reportOverhead=0;
int restoreCurrentNeedTracing= 0;// by GL //the value of currentNeedTracing of try block must be restored for catch block

int classNameCount, methodNameCount, sigCount, fieldNameCount;
int traceMultiArrayAllocation=0;
inst_info multiNewInfo;
Utf8Const **classNameList, **methodNameList, **sigList;
char **fieldNameList;

/**** collect overhead information ****/

int btreeoverhead=0;
int rleseoverhead=0;
int otheroverhead=0;
int invoketime=0;
int operandNum=0;
int symbolCount=0;
int ruleCount=0;

int internalNodeCount=0;
int leafNodeCount=0;
int hashCount=0;

int checkDigramCount=0;

int maxbtreeoverhead=0;
int maxrleseoverhead=0;
int maxotheroverhead= 0;
int maxsymbolCount=0;
int maxruleCount=0;

void dumpHotgraph(void);
void createNode(int classid, struct _method_trace *methodTrace, int pc, int* defclsid, int* defmethid, int* defsigid, int* defpc, int defsize, int, int, int, int);
void dumpInstHotgraph(inst_trace* instTrace);
void dumpRule(void);
void countNodeEdge(void *nodelist, int *nodecount, int *edgecount);
void compressRuleList(void);
int countRuleSize(void);
void countRuleOverhead(int *nodecount, int* edgecount);
/***** for debug ******/
#ifdef CollectFlowTrace
FILE *collectedflowTrace=NULL;
#endif

/********** maintain method trace and hash related functions *********/
call_frame			*tracingCallStack;
class_trace *trace;
int tracedClassCount=0;
const int MaxListMember= 8000;//test


int classHashCount;
call_frame *freeCallFrame;
int *multiArrayAllocSit= NULL;

static method_trace* findMethodTrace(methods *meth, int classID);
static call_frame* createCallFrame(methods *meth);
static class_trace* createClassTrace(methods *meth, int classID);
static method_trace* createMethodTrace(methods *meth, int classID, int methodID, int sigID);
static method_hash* createMethodHash(methods*, int, int, int);


/********  trace related **********/
static int objectNum=1;
objectIDEntry **objectIDList;

void traceCallInfo(oper_trace *, int);
void exportList(Utf8Const **list, int count, FILE*);
void exportLists(FILE *fp);
void finishTrace(void);
void countHotgraph(int* nodecount, int* edgecount);
void initHotgraph(void);

/*******  compressed trace related ******/
ct_symbol *freeSymbol;
ct_rule *freeRule;

#define ct_rule_size		(sizeof(ct_rule))
#define ct_symbol_size		(sizeof(ct_symbol))
#define method_hash_size	(sizeof(method_hash))

int executedInstCount=0;

typedef struct _check_stack
{
	ct_symbol *waiting;
	struct _check_stack *prev;
}CheckStack;
CheckStack *checkStack=NULL;

staticInitCallTraceEntry *staticInitTrace=NULL, *lastStaticInitCallEntry=NULL;

void addHash(ct_rule *s, ct_symbol*, DigramIndex**);
int check_last(ct_rule *, ct_symbol*, DigramIndex**);
int check_digram(ct_rule*, ct_symbol*, DigramIndex**);
void checkCheckStack(ct_symbol *symbol);
void deleteHash(ct_symbol*, DigramIndex**);
void dumpChildNode(ct_symbol *);
int equalDigram(ct_symbol*, ct_symbol*);
void expand(ct_rule*, ct_symbol*, DigramIndex**);
ct_symbol* find_digram(ct_rule *, ct_symbol*, DigramIndex**);
void free_rule(ct_rule*, ct_rule*);
void free_symbol(ct_symbol*);
void free_DigramIndex(DigramIndex*);
KeyType getHashCode(ct_symbol*);
void initOperTrace(oper_trace*, int);
void insertAfter(ct_symbol*, ct_symbol*);
inline void join(ct_symbol*, ct_symbol*);
ct_rule* malloc_rule(int);
ct_symbol* malloc_symbol(SymbolType, int, int);
DigramIndex *malloc_DigramIndex(void);

void pushCheckStack(ct_symbol *waiting);
ct_symbol* popCheckStack(void); 
ct_symbol* substitude(ct_symbol*, ct_rule*);

void traceOper (oper_trace *operTrace, int value, int flag);


/******** other utility functions ********/
const char* staticInitName="<clinit>";
const char* initName="<init>";

#define MAXLINECHAR             1024


int beginWith(char*, char*);

void verify(ct_rule*);
objectIDEntry* malloc_objID(unsigned int addr);
unsigned int getAddrOffset(unsigned int addr);
static void walkCallStack(void);
class_trace	*getTrace(void);
int findName(Utf8Const**, Utf8Const*, int*);
int findFieldName(char**, char*, int*);

/******************* btree related  ***************/
static PContent	    freePContent= NULL;
static PNodeChild	freeNodes= NULL;
 
PContent createNewContent(ct_symbol*, PContent);
Node* createNewNode(NodeType);
void insertNode(Node**, KeyType, void*);
void insertEntry(Node**, KeyType, void*, Node*);
void simpleInsert(KeyType, void*, Node*);
void outputTree(Node*);
void deleteEntry(Node**, KeyType, void*, Node*);
void deleteNode(Node**, KeyType, void*);
int simpleDelete(KeyType, void*, Node*);
inline void freeContent(PContent);
ct_symbol* findEntry(ct_rule *, Node**, KeyType, ct_symbol*, Node*);
ct_symbol* findNode(ct_rule *, Node**, KeyType, ct_symbol*);
int queryIndex(Node**, KeyType, ct_symbol*);
void dumpChildNode(ct_symbol *walk_symbol);

char* copyString(const char *src)
{
	char *dest;
	int length;

	length= strlen(src);
	dest= (char *)cleanMalloc(length+1);
	strcpy(dest, src);
	dest[length]='\0';

	return dest;
}

/********* interface to slicing ********/
int getTracedClassCount()
{
    return tracedClassCount;
}

const char *getClassNameFromTrace(class_trace *tracedClass)
{
    return classNameList[tracedClass->classID]->data;
}

int getClassNameID(Hjava_lang_Class* cl)
{
	return findName(classNameList, cl->name, &classNameCount);
}


class_trace	*getTrace(void)
{
    return trace;
}

int getClassNameCountFromTrace()
{
    return classNameCount;
}

int getMethodNameCountFromTrace()
{
    return methodNameCount;
}

int getSigNameCountFromTrace()
{
    return sigCount;
}

const char *getClassNameFromTraceAt(int index)
{
    return classNameList[index]->data;
}

const char *getMethodNameFromTraceAt(int index)
{
    return methodNameList[index]->data;
}

const char *getSigNameFromTraceAt(int index)
{
    return sigList[index]->data;
}

struct Hjava_lang_Class* getJavaClassFromClass(Hjava_lang_Class* startClass, const char *name)
{
    int i;

    if (startClass==NULL)
        return NULL;

    if (strcmp(startClass->name->data, "java/lang/Object")==0)
       return NULL;

    if (strcmp(startClass->name->data, name)==0)
    {
        return startClass;
    }

    if (startClass->superclass && getJavaClassFromClass(startClass->superclass, name))
    {
        return startClass->superclass;
    }

    for(i=0; i<startClass->interface_len; i++)
    {
        if (getJavaClassFromClass(startClass->interfaces[i], name))
            return startClass->interfaces[i];
    }
    return NULL;
}

struct Hjava_lang_Class* getJavaClassInKaffe(const char *name)
{
    Hjava_lang_ClassLoader *loader=trace->javaClass->loader;
    Hjava_lang_Class *sourceClass= lookupClassForSlicing(name, loader);
    if (!sourceClass)
    {
        printf("error, cannot find java-lang-class for %s\n", name);
        return NULL;
    }
    else
        return sourceClass;
}

struct _methods* getJavaMethodInKaffe(Hjava_lang_Class *parentClass, const char *name, const char *sig)
{
    int i, count;
    struct _methods *currentMeth;
    
    count=parentClass->nmethods;
    for(i=0; i<count; i++)
    {
        currentMeth= &(parentClass->methods[i]);
        if (    strcmp(currentMeth->name->data, name)==0 
            &&  strcmp(currentMeth->parsed_sig->signature->data, sig)==0) 
            return currentMeth;
    }
    printf("error, cannot find method, %s,%s\n", name, sig);
    return NULL;
}   

struct Hjava_lang_Class* getSuperClassInKaffe(struct Hjava_lang_Class *currentClass)
{
  return currentClass->superclass;
}
const char * getClassNameInKaffe(struct Hjava_lang_Class *currentClass)
{
  return currentClass->name->data;
}

const char * getClassNameOfMethInKaffe(struct _methods *currentMeth)
{
  return currentMeth->class->name->data;
}


int getInterfaceCountInKaffe(struct Hjava_lang_Class *currentClass)
{
  return currentClass->interface_len;
}

const char* getFileNameInKaffe(struct Hjava_lang_Class *currentClass)
{ 
    return currentClass->sourcefile;
}

const char *getInterfaceNameAtInKaffe(struct Hjava_lang_Class *currentClass, int index)
{
  return currentClass->interfaces[index]->name->data;
}

struct Hjava_lang_Class *getAnInterfaceInKaffe(struct Hjava_lang_Class *currentClass, int index)
{
    return currentClass->interfaces[index];
}

int getMethodCountInKaffe(struct Hjava_lang_Class *currentClass)
{
  return currentClass->nmethods;
}


struct _methods *getMethodAtInKaffe(struct Hjava_lang_Class *currentClass, int index)
{
  return &(currentClass->methods[index]);
}

int getStaticFieldCountInKaffe(struct Hjava_lang_Class *currentClass)
{
  return currentClass->nsfields;
}

int getFieldCountInKaffe(struct Hjava_lang_Class *currentClass)
{
  return currentClass->nfields;
}

int getNonStaticFieldCountInKaffe(struct Hjava_lang_Class *currentClass)
{
  return currentClass->nfields - currentClass->nsfields;
}

const char *getFieldNameInKaffe(struct Hjava_lang_Class *currentClass, int index)
{
  return currentClass->fields[index].name->data;
}

struct _method_trace *getTraceOfMethod(struct _methods *sourceMethod)
{
    return sourceMethod->trace;
}

const char * getMethodNameInKaffe(struct _methods *currentMethod)
{
    return currentMethod->name->data;
}

const char * getMethodSigInKaffe(struct _methods *currentMethod)
{
    return currentMethod->parsed_sig->signature->data;
}

int getMethodStackSizeInKaffe(struct _methods *currentMethod)
{
    return currentMethod->stacksz;
}

int getLocalVariableCountInKaffe(struct _methods *currentMethod)
{
    return currentMethod->localsz;
}

int getCodelenOfMethodInKaffe(struct _methods *currentMethod)
{
    return currentMethod->c.bcode.codelen;
}

unsigned char *getCodeOfMethodInKaffe(struct _methods *currentMethod)
{
    return currentMethod->c.bcode.code;
}

void getFieldFromConstantPool(unsigned int idx, methods* currentMeth, int isStatic, struct identity_info *field)
{
    constants* pool;
    Hjava_lang_Class *currentClass=currentMeth->class;
    unsigned int ni,ci;
    int tag;

    pool = CLASS_CONSTANTS(currentClass);
    if (pool->tags[idx] != CONSTANT_Fieldref) {
        printf("error, No Fieldref found, tag was %d\n", pool->tags[idx]);
		abort();
	}

    ni = FIELDREF_NAMEANDTYPE(idx, pool);
	field->name = WORD2UTF(pool->data[NAMEANDTYPE_NAME(ni, pool)])->data;
	field->signature = WORD2UTF(pool->data[NAMEANDTYPE_SIGNATURE(ni, pool)])->data;

    ci = FIELDREF_CLASS(idx, pool);
    tag = pool->tags[ci];

	switch (tag) {
	case CONSTANT_ResolvedClass:
        field->cname= (CLASS_CLASS(ci, pool))->name->data;
        break;

	case CONSTANT_Class:
        field->cname= WORD2UTF(pool->data[ci])->data;
        break;
    default:
        printf("error, No Class found, tag was %d\n", pool->tags[ci]);
        abort();		
	}
}

void getMethodCallInfoFromConstantPool(unsigned int idx, methods* currentMeth, int loadClass, int isSpecial, struct identity_info *mcall)
{
    constants* pool;
    Hjava_lang_Class *currentClass=currentMeth->class;
    unsigned int ni,ci;
    int tag;

    pool = CLASS_CONSTANTS(currentClass);
    if (pool->tags[idx] != CONSTANT_Methodref &&
	    pool->tags[idx] != CONSTANT_InterfaceMethodref) 
    {
        printf("error, No Methodref found, tag was %d\n", pool->tags[idx]);
        abort();
	}

    ni = METHODREF_NAMEANDTYPE(idx, pool);
	mcall->name = WORD2UTF(pool->data[NAMEANDTYPE_NAME(ni, pool)])->data;
	mcall->signature = WORD2UTF(pool->data[NAMEANDTYPE_SIGNATURE(ni, pool)])->data;

    ci = METHODREF_CLASS(idx, pool);
    tag = pool->tags[ci];

	switch (tag) {
	case CONSTANT_ResolvedClass:
        mcall->cname= (CLASS_CLASS(ci, pool))->name->data;
        break;

	case CONSTANT_Class:
        mcall->cname= WORD2UTF(pool->data[ci])->data;
        break;
    default:
        printf("error, No Class found, tag was %d\n", pool->tags[ci]);
        abort();		
	}
}

const char* getClassNameFromConstantPoolInKaffe(unsigned int idx, struct _methods* currentMeth)
{
    constants* pool;
    Hjava_lang_Class *currentClass=currentMeth->class;
    int tag;

    pool = CLASS_CONSTANTS(currentClass);

    tag = pool->tags[idx];

	switch (tag) {
	case CONSTANT_ResolvedClass:
        return (CLASS_CLASS(idx, pool))->name->data;

	case CONSTANT_Class:
        return WORD2UTF(pool->data[idx])->data;

    default:
        printf("error, No Class found, tag was %d\n", pool->tags[idx]);
        abort();
	}
}

int getAllocObjectNumFromKaffe()
{
    return objectNum-1;
}

int getExecutedInstCountFromKaffe()
{
    return executedInstCount;
}

staticInitCallTraceEntry *getStaticInitTrace()
{
    return staticInitTrace;
}

int isNativeMethod(struct _methods* meth)
{
	//workaround for checking native method, as some abstract method is labeled native
	//may not be correct
    //if (meth->accflags & ACC_NATIVE || meth->accflags & ACC_ABSTRACT) 
    if (meth->accflags & ACC_NATIVE && !(meth->accflags & ACC_ABSTRACT))
        return 1;
    else
        return 0;
}

int getLineNumCountInKaffe(struct _methods* meth)
{
    if (meth->lines)
        return meth->lines->length;
    else
        return 0;
}

void getLineNumAtInKaffe(struct _methods* meth, unsigned int index, int *lineNum, int *startPC)
{
    lineNumberEntry *entry= &(meth->lines->entry[index]);
    *lineNum= entry->line_nr;
	*startPC= entry->start_pc;
}

int getExceptionsCountInKaffe(struct _methods* meth)
{
    if (meth->exception_table)
        return meth->exception_table->length;
    else
        return 0;
}

int getExceptionsTargetInKaffe(struct _methods* meth, int index)
{
    return meth->exception_table->entry[index].handler_pc;
}


call_frame* getTracingCallStack()
{
    return tracingCallStack;
}


const char* getClassNameofTracingCallFrame(call_frame *tracingCallFrame)
{
    return classNameList[tracingCallFrame->classID]->data;
}

const char* getMethodNameofTracingCallFrame(call_frame *tracingCallFrame)
{
    return methodNameList[tracingCallFrame->methodTrace->methodID]->data;
}

const char* getSigofTracingCallFrame(call_frame *tracingCallFrame)
{
    return sigList[tracingCallFrame->methodTrace->sigID]->data;
}

int insertFieldName(const char * fldName)
{
	return findFieldName(fieldNameList, (char *)fldName, &fieldNameCount);
}

char* getFieldName(int idx)
{
	return fieldNameList[idx];
}

int insertClassName(Utf8Const * name)
{
	return findName(classNameList, name, &classNameCount);
}

/********* utility functions ********/

unsigned int getByte(unsigned char *code)
{
	unsigned int a,b,c,d;

	a= 0x000000ff&code[0];
	b= 0x000000ff&code[1];
	c= 0x000000ff&code[2];
	d= 0x000000ff&code[3];

	return ((a<<24)|(b<<16)|(c<<8)|(d));
}

int getByte1(unsigned char *code)
{
  int a;
  a= 0x000000ff&code[0];
  return a;
}

int getByte2(unsigned char *code)
{
	unsigned int a,b;

	a= 0x000000ff&code[0];
	b= 0x000000ff&code[1];

	return (short)(((a<<8)|(b)));
}

int beginWith(char *p, char *begin)
{
  int length= strlen(begin);
  int length2= strlen(p);
  int i;

  if (length>length2)
    return 0;

  for (i=0; i<length; i++)
    {
        if (p[i] != begin[i])
            return 0;
    }
  return 1;
}


int findName(Utf8Const **list, Utf8Const *name, int *count)
{
	int i;

	for (i=0; i<(*count); i++)
	{
		if ( strcmp(list[i]->data, name->data) == 0)
		{
			return i;
		}
	}

	if ( (*count) >= MaxListMember )
	{
		printf("error some list overflow.\n");

		return 0;
	}

	list[(*count)]= name;
	name->nrefs++;

	(*count)++;
	
	if(list==classNameList)
	{
		updateClassNames(name->data, ((*count)-1));
	}
	else if(list==methodNameList)
	{
		updateMethodNames(name->data, ((*count)-1));
	}
	else if(list == sigList)
	{
		updateSigs(name->data, ((*count)-1));
	}


	return ((*count)-1);
}

int findFieldName(char **list, char *name, int *count)
{
	int i;

	for (i=0; i<(*count); i++)
	{
		if ( strcmp(list[i], name) == 0)
		{
			return i;
		}
	}

	if ( (*count) >= MaxListMember )
	{
		printf("error some list overflow.\n");

		return 0;
	}

	list[(*count)]= name;

	(*count)++;


	return ((*count)-1);
}

void* cleanMalloc(unsigned int size)
{
    void *obj= malloc(size);
    if (obj == NULL)
    {
         printf("not enough memory\n");
         exit(1);
    }
    memset(obj, 0, size);
    return obj;
}

int ifNeedTracing(methods *meth)
{ 
    char *className;

    if (startSlicing || ! ifTracingAndSlicing)
    {
        startTracing= 0;
        return 0;
    }
    
    if ( isNativeMethod(meth) ) 
        return 0;
	
    className= (char *)&(meth->class->name->data[0]);
    
    if(restoreCurrentNeedTracing)//maintain value for catch block
	{
		restoreCurrentNeedTracing = 0;
		return tracingCallStack->needTracing;
	}

    if ( beginWith(className, "java/") || beginWith(className, "kaffe/"))
	{
		return startTracing;
	}
	else
	{
        if (!startSlicing)
        {
  		    startTracing= 1;
		    return 1;
        }
        else
        {
            startTracing= 0;
            return 0;
        }
	}
}

/**************  init trace ****/
void initTracing(void)
{
	classNameCount= methodNameCount= sigCount= fieldNameCount= 0;

	defineclassid= (int*)cleanMalloc(sizeof(int)*MaxDepSize);
	definemethodid= (int*)cleanMalloc(sizeof(int)*MaxDepSize);
	definesigid= (int*)cleanMalloc(sizeof(int)*MaxDepSize);
	definepc= (int*)cleanMalloc(sizeof(int)*MaxDepSize);

	classNameList= 	(Utf8Const **)cleanMalloc(MaxListMember*sizeof(Utf8Const*));
	methodNameList= (Utf8Const **)cleanMalloc(MaxListMember*sizeof(Utf8Const*));
	sigList=  	    (Utf8Const **)cleanMalloc(MaxListMember*sizeof(Utf8Const*));
	fieldNameList=  (char **)cleanMalloc(MaxListMember*sizeof(char*));
    if (reportOverhead)
    {
	    otheroverhead+=3*MaxListMember*sizeof(Utf8Const*);
	    otheroverhead+=MaxListMember*sizeof(char*);
    }	

	freeSymbol=NULL;
	freeRule=NULL;
	freeCallFrame= NULL;

	trace= NULL;
	tracingCallStack= NULL;
	
	objectIDList= (objectIDEntry **)cleanMalloc(sizeof(objectIDEntry*)*OBJIDMASK);

    if (reportOverhead)
    {
	    otheroverhead+=sizeof(objectIDEntry*)*OBJIDMASK;
    } 
    
    initHotgraph();
    
#ifdef CollectFlowTrace
    collectedflowTrace= fopen("collectedflow", "w");
        if (NULL== collectedflowTrace)
        {
                printf("open se_trace file error\n");
                abort();
        }
#endif
}

void endTracing(void)
{
	startTracing= 0;
	
	compressRuleList();
	
	//dumpHotgraph();
	int nodecount= 0;
	int edgecount= 0;
	countHotgraph(&nodecount, &edgecount);
	int nodecount1=0;
	int edgecount1=0;
	countRuleOverhead(&nodecount1, &edgecount1);
	printf("total exec inst %d\n", executedInstCount-1);
	printf("nodes / edges in DDG: %d %d\n", nodecount, edgecount);
	printf("nodes / edges in rule: %d %d\n", nodecount1, edgecount1);
	printf("rule size: %d\n", countRuleSize());
	
	//finishTrace();
#ifdef CollectFlowTrace
        fclose(collectedflowTrace);
#endif    
}

/*********  maintain method trace and hash related **********/
void traceMethodCall(methods *meth)
{
	call_frame *newFrame;
  
#ifdef _CT_DEBUG
    printf("traceMethodCall %s\n", meth->name->data);
#endif

	newFrame= createCallFrame(meth);
	newFrame->prev= tracingCallStack;
    tracingCallStack= newFrame;

	if  ( (meth->accflags & ACC_STATIC) && (strcmp(meth->name->data, "<clinit>")==0) )
        newFrame->isStaticInit= 1;
	else
        newFrame->isStaticInit=0;

#ifdef CollectFlowTrace
          fprintf(collectedflowTrace, "enter %s.%s %s %d\n",  meth->class->name->data,
                                              meth->name->data,
                                              meth->parsed_sig->signature->data,
												executedInstCount);
#endif

	if(tracingCallStack->prev != NULL 
		&& tracingCallStack->prev->executingNativeMethod
		&& !tracingCallStack->isStaticInit)// by GL
	{
		tracingCallStack->prev->executedJava= 1;
		enterNativeCalledJavaMethod(tracingCallStack->prev, currentCallFrameLevel);
	}

	return;
}

static call_frame *createCallFrame(methods *meth)
{
	int classID;
	call_frame *newFrame;

#ifdef _CT_DEBUG
	printf("createCallframe %s\n", meth->name->data);
#endif
		

	if (NULL == freeCallFrame )
	{
		newFrame= (call_frame *)cleanMalloc(sizeof(call_frame));
	if (reportOverhead)
	  {
            otheroverhead+=sizeof(call_frame);
	        if (otheroverhead>maxotheroverhead)
                maxotheroverhead= otheroverhead;
        }
	}
	else
	{
		newFrame= freeCallFrame;
		freeCallFrame= freeCallFrame->prev;
        memset(newFrame, 0, sizeof(call_frame));
	}
	classID= findName(classNameList, meth->class->name, &classNameCount);

	newFrame->classID= classID;
	newFrame->prev= NULL;
	newFrame->methodTrace= findMethodTrace(meth, classID);
    newFrame->methodTrace->hasExecuted=1;       
	newFrame->lastPC= -1;
	newFrame->localCount= getLocalVariableCountInKaffe(meth);
	newFrame->operStackTop= -1;
	newFrame->retMethodTrace= NULL;
	newFrame->retPC= -1;
	newFrame->inCatch= -1;
	if(newFrame->localCount>0)
	{
		newFrame->locals= (int*)cleanMalloc(sizeof(int)*newFrame->localCount);
		memset(newFrame->locals, -1, sizeof(int)*newFrame->localCount);
	}
	newFrame->stackSize= getMethodStackSizeInKaffe(meth);
	if(newFrame->stackSize>0)
	{
		newFrame->operStack= (int*)cleanMalloc(sizeof(int)*newFrame->stackSize);
		//memset(newFrame->operStack, -1, sizeof(int)*newFrame->stackSize);
	}
	
	currentCallFrameLevel++;
	//printf("enter method %s.%s, %x\n", meth->class->name->data, meth->name->data, classID);
	return newFrame;
}

static method_trace* findMethodTrace(methods *meth, int classID)
{
	class_trace *classTrace;


#ifdef _CT_DEBUG
    printf("findMethodTrace, %s.%s, %x\n", meth->class->name->data, meth->name->data, classID);
#endif

	if (strcmp(meth->class->name->data, classNameList[classID]->data)!=0)
	{
		printf("class name is not consistant\n");
		exit(1);
	}


	if (meth->trace)
	  return meth->trace;

	classTrace= getClassTrace(meth, classID);

    if (meth->trace)
	  return meth->trace;
    else
      {
            printf("error, should have method trace now, %s.%s, %s\n", 
                        meth->class->name->data,
                        meth->name->data,
                        meth->parsed_sig->signature->data);
            exit(1);
        }

}

static method_trace* createMethodTrace(methods *meth, int classID, int methodID, int sigID)
{
	method_trace *newMethodTrace;
	method_hash *methodHash;
	int i, codelen;
	int *hash;
	int index;

#ifdef _CT_DEBUG
    printf("create method trace %s, %s, %s\n", classNameList[classID]->data, methodNameList[methodID]->data, sigList[sigID]->data);
#endif


	newMethodTrace= (method_trace *)cleanMalloc(sizeof(method_trace));
    if (reportOverhead)
    {
        otheroverhead+=sizeof(method_trace);
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;    
    }
	newMethodTrace->methodID= methodID;
	newMethodTrace->sigID= sigID;
	newMethodTrace->next= NULL;
	newMethodTrace->catchinst= NULL; // by GL
	
	methodHash= createMethodHash(meth, classID, methodID, sigID);

	hash= newMethodTrace->hash= methodHash->hash;

	newMethodTrace->instTrace= (inst_trace *)cleanMalloc(sizeof(inst_trace)*(methodHash->count));
    if (reportOverhead)
    {
        otheroverhead+=sizeof(inst_trace)*(methodHash->count);
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;
    }

	newMethodTrace->instTracingNumber= methodHash->count;

    newMethodTrace->callInfo= (oper_trace *)cleanMalloc(sizeof(oper_trace));
    if (reportOverhead)
    {
        otheroverhead+=sizeof(oper_trace);
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;
    }

    codelen=meth->c.bcode.codelen;

	for (i=0; i<codelen; i++)
	{
		if (hash[i] != 0)
		{
			index= (hash[i]&0x7FFFFFFF)-1;
			newMethodTrace->instTrace[index].pc= i;
		}
	}
	
	free(methodHash);

    if (reportOverhead)
    {
        otheroverhead-=sizeof(method_hash);
    }
	return newMethodTrace;
}


static method_hash* createMethodHash(methods *meth, int classID, int methodID, int sigID)
{
	method_hash *newMethodHash;
	int codeLen, count, pc, oldpc;
	int *hash;
	int *entry;
	char *code;
	unsigned int instruction;
	int low, high, idx;
	int i, branch;
	unsigned int target;
    //char instWord[MAXLINECHAR];	

#ifdef _CT_DEBUG
    printf("create method hash %s.%s,%s, %d\n", meth->class->name->data, methodNameList[methodID]->data, sigList[sigID]->data, meth->c.bcode.codelen);
#endif
	
	newMethodHash=(method_hash *)cleanMalloc(sizeof(method_hash));

    if (reportOverhead)
    {
        otheroverhead+=method_hash_size;
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;
    }

	newMethodHash->next=NULL;
	newMethodHash->methodID= methodID;
	newMethodHash->sigID= sigID;

	codeLen= meth->c.bcode.codelen;
	code= meth->c.bcode.code;

	newMethodHash->hash= hash= (int *)cleanMalloc(sizeof(int)*codeLen);
	if (reportOverhead)
    {
        otheroverhead+=sizeof(int)*codeLen;
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;
    }

    entry= (int *)cleanMalloc(sizeof(int)*codeLen);
    for(i=0; i<codeLen; i++)
        entry[i]= 1;
	
    if (reportOverhead)
    {
        otheroverhead+= sizeof(int*)*codeLen;
        if (otheroverhead>maxotheroverhead)
           maxotheroverhead= otheroverhead;
    }


	pc=0;

    while(pc< codeLen)
    {
        instruction= (unsigned int)(0x000000ff & code[pc]);

        //if ( instOper[instruction]!= 0)
        //{
            hash[pc]= hash[pc]|0x00000001;
        //}

        if ( controlInfo[instruction] == 1 )
        {
            target= getByte2(&(code[pc+1]));
            target= pc+target;

            entry[target]++;

            pc+=instLen[instruction];

            if (GOTO == instruction &&  pc < codeLen)
            {
                entry[pc]--;
                continue;
            }

            if (JSR == instruction)
            {
                entry[target]++;
            }
            continue;
        }

        if ( controlInfo[instruction] == 2 )
        {
            branch=(int)getByte(&(code[pc+1]));
            branch= pc+branch;

            entry[branch]++;

            pc+=instLen[instruction];

            if ( GOTO_W == instruction &&  pc < codeLen)
            {
                entry[pc]--;
                continue;
            }

            if (JSR_W == instruction)
            {
                entry[branch]++;
            }

            continue;
        }

        if (TABLESWITCH == instruction)
        {
            oldpc= pc;
            pc=pc+ (4- (pc%4));

            branch=(int)getByte(&(code[pc]));
            branch= oldpc+branch;
            entry[branch]++;

            low=(int)getByte(&(code[pc+4]));
            high=(int)getByte(&(code[pc+8]));

            pc=pc+12;

            for (i=low; i<=high; i++)
            {
                branch=(int)getByte(&(code[pc]));
                branch= oldpc+branch;
                entry[branch]++;
                pc= pc+4;
            }
            entry[pc]--;

            continue;
        }

        if (LOOKUPSWITCH == instruction)
        {
            oldpc= pc;
            pc=pc+ (4- (pc%4));

            branch=(int)getByte(&(code[pc]));
            branch= oldpc+branch;
            entry[branch]++;

            idx=(int)getByte(&(code[pc+4]));

            pc= pc+8;

            for (i=0; i<idx; i++)
            {
                branch=(int)getByte(&(code[pc+4]));
                branch= oldpc+branch;
                entry[branch]++;
                pc= pc+8;
            }
            entry[pc]--;
            continue;
        }

        if (WIDE == instruction)
        {
            pc++;
            instruction= 0x00ff & (int)code[pc];
            pc+=instLen[instruction]*2-1;
            continue;
        }

        pc+=instLen[instruction];

        if ( IRETURN <= instruction && RETURN >=instruction && pc < codeLen)
        {  
            entry[pc]--;
            continue;
        }

        if ( RET == instruction && pc < codeLen )
        {
            entry[pc]--;
        }
    }        

	count=0;

	for(i=0; i<codeLen; i++)
	{
		if (hash[i] != 0 || entry[i]>1)
		{
			count++;
			if (entry[i]>1)
				hash[i]= 0x80000000|count;
			else
				hash[i]= count;
		}
	}
	newMethodHash->count=count;
	free(entry);
	return newMethodHash;
}

class_trace* getClassTrace(struct _methods *meth, int classID)
{
	class_trace *newClassTrace, *currentClassTrace;

#ifdef _CT_DEBUG
    printf("getClassTrace %s.%s,\n", meth->class->name->data, meth->name->data);
#endif


	currentClassTrace= trace;

	if ( NULL == trace)
	{
		trace= createClassTrace(meth, classID);
		return (trace);
	}


	while(currentClassTrace->next!=NULL)
	{
		if (currentClassTrace->classID == classID)
		{
			break;
		}
		currentClassTrace= currentClassTrace->next;
	}

 	if (currentClassTrace->classID == classID)
	{
		return currentClassTrace;
	}
	else
	{
		newClassTrace= createClassTrace(meth, classID);
       
		newClassTrace->next= trace;
		trace= newClassTrace;


		return newClassTrace;
 	}
}

static class_trace* createClassTrace(methods *meth, int classID)
{
	class_trace *newClassTrace;
    method_trace *newMethodTrace;
    methods *currentMeth;
    int methIndex;
   	Hjava_lang_Class	*jclass;
    int methodID,	sigID;
    
#ifdef _CT_DEBUG 
    printf("createClassTrace, %s\n", classNameList[classID]->data);
#endif
	jclass= meth->class;

	newClassTrace= (class_trace *)cleanMalloc(sizeof(class_trace));
    if (reportOverhead)
    {
        otheroverhead+=sizeof(class_trace);
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;
    }
    newClassTrace->javaClass= meth->class; 
    newClassTrace->classID= classID;
    newClassTrace->methodTrace= NULL;
    newClassTrace->next= NULL;
    for(methIndex=0; methIndex<jclass->nmethods; methIndex++)
    {
        currentMeth=&(jclass->methods[methIndex]); 
        if (isNativeMethod(currentMeth))
            continue;
	

        methodID= findName(methodNameList, currentMeth->name, &methodNameCount);
        sigID= findName(sigList, currentMeth->parsed_sig->signature, &sigCount);


        newMethodTrace= createMethodTrace(currentMeth, classID, methodID, sigID);
        
        newMethodTrace->classTrace= newClassTrace;

        newMethodTrace->next= newClassTrace->methodTrace;

        newClassTrace->methodTrace= newMethodTrace;
        currentMeth->trace= newMethodTrace;
    }

    tracedClassCount++;
    
    buildCDG(newClassTrace);
    
	return newClassTrace;
}


static void walkCallStack()
{
	call_frame *walk;
	method_trace *methodTrace;
	class_trace *classTrace;

	walk= tracingCallStack;

	while(walk!=NULL)
	{
		printf("%x:%s.",(int)(walk->methodTrace), classNameList[walk->classID]->data);
		methodTrace= walk->methodTrace;
		printf("%s %s.", methodNameList[methodTrace->methodID]->data, sigList[methodTrace->sigID]->data);
		printf("hash %x\n", (int)methodTrace->hash);
		walk= walk->prev;
	}

	printf("************* class trace\n");
	classTrace= trace;

	while( classTrace!=NULL)
	{
		printf("%s. ", classNameList[classTrace->classID]->data);
		methodTrace= classTrace->methodTrace;
		while(methodTrace!= NULL)
		{
			printf("%x,", (int)methodTrace);
			methodTrace= methodTrace->next;
		}
		classTrace= classTrace->next;
	}
}

//by GL
int isCallFrameMatch(methods* meth)
{
	call_frame *currentCallFrame;
	if(meth == NULL) {
		printf("Error: trace.c:isCallFrameMatch: method is null");
		return 0;
	}
	
	currentCallFrame= tracingCallStack;
	
	if(currentCallFrame == NULL) {
		printf("Warn: trace.c: current call frame is null\n");
		return 0;
	}
	
	if(strcmp(classNameList[currentCallFrame->classID]->data, meth->class->name->data) != 0
		|| strcmp(methodNameList[currentCallFrame->methodTrace->methodID]->data, meth->name->data) != 0
		|| strcmp(sigList[currentCallFrame->methodTrace->sigID]->data, meth->parsed_sig->signature->data) != 0) {
		return 0;
	}
	else {
		return 1;
	}
}
//

void exitMethod(methods* meth, int exitDueToException)
{
	call_frame *releaseFrame;
	call_frame *currentCallFrame;
    staticInitCallTraceEntry *newStaticInitCallTraceEntry;

#ifdef _CT_DEBUG
    printf("exit method %s.%s %s\n", meth->class->name->data,  meth->name->data, meth->parsed_sig->signature->data);
#endif
	//printf("exit method %s.%s %s\n", meth->class->name->data,  meth->name->data, meth->parsed_sig->signature->data);

	currentCallFrame= tracingCallStack;

#ifdef CollectFlowTrace
        fprintf( collectedflowTrace, "exit %s.%s %s %d\n", meth->class->name->data,  meth->name->data, meth->parsed_sig->signature->data, executedInstCount);
#endif

	if(tracingCallStack->prev != NULL 
		&& tracingCallStack->prev->executingNativeMethod
		&& !tracingCallStack->isStaticInit)// by GL
	{
		if(exitDueToException)
		{
			//pop native_call_method_list from stack
			/*
#ifdef CollectFlowTrace
			fprintf(collectedflowTrace, "native: pop for exception %s:%d with java method: %s.%s(%s)\n", getMethodNameofTracingCallFrame(tracingCallStack->prev), tracingCallStack->prev->lastPC, meth->class->name->data, meth->name->data, meth->parsed_sig->signature->data);
#endif
			removeStackTop(tracingCallStack->prev);
			*/
		}
		else
		{
			exitNativeCalledJavaMethod(tracingCallStack->prev, tracingCallStack, currentCallFrameLevel);

#ifdef CollectFlowTrace
			fprintf(collectedflowTrace, "update native call %s.%s:%d with java method: %s.%s(%s)\n", classNameList[tracingCallStack->prev->classID]->data, getMethodNameofTracingCallFrame(tracingCallStack->prev), tracingCallStack->prev->lastPC, meth->class->name->data, meth->name->data, meth->parsed_sig->signature->data);
#endif
		}
	}
	
	if (tracingCallStack->isStaticInit)
	{
        newStaticInitCallTraceEntry= (staticInitCallTraceEntry *)cleanMalloc(sizeof(staticInitCallTraceEntry));
	    if (tracingCallStack->prev)
	      {
	           newStaticInitCallTraceEntry->classNameId= tracingCallStack->prev->classID;
               newStaticInitCallTraceEntry->methodNameId=tracingCallStack->prev->methodTrace->methodID; 
               newStaticInitCallTraceEntry->sigId=tracingCallStack->prev->methodTrace->sigID;
	           newStaticInitCallTraceEntry->lastPC=tracingCallStack->prev->lastPC;
               newStaticInitCallTraceEntry->count=executedInstCount;
               newStaticInitCallTraceEntry->invokedClassNameId=tracingCallStack->classID;
	      }
	    else
	      {

               newStaticInitCallTraceEntry->classNameId= -1;
               newStaticInitCallTraceEntry->methodNameId=-1; 
               newStaticInitCallTraceEntry->sigId=-1;
	           newStaticInitCallTraceEntry->lastPC=-1;
               newStaticInitCallTraceEntry->count=executedInstCount;
               newStaticInitCallTraceEntry->invokedClassNameId=tracingCallStack->classID;
	      }

        if (staticInitTrace==NULL)
            staticInitTrace= newStaticInitCallTraceEntry;
        if (lastStaticInitCallEntry!= NULL)
            lastStaticInitCallEntry->next= newStaticInitCallTraceEntry;
        lastStaticInitCallEntry= newStaticInitCallTraceEntry;        
	}
/*
	traceCallInfo(tracingCallStack->methodTrace->callInfo, tracingCallStack->lastPC);
*/

	if ( strcmp(classNameList[currentCallFrame->classID]->data, meth->class->name->data) != 0
		|| strcmp(methodNameList[currentCallFrame->methodTrace->methodID]->data, meth->name->data) != 0
		|| strcmp(sigList[currentCallFrame->methodTrace->sigID]->data, meth->parsed_sig->signature->data) != 0	)
	{
		printf("call stack notmatch\n");
		walkCallStack();
		abort();
	} 
	
    //store last exec bc for possible data dep who uses return value
    if(tracingCallStack->prev != NULL)
    {
    	if(exitDueToException && tracingCallStack->retMethodTrace!=NULL)
        {
    		tracingCallStack->prev->retMethodTrace= tracingCallStack->retMethodTrace;
    		tracingCallStack->prev->retPC= tracingCallStack->retPC;
        }
        else
        {
        	tracingCallStack->prev->retMethodTrace= tracingCallStack->methodTrace;
        	tracingCallStack->prev->retPC= tracingCallStack->lastPC;
        }
    }

	releaseFrame= currentCallFrame;
	tracingCallStack= currentCallFrame->prev;
	releaseFrame->prev= freeCallFrame;
	freeCallFrame= releaseFrame;
	if(releaseFrame->locals!=NULL)
	{
		free(releaseFrame->locals);
	}
	if(releaseFrame->operStack!=NULL)
	{
		free(releaseFrame->operStack);
	}
	if(currentCallFrameLevel==-1)
		printf("error: call frame level value incorrect\n");
	currentCallFrameLevel--;

	if (tracingCallStack==NULL)
	  startTracing= 0;
	return;
}

void defineLocal(call_frame *currentCallFrame, int localIndex, int pc)
{
	//pc defines the local var
	if(localIndex>=currentCallFrame->localCount)
	{
		printf("error: local count exceeds\n");
		exit(1);
	}
	currentCallFrame->locals[localIndex]= pc;
}

int useLocal(call_frame *currentCallFrame, int localIndex)
{
	//return the pc that defined the local var
	if(localIndex>=currentCallFrame->localCount)
	{
		printf("error: local count exceeds\n");
		exit(1);
	}
	return currentCallFrame->locals[localIndex];
}

void pushOperStack(call_frame *currentCallFrame, int size, int pc)
{
	//pc push oper of size items
	int newOperStackTop= currentCallFrame->operStackTop+size;
		
    if ( newOperStackTop >= currentCallFrame->stackSize)
    {
        printf("oper stack overflow, %d\n", executedInstCount);
        exit(1);
    }
    

    for(; currentCallFrame->operStackTop < newOperStackTop; currentCallFrame->operStackTop++)
    {
    	currentCallFrame->operStack[currentCallFrame->operStackTop+1]= pc;
    }
}

void popOperStack(call_frame *currentCallFrame, int size, int* defpc)
{
	//return list of pc that pushed the stack with size
	int newOperStackTop= currentCallFrame->operStackTop-size;

    if ( newOperStackTop < -1)
    {
        printf("oper stack underflow, %d\n", executedInstCount);
        exit(1);
    }

	//int* result= (int*)cleanMalloc(sizeof(int)*size);
    //put the toppest to the back of return list
	int count=size-1;
	
    for(; currentCallFrame->operStackTop> newOperStackTop; currentCallFrame->operStackTop--)
    {
    	int temp= currentCallFrame->operStack[currentCallFrame->operStackTop]; 
        //if (temp)
        //{
        	//currentCallFrame->operStackTop= newOperStackTop;
            defpc[count]= temp;
            count--;
        //}
//        else
//        {
//        	printf("error: oper stack has no value\n");
//        	exit(1);
//        }
    }
    
    //return result;
}

/********  trace ******/

unsigned int getAddrOffset(unsigned int addr)
{
	addr= addr>>(OBJIDOFFSET);

	return (addr%OBJIDMASK);
}

objectIDEntry* malloc_objID(unsigned int addr)
{
	objectIDEntry* newObjID;


	newObjID=(objectIDEntry *)cleanMalloc(sizeof(objectIDEntry));
    if (reportOverhead)
    {
        otheroverhead+= sizeof(objectIDEntry);
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;
    }
	newObjID->addr=addr;
	newObjID->number=objectNum;
	objectNum++;

	newObjID->next=NULL;
	return (newObjID);
}


objectIDEntry* getObjectID(void* addr)
{ 
	unsigned int offset;
	objectIDEntry *objectID;

	offset= getAddrOffset((unsigned int)addr);


	if (NULL == objectIDList[offset])
	{		
		objectIDList[offset]=malloc_objID((unsigned int)addr);
		return (objectIDList[offset]);
	}

	objectID= objectIDList[offset];
	while(NULL != objectID )
	{
		if (objectID->addr == (unsigned int)addr)
			return (objectID);

		objectID= objectID->next;
	}

	objectID=malloc_objID((unsigned int)addr);
	objectID->next= objectIDList[offset];
	objectIDList[offset]= objectID;
	
	return (objectID);
}

objectIDEntry* insertObjectID(void* addr)
{
	unsigned int offset;
	objectIDEntry *objectID;

	if (!startTracing)
		return NULL;

	offset= getAddrOffset((unsigned int) addr);

	if (NULL == objectIDList[offset])
	{
		objectIDList[offset]=malloc_objID((unsigned int)addr);
		return (objectIDList[offset]);
	}

	objectID= objectIDList[offset];
	while(NULL != objectID )
	{
		if (objectID->addr == (unsigned int)addr)
		{
			objectID->number= objectNum;
			objectNum++;
			return (objectID);
		}
		objectID= objectID->next;
	}
	objectID=malloc_objID((unsigned int)addr);
	objectID->next= objectIDList[offset];
	objectIDList[offset]= objectID;

	return (objectID);
}

void* getAddrFromObjectID(int id)
{
	int i=0;	
	for(i =0; i <OBJIDMASK; i++)
	{
		objectIDEntry *idEntry = objectIDList[i];
		if(idEntry!=NULL && idEntry->number==id)
		{
			int exp = getObjectID((void *)idEntry->addr)->number;
			if(exp != id)
				printf("error: wrong addr\n");
			return (void *)idEntry->addr;
		}
	}
	return (void *)NULL;
}

void traceCallInfo(oper_trace *operTrace, int value)
{
	if ( NULL == operTrace->s)
	{
		initOperTrace(operTrace, value);
	}
	else
	{
		traceOper(operTrace, value, 1);
	}
}

void traceControlInfo(inst_trace* instTrace, int value)
{
	oper_trace *operTrace;
/*
	if (NULL == instTrace->controlTrace)
	{
		operTrace= instTrace->controlTrace= (oper_trace *)cleanMalloc(sizeof(oper_trace));
        if (reportOverhead)
        {
            otheroverhead+=sizeof(oper_trace);
            if (otheroverhead>maxotheroverhead)
                maxotheroverhead= otheroverhead;
        }
		initOperTrace(operTrace, value);
	}
	else
	{
		traceOper(instTrace->controlTrace, value, 1);
	}
	*/
	return;
}

void traceInstruction (inst_info* instInfo)
{
	oper_trace *operTrace;
	call_frame *currentCallFrame;
	method_trace *methodTrace;
	int index,i;
	inst_trace *instTrace;

	//if ( instInfo->operand_num ==0)
	//  return;

	currentCallFrame=  tracingCallStack;
	methodTrace= currentCallFrame->methodTrace;
	index= ((methodTrace->hash[instInfo->pc])&0x7FFFFFFF)-1;

	//printf("trace %s %d - %d\n", methodNameList[methodTrace->methodID]->data, instInfo->pc, tracingCallStack->operStackTop);

	if (index== -1)
	{
		printf("error! no instruction trace slot %s, %s, %s, %d, %s\n", classNameList[tracingCallStack->classID]->data,
		    methodNameList[methodTrace->methodID]->data, sigList[methodTrace->sigID]->data,
            instInfo->pc, 
            bytecodeName[instInfo->instruction]
            );

		exit(1);
	}

	instTrace= &(methodTrace->instTrace[index]);


	if (instTrace->pc != instInfo->pc)
	{
		methodTrace= tracingCallStack->methodTrace;
		printf("trace pc error,%s.%s, %x, %x\n",classNameList[tracingCallStack->classID]->data,
		    methodNameList[methodTrace->methodID]->data, instTrace->pc, instInfo->pc);
		exit(1);
	}
/*
	if (NULL == instTrace->operTrace)
	{
		instTrace->operand_num= instInfo->operand_num;

		instTrace->operTrace= (oper_trace *)cleanMalloc(instInfo->operand_num*sizeof(oper_trace));
        if (reportOverhead)
        {
            otheroverhead+=instInfo->operand_num*sizeof(oper_trace);
            if (otheroverhead>maxotheroverhead)
                maxotheroverhead= otheroverhead;
        }
		operTrace= instTrace->operTrace;
		for(i=0; i<instTrace->operand_num;i++)
		{
			initOperTrace(&(operTrace[i]), instInfo->operands[i]);
		}
	}
	else
	{
		operTrace= instTrace->operTrace;
		for (i=0; i<instTrace->operand_num;i++)
		{

			traceOper(&(operTrace[i]), instInfo->operands[i], 1);
		}
	}
	*/
	
    tracingCallStack->lastPC= instInfo->pc;
                                                                                                                         
    //store the ctrl dep current->invoke or current->exceptionPoint
    //this dep is only created when current has no ctrl dep
    //otherwise, the invoke can be visited in traversal
    int calldepclassid= -1;
    int calldepmethodid= -1;
    int calldepsigid= -1;
    int calldeppc= -1;
    if(tracingCallStack->inCatch > -1)
    {
        if(tracingCallStack->retMethodTrace == NULL)
        {
            printf("error: retMethodTrace is null\n");
            exit(1);
        }
        //in catch block
        //make dep from current to exception point
        instInfo->depclassid[instInfo->depsize]= tracingCallStack->retMethodTrace->classTrace->classID;
        instInfo->depmethodid[instInfo->depsize]= tracingCallStack->retMethodTrace->methodID;
        instInfo->depsigid[instInfo->depsize]= tracingCallStack->retMethodTrace->sigID;
        instInfo->deppc[instInfo->depsize]= tracingCallStack->retPC;
        instInfo->depsize= instInfo->depsize+1;
                                                                                                                     
        if(instInfo->instruction == RETURN)
        {
            tracingCallStack->inCatch= -1;
        }
    }
    else if (tracingCallStack->isStaticInit==0 && tracingCallStack->prev != NULL)
    {
		//create ctrl dep from called meth to invoke bc
		calldepclassid= tracingCallStack->prev->classID;
		calldepmethodid= tracingCallStack->prev->methodTrace->methodID;
		calldepsigid= tracingCallStack->prev->methodTrace->sigID;
		calldeppc= tracingCallStack->prev->lastPC;
	}
	
	createNode(tracingCallStack->classID, methodTrace, instInfo->pc, 
			instInfo->depclassid, instInfo->depmethodid, instInfo->depsigid, 
			instInfo->deppc, instInfo->depsize,
			calldepclassid, calldepmethodid, calldepsigid, calldeppc);
	
	instTrace->latestTimestamp= executedInstCount;
	
	/*if(instInfo->depsize>0)
	{
		free(instInfo->depclassid);
		free(instInfo->depmethodid);
		free(instInfo->depsigid);
		free(instInfo->deppc);
	}*/
	return;
}

void traceSpecialValue(int pc, int value)
{
	oper_trace *operTrace;
	call_frame *currentCallFrame;
	method_trace *methodTrace;
	int index,i;
	inst_trace *instTrace;

	currentCallFrame=  tracingCallStack;
	methodTrace= currentCallFrame->methodTrace;
	index= ((methodTrace->hash[pc])&0x7FFFFFFF)-1;


	if (index== -1)
	{
		printf("error! no instruction trace slot %s, %s, %s, %d\n", classNameList[tracingCallStack->classID]->data,
		    methodNameList[methodTrace->methodID]->data, sigList[methodTrace->sigID]->data,
            pc);

		exit(1);
	}

	instTrace= &(methodTrace->instTrace[index]);


	if (instTrace->pc != pc)
	{
		methodTrace= tracingCallStack->methodTrace;
		printf("trace pc error,%s.%s, %x, %x\n",classNameList[tracingCallStack->classID]->data,
		    methodNameList[methodTrace->methodID]->data, instTrace->pc, pc);
		exit(1);
	}
/*
	if (NULL == instTrace->valueTrace)
	{
		instTrace->valueTrace= (oper_trace *)cleanMalloc(sizeof(oper_trace));
        if (reportOverhead)
        {
            otheroverhead+=sizeof(oper_trace);
            if (otheroverhead>maxotheroverhead)
                maxotheroverhead= otheroverhead;
        }
		operTrace= instTrace->valueTrace;
		initOperTrace(operTrace, value);
	}
	else
	{
		operTrace= instTrace->valueTrace;
		traceOper(operTrace, value, 1);
	}*/
	
	return;
}

void finishTrace(void)
{
    class_trace		*classTrace;
    method_trace		*methodTrace;
    inst_trace		*instTrace;
    oper_trace		*operTrace;
    int i, j;

	classTrace= trace;

    while(classTrace != NULL)
    {
        methodTrace= classTrace->methodTrace;        
		while(methodTrace!=NULL)
		{
            if (! methodTrace->hasExecuted)
             {
                    methodTrace= methodTrace->next;
                    continue;
             }

            if (methodTrace->callInfo->s!=NULL)
            {
                traceOper(methodTrace->callInfo, methodTrace->callInfo->lastBase, 0);
                check_digram(methodTrace->callInfo->s, 
                            methodTrace->callInfo->s->guard->prev->prev, 
                            &(methodTrace->callInfo->index));
            }

			for (i=0; i<methodTrace->instTracingNumber; i++)
			{
				instTrace= &(methodTrace->instTrace[i]);
    

                if (NULL != instTrace->controlTrace)
                {
                    operTrace= instTrace->controlTrace;
                    traceOper(operTrace, operTrace->lastBase, 0);
                    check_digram(operTrace->s, operTrace->s->guard->prev->prev, &(operTrace->index));
                   
				}

                for (j=0; j<instTrace->operand_num; j++)
                {
                    operTrace= &(instTrace->operTrace[j]);
                    traceOper(operTrace, operTrace->lastBase, 0);
                    check_digram(operTrace->s, operTrace->s->guard->prev->prev, &(operTrace->index));

                }
                
                if(NULL != instTrace->valueTrace)
                {
                	operTrace= instTrace->valueTrace;
                	traceOper(operTrace, operTrace->lastBase, 0);
                	check_digram(operTrace->s, operTrace->s->guard->prev->prev, &(operTrace->index));
                }

			}
 			methodTrace= methodTrace->next;
		}
		classTrace= classTrace->next;
	}

    if (reportOverhead)
    {
        printf("sizeofRule %d, sizeof symbol %d\n", sizeof(ct_rule), sizeof(ct_symbol));
        printf("invoketime %d, operand: %d, check digram: %d, symbolCount: %d, ruleCount: %d, btree: %d K rlese: %d K otheroverhead %d K\n", 
        invoketime, operandNum, checkDigramCount, maxsymbolCount, maxruleCount,  maxbtreeoverhead/(1024), maxrleseoverhead/(1024), maxotheroverhead/(1024) );
    }
}

// by GL
void dumpTrace(void)
{
    class_trace		*classTrace;
    method_trace	*methodTrace;
    inst_trace		*instTrace;
    oper_trace		*operTrace;
    int i, j;

	classTrace= trace;

    while(classTrace != NULL)
    {
        methodTrace= classTrace->methodTrace;
        printf("class: %s\n", classNameList[classTrace->classID]->data);
		while(methodTrace!=NULL)
		{
			printf("\tmethod: %s, %d\n", methodNameList[methodTrace->methodID]->data, methodTrace->instTracingNumber);
			dumpNativeCall(methodTrace);
			dumpCatchInst(methodTrace);
			/*for (i=0; i<methodTrace->instTracingNumber; i++)
			{
				instTrace= &(methodTrace->instTrace[i]);
				printf("\t\tinst pc:%d\n", instTrace->pc);
			}*/
 			methodTrace= methodTrace->next;
		}
		classTrace= classTrace->next;
	}
	printf("end dump\n");
}

void dumpHotgraph(void)
{
    class_trace		*classTrace;
    method_trace	*methodTrace;
    inst_trace		*instTrace;
    oper_trace		*operTrace;
    int i, j;

	classTrace= trace;
	
	printf("begin dump\n");

    while(classTrace != NULL)
    {
        methodTrace= classTrace->methodTrace;
        printf("class: %s\n", classNameList[classTrace->classID]->data);
		while(methodTrace!=NULL)
		{
			printf("\tmethod: %s, %d\n", methodNameList[methodTrace->methodID]->data, methodTrace->instTracingNumber);
			//dumpNativeCall(methodTrace);
			//dumpCatchInst(methodTrace);
			
			if(methodTrace->hasExecuted == 0)
			{
				methodTrace= methodTrace->next;
				continue;
			}
			
			for (i=0; i<methodTrace->instTracingNumber; i++)
			{
				instTrace= &(methodTrace->instTrace[i]);
				printf("\t\tinst pc:%d\n", instTrace->pc);
				dumpInstHotgraph(instTrace);
			}
 			methodTrace= methodTrace->next;
		}
		classTrace= classTrace->next;
	}
    
    dumpRule();
	printf("end dump\n");
}


void countHotgraph(int* nodecount, int* edgecount)
{
    class_trace		*classTrace;
    method_trace	*methodTrace;
    inst_trace		*instTrace;
    oper_trace		*operTrace;
    int i, j;

   // *nodecount = 0;
   // *edgecount = 0;
	classTrace= trace;

    while(classTrace != NULL)
    {
        methodTrace= classTrace->methodTrace;
		while(methodTrace!=NULL)
		{
			
			if(methodTrace->hasExecuted == 0)
			{
				methodTrace= methodTrace->next;
				continue;
			}
			
			for (i=0; i<methodTrace->instTracingNumber; i++)
			{
				instTrace= &(methodTrace->instTrace[i]);
				//printf("pc %d %d\n", instTrace->pc, i);
				countNodeEdge(instTrace->instances, nodecount, edgecount);
			}
 			methodTrace= methodTrace->next;
		}
		classTrace= classTrace->next;
	}
    
    //count+=countRuleOverhead();
    
    //return count;
}
 
/********* RLESe compressed trace related ******/
ct_rule* malloc_rule(int index)
{
	ct_rule *newrule;
	ct_symbol *guard;

    if (reportOverhead)
    {
	    rleseoverhead+=(ct_rule_size);
	    rleseoverhead+=(ct_symbol_size);
	    symbolCount++;
	    ruleCount++;
        if (rleseoverhead>maxrleseoverhead)
            maxrleseoverhead= rleseoverhead;

        if (symbolCount>maxsymbolCount)
            maxsymbolCount= symbolCount;

        if (ruleCount>maxruleCount)
            maxruleCount= ruleCount;
    }

	if (NULL == freeRule)
	{
		newrule= (ct_rule *)cleanMalloc(ct_rule_size);
	}
	else
	{
		newrule= freeRule;
		freeRule=freeRule->next;
        memset(newrule, 0,ct_rule_size);
	}

	newrule->count= 0;
	newrule->index= index;
	newrule->next= NULL;

	if (freeSymbol==NULL)
	{
		newrule->guard= guard= (ct_symbol *)cleanMalloc(ct_symbol_size);
	}
	else
	{
		newrule->guard= guard= freeSymbol;
		freeSymbol= freeSymbol->next;
        memset(guard, 0, ct_symbol_size);
	}

	guard->next= guard->prev =guard;
	guard->type= GUARD_SYMBOL;
	guard->value->rule= newrule;

	return newrule;
}


void free_rule(ct_rule *s, ct_rule *rule)
{
	ct_rule *iter=s;

	while(iter->next != rule)
	{
		iter=iter->next;
	}

	iter->next= rule->next;

	rule->guard->next= freeSymbol;
	freeSymbol= rule->guard;

	rule->next= freeRule;
	freeRule= rule;

    if (reportOverhead)
    {
        rleseoverhead-=ct_rule_size;
        rleseoverhead-=ct_symbol_size;
        ruleCount--;
        symbolCount--;
    }
}

ct_symbol* malloc_symbol(SymbolType type, int value, int count)
{
	ct_symbol *newSymbol;

    if (reportOverhead)
    {
        symbolCount++;
        rleseoverhead+=ct_symbol_size;

        if (symbolCount>maxsymbolCount)
            maxsymbolCount= symbolCount;

        if (rleseoverhead>maxrleseoverhead)
            maxrleseoverhead= rleseoverhead;
    }

	if (freeSymbol==NULL)
	{
		newSymbol=(ct_symbol *)cleanMalloc(ct_symbol_size);        
	}
	else
	{
		newSymbol= freeSymbol;
		freeSymbol= freeSymbol->next;
        memset(newSymbol, 0,ct_symbol_size);
	}

	newSymbol->type= type;
	newSymbol->value->offset= value;	/* offset and child has the same address, use one assignment can do it */
	newSymbol->count=count;
	newSymbol->next= newSymbol->prev=NULL;

	if (NON_TERMINAL_SYMBOL == type)
	{
		((ct_rule *)value)->count++;
	}
	return newSymbol;
}


void free_symbol(ct_symbol *node)
{
    if (reportOverhead)
    {
        symbolCount--;
        rleseoverhead-=ct_symbol_size;
    }

    checkCheckStack(node);

    join(node->prev, node->next);

    if (NON_TERMINAL_SYMBOL == node->type)
    {
	    node->value->rule->count--;
    }

	node->next= freeSymbol;
	freeSymbol=node;
}

inline void join(ct_symbol *left, ct_symbol *right)
{
	left->next= right;
	right->prev= left;
}

KeyType getHashCode(ct_symbol *digram)
{
 	unsigned int hash1, hash2;
	KeyType key;
	ct_symbol *next= digram->next;

	if (TERMINAL_SYMBOL == digram->type)
	{
		hash1= (unsigned int) digram->value->offset;
	}
	else
	{
		hash1= (unsigned int) digram->value->rule->index;
	}

	if (TERMINAL_SYMBOL == next->type)
	{
		hash2= (unsigned int) next->value->offset;
	}
	else
	{
		hash2= (unsigned int) next->value->rule->index;
	}

	key= ( ((KeyType)hash1)<<32)+hash2;


	return key;
}

void insertAfter(ct_symbol *x, ct_symbol *y)
{
	join(y, x->next);
	join(x, y);
}

ct_symbol* find_digram(ct_rule *s, ct_symbol *node, DigramIndex **index)
{
	KeyType hashKey;	
	hashKey= getHashCode(node);
	return findNode(s, index, hashKey, node);
}

ct_symbol* substitude(ct_symbol *node, ct_rule *rule)
{
    ct_symbol *newSymbol;
	ct_symbol *p= node->prev;

	free_symbol(p->next);
	free_symbol(p->next);

    newSymbol= malloc_symbol(NON_TERMINAL_SYMBOL, (int)rule, 1);
	insertAfter(p, newSymbol);
    return newSymbol;
}


void expand(ct_rule *s, ct_symbol *node, DigramIndex **index)
{
	ct_symbol *left = node->prev;
	ct_symbol *right = node->next;
	ct_symbol *first = node->value->rule->guard->next;
	ct_symbol *last = node->value->rule->guard->prev;
	ct_symbol *second;
	ct_rule	  *rule= node->value->rule;


	deleteHash(left, index);
	deleteHash(node, index);

	free_symbol(node);

	if (left->type== first->type && left->value->offset == first->value->offset)
	{
		first->count+= left->count;
		left->prev->next= first;
		first->prev= left->prev;
		free_symbol(left);

	}
	else
	{
		left->next= first;
		first->prev= left;
		addHash(s, left, index);
	}

	if (right->type == last->type && right->value->offset == last->value->offset)
	{
		second= last->prev;

		right->count=right->count+last->count;
		free_symbol(last);
		second->next= right;
		right->prev= second;
	}
	else
	{
		right->prev= last;
		last->next= right;
		addHash(s, last, index);
	}
	free_rule(s, rule);
	return;
}

void printSymbol(ct_symbol *symbol)
{
	unsigned int offset;

	if (TERMINAL_SYMBOL == symbol->type)
	{
		offset= (unsigned int) symbol->value->offset;
	}
	else
	{
		offset= (unsigned int) symbol->value->rule->index;
	}

	printf("%u,",offset);

	return;
}

void addHash(ct_rule *s, ct_symbol *digram, DigramIndex **index)
{
	KeyType hashKey;

	if ( GUARD_SYMBOL == digram->type || GUARD_SYMBOL == digram->next->type)
		return;

	hashKey= getHashCode(digram);
	insertNode(index, hashKey, digram); 
}

void deleteHash(ct_symbol *digram, DigramIndex **index)
{
	KeyType hashKey;

	if ( GUARD_SYMBOL == digram->type || GUARD_SYMBOL == digram->next->type)
		return;

	hashKey= getHashCode(digram);
	deleteNode(index, hashKey, digram);
}


int check_digram(ct_rule *s, ct_symbol *node, DigramIndex **index)
{
    ct_symbol *duplicate, *first, *prev, *oldprev, *waiting;
    ct_rule *newrule;


    if ( GUARD_SYMBOL == node->type || GUARD_SYMBOL == node->next->type)
    {
        return 0;
    }
    if (reportOverhead)
    {
        checkDigramCount++;
    }

	duplicate= find_digram(s, node, index);	
    if ( NULL!=duplicate && duplicate->next!= node && node->next!= duplicate )
    {
        if ( GUARD_SYMBOL==duplicate->prev->type && GUARD_SYMBOL == duplicate->next->next->type)
        {
           
            newrule=duplicate->prev->value->rule;
            prev= node->prev;
            pushCheckStack(node->next->next);

            deleteHash(prev, index);
            deleteHash(node, index);
            deleteHash(node->next, index);

            substitude(node, newrule);

        

            if ( check_last(s, prev, index) )
            {
                check_digram(s, prev->prev, index);
            }
            else
            {
        
                check_digram(s, prev, index);
            }

            
            
            waiting= popCheckStack();
            if (waiting)
                check_digram(s, waiting->prev, index);

            
            return 1;
        }
		else
		{
            s->index++;
            newrule= malloc_rule(s->index);
            newrule->next= s->next;
            s->next= newrule;



            insertAfter(newrule->guard, malloc_symbol(node->type, node->value->offset, node->count));
            insertAfter(newrule->guard->next, malloc_symbol(node->next->type, node->next->value->offset, node->next->count));

            
            pushCheckStack(node->next->next);

            deleteHash(duplicate->prev, index);
            deleteHash(duplicate, index);
            deleteHash(duplicate->next, index);

            deleteHash(node->prev, index);
            deleteHash(node, index);
            deleteHash(node->next, index);

            
            oldprev= substitude(duplicate, newrule)->prev;
            prev= substitude(node, newrule)->prev;

            addHash(s, newrule->guard->next, index);
            addHash(s, oldprev, index);
            addHash(s, oldprev->next, index);


            first=newrule->guard->next;

            if ( NON_TERMINAL_SYMBOL == first->type && first->value->rule->count==1)
            {
                expand(s, first, index);
            }

            if ( check_last(s, prev, index) )
            {
                check_digram(s, prev->prev, index);
            }
            else
            {
                check_digram(s, prev, index);
            }

            waiting= popCheckStack();
            if (waiting)
                check_digram(s, waiting->prev, index);	
			return 1;
		}
	}
	return 0;
}

int equalDigram(ct_symbol *node1, ct_symbol *node2)
{
	if (    (node1->type== node2->type) 
         && (node1->value->offset== node2->value->offset) 
		 && (node1->next->type== node2->next->type) 
		 && (node1->next->value->offset== node2->next->value->offset) )
	{
		return 1;
	}
	return 0;
}


int check_last(ct_rule *s, ct_symbol *node, DigramIndex **index)
{
	ct_symbol *next= node->next;



	if ( (node->type == next->type) && (node->value->offset == next->value->offset))
	{
		node->count+=next->count;

		if (NON_TERMINAL_SYMBOL == node->type)
		{
			node->value->rule->count+= next->count;
		}
		
		deleteHash(node, index);
		free_symbol(next);
		return 1;
	}
	return 0;
}

void pushCheckStack(ct_symbol *waiting)
{
	CheckStack *newCheckStack= (CheckStack *)cleanMalloc(sizeof(CheckStack));
    if (reportOverhead)
    {
        otheroverhead+= sizeof(CheckStack);
        if (otheroverhead>maxotheroverhead)
            maxotheroverhead= otheroverhead;
    }
    newCheckStack->waiting= waiting;
    newCheckStack->prev= checkStack;
    checkStack= newCheckStack;
}

ct_symbol* popCheckStack(void)
{
	ct_symbol *ret= checkStack->waiting;
	CheckStack *freeCheckStack= checkStack;
	checkStack= checkStack->prev;
	free(freeCheckStack);
    if (reportOverhead)
    {
        otheroverhead -= sizeof(CheckStack);
    }
	return ret;
}

void checkCheckStack(ct_symbol *symbol)
{
	CheckStack *ite= checkStack;
	while (ite!= NULL)
	{
		if (ite->waiting==symbol)
			ite->waiting= NULL;
		ite= ite->prev;	
	}
}

int decompress(ct_rule *rule, int output[], int k)
{
	ct_symbol *walk;
	int i;

	walk= rule->guard->next;

	while(GUARD_SYMBOL != walk->type)
	{
		if (TERMINAL_SYMBOL == walk->type)
		{
			for (i=0; i<walk->count; i++)
			{
				if (output[k]!= walk->value->offset)
				{
					printf("error %x, %x\n", k, walk->value->offset);	
				}
				k++;
			}
		}

		if (NON_TERMINAL_SYMBOL == walk->type)
		{
			for (i=0; i<walk->count; i++)
			{
				k= decompress(walk->value->rule, output, k);
			}
		}
		walk= walk->next;
	}

	return k;
}

void alldigram(ct_rule *s)
{
	int count, rules;
	ct_symbol *walk;
	ct_rule *iterRule;

	iterRule=s;
	rules=count=0; 

	while(iterRule!=NULL)
	{
		rules++;
		walk= iterRule->guard->next;

		while (walk->type!=GUARD_SYMBOL)
		{
			count++;
			walk= walk->next;
		}
		count--;
		iterRule= iterRule->next;
	}

	printf("all digrams: %x, all rules:%x\n", count, rules);
}

void initOperTrace (oper_trace *operTrace, int base)
{
    if (reportOverhead)
    {
        invoketime++;
        operandNum++;
    }
	operTrace->s= malloc_rule(0);

	operTrace->lastBase= base;
	operTrace->index=createNewNode(LeafNode);

	return;
}


void traceOper (oper_trace *operTrace, int value, int flag)
{
    int offset;
    ct_symbol *tail, *newSymbol;

#ifdef _CT_DEBUG
    //printf("traceOper \n");
#endif


    if (reportOverhead)
    {
        invoketime++;
    }

    if (!flag)
        offset= value;		
    else
        offset= value - operTrace->lastBase;

	operTrace->lastBase= value;
	tail= operTrace->s->guard->prev;
 
	if ( (tail->type == TERMINAL_SYMBOL) && (tail->value->offset == offset))
	{
		tail->count++;
	}
	else
	{

		check_digram(operTrace->s, tail->prev, &(operTrace->index));

		newSymbol= malloc_symbol(TERMINAL_SYMBOL, offset, 1);
        insertAfter(operTrace->s->guard->prev, newSymbol);
		
	}
}
  
void verify(ct_rule *s)
{
	ct_rule *iter;
	ct_symbol *walk_symbol;

	if (s== NULL)
		return;
	iter= s;

	while(NULL != iter)
	{

		walk_symbol= iter->guard->next;

		while( GUARD_SYMBOL != walk_symbol->type)
		{
			if ( TERMINAL_SYMBOL != walk_symbol->type && NON_TERMINAL_SYMBOL != walk_symbol->type)
			{
				printf("check_prints error, %d\n", walk_symbol->type);				
			}
			walk_symbol= walk_symbol->next;
		}
		iter= iter->next;
	}
}


/****** btree *****/
PContent createNewContent(ct_symbol	*p, PContent next)
{
	PContent	newContent;
    if (reportOverhead)
    {
        btreeoverhead+= sizeof(Content);
        if (btreeoverhead>maxbtreeoverhead)
            maxbtreeoverhead= btreeoverhead;
    }
	if (!freePContent)
	{
		newContent= (PContent)cleanMalloc(sizeof(Content));		
	}
	else
	{
		newContent= freePContent;
		freePContent= freePContent->next;
        memset(newContent, 0, sizeof(Content));
	}
	
	newContent->p= p;
	newContent->next= next;
	return newContent;
}

inline void freeContent(PContent pContent)
{
    if (reportOverhead)
    {
        btreeoverhead-=sizeof(Content);
    }
	pContent->next= freePContent;
	freePContent= pContent;
}

Node* createNewNode(NodeType type)
{
	int i;
	Node *n;
    if ( NULL == freeNodes )
    {
        n = (Node *)cleanMalloc(sizeof(Node));
    }
    else
    {
        n= freeNodes;
        freeNodes= freeNodes->parent;
        memset(n, 0, sizeof(Node));
    }

    if (reportOverhead)
    {
        btreeoverhead= btreeoverhead+ sizeof(Node);
        if (btreeoverhead>maxbtreeoverhead)
            maxbtreeoverhead= btreeoverhead;
    }

	n->count= 0;
	n->type = type;
	n->parent = NULL;
	for (i=0; i<FANOUT; i++)
	{
		n->key[i] = -1;
		n->child[i] = NULL;
	}
	n->child[FANOUT] = NULL;

	return n;
}

inline void freeNode(PNodeChild pNode)
{
    if (reportOverhead)
    {
        btreeoverhead-=sizeof(Node);
    }
    pNode->parent= freeNodes;
    freeNodes= pNode;
}


void printKey(KeyType key)
{
	unsigned int subkey1, subkey2;
	subkey1= (unsigned int)((key)>>32);
	subkey2= (unsigned int)(key);
	printf("%u %u ",subkey1, subkey2);
}


void freeTree(Node *n)
{
	int i;
	PContent ite, current;

	if (n)
	{
		if (n->type == InternalNode)
		{
			for (i=0; i<=n->count; i++)
			{
				freeTree((Node *)n->child[i]);
			}
		}
		else 
		{
			for (i=0; i<n->count; i++)
			{				
				ite= (PContent)(n->child[i+1]);
				while(ite!=NULL)
				{
                    current= ite;
					ite= ite->next;
                    free(current);
				}
			}
		}
        free(n);
	}
}

void outputTree(Node *n)
{
    int i;
	PContent ite;

	printf("this: %x --- parent: %x,  %d\n", (unsigned int)n, (unsigned int)(n->parent), n->count);

	if (n)
	{
		if (n->type == InternalNode)
		{
			for (i=0; i<n->count; i++)
			{
				printKey(n->key[i]);
			}
			printf("\n----------------------\n");
			for (i=0; i<=n->count; i++)
			{
				outputTree((Node *)n->child[i]);
			}
			printf("=======================\n");
		}
		else 
		{
			for (i=0; i<n->count; i++)
			{
				printKey(n->key[i]);
				ite= (PContent)(n->child[i+1]);
				while(ite!=NULL)
				{
					printf("\t");
					dumpChildNode(ite->p);
					dumpChildNode(ite->p->next);
					printf("\n");
					ite= ite->next;
				}
			}
			printf("\n* * * * * * * * \n");
		}
	}
}




ct_symbol* findNode(ct_rule *s, Node **root, KeyType key, ct_symbol *p)
{
	int i, location;
	Node *current;

	current = *root;

	while (InternalNode == current->type)
	{
		location= current->count;
		for (i=0; i<current->count; i++)
		{
			if (key < current->key[i])
			{
				location = i ;
				break;
			}
		}
 		current = (Node*)(current->child[location]);
	}
	
	return findEntry(s, root, key, p, current);
}




ct_symbol* findEntry(ct_rule *s, Node **root, KeyType key, ct_symbol *p, Node *current)
{
	int	i, existing=0;
	PContent ite;
	ct_symbol *firstSymbol, *secondSymbol, *p2, *prev, *newSymbol;


	for (i=0; i<current->count; i++)
	{
		if ( key == current->key[i] )
		{				
			ite= (PContent)(current->child[i+1]);
			while(ite!= NULL)
			{
				if ( equalDigram(ite->p, p) )
				{
				  if ( ite->p == p)
				    existing=1;
					if (ite->p != p && ite->p->next !=p && p->next !=ite->p)
					{
						firstSymbol= ite->p;
						secondSymbol= firstSymbol->next;
						p2= p->next;

						if (firstSymbol->count != p->count)
						{
							if (firstSymbol->count > p->count)
							{
								prev= firstSymbol->prev;
								newSymbol= malloc_symbol(firstSymbol->type, firstSymbol->value->offset, firstSymbol->count - p->count);
								insertAfter(prev, newSymbol);
								firstSymbol->count= p->count;
								addHash(s, newSymbol, root);	

							}
							else
							{
								prev= p->prev;
								newSymbol= malloc_symbol(p->type, p->value->offset, p->count - firstSymbol->count);
								insertAfter(prev, newSymbol);
								p->count= firstSymbol->count;
								addHash(s, newSymbol, root);								
							}
						}

						if (secondSymbol->count != p2->count)
						{
							if (secondSymbol->count > p2->count)
							{
		
								newSymbol= malloc_symbol(secondSymbol->type, secondSymbol->value->offset, secondSymbol->count-p2->count);
								deleteHash(secondSymbol, root);

								insertAfter(secondSymbol, newSymbol);
								secondSymbol->count= p2->count;
								addHash(s, secondSymbol, root);
								addHash(s, newSymbol, root);
							}
							else
							{

								newSymbol= malloc_symbol(p2->type, p2->value->offset, p2->count-secondSymbol->count);
								deleteHash(p2, root);
								insertAfter(p2, newSymbol);
								p2->count= secondSymbol->count;
								addHash(s, p2, root);
								addHash(s, newSymbol, root);								


							}
						}
						return firstSymbol;
					}
				}				
				ite= ite->next;
			}
		}
	}

	if (!existing)
	  insertEntry(root, key, p, current);	

	return NULL;
}

void insertNode(Node **root, KeyType key, void* p) /* lowerbound <= key <upperbound */
{
	int i, location;
	Node *current;

	/*  find the place to insert new entry */
	current = *root;

	while (InternalNode == current->type)
	{
		location= current->count;
		for (i=0; i<current->count; i++)
		{
			if (key < current->key[i])
			{
				location = i ;
				break;
			}
		}
 		current = (Node*)(current->child[location]);
	}
	/*  Insert new entry to the tree */
	insertEntry(root, key, p, current);
}

void insertEntry(Node **root, KeyType key, void *p, Node *current)
{
	int i, offset;
	KeyType newKey;
	Node *newNode, *newRoot;

	// move right in case of current entry has been split before insertion

	if (current->count < FANOUT)  // there is enough space, simply insert it
	{
		simpleInsert(key, p, current);
	}
	else  // must split
	{
		/* create new node  */
		if (current->type == LeafNode) //  leaf node
		{
			newNode = createNewNode(LeafNode);
			newKey = current->key[FANOUT/2];

			/* move last [fanout/2] entries to the new node */
			newNode->child[0] = NULL;
			newNode->count= FANOUT- FANOUT/2;
			current->count= FANOUT/2;

			for (i=FANOUT/2; i<FANOUT; i++)
			{
				newNode->key[i-FANOUT/2] = current->key[i];
				current->key[i] = -1;
				newNode->child[i-FANOUT/2+1] = current->child[i+1];
				current->child[i+1] = NULL;
			}
			/* Insert new entry */
			if (key < newKey)
				simpleInsert(key, p, current);
			else
				simpleInsert(key, p, newNode);
		}
		else // non-leaf node
		{
			/* pick up the new key & set the first child of new node*/
			newNode = createNewNode(InternalNode);
			current->count= FANOUT/2;
			newNode->count= FANOUT- FANOUT/2-1;

			newKey = current->key[FANOUT/2];

			if ( key < newKey)
				offset= 1;
			else
				offset =0;

			current->key[FANOUT/2] = -1;

			newNode->child[0+offset] = current->child[FANOUT/2+1];
			((Node *)(newNode->child[0+offset]))->parent= newNode;
			current->child[FANOUT/2+1] = NULL;

			/* move last [fanout/2]-1 entries to the new node and modify parents*/
			for (i=FANOUT/2+1; i<FANOUT; i++)
			{
				newNode->key[i-FANOUT/2-1+offset] = current->key[i];
				current->key[i] = -1;
				newNode->child[i-FANOUT/2+offset] = current->child[i+1];
				((Node *)(current->child[i+1]))->parent= newNode;				
				/*
				do not need this parent pointer if using recursive algorithm,
				therefore, we did not consider its cost here
				*/
				current->child[i+1] = NULL;	
			}

			/* Insert new entry */
			if (key < newKey)
			{
				simpleInsert(key, p, current);

				newNode->key[0]= newKey;
				newKey= current->key[current->count-1];
				newNode->child[0]= current->child[current->count];
				((Node *)(newNode->child[0]))->parent= newNode;
				current->count--;				
				newNode->count++;
			}
			else
				simpleInsert(key, p, newNode);
		}
		/* back up to the parents */
		
		if (current->parent != NULL) // not root level
		{
			insertEntry(root, newKey, (void *)newNode, current->parent);
		}
		else  // root level
		{
			newRoot = createNewNode(InternalNode);			
			newRoot->count = 1;
			newRoot->key[0] = newKey;
			newRoot->child[0] = current;
			newRoot->child[1] = newNode;
			current->parent = newRoot;
			newNode->parent = newRoot;
			*root = newRoot;		
		}
	}
}


void simpleInsert(KeyType key, void *p, Node *current)
{
	int i, location;
	PContent ite;

	location = current->count;

	for (i=0; i<current->count; i++)
	{
		if (key < current->key[i])
		{
			location = i;
			break;
		}
		else
		{
			if ( InternalNode != current->type && key == current->key[i] )
			{
				ite= (PContent)(current->child[i+1]);
				while(ite!= NULL)
				{
					if ( ite->p==p) 
					{
						return;
				}
					ite= ite->next;
				}

				ite=createNewContent((ct_symbol*)p, (PContent)(current->child[i+1]));
				current->child[i+1]= ite;
				return;
			}
		}
	}
	
	for (i=current->count; i>location; i--)
	{
		current->key[i] = current->key[i-1];
		current->child[i+1] = current->child[i];			
	}

	current->key[location] = key;
	if ( InternalNode == current->type )
	{
		current->child[location+1] = p;
		((Node *)p)->parent= current;		
	}
	else
	{
		current->child[location+1] = createNewContent((ct_symbol*)p, NULL);
	}
	current->count ++;
}


int simpleDelete(KeyType key, void *p, Node *current)
{
	int i, j;
	PContent ite, pre;

	for (i=0; i<current->count; i++)
	{
		if (key == current->key[i])
		{
			if (InternalNode == current->type)
			{
				current->key[i] = -1;

				freeNode( (Node *)(current->child[i+1]));

				for (j=i+1; j<current->count; j++)
				{
					current->key[j-1] = current->key[j];
					current->child[j] = current->child[j+1];
				}
				current->count --;
				return 1;
			}
			else
			{
				ite= (PContent)current->child[i+1];
				pre=NULL;
				while( ite!= NULL)
				{
					if (ite->p== p)
					{
						if (ite == current->child[i+1])
						{
							current->child[i+1]= ite->next;							
							if (ite->next == NULL)
							{								
								current->key[i] = -1;
								for (j=i+1; j<current->count; j++)
								{
									current->key[j-1] = current->key[j];
									current->child[j] = current->child[j+1];
								}
								current->count --;
							}
							freeContent(ite);
							return 1;
						}
						else
						{
							pre->next= ite->next;
							freeContent(ite);
							return 1;
						}
					}
					pre= ite;
					ite= ite->next;
				}
			}

			//printf("simpleDelete, should not reach here\n");
			return 0;
		}
	}

	return 0;
}

void deleteNode(Node **root, KeyType key, void *p)
{
	int i, location; 
	Node *current;
	
	/*  find the leaf node that contains p */
	current = *root;
	while (InternalNode == current->type)
	{
		location = current->count;
		for (i=0; i<current->count; i++)
		{
			if (key < current->key[i])
			{
				location = i ;
				break;
			}
		}
 		current = (Node *)current->child[location];				
	}
	deleteEntry(root, key, p, current);

	if (*root == NULL)
		*root = createNewNode(LeafNode);
}

void deleteEntry(Node **root, KeyType key, void *p, Node *current)
{
	int i, location, left, right, sumCount, mid,offset;
	Node *left_sibling, *right_sibling;
	Node *parent;

	if (!simpleDelete(key, p, current))
		return;
	
	/* modify the root if necessary */
	if (current->parent == NULL)
	{
		if (current->count == 0 && InternalNode == current->type ) // only one child
		{
			*root = (Node *)current->child[0];
			if (*root)
				(*root)->parent = NULL;	
		
			freeNode(current);
		}
	}
	else 
	{
		if (current->count < FANOUT/2) // underflow
		{
			//find siblings
			parent = (Node*)current->parent;
			location = parent->count;
			for (i=0; i<parent->count; i++)
			{
				if (key < parent->key[i])
				{
					location = i;
					break;
				}
			}
			left = location -1; // key place
			right = location;

			/* try left sibling */
			if (left >=0)
				left_sibling = (Node *)parent->child[left];
			else 
				left_sibling = NULL;


			if ( left_sibling != NULL )
			{
				sumCount= left_sibling->count + current->count;

				if ( sumCount>= FANOUT )
				{
					mid= sumCount /2;
					offset= left_sibling->count- mid;				

					if ( current->type== InternalNode )
					{
						for (i= current->count-1; i>=0; i--)
						{
							current->key [i+offset]= current->key[i];
							current->child[i+offset+1]= current->child[i+1];
						}
						current->key[offset-1]= parent->key[location-1];
						current->child[offset]= current->child[0];
						current->count= current->count+ offset;

						for (i=1; i<offset; i++)
						{
							current->key[i-1]= left_sibling->key[mid+i];
							current->child[i]= left_sibling->child[mid+i+1];
							((Node *)(current->child[i]))->parent= current;							
						}
						parent->key[location-1]= left_sibling->key[mid];
						current->child[0]= left_sibling->child[mid+1];
						((Node *)(current->child[0]))->parent= current;
						left_sibling->count= mid;
						return;
					}
					else
					{
						for (i= current->count-1; i>=0; i--)
						{
							current->key[i+offset]= current->key[i];
							current->child[i+offset+1]= current->child[i+1];
						}
						current->count= current->count+ offset;

						for (i=0; i<offset; i++)
						{
							current->key[i]= left_sibling->key[mid+i];
							current->child[i+1]= left_sibling->child[mid+i+1];
						}
						parent->key[location-1]= current->key[0];
						left_sibling->count= mid;
						return;
					}
				}
			}

			if (right < parent->count)
				right_sibling = (Node *)parent->child[right+1];
			else 
				right_sibling = NULL;

			if ( right_sibling != NULL )
			{
				sumCount= right_sibling->count + current->count;

				if ( sumCount >= FANOUT )
				{
					mid= sumCount /2;
					offset= right_sibling->count- mid;

					if ( current->type== InternalNode )
					{
						current->key[current->count]= parent->key[location];
						current->child[current->count+1] = right_sibling->child[0];
						((Node *)(current->child[current->count+1]))->parent= current;
						
						for (i=1; i< offset; i++)
						{
							current->key[i+current->count]= right_sibling->key[i-1];
							current->child[i+current->count+1]= right_sibling->child[i];
							((Node *)(current->child[i+current->count+1]))->parent= current;	
						}
						current->count= current->count+offset;

						parent->key[location]= right_sibling->key[offset-1];

						for (i=0; i<mid; i++)
						{
							right_sibling->key[i]= right_sibling->key[i+offset];
							right_sibling->child[i]= right_sibling->child[i+offset];
						}
						right_sibling->child[mid]= right_sibling->child[mid+offset];
						right_sibling->count= mid;

						return;
					}
					else
					{
						mid= sumCount /2;
						offset= right_sibling->count- mid;

						for (i=0; i<offset; i++)
						{
							current->key[i+current->count]= right_sibling->key[i];
							current->child[i+current->count+1]= right_sibling->child[i+1];
						}
						current->count= current->count+offset;
						parent->key[location]= right_sibling->key[offset];

						for (i=0; i<mid; i++)
						{
							right_sibling->key[i]= right_sibling->key[i+offset];
							right_sibling->child[i+1]= right_sibling->child[i+offset+1];
						}
						right_sibling->count= mid;
						
						return;
					}
				}
			}

			if ( left_sibling != NULL && left_sibling->count + current->count <=FANOUT-1)
			{
				// merge two nodes
				if (current->type== InternalNode) // non leaf node
				{
					left_sibling->key[left_sibling->count] = parent->key[left];
					for (i=0; i<current->count; i++)
					{
						left_sibling->key[left_sibling->count+i+1] = current->key[i];
						left_sibling->child[left_sibling->count+i+1] = current->child[i];
						((Node *)(current->child[i]))->parent = left_sibling;  // better to use recursive way
					}
					left_sibling->count += 1 + current->count;
					left_sibling->child[left_sibling->count] = current->child[current->count];
					 ((Node *)(current->child[current->count]))->parent= left_sibling;  
				}
				else
				{
					for (i=0; i<current->count; i++)
					{
						left_sibling->key[left_sibling->count+i] = current->key[i];
						left_sibling->child[left_sibling->count+i+1] = current->child[i+1];
					}
					left_sibling->count +=current->count;
				}
				
				// modify right link			 
				deleteEntry(root, parent->key[left], (void *)current, parent);
			}
			else /* try right sibling */
			{
				if (right_sibling != NULL && right_sibling->count + current->count <=FANOUT-1)
				{
					// merge two nodes
					if (current->type== InternalNode) // non leaf node
					{
						current->key[current->count] = parent->key[right];
						for (i=0; i<right_sibling->count; i++)
						{
							current->key[current->count+i+1] = right_sibling->key[i];
							current->child[current->count+i+1] = right_sibling->child[i];
							((Node *)(right_sibling->child[i]))->parent= current;  
						}
						current->count += 1 + right_sibling->count;
						current->child[current->count] = right_sibling->child[right_sibling->count];
						((Node *)(right_sibling->child[right_sibling->count]))->parent = current;  
					}
					else
					{
						for (i=0; i<right_sibling->count; i++)
						{
							current->key[current->count+i] = right_sibling->key[i];
							current->child[current->count+i+1] = right_sibling->child[i+1];
						}
						current->count += right_sibling->count;
					}
					//modify right link

					deleteEntry(root, parent->key[right], (void *)right_sibling, parent);
				}
			}
		}
	}
}
 
int queryIndex(Node** root, KeyType key, ct_symbol *p)
{
	int i, location;
	Node *current;
	PContent ite;

	/*  find the place to insert new entry */
    current = *root;
    while (InternalNode == current->type)
    {
        location= current->count;
        for (i=0; i<current->count; i++)
        {
            if (key < current->key[i])
            {
                location = i ;
                break;
            }
        }
        current = (Node*)(current->child[location]);
    }

    location = current->count;
    for (i=0; i<current->count; i++)
    {
        if (key < current->key[i])
        {
            location = i;
            break;
        }
        else
        {
            if ( key == current->key[i] )
            {				
                ite= (PContent)(current->child[i+1]);
                while(ite!= NULL)
                {
                    if ( equalDigram(ite->p, (ct_symbol*)p) )
                    {
                        return 1;
                    }
                    ite= ite->next;
                }
            }		
        }
	}
	return 0;
}

void dumpChildNode(ct_symbol *walk_symbol)
{
	if ( TERMINAL_SYMBOL == walk_symbol->type)
	{
		if (walk_symbol->count>1)
		{
			printf("terminal %d %d@----", walk_symbol->value->offset, walk_symbol->count);
		}
		else
		{
			printf("terminal %d----", walk_symbol->value->offset);
		}
	}
	else
	{
		if ( NON_TERMINAL_SYMBOL == walk_symbol->type)

		{
			if (walk_symbol->count>1)
			{
				printf("non %d %d@----", walk_symbol->value->rule->index, walk_symbol->count);
			}
			else
			{
				printf("non %d----", walk_symbol->value->rule->index);
			}
		}
	}
}

//========================
void traceLoadArray(inst_info* instInfo, int pc, int instruction, objectIDEntry* objectId, int index, int pushsize)
{
	instInfo->pc= pc;
	instInfo->instruction= instruction;
	instInfo->operand_num= instOper[instruction];
	instInfo->operands[0]= objectId->number;
	instInfo->operands[1]= index;
	
	int depsize= 3;
	//int *depPC= (int*)cleanMalloc(sizeof(int)*depsize); 
	//int *depclassid= (int*)cleanMalloc(sizeof(int)*depsize); 
	//int *depmethodid= (int*)cleanMalloc(sizeof(int)*depsize);
	//int *depsigid= (int*)cleanMalloc(sizeof(int)*depsize);
	
	//fill first with array element dep
	int result= getArrayElementDefine(objectId->number, index, instInfo->depclassid, instInfo->depmethodid, instInfo->depsigid, instInfo->deppc);
	
	if(result>0)
	{
		popOperStack(tracingCallStack, depsize-1, &(instInfo->deppc[1]));
		int x;
		for(x=1; x<depsize; x++)
		{
			instInfo->depclassid[x]= tracingCallStack->classID;
			instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
			instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
			//depPC[x]= deppc0[x-1];
		}
		//free(deppc0);
	}
	else
	{
		//free(depclassid);
		//free(depmethodid);
		//free(depsigid);
		//free(depPC);
		depsize= 2;
		popOperStack(tracingCallStack, depsize, instInfo->deppc);
		//depclassid= (int*)cleanMalloc(sizeof(int)*depsize); 
		//depmethodid= (int*)cleanMalloc(sizeof(int)*depsize);
		//depsigid= (int*)cleanMalloc(sizeof(int)*depsize);
		int x;
		for(x=0; x<depsize; x++)
		{
			instInfo->depclassid[x]= tracingCallStack->classID;
			instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
			instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
		}
	}

//	instInfo->depclassid= depclassid;
//	instInfo->depmethodid= depmethodid;
//	instInfo->depsigid= depsigid;
//	instInfo->deppc= depPC;
	instInfo->depsize= depsize;
	
	pushOperStack(tracingCallStack, pushsize, pc);
	
	traceInstruction(instInfo);
}

void traceLoadLocal(inst_info* instInfo, int pc, int instruction, int idx, int pushsize)
{
	instInfo->pc= pc;
	instInfo->instruction= instruction;
	instInfo->operand_num= instOper[instruction];
	instInfo->operands[0]= idx;
	instInfo->depsize= 0;
	//int operand= getByte1( &(idx) );

	assert(idx < tracingCallStack->localCount);
	
	int depsize=0;
	int deppc= useLocal(tracingCallStack, idx);
	
	/*//for now not considering dep across parameter
	if(deppc > -1)
	{
		depsize= 1;
	}*/
	depsize= 1;
	
	/*if(deppc == 0 && pc == 0)
	{
		depsize= 0;
	}*/

	//if(depsize>0)
	if(deppc > -1)
	{
		int x;
		for(x=0; x<depsize; x++)
		{
			instInfo->depclassid[x]= tracingCallStack->classID;
			instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
			instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
			instInfo->deppc[x]= deppc;
		}
		instInfo->depsize= depsize;
	}
    else
    {
        //deppc == -1, parameter dep crossing method call
        //check parameter list on previous callframe
        call_frame* prev= tracingCallStack->prev;
        if(prev == NULL)
        {
            if(strcmp(methodNameList[tracingCallStack->methodTrace->methodID]->data, "main")==0)
            {
                                                                                                                 
            }
            else
            {
                assert(prev!=NULL);
            }
        }
        else
        {
            if(prev->executingNativeMethod)
            {
                //depsize= 0;
                instInfo->depsize= 0;
            }
            else
            {
                //printf("idx: %d, calling count: %d\n", idx, prev->callingArgCount);
                assert(idx < prev->callingArgCount);
                                                                                                             
                instInfo->depclassid[0]= prev->classID;
                instInfo->depmethodid[0]= prev->methodTrace->methodID;
                instInfo->depsigid[0]= prev->methodTrace->sigID;
                instInfo->deppc[0]= prev->callingArgs[idx];
                instInfo->depsize= 1;
            }
        }
    	//instInfo->depsize= 0;
    }
	
	pushOperStack(tracingCallStack, pushsize, pc);
	
	traceInstruction(instInfo);
}

void traceDefineLocal(inst_info* instInfo, int pc, int instruction, int idx, int depsize)
{
	instInfo->pc= pc;
	instInfo->instruction= instruction;
	instInfo->operand_num= instOper[instruction];
	//int operand= getByte1( &(idx) );
	popOperStack(tracingCallStack, depsize, instInfo->deppc);
	//int *depclassid= (int*)cleanMalloc(sizeof(int)*depsize); 
	//int *depmethodid= (int*)cleanMalloc(sizeof(int)*depsize);
	//int *depsigid= (int*)cleanMalloc(sizeof(int)*depsize); 
	int x;
	for(x=0; x<depsize; x++)
	{
		instInfo->depclassid[x]= tracingCallStack->classID;
		instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
		instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
	}
	
//	instInfo->depclassid= depclassid;
//	instInfo->depmethodid= depmethodid;
//	instInfo->depsigid= depsigid;
//	instInfo->deppc= depPC;
	instInfo->depsize= depsize;
	
	defineLocal(tracingCallStack, idx, pc);

	traceInstruction(instInfo);
}

void traceDefineArray(inst_info *instInfo, int pc, int instruction, objectIDEntry* objectId, int index, int depsize)
{
	instInfo->pc= pc;
	instInfo->instruction= instruction;
	instInfo->operand_num= instOper[instruction];
	instInfo->operands[0]= objectId->number;
	instInfo->operands[1]= index;

	popOperStack(tracingCallStack, depsize, instInfo->deppc);
	//int *depclassid= (int*)cleanMalloc(sizeof(int)*depsize); 
	//int *depmethodid= (int*)cleanMalloc(sizeof(int)*depsize);
	//int *depsigid= (int*)cleanMalloc(sizeof(int)*depsize); 
	int x;
	for(x=0; x<depsize; x++)
	{
		instInfo->depclassid[x]= tracingCallStack->classID;
		instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
		instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
	}
	
//	instInfo->depclassid= depclassid;
//	instInfo->depmethodid= depmethodid;
//	instInfo->depsigid= depsigid;
//	instInfo->deppc= depPC;
	instInfo->depsize= depsize;
	
	insertArrayElement(objectId->number, index, tracingCallStack->classID, tracingCallStack->methodTrace->methodID, tracingCallStack->methodTrace->sigID, pc);

	traceInstruction(instInfo);
}

void traceCommon(inst_info* instInfo, int pc, int instruction, int pushsize, int popsize)
{
	instInfo->pc= pc;
	instInfo->instruction= instruction;
	instInfo->operand_num= instOper[instruction];
	instInfo->depsize= 0;
	
	if(popsize > 0)
	{
		//int *depPC= popOperStack(tracingCallStack, popsize);
		//int *depclassid= (int*)cleanMalloc(sizeof(int)*popsize); 
		//int *depmethodid= (int*)cleanMalloc(sizeof(int)*popsize);
		//int *depsigid= (int*)cleanMalloc(sizeof(int)*popsize);
		popOperStack(tracingCallStack, popsize, instInfo->deppc);
		int x;
		for(x=0; x<popsize; x++)
		{
			instInfo->depclassid[x]= tracingCallStack->classID;
			instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
			instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
		}
		
		//instInfo->depclassid= depclassid;
		//instInfo->depmethodid= depmethodid;
		//instInfo->depsigid= depsigid;
		//instInfo->deppc= depPC;
		instInfo->depsize= popsize;
	}
	
	if(pushsize > 0)
	{
		pushOperStack(tracingCallStack, pushsize, pc);
	}
	
	traceInstruction(instInfo);
}

void traceIINC(inst_info* instInfo, int pc, int instruction, int idx)
{
	instInfo->pc= pc;
	instInfo->instruction= instruction;
	instInfo->operand_num= instOper[instruction];
	instInfo->operands[0]= idx;
	instInfo->depsize= 0;

	assert(idx < tracingCallStack->localCount);
	
	int depsize=0;
	int deppc= useLocal(tracingCallStack, idx);
	
	/*//for now not considering dep across parameter
	if(deppc > -1)
	{
		depsize= 1;
	}*/
	depsize= 1;

	//if(depsize>0)
	if(deppc > -1)
	{
		int x;
		for(x=0; x<depsize; x++)
		{
			instInfo->depclassid[x]= tracingCallStack->classID;
			instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
			instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
			instInfo->deppc[x]= deppc;
		}
		instInfo->depsize= depsize;
	}
	else
    {
        //deppc == -1, parameter dep crossing method call
        call_frame* prev= tracingCallStack->prev;
        if(prev == NULL)
        {
            printf("error: prev callframe is null\n");
            exit(1);
        }
        assert(idx < prev->callingArgCount);
        instInfo->depclassid[0]= prev->classID;
        instInfo->depmethodid[0]= prev->methodTrace->methodID;
        instInfo->depsigid[0]= prev->methodTrace->sigID;
        instInfo->deppc[0]= prev->callingArgs[idx];
        instInfo->depsize= 1;
		//instInfo->depsize= 0;
    }
		
	defineLocal(tracingCallStack, idx, pc);
	
	traceInstruction(instInfo);
}

void traceStackPop(inst_info* instInfo, int popsize, int depexist)
{
	int depsize= 0;
	if(depexist)
	{
		depsize= popsize + instInfo->depsize;
		popOperStack(tracingCallStack, popsize, &(instInfo->deppc[instInfo->depsize]));

		int x;
		for(x=instInfo->depsize; x<depsize; x++)
		{
			instInfo->depclassid[x]= tracingCallStack->classID;
			instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
			instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
		}
		instInfo->depsize= depsize;
	}
	else
	{
		depsize= popsize;
		instInfo->depsize= 0;
		popOperStack(tracingCallStack, popsize, instInfo->deppc);
		int x;
		for(x=0; x<popsize; x++)
		{
			instInfo->depclassid[x]= tracingCallStack->classID;
			instInfo->depmethodid[x]= tracingCallStack->methodTrace->methodID;
			instInfo->depsigid[x]= tracingCallStack->methodTrace->sigID;
		}
		instInfo->depsize= depsize;
	}
}

void updateCallingArgs(inst_info* instInfo, int argCount, int hasObject)
{
    tracingCallStack->callingArgCount= argCount;
    tracingCallStack->callingArgs= (int*)cleanMalloc(sizeof(int)*argCount);
    //int a, b, c;
    /*int i;
    for(i=argCount-1; i>=0; i--)
    {
        popOperStack(tracingCallStack, 1, &a, &b, &c,
                &(tracingCallStack->callingArgs[i]));
    }*/
    popOperStack(tracingCallStack, argCount, tracingCallStack->callingArgs);
    if(hasObject)//only store data dep for invoke and the target object
    {
        int depsize= instInfo->depsize + 1;
        instInfo->depclassid[instInfo->depsize]= tracingCallStack->classID;
        instInfo->depmethodid[instInfo->depsize]= tracingCallStack->methodTrace->methodID;
        instInfo->depsigid[instInfo->depsize]= tracingCallStack->methodTrace->sigID;
        instInfo->deppc[instInfo->depsize]= tracingCallStack->callingArgs[0];
        instInfo->depsize= depsize;
    }
}

