#ifndef ACCESSLOCAL_H
#define ACCESSLOCAL_H

class AccessLocal
{
protected:
	int operand;
public:
	int getOperand();
	void setOperand(int);
	AccessLocal(int);
	virtual ~AccessLocal();
};

#endif

