#ifndef ACCESSSTATIC_H
#define ACCESSSTATIC_H

class JMethod;

class AccessStatic
{
protected:
	JMethod *staticInit;
public:
	virtual JMethod* getStaticInit()=0;
};

#endif

