#ifndef JNEWARRAY_H
#define JNEWARRAY_H

#include "jbytecode.h"

/**
  *@author wt
  */

class JMethod;

class JNewArray : public JBytecode
{
public:
	JNewArray(JMethod *,int, int);//, int);
};

#endif
