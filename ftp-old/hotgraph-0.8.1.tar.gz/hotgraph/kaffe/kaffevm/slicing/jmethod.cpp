#include "slicing.h"
#include "jmethod.h"
#include "jbytecode.h"
#include "bytecodelist.h"
#include "jloadlocal.h"
#include "jloadstatic.h"
#include "jloadarray.h"
#include "jloadfield.h"
#include "jdefinelocal.h"
#include "jdefinestatic.h"
#include "jdefinearray.h"
#include "jdefinefield.h"
#include "jcommon.h"
#include "jbranch.h"
#include "cnamelist.h"
#include "signature.h"
#include "jinvokenonstatic.h"
#include "jinvokestatic.h"
#include "linetable.h"
#include "jbytecoderef.h"
#include "accesslocal.h"
#include "jnew.h"
#include "jnewarray.h"
#include "jnewmultiarray.h"
#include <stack>
#include "criterions.h"

using std::stack;
using std::vector;

JMethod::JMethod()
{
	hash=NULL;
	basicBlocks=NULL;
	basicBlockCount=0;
	staticInit=-1;
	mainMethod= 0;
	hasBuilded= 0;
    lineNumCount=0;
    lines=NULL;
}

void JMethod::initLocalArgsPos()
{	int argsNum= signature->getNargs();
	int allArgsUseOperNum = 0;
    if (argsNum >0)
    {
        argsLocalVarPos= (int *)cleanMalloc(sizeof(int) * argsNum);
        for (int i=0; i<argsNum ; i++)
        {
    		argsLocalVarPos[i]= allArgsUseOperNum+1;
		    allArgsUseOperNum+= signature->getSizeOfNArgs(i);
            //printf("xxx: jmethod.cpp: x1: %d, %d\n", i, invokePasedSig->getSizeOfNArgs(i));
	    }
    }
    else
    {
        argsLocalVarPos= NULL;
    }
}

int JMethod::getnArgsLocalPos(int index)
{
	return argsLocalVarPos[index];
}

int JMethod::init(JClass *parent, struct _methods *sourceMethod, int id)
{
	pClass= parent;
	this->id= id;

    this->sourceMethod= sourceMethod;

    const char *methodName= getMethodNameInKaffe(sourceMethod);
    nameId= methodNames->update(methodName);
	sigId= sigs->update(getMethodSigInKaffe(sourceMethod));
	signature= new Signature(getMethodSigInKaffe(sourceMethod));

	initLocalArgsPos();// by GL
	if (strcmp(methodName, staticInitName) ==0)
		staticInit= 1;
	else
		staticInit= 0;

	if (strcmp( methodName, "main") ==0 && strcmp(getMethodSigInKaffe(sourceMethod), "([Ljava/lang/String;)V")==0)
    {
		mainMethod= 1;
    }

#ifdef _read_debug
	printf("------------------------------------\n");
	printf("\t init method %s %s %s\n", classNames->getCNameAt(pClass->getNameId()), methodNames->getCNameAt(nameId), sigs->getCNameAt(sigId));
#endif

    isNative= isNativeMethod(sourceMethod);

    struct _method_trace *methTrace= getTraceOfMethod(sourceMethod);    
    codelen= getCodelenOfMethodInKaffe(sourceMethod);

    if (isNative || methTrace==NULL || codelen==0)
    {
        stackSize= 0;
    	localCount= 0;
        top=-1;
        basicBlockCount=0;
        hash=NULL;
        codelen=0;
        sourceMethod=NULL;
        staticInit=0;
	    mainMethod=0;
        callInfo=NULL;
        bytecodes=NULL; 
	    basicBlocks=NULL;
        bytecodes=NULL;
        return 0;
    }

    lineNumCount= getLineNumCountInKaffe(sourceMethod);
    if (lineNumCount>0)
    {
        int lineIndex;
        int lineNum, startPC;

        lines= new LineNumEntry[lineNumCount];
        for(lineIndex=0; lineIndex<lineNumCount; lineIndex++)
        {
            getLineNumAtInKaffe(sourceMethod, lineIndex, &lineNum, &startPC);
            int lineIndex2, lineIte;
            for(lineIndex2=0; lineIndex2<lineIndex; lineIndex2++)
            {
                if (startPC <lines[lineIndex2].startPC)
                    break;
            }
            for(lineIte=lineIndex; lineIte>lineIndex2; lineIte--)
            {
                lines[lineIte].lineNum= lines[lineIte-1].lineNum;
                lines[lineIte].startPC= lines[lineIte-1].startPC;   
            }
            lines[lineIndex2].lineNum= lineNum;
            lines[lineIndex2].startPC= startPC;        
        }
    }

    ArrayList<int> exceptions;
    int exceptionsCount= getExceptionsCountInKaffe(sourceMethod);
    for(int i=0; i<exceptionsCount; i++)
    {
        exceptions.uniqueAdd(getExceptionsTargetInKaffe(sourceMethod, i));
    }
    
    /** by GL **/
    catchinst = methTrace->catchinst;

   	bytecodes= new BytecodeList();

    stackSize =  getMethodStackSizeInKaffe(sourceMethod);
    localCount =getLocalVariableCountInKaffe(sourceMethod);    
    top= -1;

	int pc=0;
    
    unsigned char *code=getCodeOfMethodInKaffe(sourceMethod);
    int prevWide= 0;


    while(pc<codelen)
	{
		int operation= code[pc] & 0x000000ff;
		int operand= -1;

		if ( operation<0 || operation>= BYTECODENUM)
		{
			printf("unkonw instruction: %d\n", operation);
			abort();
		}

#ifdef _read_debug		
		printf("%d %s, %d, %d\n", pc, bytecodeName[operation], top, stackSize);
#endif

		JBytecode *newBytecode;
		BytecodeList *usedList;
		BytecodeList *usedList1,*usedList2,*usedList3,*usedList4;
		int i, j, n, invokeClassNameId, invokeMethodNameId, invokeMethodSigId, dimension, lookupsize;
		char *invokeSig, *newClassName;
		Signature *invokePasedSig;


		switch (operation)
		{
			case  NOP:
				newBytecode= new JCommon(this, operation, pc);
				break;
			case  ACONST_NULL:
			case  ICONST_M1:
			case  ICONST_0:
			case  ICONST_1:
			case  ICONST_2:
			case  ICONST_3:
			case  ICONST_4:
			case  ICONST_5:
			case  FCONST_0:
			case  FCONST_1:
			case  FCONST_2:
			case  LDC1:
			case  LDC2:
			case  BIPUSH:
			case  SIPUSH:
				newBytecode= new JCommon(this, operation, pc);				
				break;

			case  LCONST_0:
			case  LCONST_1:
			case  DCONST_0:
			case  DCONST_1:
			case  LDC2W:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  ILOAD:
			case  FLOAD:
			case  ALOAD:
                {
                    int lastPC= pc;
                    if (prevWide==0)
                    {
                        operand= getByte1( &(code[pc+1]) );
                    }
                    else
                    {
                        operand= getByte2( &(code[pc+1]) );
                        prevWide=0;
                        pc++;
                    }        
                    assert(operand< localCount);
    				newBytecode= new JLoadLocal(this, operation, lastPC, operand);
                }
				break;

			case  LLOAD:
			case  DLOAD:
                {
                    int lastPC= pc;
                    if (prevWide==0)
                    {
                        operand= getByte1( &(code[pc+1]) );
                    }
                    else
                    {
                        operand= getByte2( &(code[pc+1]) );
                        prevWide=0;
                         pc++;
                    }          
                    assert(operand< localCount);              
    				newBytecode= new JLoadLocal(this, operation, lastPC, operand);
                }
				break;

			case  ILOAD_0:
			case  FLOAD_0:
			case  ALOAD_0:
				newBytecode= new JLoadLocal(this, operation, pc, 0);
				break;

			case  LLOAD_0:
			case  DLOAD_0:
				newBytecode= new JLoadLocal(this, operation, pc, 0);
				break;

			case  ILOAD_1:
			case  FLOAD_1:
			case  ALOAD_1:
                assert(1< localCount);
				newBytecode= new JLoadLocal(this, operation, pc, 1);
				break;

			case  LLOAD_1:
			case  DLOAD_1:
                assert(1< localCount);
				newBytecode= new JLoadLocal(this, operation, pc, 1);
				break;

			case  ILOAD_2:
			case  FLOAD_2:
			case  ALOAD_2:
                assert(2< localCount);
				newBytecode= new JLoadLocal(this, operation, pc, 2);
				break;

			case  LLOAD_2:
			case  DLOAD_2:
                assert(2< localCount);
				newBytecode= new JLoadLocal(this, operation, pc, 2);
				break;

			case  ILOAD_3:
			case  FLOAD_3:
			case  ALOAD_3:
                assert(3< localCount);
				newBytecode= new JLoadLocal(this, operation, pc, 3);
				break;

			case  LLOAD_3:
			case  DLOAD_3:
                assert(3< localCount);
				newBytecode= new JLoadLocal(this, operation, pc, 3);
				break;

			case  IALOAD:
			case  FALOAD:
			case  BALOAD:
			case  AALOAD:
			case  CALOAD:
			case  SALOAD:                
				newBytecode= new JLoadArray(this, operation, pc);
				break;

			case  LALOAD:
			case  DALOAD:
				newBytecode= new JLoadArray(this, operation, pc);
				break;

			case  ISTORE:
			case  FSTORE:
			case  ASTORE:
                {
                    int lastPC= pc;
                    if (prevWide==0)
                    {
                        operand= getByte1( &(code[pc+1]) );
                    }
                    else
                    {
                        operand= getByte2( &(code[pc+1]) );
                        prevWide=0; 
                        pc++;
                    }
                
                    assert(operand< localCount);
    				newBytecode= new JDefineLocal(this, operation, lastPC, operand);
                }
            
				break;

			case  LSTORE:
			case  DSTORE:
                {
                    int lastPC= pc;
                    if (prevWide==0)
                    {
                        operand= getByte1( &(code[pc+1]) );
                    }
                    else
                    {
                        operand= getByte2( &(code[pc+1]) );
                        prevWide=0;
                        pc++;
                    }
                    assert(operand< localCount);
	       			newBytecode= new JDefineLocal(this, operation, lastPC, operand);
                }
		
				break;

			case  ISTORE_0:
			case  FSTORE_0:
			case  ASTORE_0:
				newBytecode= new JDefineLocal(this, operation, pc, 0);
				break;

			case  LSTORE_0:
			case  DSTORE_0:
				newBytecode= new JDefineLocal(this, operation, pc, 0);				
				break;

			case  ISTORE_1:
			case  FSTORE_1:
			case  ASTORE_1:
                assert(1< localCount);
				newBytecode= new JDefineLocal(this, operation, pc, 1);
		
				break;

			case  LSTORE_1:
			case  DSTORE_1:
                assert(1< localCount);
				newBytecode= new JDefineLocal(this, operation, pc, 1);
				break;

			case  ISTORE_2:
			case  FSTORE_2:
			case  ASTORE_2:
                assert(2< localCount);
				newBytecode= new JDefineLocal(this, operation, pc, 2);
			
				break;

			case  LSTORE_2:
			case  DSTORE_2:
                assert(2< localCount);
				newBytecode= new JDefineLocal(this, operation, pc, 2);
				break;

			case  ISTORE_3:
			case  FSTORE_3:
			case  ASTORE_3:
                assert(3< localCount);
				newBytecode= new JDefineLocal(this, operation, pc, 3);			
				break;

			case  LSTORE_3:
			case  DSTORE_3:
                assert(3< localCount);
				newBytecode= new JDefineLocal(this, operation, pc, 3);				
				break;

			case  IASTORE:
			case  FASTORE:
			case  AASTORE:
			case  BASTORE:
			case  CASTORE:
			case  SASTORE:
				newBytecode= new JDefineArray(this, operation, pc);
				break;


			case  LASTORE:
			case  DASTORE:
				newBytecode= new JDefineArray(this, operation, pc);
				break;

			case  POP:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  POP2:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  DUP:
				newBytecode= new JCommon(this, operation, pc);							
				break;

			case  DUP_X1:
				newBytecode= new JCommon(this, operation, pc);				
				break;

			case  DUP_X2:
				newBytecode= new JCommon(this, operation, pc);		
				break;

			case  DUP2:
				newBytecode= new JCommon(this, operation, pc);	
				break;

			case  DUP2_X1:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  DUP2_X2:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  SWAP:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  IADD:
			case  FADD:
			case  ISUB:
			case  FSUB:
			case  IMUL:
			case  FMUL:
			case  IDIV:
			case  FDIV:
			case  IREM:
			case  FREM:

			case  ISHL:
			case  ISHR:
			case  IUSHR:
			case  IAND:
			case  IOR:
			case  IXOR:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  LADD:
			case  DADD:
			case  LSUB:
			case  DSUB:
			case  LMUL:
			case  DMUL:
			case  LDIV:
			case  DDIV:
			case  LREM:
			case  DREM:
			case  LAND:
			case  LOR:
			case  LXOR:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  INEG:
			case  FNEG:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  LNEG:
			case  DNEG:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  LSHL:
			case  LSHR:
			case  LUSHR:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  IINC:
                {
                    int lastPC= pc;
    
                    if (prevWide==0)
                    {
                        operand= getByte1( &(code[pc+1]) );
                    }
                    else
                    {
                        operand= getByte2( &(code[pc+1]) );  
                        prevWide=0;           
                        pc+= 2;       
                    }        
                    assert(operand< localCount);
	       			newBytecode= new JDefineLocal(this, operation, lastPC, operand);
                }
				break;

			case  I2L:
			case  I2D:
			case  F2L:
			case  F2D:
				newBytecode= new JCommon(this, operation, pc);			
				break;

			case  I2F:
			case  L2D:
			case  F2I:
			case  D2L:
			case  INT2BYTE:
			case  INT2CHAR:
			case  INT2SHORT:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  L2I:
			case  L2F:
			case  D2I:
			case  D2F:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  LCMP:
			case  DCMPL:
			case  DCMPG:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  FCMPL:
			case  FCMPG:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  IFEQ:
			case  IFNE:
			case  IFLT:
			case  IFGE:
			case  IFGT:
			case  IFLE:
				newBytecode= new JBranch(this, operation, pc);			
				break;

			case  IF_ICMPEQ:
			case  IF_ICMPNE:
			case  IF_ICMPLT:
			case  IF_ICMPGE:
			case  IF_ICMPGT:
			case  IF_ICMPLE:
			case  IF_ACMPEQ:
			case  IF_ACMPNE:
				newBytecode= new JBranch(this, operation, pc);		
				break;

			case  GOTO:
				newBytecode= new JBranch(this, operation, pc);
				break;

			case  JSR:			
				newBytecode= new JBranch(this, operation, pc);
                {
                 	unsigned int target=getByte2(&(code[pc+1]));
                    target= pc+target;
                    exceptions.uniqueAdd(target);
                }				
				break;			

			case  RET:// by GL change to JBranch
                newBytecode= new JBranch(this, operation, pc);
				{
                    //int lastPC= pc;
                    if (prevWide!=0 )
                    {
                        pc++;
                        prevWide=0;
                    }
    				//newBytecode= new JCommon(this, operation, lastPC);
                }
				break;

			case  TABLESWITCH:
                newBytecode= new JBranch(this, operation, pc);
        		{
	           		pc=pc+ (4- (pc%4));

	           		int low=(int)get4Byte(&(code[pc+4]));
	           		int high=(int)get4Byte(&(code[pc+8]));

	           		pc=pc+12;
	           		for (i=low; i<=high; i++)
	           		{
	           			pc= pc+4;
	           		}
                }
                break;

			case  LOOKUPSWITCH:
				newBytecode= new JBranch(this, operation, pc);
                {
                    pc=pc+ (4- (pc%4));
        			int idx=(int)get4Byte(&(code[pc+4]));
		          	pc= pc+8;
		          	for (i=0; i<idx; i++)
		          	{
		          		pc= pc+8;
		          	}
                }
				break;

			case  IRETURN:
			case  FRETURN:
			case  ARETURN:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  LRETURN:
			case  DRETURN:
				newBytecode= new JCommon(this, operation, pc);
				break;
				
			case  RETURN:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  GETSTATIC:
                {
                   	identity_info finfo;
                    unsigned int idx= getByte2( &(code[pc+1]));
                    getFieldFromConstantPool(idx, sourceMethod, true, &finfo);

    		        invokeClassNameId= classNames->update(finfo.cname);
    		        operand= staticFieldNames->update(finfo.name); 
			        n= Signature::sizeofSigChar(finfo.signature[0]); 

			        newBytecode= new JLoadStatic(this, operation, pc, operand, invokeClassNameId, n);
                }
				break;

			case  PUTSTATIC:
                {
				    identity_info finfo;
                    unsigned int idx= getByte2( &(code[pc+1]));
                    getFieldFromConstantPool(idx, sourceMethod, true, &finfo);

				    invokeClassNameId= classNames->update(finfo.cname);
				    operand= staticFieldNames->update(finfo.name); 
				    n= Signature::sizeofSigChar(finfo.signature[0]); 

				    newBytecode= new JDefineStatic(this, operation, pc, operand, invokeClassNameId, n);
                }
				break;


			case  GETFIELD:
                 {
				    identity_info finfo;
                    unsigned int idx= getByte2( &(code[pc+1]));
                    getFieldFromConstantPool(idx, sourceMethod, false, &finfo);

				    operand= instanceFieldNames->update(finfo.name); 
				    n= Signature::sizeofSigChar(finfo.signature[0]);
			        newBytecode= new JLoadField(this, operation, pc, operand,n);
                 }
				break;

			case  PUTFIELD:
				 {
				    identity_info finfo;
                    unsigned int idx= getByte2( &(code[pc+1]));
                    getFieldFromConstantPool(idx, sourceMethod, false, &finfo);

				    operand= instanceFieldNames->update(finfo.name); 
				    n= Signature::sizeofSigChar(finfo.signature[0]);                     

				    newBytecode= new JDefineField(this, operation, pc, operand, n);
                 }
				break;			

			case  INVOKESPECIAL:
            case  INVOKEVIRTUAL:
			case  INVOKEINTERFACE:
                {
                    identity_info cinfo;
                    unsigned int idx= getByte2( &(code[pc+1]));

                    switch (operation)
                    {
                        case  INVOKEVIRTUAL:
                            getMethodCallInfoFromConstantPool(idx, sourceMethod, true, 0, &cinfo);
                            break;

                        case  INVOKESPECIAL:
                            getMethodCallInfoFromConstantPool(idx, sourceMethod, true, 1, &cinfo);
                            break;
			        	case  INVOKEINTERFACE:
                            getMethodCallInfoFromConstantPool(idx, sourceMethod, true, 2, &cinfo);
                            break;
                    }
				
				    invokeClassNameId= classNames->update( cinfo.cname);
				    invokeMethodNameId= methodNames->update( cinfo.name );				    
				    invokeMethodSigId= sigs->update(cinfo.signature);				
				    

				    newBytecode= new JInvokeNonStatic(this, operation, pc, invokeClassNameId, invokeMethodNameId, invokeMethodSigId, cinfo.signature);
				    invokePasedSig= ((JInvokeNonStatic *)newBytecode)->getSig();
				    n= invokePasedSig->getNargs();
					//printf("xxx:jmethod.cpp: %s sig: %s\n", cinfo.name, invokePasedSig->sig);

                    for (i=0; i<n ; i++)
                    {
                        ((JInvokeNonStatic *)newBytecode)->setnUseOperNum(i, invokePasedSig->getSizeOfNArgs(i));
                        //printf("xxx: jmethod.cpp: x1: %d, %d\n", i, invokePasedSig->getSizeOfNArgs(i));
				    }
                    ((JInvokeNonStatic *)newBytecode)->setDefOperNum(invokePasedSig->getSizeOfRet());
                    ((JInvokeNonStatic *)newBytecode)->javaMethods= getNativeCalledJavaMethodListForInstruction(methTrace, pc);// by GL
                }
				break;
			
			case  INVOKESTATIC:
                {
                    identity_info cinfo;
                    unsigned int idx= getByte2( &(code[pc+1]));

                    getMethodCallInfoFromConstantPool(idx, sourceMethod, true, 0, &cinfo);

                    invokeClassNameId= classNames->update( cinfo.cname );
				    invokeMethodNameId= methodNames->update( cinfo.name );				    
				    invokeMethodSigId= sigs->update(cinfo.signature);
				
				    newBytecode= new JInvokeStatic(this, operation, pc, invokeClassNameId, invokeMethodNameId, invokeMethodSigId, cinfo.signature);
				    invokePasedSig= ((JInvokeStatic *)newBytecode)->getSig();
				    n= invokePasedSig->getNargs();

                    for (i=0; i<n ; i++)
                    {
                        ((JInvokeStatic *)newBytecode)->setnUseOperNum(i, invokePasedSig->getSizeOfNArgs(i));
				    }
                    ((JInvokeStatic *)newBytecode)->setDefOperNum(invokePasedSig->getSizeOfRet());
					((JInvokeStatic *)newBytecode)->javaMethods= getNativeCalledJavaMethodListForInstruction(methTrace, pc);// by GL
                }
				break;

			case  NEW:
                {
                    unsigned int idx= getByte2( &(code[pc+1]));
                    newClassName= copyString(getClassNameFromConstantPoolInKaffe(idx, sourceMethod));
                    formatClassName(newClassName);   
                    newBytecode= new JNew(this, operation, pc, newClassName);            
                }
				break;

			case  NEWARRAY:
			case  ANEWARRAY:
				newBytecode= new JNewArray(this, operation, pc);
				break;

			case  ARRAYLENGTH:
			case  CHECKCAST:
			case  INSTANCEOF:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  ATHROW:
				newBytecode= new JCommon(this, operation, pc);
				break;


			case  MONITORENTER:
			case  MONITOREXIT:
				newBytecode= new JCommon(this, operation, pc);
				break;

			case  WIDE:
				newBytecode= new JCommon(this, operation, pc);
                prevWide=1;
				break;

			case  MULTIANEWARRAY:
				dimension= getByte1( &(code[pc+3]) );
				
				newBytecode= new JNewMultiArray(this, operation, pc, dimension);
				break;

			case  IFNULL:
			case  IFNONNULL:
				newBytecode= new JBranch(this, operation, pc);
				break;

			case  GOTO_W:
				newBytecode= new JBranch(this, operation, pc);
				break;

			case  JSR_W:
				newBytecode= new JBranch(this, operation, pc);
                {
                    int target=(int)get4Byte(&(code[pc+1]));
        			target= pc+ target;
                    exceptions.uniqueAdd(target);
                }
				break;

			case  BREAKPOINT:
				printf("error: we not handle breakpoint\n");
				break;

            default:
                break;
		}
        if (prevWide==1 && operation!= WIDE)
        {
            printf("error, should not be prefWide, \n");
        }

        newBytecode->lineNum=getLineNumOfBytecode(newBytecode);
        bytecodes->append(newBytecode);
		pc= pc+instLen[operation];
	};


	freeStack();
    return 1;
}

int JMethod::getNameId()
{
	return nameId;
}

int JMethod::getSigId()
{
	return sigId;
}

Signature* JMethod::getSig()
{
	return signature;
}

JMethod::~JMethod()
{
	JBytecodeRef *jBytecodeRef;

    if (bytecodes)
    {
    	for (jBytecodeRef= bytecodes->getFirst(); jBytecodeRef->hasNext(); jBytecodeRef=jBytecodeRef->getNext())
	   {
	   	delete (jBytecodeRef->getBytecode());
	   }
    }

	delete bytecodes;
	delete signature;

	free(hash);
	delete[] basicBlocks;
    delete[] lines;
	
	bytecodes=NULL;
	hash=NULL;
	basicBlocks=NULL;
	signature=NULL;
}

void JMethod::buildCDG()
{
	char	*postDominator, *t, *parent, *dependence;
	int i, j, k, change, *control, *immedia,z, count;

	/* calculate the postDominator */

	postDominator= (char *)cleanMalloc(sizeof(char)*basicBlockCount*basicBlockCount);
	t= (char *)cleanMalloc(sizeof(char)*basicBlockCount);

	for (i=0; i<basicBlockCount; i++)
	{
		if ( !basicBlocks[i].control[0])
		{
			postDominator[i*basicBlockCount+i]= 1;
		}
		else
		{
			memset(&(postDominator[i*basicBlockCount]), 1, sizeof(char)*basicBlockCount);
		}
	}

	change= 1;

	while (change)
	{
		change= 0;
		for (i=0; i< basicBlockCount; i++)
		{
			memcpy(t, &(postDominator[i*basicBlockCount]), sizeof(char)*basicBlockCount);
			control= basicBlocks[i].control;
			for(j=0; j<control[0]; j++)
			{
				parent= &(postDominator[control[j+1]*basicBlockCount]);
				for (k=0; k< basicBlockCount; k++)
				{
					if ( t[k] && parent[k])
						t[k]= 1;
					else
						t[k]= 0;
				}
			}
			t[i]= 1;

			for (k=0; k< basicBlockCount; k++)
			{
				if (t[k] != postDominator[i*basicBlockCount+k])
				{
					postDominator[i*basicBlockCount+k]= t[k];
					change= 1;
				}
			}
		}
	}
	free(t);
    t=NULL;

#ifdef _read_debug
	printf("\t \t \t post dominator \n");
	for (i=0; i<basicBlockCount; i++)
	{
		printf("\t \t \t \t %d: ", i);
		for (j=0; j<basicBlockCount; j++)
		{
			if (postDominator[i*basicBlockCount+j])
			{
				printf("%d, ", j);
			}
		}
		printf("\n");
	}
#endif

	/* transform to immedia postdominator */

	immedia= (int *)cleanMalloc(sizeof(int)*basicBlockCount);
	for (i=0; i<basicBlockCount; i++)
	{
		immedia[i]= basicBlockCount+1;
	}

	change= 1;

	while(change)
	{
		change= 0;

		for (i=0; i<basicBlockCount; i++)
		{
			if (immedia[i]!= basicBlockCount+1)
				continue;

			count=0;
			z= basicBlockCount;

			for (j=0; j<basicBlockCount; j++)
			{
				if (postDominator[i*basicBlockCount+j] && i!=j)
				{
					count++;
					z= j;
				}
			}

			if (count<=1)
			{
				immedia[i]= z;
				change= 1;
				if ( z!= basicBlockCount)
				{
					for (j=0; j<basicBlockCount; j++)
					{
						if (postDominator[j*basicBlockCount+i])
						{
							postDominator[j*basicBlockCount+z]= 0;
						}
					}
				}
			}
		}
	}
	free(postDominator);
	postDominator=NULL;

#ifdef _read_debug
	printf("\t \t \t immedia post dominator \n");
	for (i=0; i<basicBlockCount; i++)
	{
		printf("\t \t \t \t %d: %d\n", i, immedia[i]);
	
	}
#endif


	// get the control dependence graph
	
#ifdef _read_debug
	printf("\t \t \t dependence \n");
#endif
	dependence= (char *)cleanMalloc(sizeof(char)*basicBlockCount*basicBlockCount);


	for (i=0; i<basicBlockCount; i++)
	{
		control= basicBlocks[i].control;
		basicBlocks[i].meth= this;
	}

	for (i=0; i<basicBlockCount; i++)
	{
		control= basicBlocks[i].control;
		int size= control[0];

		for (j=0; j<size; j++)
		{
			z= control[j+1];
			JBytecode *target= hash[basicBlocks[z].startInst]->getBytecode();

			while( z != immedia[i] && z!=basicBlockCount )
			{

				dependence[z*basicBlockCount+i]= 1;
				z= immedia[z];
			}
		}
	}
//	printf("method %s %s\n", methodNames->getCNameAt(nameId), sigs->getCNameAt(sigId));


	for (i=0; i<basicBlockCount; i++)
	{
		count= 0;
		free(basicBlocks[i].control);
		basicBlocks[i].control=NULL;

		for (j=0; j<basicBlockCount; j++)
		{
			if (dependence[j*basicBlockCount+i])
			{
				count++;
			}
		}

		basicBlocks[i].control= (int *)cleanMalloc(sizeof(int)*(count+1));
		basicBlocks[i].control[0]= count;
		count= 0;

		for (j=0; j<basicBlockCount; j++)
		{
			if (dependence[j*basicBlockCount+i])
			{

				count++;
				basicBlocks[i].control[count]= j;
			}
		}
	}
	free(dependence);
	dependence=NULL;	
}




void JMethod::build()
{
	hasBuilded= 1;

#ifdef _read_debug
	JBytecodeRef *ite;
	printf("build method %s %s\n", methodNames->getCNameAt(nameId), sigs->getCNameAt(sigId));
    printf("instructions: \n", (unsigned int)bytecodes);
    

    for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
    {
		ite->getBytecode()->dumpBytecode();
     	ite->getBytecode()->dumpType();
    }

#endif
	
	int i;

    unsigned char *code= getCodeOfMethodInKaffe(sourceMethod);

	hash= (JBytecodeRef **)cleanMalloc(sizeof(JBytecodeRef*)*codelen);

	JBytecodeRef *bytecodeRef= bytecodes->getFirst();

	int pc=0;
	int operation;

#ifdef _read_debug
	printf("get bytecode from class ------------------------------, %d\n", codelen);
#endif

	JBytecode *lastBytecode= NULL;
    
	// init the hash, so that we can find the bytecode w.r.t the pc quickly
	while(pc< codelen)
	{
		hash[pc]= bytecodeRef;
		JBytecode *bytecode= bytecodeRef->getBytecode();

		bytecode->prevBytecode= lastBytecode;
		lastBytecode= bytecode;

		bytecode->setPC(pc);
		operation = (int)(0x000000ff & code[pc]);
		int operand;

#ifdef _read_debug
		printf("%d %s %d\n", pc, bytecodeName[operation], operation);
#endif

		if (operation != bytecode->getOperation())
		{
			bytecode->setOperation(operation);
		}

		if ( TABLESWITCH == operation)
		{
			pc=pc+ (4- (pc%4));

			int low=(int)get4Byte(&(code[pc+4]));
			int high=(int)get4Byte(&(code[pc+8]));

			pc=pc+12;
			for (i=low; i<=high; i++)
			{
				pc= pc+4;
			}
			bytecodeRef= bytecodeRef->getNext();
			continue;
		}

		if (LOOKUPSWITCH == operation)
		{
			pc=pc+ (4- (pc%4));
			int idx=(int)get4Byte(&(code[pc+4]));
			pc= pc+8;
			for (i=0; i<idx; i++)
			{
				pc= pc+8;
			}
			bytecodeRef= bytecodeRef->getNext();
			continue;
		}

		if (WIDE == operation)
		{
			pc++;
			bytecodeRef= bytecodeRef->getNext();
			hash[pc]= bytecodeRef;
			operation= 0x00ff & code[pc];
			bytecode= bytecodeRef->getBytecode();

#ifdef _read_debug
    		printf("%d %s %d\n", pc, bytecodeName[operation], operation);

			if (operation != bytecodeRef->getBytecode()->getOperation())
			{
				printf("operation not the same\n");
				abort();
			}
#endif
            if (operation == IINC)
                pc=pc + instLen[operation]+ 2;
            else
                pc=pc + instLen[operation]+ 1;
    		bytecodeRef= bytecodeRef->getNext();
            continue;
		}
		pc+=instLen[operation];
		bytecodeRef= bytecodeRef->getNext();
	}

	pc=0;
	lastBytecode= NULL;
	JBytecode *targetBytecode= NULL;
	int target, branch, oldpc, low, high, idx;

    // jsrEntries, record information for jsr information
    // if the value is 0, there is nothing
    // it the value is -1, this is a jsr entry point
    // if the value is >0, the bytecode need filling prevBytecode, which is a ret bytecode
    int *jsrEntries=(int *)cleanMalloc(sizeof(int)*codelen);

	while(pc<codelen)
	{
		JBytecode *bytecode= hash[pc]->getBytecode();
		operation = (int)(0x000000ff & code[pc]);

		if ( controlInfo[operation] == 1 )
		{
			target= get2SignedByte(&(code[pc+1]));
			target= pc+target;
			hash[target]->getBytecode()->prevBytecode= bytecode;
			pc+=instLen[operation];

            if (JSR == operation)
            {
                jsrEntries[pc]= target;
                jsrEntries[target]= -1;
            }

			continue;
		}

		if ( controlInfo[operation] == 2 )
		{
			branch=(int)get4Byte(&(code[pc+1]));
			branch= pc+branch;
			hash[branch]->getBytecode()->prevBytecode= bytecode;

			pc+=instLen[operation];
            
            if (JSR_W == operation)
            {
                jsrEntries[pc]= target;
                jsrEntries[target]= -1;
            }
			continue;
		}

		if ( TABLESWITCH == operation)
		{
			oldpc= pc;
			pc=pc+ (4- (pc%4));

			branch=(int)get4Byte(&(code[pc]));
			branch= oldpc+branch;
			hash[branch]->getBytecode()->prevBytecode= bytecode;
			
			low=(int)get4Byte(&(code[pc+4]));
			high=(int)get4Byte(&(code[pc+8]));

			pc=pc+12;

			for (i=low; i<=high; i++)
			{
				branch=(int)get4Byte(&(code[pc]));
				branch= oldpc+branch;
				hash[branch]->getBytecode()->prevBytecode= bytecode;				
				pc= pc+4;
			}
			continue;
		}

		if (LOOKUPSWITCH == operation)
		{			
			oldpc= pc;
			pc=pc+ (4- (pc%4));

			branch=(int)get4Byte(&(code[pc]));
			branch= oldpc+branch;
			hash[branch]->getBytecode()->prevBytecode= bytecode;			

			idx=(int)get4Byte(&(code[pc+4]));

			pc= pc+8;

			for (i=0; i<idx; i++)
			{
				branch=(int)get4Byte(&(code[pc+4]));
				branch= oldpc+branch;
				hash[branch]->getBytecode()->prevBytecode= bytecode;
				pc= pc+8;
			}
			continue;
		}

		if (WIDE == operation)
		{
			pc++;
			operation= 0x00ff & (int)code[pc];

            if (operation == IINC)
                pc=pc + instLen[operation]+ 2;
            else
                pc=pc + instLen[operation]+ 1;

			continue;
		}
		pc+=instLen[operation];
	}

    stack<int> s;

    for (pc=0; pc<codelen; pc++)
    {
         if (hash[pc] != NULL)
         {
             if ( hash[pc]->getBytecode()->getOperation() == RET)
             {
                if (s.empty())
                {
                    continue;
                }

                int target= s.top();
                s.pop();
                for (int pc1=0; pc1<codelen; pc1++)
                {
                    if (jsrEntries[pc1]==target)
                    {
                        hash[pc1]->getBytecode()->prevBytecode= hash[pc]->getBytecode();
                    }
                }
             }

             if (jsrEntries[pc] == -1)
             {
                s.push(pc);
             }
         }
     }

    free(jsrEntries);

#ifdef _read_debug
	printf("instructions: \n");

	for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
	{
		ite->getBytecode()->dumpBytecode();
		ite->getBytecode()->dumpType();
	}	
#endif

#ifdef _read_debug
     printf("hash: \n");

     for (pc=0; pc<codelen; pc++)
     {
         if (hash[pc] != NULL)
         {
             hash[pc]->getBytecode()->dumpBytecode();
             printf("\n");
             if (pc!=hash[pc]->getBytecode()->getPC())
             {
                 printf("pc is wrong \n");
             }
         }
     }
	 printf("11111111111111\n");
#endif


	int *entry= (int *)cleanMalloc(sizeof(int)*codelen);
	

	//the sequence of jsr/ret:
	// jsr xxx; ret y; jsr xxx
	//the above will be processed on the fly
	vector<JSREntry> jsrStack; //by GL //store the first jsr occurrence only, for ret match
	vector<JSREntry> jsrStore;//maintain all jsr occurred

	pc=0;

	/* mark the entry point for each basic block */

	while(pc< codelen)
	{
		JBranch *jBranch;
		char ch= code[pc];
		operation = (int)(0x000000ff & ch);

		if (pc == 0)
		{
			entry[0]= 1;
		}

		if ( (operation>=IFEQ && operation<= IF_ACMPNE) || IFNULL==operation || IFNONNULL==operation )
		{
			int idx= get2SignedByte(&(code[pc+1]));
			idx= pc+ idx;

			jBranch= dynamic_cast<JBranch*>(hash[pc]->getBytecode());
			jBranch->addControl(hash[pc]->getNext());
			jBranch->addControl(hash[idx]);

			entry[idx]= 1;
			pc+=instLen[operation];
            if (pc<codelen)
    			entry[pc]= 1;

			continue;
		}

		if ( GOTO== operation)
		{
			int idx= get2SignedByte(&(code[pc+1]));
			idx= pc+ idx;

			jBranch=dynamic_cast<JBranch *>(hash[pc]->getBytecode());
			jBranch->addControl(hash[idx]);		

			entry[idx]= 1;
			pc+=instLen[operation];
			if (pc<codelen)
    			entry[pc]= 1;

			continue;
		}

		if ( TABLESWITCH == operation)
		{
			jBranch=dynamic_cast<JBranch *>(hash[pc]->getBytecode());
			int oldpc= pc;
			pc=pc+ (4- (pc%4));

			int branch=(int)get4Byte(&(code[pc]));
			branch= oldpc+branch;
			entry[branch]= 1;

			jBranch->addControl(hash[branch]);

			int low=(int)get4Byte(&(code[pc+4]));
			int high=(int)get4Byte(&(code[pc+8]));

			pc=pc+12;

			for (i=low; i<=high; i++)
			{
				branch=(int)get4Byte(&(code[pc]));
				branch= oldpc+branch;
				entry[branch]= 1;
				jBranch->addControl(hash[branch]);
				pc= pc+4;
			}
            if (pc<codelen)
    			entry[pc]= 1;
			continue;
		}

		if (LOOKUPSWITCH == operation)
		{
			jBranch=dynamic_cast<JBranch *>(hash[pc]->getBytecode());
			int oldpc= pc;
			pc=pc+ (4- (pc%4));

			int branch=(int)get4Byte(&(code[pc]));
			branch= oldpc+branch;
			entry[branch]= 1;
			jBranch->addControl(hash[branch]);

			int idx=(int)get4Byte(&(code[pc+4]));

			pc= pc+8;

			for (i=0; i<idx; i++)
			{
				branch=(int)get4Byte(&(code[pc+4]));
				branch= oldpc+branch;
				entry[branch]= 1;
				jBranch->addControl(hash[branch]);
				pc= pc+8;
			}
        if (pc<codelen)
			entry[pc]= 1;
			continue;
		}

		if (WIDE == operation)
		{
			pc++;

			operation= 0x00ff & (int)(code[pc]);
			if (operation == IINC)
                pc=pc + instLen[operation]+ 2;
            else
                pc=pc + instLen[operation]+ 1;

			continue;
		}

		if ( GOTO_W== operation)
		{
			jBranch=dynamic_cast<JBranch *>(hash[pc]->getBytecode());
			int idx= (int)get4Byte(&(code[pc+1]));
			idx= pc+ idx;
			jBranch->addControl(hash[idx]);

			entry[idx]= 1;
			pc+=instLen[operation];
			if (pc<codelen)
    			entry[pc]= 1;
			continue;
		}

        if ( JSR == operation)
		{
			jBranch=dynamic_cast<JBranch *>(hash[pc]->getBytecode());
			int idx= (int)get2SignedByte(&(code[pc+1]));
			idx= pc+ idx;

			jBranch->addControl(hash[idx]);

			entry[idx]= 1;
			
			pc+=instLen[operation];
            if (pc<codelen)
            {
    			entry[pc]= 1;
			
				// by GL add "pc" to instr at "idx"
				//printf("jsrstack: jsr at %s.%s %d\n", getParentClass()->getClassName(), methodNames->getCNameAt(nameId), pc);

				int foundjsrentry=0;
				for(int i=0; i < jsrStore.size(); i++)
				{
					if(jsrStore.at(i).jsrTarget == idx)
					{
						foundjsrentry=1;
						int *temp = (int *)cleanMalloc(sizeof(int));
						*temp = pc;
						jsrStore.at(i).jsrNext.push_back(*temp);
						break;
					}
				}
				if(foundjsrentry == 0)
				{
					for(int i=0; i < jsrStack.size(); i++)
					{
						if(jsrStack.at(i).jsrTarget == idx)
						{
							foundjsrentry=1;
							int *temp = (int *)cleanMalloc(sizeof(int));
							*temp = pc;
							jsrStack.at(i).jsrNext.push_back(*temp);
							break;
						}
					}
				}
				if(foundjsrentry == 0)
				{
					JSREntry *jsrEntry = new JSREntry();
					jsrEntry->jsrTarget= idx;
					int *temp = (int *)cleanMalloc(sizeof(int));
					*temp = pc;
					jsrEntry->jsrNext.push_back(*temp);
					jsrStack.push_back(*jsrEntry);
				}
			}
			continue;
		}

		if ( JSR_W == operation)
		{
			jBranch=dynamic_cast<JBranch *>(hash[pc]->getBytecode());
			int idx= (int)get4Byte(&(code[pc+1]));
			idx= pc+ idx;
			jBranch->addControl(hash[idx]);

			entry[idx]= 1;

			pc+=instLen[operation];
        	if (pc<codelen)
			{
				entry[pc]= 1;
							// by GL add "pc" to instr at "idx"
				//printf("jsrstack: jsrw at %s.%s %d\n", getParentClass()->getClassName(), methodNames->getCNameAt(nameId), pc);
				
				int foundjsrentry=0;
				for(int i=0; i < jsrStore.size(); i++)
				{
					if(jsrStore.at(i).jsrTarget == idx)
					{
						foundjsrentry=1;
						int *temp = (int *)cleanMalloc(sizeof(int));
						*temp = pc;
						jsrStore.at(i).jsrNext.push_back(*temp);
						break;
					}
				}
				if(foundjsrentry == 0)
				{
					for(int i=0; i < jsrStack.size(); i++)
					{
						if(jsrStack.at(i).jsrTarget == idx)
						{
							foundjsrentry=1;
							int *temp = (int *)cleanMalloc(sizeof(int));
							*temp = pc;
							jsrStack.at(i).jsrNext.push_back(*temp);
							break;
						}
					}
				}
				if(foundjsrentry == 0)
				{
					JSREntry *jsrEntry = new JSREntry();
					jsrEntry->jsrTarget= idx;
					int *temp = (int *)cleanMalloc(sizeof(int));
					*temp = pc;
					jsrEntry->jsrNext.push_back(*temp);
					jsrStack.push_back(*jsrEntry);
				}
			}
			continue;
		}
		
		if(RET == operation)
		{
			//printf("jsrstack: ret at %s.%s %d\n", getParentClass()->getClassName(), methodNames->getCNameAt(nameId), pc);
			if(jsrStack.size()>0)
			{
				JSREntry *top = &jsrStack.at(jsrStack.size()-1);
				JSREntry *newtop= new JSREntry();
				newtop->jsrTarget = top->jsrTarget;
				newtop->retPC = pc;
				for(int j=0; j<(top->jsrNext).size(); j++)
				{
					int *temp = (int *)cleanMalloc(sizeof(int));
					*temp = (top->jsrNext).at(j);
					(newtop->jsrNext).push_back(*temp);
				}
				jsrStore.push_back(*newtop);
				jsrStack.pop_back();
			}
			else
			{
				//we ignore the error case in System.clinit()
				//we also assume ret will not preceed jsr, this may not be true
			}
			
			pc+=instLen[operation];
	        if (pc<codelen)
				entry[pc]= 1;
			continue;
		}
		
		if (ATHROW == operation)
		{
			pc+=instLen[operation];
	        if (pc<codelen)
				entry[pc]= 1;
			continue;
		}

		pc+=instLen[operation];
	}
	
	if(jsrStack.size()>0)
		printf("error: jsrStack is not empty at the end of method %s\n", getMethodName());

	for(int j = 0; j < jsrStore.size(); j++)	{
		//printf("jsrstack: curr entry: %d -> %d\n", jsrStore.at(j).jsrTarget, jsrStore.at(j).retPC);
		JBranch *retBranch = dynamic_cast<JBranch *>(hash[jsrStore.at(j).retPC]->getBytecode());
		for(int i=0; i<jsrStore.at(j).jsrNext.size(); i++)
		{
			//printf("jsrstack: jsrnext: curr: %d\n", jsrStore.at(j).jsrNext.at(i));
			retBranch->addControl(hash[jsrStore.at(j).jsrNext.at(i)]);
		}
	}
	jsrStore.clear();
	jsrStack.clear();


#ifdef _read_debug     
       printf("basic blocks, entry:\n");
#endif

	/* set the basic block id to each bytecode, and get how many basic blocks we have*/
	
	basicBlockCount=-1;

	for(bytecodeRef= bytecodes->getFirst(); bytecodeRef->hasNext();bytecodeRef= bytecodeRef->getNext())
	{
		pc= bytecodeRef->getBytecode()->getPC();
		if (entry[pc]!= 0) 
            basicBlockCount++;
		bytecodeRef->getBytecode()->setBasicBlock(basicBlockCount);
#ifdef _read_debug
            printf("%d,  %d\n", basicBlockCount, pc);
#endif        
	}
   
	basicBlockCount++;

#ifdef _read_debug
       printf("basic block information, %d\n", basicBlockCount);
#endif
    
	/* init all the basic blocks */
	basicBlocks= new BasicBlock[basicBlockCount];

	for(bytecodeRef= bytecodes->getFirst(); bytecodeRef->hasNext(); bytecodeRef= bytecodeRef->getNext())
	{
		JBytecode *jbytecode= bytecodeRef->getBytecode();
		pc= jbytecode->getPC();
		
		if (entry[pc]!= 0) 
			basicBlocks[jbytecode->getBasicBlockId()].startInst= pc;

		int id= jbytecode->getBasicBlockId();

		basicBlocks[id].endInst= pc;
		basicBlocks[id].id= id;
	}

#ifdef _read_debug
      for (i=0; i<basicBlockCount; i++)
      {
          printf("%d: %d %d--%d\n", i, basicBlocks[i].id, basicBlocks[i].startInst, basicBlocks[i].endInst);          
      }

      printf("control information \n");
#endif
    
	/* calculte the control flow for each basic, that is which other basic blocks are under control */

	JBytecodeRef *jBytecodeRef;
	int j;
	for (i=0; i<basicBlockCount; i++)
	{
		jBytecodeRef= hash[basicBlocks[i].startInst];		
		int nobasic=1;
#ifdef _read_debug
			printf("==== %d, %d, %d\n", i, basicBlocks[i].startInst, basicBlocks[i].endInst);
#endif 

		while(jBytecodeRef->getBytecode()->getPC() <= basicBlocks[i].endInst)
		{

#ifdef _read_debug
			jBytecodeRef->getBytecode()->dumpBytecode();
			printf("\n");
#endif
            JBytecode *currentBytecode= jBytecodeRef->getBytecode();

			JBranch *jBranch= dynamic_cast<JBranch*>(currentBytecode);
                                
			if (jBranch != NULL)
			{
				BytecodeList *controlBytecodeList= jBranch->getControl();
				nobasic= 0;
#ifdef _read_debug
                printf("\t-branch");
                jBranch->dumpBytecode();
                printf("\n      , control:    ");
                controlBytecodeList->dumpList();
                printf("\t-end of branch\n");
#endif                

				basicBlocks[i].control= (int *)cleanMalloc(sizeof(int)*(controlBytecodeList->getCount()+1));
				basicBlocks[i].control[0]= controlBytecodeList->getCount();
				JBytecodeRef *controlBytecodeRef= controlBytecodeList->getFirst();

				for (j=0; j< controlBytecodeList->getCount(); j++)
				{
					basicBlocks[i].control[j+1]= controlBytecodeRef->getBytecode()->getBasicBlockId();
					controlBytecodeRef= controlBytecodeRef->getNext();
				}
				break;
			}
			else
			{	
				operation= jBytecodeRef->getBytecode()->getOperation();
				if ( (operation>= IRETURN && operation<= RETURN) || operation== ATHROW)
				{
					basicBlocks[i].control= (int *)cleanMalloc(sizeof(int)*1);
					basicBlocks[i].control[0]=0;
					nobasic= 0;
				}
			}
			if ( jBytecodeRef->getBytecode()->getPC() == basicBlocks[i].endInst)
			{
				break;
			}
			else
			{
				jBytecodeRef= jBytecodeRef->getNext();
			}
		}

		if (nobasic)
		{
            if (jBytecodeRef->getNext()->getBytecode())
            {            
    			basicBlocks[i].control= (int *)cleanMalloc(sizeof(int)*2);
	      		basicBlocks[i].control[0]=1;

	       		basicBlocks[i].control[1]= jBytecodeRef->getNext()->getBytecode()->getBasicBlockId();
            }
            else
            {
                basicBlocks[i].control= (int *)cleanMalloc(sizeof(int)*1);
    			basicBlocks[i].control[0]=0;
            }
		}
	}

#ifdef _read_debug
       printf("33333333333333333\n");
	   for (i=0; i<basicBlockCount; i++)
	   {
			printf("%d:", basicBlocks[i].id);
			if (basicBlocks[i].control)
			{
				for (j=0; j<basicBlocks[i].control[0]; j++)
				{
					printf("%d, ", basicBlocks[i].control[j+1]);
				}
			}
			printf("\n");
	   }
#endif

	buildCDG();

#ifdef _read_debug
       printf("44444444444444\n");
	   for (i=0; i<basicBlockCount; i++)
	   {
			printf("%d:", basicBlocks[i].id);
			if (basicBlocks[i].control)
			{
				for (j=0; j<basicBlocks[i].control[0]; j++)
				{
					printf("%d, ", basicBlocks[i].control[j+1]);
				}
			}
			printf("\n");
	   }
#endif	

	free(entry);
	entry=NULL;

}


int JMethod::getLocalCount()
{	
	return localCount;
}

JBytecodeRef* JMethod::getBytecodeRefAt(int pc)
{
	return (hash[pc]);
}

int JMethod::getCodeLen()
{	
	return codelen;
}

JClass* JMethod::getParentClass()
{
	return pClass;
}

void JMethod::dumpSlice(FILE *fp)
{
	
	JBytecodeRef *ite;
    if (bytecodes==NULL)
        return;

	ArrayList<int> inSlicer;  
	const char *fileName=getParentClass()->getFileName();
	const char *className=getParentClass()->getClassName();

	for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
	{
		allBytecodeCount++;        

		if (ite->getBytecode()->slice != NotIncludedSlice)
		{
			slicedBytecodeCount++;
			//fprintf(fp, "%s\n", fileName);
            //fprintf(fp, "line %d, pc %d\n", ite->getBytecode()->lineNum, ite->getBytecode()->getPC());
            if (lines)
            {
            	if(ite->getBytecode()->lineNum >0)
	                inSlicer.uniqueAdd(ite->getBytecode()->lineNum);
            }
            else
            {
                inSlicer.uniqueAdd(ite->getBytecode()->getPC());
            }
		}

		if (ite->getBytecode()->executed)
		{
			executedBytecodeCount++;
		}
	}

    if (inSlicer.size()>0)
    {
        //if (foreclipse && lines)
        if(foreclipse)
        {
        	if(lines){
            for (int i=0; i<inSlicer.size(); i++)
            {
            	#ifdef MethodCriterion
            	const char *methName = getMethodName();
            	if(strncmp(methName, "test", 4) == 0
					&& strncmp(className, "junit", 5) != 0)
            	{
            		fprintf(fp, "%s ", className);
            		fprintf(fp, "%s ", methName);
					fprintf(fp, "%d\n", inSlicer.getAt(i));
            	}
            	#else
                fprintf(fp, "%s\n", fileName);
                fprintf(fp, "%d\n", inSlicer.getAt(i));
                #endif
            }
            }
        }
        else
        {
            fprintf(fp, "\t method: %s  %s", methodNames->getCNameAt(nameId), sigs->getCNameAt(sigId));
            if (lines)
            {
                fprintf(fp,"\n\t \t LineNums:");
                for (int i=0; i<inSlicer.size(); i++)
                    fprintf(fp, "%d ", inSlicer.getAt(i));
                fprintf(fp, "\n");
            }		
            else
            {
                fprintf(fp, "==  no line number table. \n \t \t Bytecodes:\n");
                for (int i=0; i<inSlicer.size(); i++)
                {
                    fprintf(fp, "\t \t \t");
                    getBytecodeRefAt(inSlicer.getAt(i))->getBytecode()->dumpBytecode(fp);
          	 		fprintf(fp, "\n");
                }
            }
        }
    }
}

void JMethod::dumpSliceDifference(FILE *fp)
{
	
	JBytecodeRef *ite;
    if (bytecodes==NULL)
        return;

	ArrayList<int> inSlicer;  
	const char *fileName=getParentClass()->getFileName();
	const char *className=getParentClass()->getClassName();

	for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
	{
		//allBytecodeCount++;        

		if (ite->getBytecode()->slice != NotIncludedSlice && ite->getBytecode()->sliceOutputed==0)
		{
			//slicedBytecodeCount++;
            if (lines)
            {
            	if(ite->getBytecode()->lineNum >0)
            	{
	                inSlicer.uniqueAdd(ite->getBytecode()->lineNum);
	                ite->getBytecode()->sliceOutputed= 1;
	            }
            }
		}
	}

    if (inSlicer.size()>0)
    {
        //if (foreclipse && lines)
        if(foreclipse)
        {
        	if(lines){
            for (int i=0; i<inSlicer.size(); i++)
            {
            	#ifdef MethodCriterion
            	fprintf(fp, "%s\n", className);
            	#else
                fprintf(fp, "%s\n", fileName);
                #endif
                fprintf(fp, "%d\n", inSlicer.getAt(i));
            }
            }
        }
    }
}

void JMethod::freeStack()
{
    return;
}



void JMethod::buildCallGraph()
{
	JBytecodeRef *jBytecodeRef;    
    if (bytecodes==NULL)
        return;

	for(jBytecodeRef= bytecodes->getFirst(); jBytecodeRef->hasNext(); jBytecodeRef= jBytecodeRef->getNext())
	{
		JBytecode *jBytecode= jBytecodeRef->getBytecode();

		{
			JInvokeNonStatic *jInvoke= dynamic_cast<JInvokeNonStatic *>(jBytecode);
			if (jInvoke)
			{
				/*if (strcmp("java/lang/Class", classNames->getCNameAt(pClass->getNameId()))==0
					&& strcmp("newInstance", methodNames->getCNameAt(nameId))==0
					&& strcmp("newInstance", jInvoke->getInvokedMethodName())==0 )
				{
					jInvoke->initReflectCalls();
					continue;
				}*/
				jInvoke->initCalls();
				continue;
			}

		}

		{
			JInvokeStatic *jInvoke= dynamic_cast<JInvokeStatic *>(jBytecode);
			if (jInvoke)
			{
				jInvoke->initCalls();
				continue;
			}
		}	
	}

}


void JMethod::dumpCallGraph()
{
	int i;

	printf("method:-----------%s%s\n", methodNames->getCNameAt(nameId), sigs->getCNameAt(sigId));

	for (i=0; i<basicBlockCount; i++)
		basicBlocks[i].dumpCallGraph();
}

int JMethod::getBasicBlockCount()
{
	return basicBlockCount;
}

int JMethod::isStaticInit()
{
	return staticInit;
}


JBytecode* JMethod::getJBytecodeAt(int pc)
{
	return hash[pc]->getBytecode();
}

int JMethod::isMainMethod()
{
	return mainMethod;
}

int JMethod::getBytecodeCount()
{
	int count=0;
	JBytecodeRef *ite;

    if (bytecodes==NULL)
        return 0;

	for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
	{
		count++;
	}
	return count;
}

int JMethod::getTracedBytecodeCount()
{
	int count=0;

	JBytecodeRef *ite;    
    if (bytecodes==NULL)
        return 0;
	for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
	{
		JBytecode *jBytecode= ite->getBytecode();

		if (jBytecode->dOper != NULL)
			count++;
	}

	return count;
}

int JMethod::getExecutedBytecode()
{
	int count=0;

	JBytecodeRef *ite;    
    if (bytecodes==NULL)
        return 0;

	for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
	{        
		JBytecode *jBytecode= ite->getBytecode();        

		if (jBytecode->executed)
			count++;
	}

	return count;
}

void JMethod::dumpExecutedBytecode()
{
    printf("\t %s %s\n", methodNames->getCNameAt(nameId), sigs->getCNameAt(sigId));    

	JBytecodeRef *ite;    
    if (bytecodes==NULL)
        return;
	for(ite= bytecodes->getFirst(); ite->hasNext(); ite= ite->getNext())
	{
		JBytecode *jBytecode= ite->getBytecode();

		if (jBytecode->executed)
        {
            printf("\t \t %d, %s\n", jBytecode->getPC(), bytecodeName[jBytecode->getOperation()]);
        }
	}
}

int JMethod::isNativeMeth()
{
    return isNative;
}

const char *JMethod::getMethodName()
{
    return methodNames->getCNameAt(nameId);
}

const char *JMethod::getMethodSig()
{
    return sigs->getCNameAt(sigId);
}

int JMethod::getLineNumOfBytecode(JBytecode *bytecode)
{
    if (!lines)
        return 0;

    int pc=bytecode->getPC();
    int i;
    for(i=0; i<lineNumCount; i++)
    {
        if ( pc< lines[i].startPC)
            break;
    }
    if(i == 0)
    	return 0;
    return lines[i-1].lineNum;
}


int JMethod::getStackSize()
{
    return stackSize;
}

LineNumEntry::LineNumEntry()
{
    lineNum= startPC=-1;
}

JSREntry::JSREntry()
{
	jsrTarget=-1;
	retPC=-1;
}
