#include "index2intlist.h"
#include "slicing.h"

Index2IntList::Index2IntList()
{
	root=createNewBTreeNode(LeafNode);
}

Index2IntList::~Index2IntList()
{
	freeBTreeNode(root);
}

void Index2IntList::insertObj(unsigned int op1, unsigned int op2)
{
	PContent	newContent= createNewContent(op1, op2);
	KeyType key=  ( (0x00000000ffffffff & ((longint)op1))<<32) + op2;
	
	insertNode(&root, key, newContent);
}

int Index2IntList::size()
{
	return getBTreeSize(root);
}

void Index2IntList::dump()
{
	outputTree(root);
}

int Index2IntList::removeCount(unsigned int op1, unsigned int op2, int count)
{
	KeyType key=  ( (0x00000000ffffffff & ((longint)op1))<<32) + op2;
	return deleteNode(&root, key, NULL, count);
}

int Index2IntList::remove(unsigned int op1, unsigned int op2)
{
	KeyType key=  ( (0x00000000ffffffff & ((longint)op1))<<32) + op2;
	return deleteNode(&root, key, NULL, 0);
}

int Index2IntList::ifContain(longint key)
{
	return queryNode(root, key);
}
