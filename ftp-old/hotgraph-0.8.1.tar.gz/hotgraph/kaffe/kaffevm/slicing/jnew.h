#ifndef JNEW_H
#define JNEW_H

#include "jbytecode.h"
#include "arraylist.h"

/**
  *@author wt
  */
class JMethod;

class JNew : public JBytecode
{
private:
	const char *classObjName;
	ArrayList<int> *fields;
public:	
	JNew(JMethod *,int, int, const char*);
	ArrayList<int>* getFields();
    const char *getClassObjName();
};

#endif
