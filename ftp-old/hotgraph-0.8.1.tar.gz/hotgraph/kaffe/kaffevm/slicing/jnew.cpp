#include "jnew.h"
#include "linklist.h"
#include "jclass.h"
#include "cnamelist.h"
#include "slicing.h"

JNew::JNew(JMethod *meth, int operation, int pc, const char *className):
JBytecode(meth,operation, pc, NewObj)
{	
	this->classObjName= className;
	fields= NULL;
}

ArrayList<int>* JNew::getFields()
{    
	if (!fields)
	{
		fields= new ArrayList<int>();

        JClass* jclassObj= getJClass(classObjName);
        if (!jclassObj)
        {
            return fields;
        }
		struct Hjava_lang_Class *currentSourceClass= jclassObj->getSourceClass();

		if (currentSourceClass)
		{
			LinkList<struct Hjava_lang_Class *> *parentClasses= new LinkList<struct Hjava_lang_Class *>();
			LinkList<struct Hjava_lang_Class *> *checkedClasses= new LinkList<struct Hjava_lang_Class *>();

			parentClasses->addTail(currentSourceClass);

			while( parentClasses->size() !=0)
			{
				int i;

				currentSourceClass= parentClasses->getHeadAndRemove();
				checkedClasses->addTail(currentSourceClass);

                int fieldCount= getFieldCountInKaffe(currentSourceClass);
                int staticFieldCount= getStaticFieldCountInKaffe(currentSourceClass);
                for (i=staticFieldCount; i<fieldCount; i++)
				{
					fields->uniqueAdd( instanceFieldNames->update(getFieldNameInKaffe(currentSourceClass, i)));
				}
    
                struct Hjava_lang_Class *superSourceClass= getSuperClassInKaffe(currentSourceClass);
                if (superSourceClass)
                {
                    parentClasses->uniqueInsert(superSourceClass);
                }
                int interfaceCount=getInterfaceCountInKaffe(currentSourceClass);
                for(i=0; i<interfaceCount; i++)
                {
                    parentClasses->uniqueInsert(getAnInterfaceInKaffe(currentSourceClass,i));

                }
			}

			delete parentClasses;
			delete checkedClasses;
		}
        else
        {
            printf("error! the class of new object should have been executed\n");
        }
	}
	return fields;
}


const char* JNew::getClassObjName()
{
    return classObjName;
}

