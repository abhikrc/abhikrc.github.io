#ifndef JINVOKENONSTATIC_H
#define JINVOKENONSTATIC_H

#include "jbytecode.h"
#include "linklist.h"
#include "jmethod.h"
#include "slicing.h"
#include "callframe.h"
#include "nativeHandle.h"

class Signature;
class BytecodeList;

class JInvokeNonStatic: public JBytecode
{
	int classNameId;
	int methodNameId;
	int methodSigId;
	Signature *signature;
	LinkList<JMethod*> invokeMethod;	
    int *argsUseOperNum;
    int *argsLocalVarPos;
    int argsNum;
    int allArgsUseOperNum;
    int defOperNum;

public:
    native_called_method_list *javaMethods;//by GL //the java method transitively called
    native_called_method_list *getNextNativeCalledMethodList();
	//int reflectCall;
	int getInvokedMethodSigId();
	int getInvokedMethodNameId();
	int getInvokedClassNameId();
	char* getInvokedMethodName();
	Signature* getSig();
	int getArgsCount();
	JInvokeNonStatic(JMethod*, int, int, int, int, int, const char*);
	~JInvokeNonStatic();
	//void initReflectCalls();
	JClass* getInvokeJClass();
	void initCalls();
	void getInvokeMethodFromClass(JClass*);		
	LinkList<JMethod*>* getInvokeMethod();
	void dumpCallGraph();

  	void setnUseOperNum(int, int);
	int getnUseOperNum(int);
    void setDefOperNum(int);
	int getDefOperNum();
    int getAllArgsUseOperNum(); 
    int getnArgsLocalPos(int);
};

#endif //JInvokeNonStatic_H
