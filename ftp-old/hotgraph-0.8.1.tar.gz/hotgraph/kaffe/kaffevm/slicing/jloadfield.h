// JLoadField.h: interface for the JLoadField class.
//
//////////////////////////////////////////////////////////////////////

#ifndef JLOADFIELD_H
#define JLOADFIELD_H

#include "jbytecode.h"

class JLoadField: public JBytecode 
{
private:
	int field;
public:
    int fieldSize;
	int getField();
	JLoadField(JMethod *,int, int, int, int);//, int);
	~JLoadField();

};

#endif // !defined(AFX_JLOADFIELD_H__B8DB419D_681D_476B_B219_643BFEE3F464__INCLUDED_)
