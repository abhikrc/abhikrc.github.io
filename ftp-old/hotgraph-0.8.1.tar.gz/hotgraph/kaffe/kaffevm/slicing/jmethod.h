#ifndef JMETHOD_H
#define JMETHOD_H

#include "slicing.h"
#include "arraylist.h"
#include "basicblock.h"
#include <vector>

 
class JClass;
class JBytecode;
class JBytecodeRef;
class BasicBlock;
class BytecodeList;
class Signature;
class LineTable;
class JMethod;

struct _methods;
struct _method_trace;

class LineNumEntry
{
public:
    int lineNum;
    int startPC;
    LineNumEntry();
};

class JSREntry
{
public:
	int jsrTarget;
	std::vector<int> jsrNext;
	int retPC;
	JSREntry();
};

class JMethod
{
	int id;					// the index in the method array of the method	
	int nameId;				// use the name, do not include the signature
	int sigId;				// the signature id
    Signature *signature;	// the pased signature    
	int localCount;			// the number of local variables

	int stackSize;
	int codelen;
	int top;

	BytecodeList* popStack();
	void pushStack(JBytecode*);
	void pushStack(BytecodeList*);
	
    JClass *pClass;	   
	int basicBlockCount;
    struct _methods* sourceMethod;

	JBytecodeRef **hash;		// hash from the pc to the bytecode
	int staticInit;
	int mainMethod;

	ArrayList<char *> exceptionLables;

	int hasBuilded;
    int isNative;
    int lineNumCount;
    LineNumEntry *lines;

	int *argsLocalVarPos;
	void initLocalArgsPos();
	
public:	catch_inst *catchinst; // by GL
	int getnArgsLocalPos(int index);

	int getExecutedBytecode();
    void dumpExecutedBytecode();
	int getBytecodeCount();
	int getTracedBytecodeCount();	
	int isMainMethod();
	JBytecode* getJBytecodeAt(int pc);
	RLESe	*callInfo;		/* call information, array */
	int isStaticInit();
	int getBasicBlockCount();
	JMethod();
	void dumpSlice(FILE *);
	void dumpSliceDifference(FILE *);
	BytecodeList *bytecodes; 
	BasicBlock *basicBlocks;
	JClass* getParentClass();
	int getCodeLen();
	JBytecodeRef* getBytecodeRefAt(int);
    int getStackSize();
	
	int getLocalCount();
	void build();
	int getNameId();
	int getSigId();
	Signature* getSig();
	int init(JClass *, struct _methods *, int);
	void buildCDG();
	~JMethod();
	void buildCallGraph();
	void dumpCallGraph();
    int isNativeMeth();
    const char *getMethodName();
    const char *getMethodSig();
    int getLineNumOfBytecode(JBytecode *);

protected:
	void freeStack();
};

#endif //JMETHOD_H
