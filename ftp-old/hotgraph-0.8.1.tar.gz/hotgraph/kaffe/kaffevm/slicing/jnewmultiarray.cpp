#include "jnewmultiarray.h"
#include "slicing.h"

JNewMultiArray::JNewMultiArray(JMethod *meth, int operation, int pc, int dimension):
JBytecode(meth,operation, pc, NewMultiArray)
{
	this->dimension= dimension;
}


JNewMultiArray::~JNewMultiArray()
{
}

int JNewMultiArray::getDimension()
{
	return dimension;
}

