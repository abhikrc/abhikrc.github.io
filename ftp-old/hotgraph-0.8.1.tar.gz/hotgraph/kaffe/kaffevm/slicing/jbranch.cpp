/***************************************************************************
                          jdefinelocal.cpp  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "jbranch.h"
#include "slicing.h"
#include "bytecodelist.h"
#include "cnamelist.h"
#include "jbytecoderef.h"
#include "jmethod.h"
#include "callframe.h"

JBranch::JBranch(JMethod *meth, int operation, int pc): JBytecode(meth, operation, pc, BranchBytecode) {
	control= new BytecodeList();
}

JBranch::~JBranch(){
	delete control;
	control=NULL;
}

void JBranch::addControl(JBytecodeRef *ref)
{
	control->append(ref->getBytecode());
}

BytecodeList* JBranch::getControl()
{
	return control;

}

void JBranch::dumpType()
{
	printf("JBranch\n");
}
