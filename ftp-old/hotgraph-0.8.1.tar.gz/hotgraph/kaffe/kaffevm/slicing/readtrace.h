#ifndef READTRACE_H
#define READTRACE_H

#include "slicing.h"
#include "jmethod.h"
#include "cnamelist.h"

class ReadTrace
{
private:
/******************* for compressed trace****************/	
	int executedInstCount;
	int allocObjCount;	// the number of objects created at run time
	CNameList *tracedClassNames;    
	CNameList *classNamesInTrace, *methodNamesInTrace, *sigNamesInTrace;
    RLESe *getRLESe(RLESe*, oper_trace*);

public:
    CNameList *getClassNames();
    CNameList *getMethodNames();
    CNameList *getSigNames();
    CNameList *getTracedClassNames();
    int getTracedClassCount();
	int getAllocObjCount();
	int getExecutedInstCount();	
       
	ReadTrace();
	~ReadTrace();
	void fillTrace();
};

#endif
