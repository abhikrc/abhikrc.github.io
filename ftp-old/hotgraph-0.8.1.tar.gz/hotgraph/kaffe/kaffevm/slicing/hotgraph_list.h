#ifndef HOTGRAPH_H_
#define HOTGRAPH_H_
//#include "hotgraphcomp.h"
#include <set>
#include <vector>
#include <list>
using namespace std;

struct _method_trace;
struct _inst_trace;

typedef enum
{
	NormalNode= 0,
	SuperNode=1,
} GNodeType;

class GNode;
class GEdge;
class GRule;

class GNodeComp
{
public:
	//diff instances
	bool operator()(GNode* s1, GNode* s2);
};

class GEdgeOutgoingComp
{
public:
	bool operator()(GEdge* e1, GEdge* e2);
};

class GEdgeIncomingComp
{
public:
	bool operator()(GEdge* e1, GEdge* e2);
};

class GNode
{
public:
	list<GEdge*>* outgoing;
	list<GEdge*>* incoming;
	GNodeType nodetype;
	void *parent;//normal - inst_trace; super - grule
	GRule* containBy;
	int timestamp;
	GNode();
	GNode(GNodeType type, void* p, int t);
	bool operator==(GNode n1);
};

class GEdge
{
public:
	GNode* from;
	GNode* to;
	GEdge();
	GEdge(GNode* f, GNode* t);
};

class GRule
{
public:
	int id;
	GNode* root;
	int frequency;
	vector<GNode*>* instances;
};


extern "C" void createNode(int classid, struct _method_trace *methodTrace, int pc, int* defclsid, int* defmethid, int* defsigid, int* defpc, int defsize);
extern "C" void dumpInstHotgraph(struct _inst_trace* instTrace);
extern "C" void dumpRule();

//int getNodeID(GNode v);
//
//int getNodeTimestamp(GNode v);
//void compressRuleList(void);
//void countRuleOverhead(int * nodecount, int* edgecount);
//
//int getNodeTimestamp(GNode v);
//int countRuleSize(void);
//
extern "C" void countNodeEdge(struct _inst_trace *instTrace, int *nodecount, int *edgecount);

#endif /*HOTGRAPH_H_*/
