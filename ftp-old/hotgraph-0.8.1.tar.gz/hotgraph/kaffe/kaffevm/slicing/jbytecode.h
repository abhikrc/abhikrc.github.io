#ifndef JBYTECODE_H
#define JBYTECODE_H

#include "slicing.h"

class BytecodeList;

class JBytecode
{
//private:
//	BytecodeList *used;
protected:	
    int operation;
    int pc;    

public:
    JMethod *meth;
    int hasCheckedCriterion;
	int				executed;
	BytecodeType	type;
	int				dOperNum;		/* operands in the trace */
	RLESe			*dOper;			/* operands in the trace, dynamic operands, array */
	RLESe			*prev;			/* previous bytecode being executed, */
	RLESe			*specialValue;
	JBytecode		*prevBytecode;
    int             lineNum;
	SliceType      slice;
	int basicBlock;
	int				sliceOutputed; //used for debug: output slice difference

	void setOperation(int);
	virtual void dumpType();
	int getBasicBlockId();
	void setBasicBlock(int);
	int getPC();
	void setPC(int);
	virtual void dumpBytecode(FILE *fp=stdout);


    JBytecode(JMethod*, int, int, BytecodeType);
	int getOperation();
    static int parseOperation(char*);
    virtual ~JBytecode();
};

#endif
