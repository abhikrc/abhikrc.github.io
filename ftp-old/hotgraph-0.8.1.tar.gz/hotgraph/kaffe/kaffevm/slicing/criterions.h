#ifndef CRITERION_H
#define CRITERION_H

//#define MethodCriterion

class JBytecode;

class Criterions
{
	int count;
	int *classNameIds, *methNameIds, *pcs, *sigNameIds, *fileNameIds;
    int *isSingleOccurrence;
    
    void init();
    
#ifdef MethodCriterion
	int mcCount;
	int *mcClassNameIds, *mcMethNameIds;
	int currentMCClassId, currentMCMethodId;
	void initMethodCriterion();
	int containMethod(int, int);
#endif
public:
    int contain(int, JBytecode *);
	int contain(int, int, int, JBytecode*);
	Criterions();
	~Criterions();
#ifdef MethodCriterion	void mcPushCallFrame(int, int);
	void mcPopCallFrame(int, int);
	int inMethodCriterion();
#endif

};

extern int foreclipse;

#endif
