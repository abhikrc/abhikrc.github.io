#ifndef STATICFIELDS_H_
#define STATICFIELDS_H_

//typedef struct _fieldidentity
//{
//	//key
//	int objectid;//class id for static; object id for object field and array
//	int fieldid;//field id for static and object field; index for array
//	//value
//	int defclassid;
//	int defmethodid;
//	int defsigid;
//	int defpc;
//	struct _fieldidentity *next;
//} fieldidentity;

extern "C" void insertStaticField(int classid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc);
extern "C" void insertObjectField(int objectid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc);
extern "C" void insertArrayElement(int objectid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc);
extern "C" int getStaticFieldDefine(int classid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc);
extern "C" int getObjectFieldDefine(int objectid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc);
extern "C" int getArrayElementDefine(int objectid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc);

#endif /*STATICFIELDS_H_*/
