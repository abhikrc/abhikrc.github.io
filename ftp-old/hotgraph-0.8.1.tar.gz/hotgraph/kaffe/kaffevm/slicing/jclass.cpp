#include "slicing.h"
#include "jclass.h"
#include "jmethod.h"
#include "cnamelist.h"
#include "criterions.h"

JClass::JClass()
{
    fileNameId=-1;
	nameId= -1;
	id= -1;
	methods= NULL;
	methodCount= 0;	
	staticInit= NULL;
	checkedStaticInit= 0;
	isSystemClass=0;
	nextClass= NULL;
}

JClass::~JClass()
{
    delete []methods;
}

int JClass::init(struct _class_trace *classTrace, int id)
{ 
	this->id= id;
	if(id != classTrace->classID)
	{
		printf("error: non equal class id\n");
		exit(1);
	}
    //nameId= classTrace->classID;
	nameId= classNames->getNameId(getClassNameFromTrace(classTrace));
    sourceClass = classTrace->javaClass;
    if(sourceClass==NULL)
    	printf("error: jclass: null\n");
    char *className= classNames->getCNameAt(nameId);
	isSystemClass= ifSystemClass(className);
	const char*fileName= getFileNameInKaffe(sourceClass);

	if(fileName == NULL)
	{
		fileNameId= -1;
	}
	else
	{
    	fileNameId= fileNames->update(getFileNameInKaffe(sourceClass));
	}

    staticFieldCount= getStaticFieldCountInKaffe(sourceClass);
	staticFields= (int *)cleanMalloc(sizeof(int)*staticFieldCount);
    int i;

	for (i=0; i<staticFieldCount; i++)
	{		
		staticFields[i]= staticFieldNames->update(getFieldNameInKaffe(sourceClass, i));			
	} 
	
    int fieldCount= getFieldCountInKaffe(sourceClass);

    nonStaticFieldCount= getNonStaticFieldCountInKaffe(sourceClass);
	nonStaticFields= (int *)cleanMalloc(sizeof(int)*nonStaticFieldCount);

	for (i=0; i<nonStaticFieldCount; i++)
	{
		nonStaticFields[i]= instanceFieldNames->update(getFieldNameInKaffe(sourceClass, i+staticFieldCount));	
	}
    
    methodCount=getMethodCountInKaffe(sourceClass);
	methods= new JMethod[methodCount];

    for (i=0; i<methodCount; i++)
	{
		int needBuild=methods[i].init(this, getMethodAtInKaffe(sourceClass,i), i);
        if ( strcmp( methods[i].getMethodName(), staticInitName) ==0 )
        {
            staticInit= &(methods[i]);
        }
        if (needBuild )
            methods[i].build();
	}

	return 1;
}

int JClass::getMethodCount()
{
	return methodCount;
}

JClass* JClass::getSuperJClass()
{
	struct Hjava_lang_Class *superClass= getSuperClassInKaffe(sourceClass);
	if(superClass== NULL)
		return NULL;
	const char * superName= getClassNameInKaffe(superClass);
	int nameId= classNames->update(superName);
	int i;
	JClass *target=classes;
	while(target!=NULL)
	{
		if(target->getNameId() == nameId)
			return target;
		target= target->nextClass;
	}
	return NULL;
}

const char* JClass::getFileName()
{
	if(fileNameId == -1)
	{
		return "<nullclass>";
	}
    return fileNames->getCNameAt(fileNameId);
}

const char* JClass::getClassName()
{
    return classNames->getCNameAt(nameId);
}

int JClass::getNameId()
{
	return nameId;
}

void JClass::dumpSlice(FILE *fp)
{
	int i;

    if (!foreclipse)
    	fprintf(fp, "class: %s\n", classNames->getCNameAt(nameId));
	for (i=0; i<methodCount; i++)
	{
		methods[i].dumpSlice(fp);
	}
}

void JClass::dumpSliceDifference(FILE *fp)
{
	int i;

    if (!foreclipse)
    	fprintf(fp, "class: %s\n", classNames->getCNameAt(nameId));
	for (i=0; i<methodCount; i++)
	{
		methods[i].dumpSliceDifference(fp);
	}
}


JMethod* JClass::getMethods()
{
	return methods;
}


void JClass::buildCallGraph()
{
	int i;
	for (i=0; i<methodCount; i++)
		methods[i].buildCallGraph();
}

void JClass::dumpCallGraph()
{
	int i;

	printf("class:--------------------------%s\n", classNames->getCNameAt(nameId));

	for (i=0; i<methodCount; i++)
		methods[i].dumpCallGraph();
}


JMethod* JClass::getStaticInit()
{
	return staticInit;
}

void JClass::checkeStaticInit()
{
	checkedStaticInit= 1;
}

int JClass::hasCheckedStaticInit()
{
	return checkedStaticInit;
}

JMethod* JClass::getMethod(char *methodName, char *sigName)
{
	int i;

	for (i=0; i<methodCount; i++)
	{
		if ( strcmp(methodNames->getCNameAt(methods[i].getNameId()), methodName) ==0
			 && strcmp(sigs->getCNameAt(methods[i].getSigId()), sigName) ==0 )
			return (&methods[i]);
	}
	return NULL;
}

JMethod* JClass::getMethod(int methodNameId, int methodSigId)
{
	int i;
	for (i=0; i<methodCount; i++)
	{
		if ( methods[i].getNameId() == methodNameId 
			&& methods[i].getSigId()== methodSigId)
		{
			return &(methods[i]);
		}
	}
	return NULL;
}

int JClass::getTracedBytecodeCount()
{
	int i, count=0;

	for (i=0; i<methodCount; i++)
	{
		count+= methods[i].getTracedBytecodeCount();
	}

	return count;
}

int JClass::getBytecodeCount()
{
	int i, count=0;	

	for (i=0; i<methodCount; i++)
	{
		count+= methods[i].getBytecodeCount();
	}
	return count;
}



int JClass::getExecutedBytecode()
{
	int i, count=0;

	for (i=0; i<methodCount; i++)
	{
		count+= methods[i].getExecutedBytecode();
	}

	return count;
}

void JClass::dumpExecutedBytecode()
{
	int i;
	printf("%s\n", classNames->getCNameAt(nameId));

	for (i=0; i<methodCount; i++)
	{
		methods[i].dumpExecutedBytecode();
	}
}

int JClass::getStaticFieldCount()
{
	return staticFieldCount;
}		

int JClass::getNonStaticFieldCount()
{
	return nonStaticFieldCount;
}

int* JClass::getStaticFields()
{
	return staticFields;
}

int* JClass::getNonStaticFields()
{
	return nonStaticFields;
}

struct Hjava_lang_Class *JClass::getSourceClass()
{
    return sourceClass;
}


int JClass::getFileNameId()
{
    return fileNameId;
}

