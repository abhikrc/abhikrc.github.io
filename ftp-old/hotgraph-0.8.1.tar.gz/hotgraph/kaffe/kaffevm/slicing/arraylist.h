#ifndef ARRAYLIST_H
#define ARRAYLIST_H

#include <assert.h>
#include <string.h>

extern "C" void *cleanMalloc(unsigned int);

template <class OBJTYPE> 
class ArrayList
{
protected:
	int increased;
	int capacity;
	int count;
	OBJTYPE *list;

	void ensureCapacity();
public:
	ArrayList();
	ArrayList(int);
	~ArrayList();
	OBJTYPE getAt(int);
	void setAt(int, OBJTYPE);
	int addTail(OBJTYPE);
	int empty();
	int size();
	void removeAll();
	int find(OBJTYPE);
	int contain(OBJTYPE);
	int uniqueAdd(OBJTYPE);
};

template <class OBJTYPE>
ArrayList<OBJTYPE>::ArrayList()
{
	increased= 20;
	capacity= 10;
	count=0;
	list= (OBJTYPE*)cleanMalloc(sizeof(OBJTYPE)*capacity);
}

template <class OBJTYPE>
ArrayList<OBJTYPE>::ArrayList(int capacity)
{
	this->increased= 1;
	this->capacity= capacity;
	count=0;
	list= (OBJTYPE*)cleanMalloc(sizeof(OBJTYPE)*capacity);
	assert(capacity>=0);
	assert(increased>=0);
}


template <class OBJTYPE>
ArrayList<OBJTYPE>::~ArrayList()
{
	free(list);
	list=NULL;
}

template <class OBJTYPE>
OBJTYPE ArrayList<OBJTYPE>::getAt(int index)
{
	assert(index<count);
	return list[index];
}

template <class OBJTYPE>
int ArrayList<OBJTYPE>::addTail(OBJTYPE p)
{
	ensureCapacity();
	list[count]= p;	
	count++;
	return (count-1);
}

template <class OBJTYPE>
void ArrayList<OBJTYPE>::ensureCapacity()
{
	OBJTYPE *newlist;
	int oldcapacity;

	if (count>= capacity)
	{
		oldcapacity= capacity;
		capacity= capacity+increased;
		newlist= (OBJTYPE*)cleanMalloc(sizeof(OBJTYPE)*capacity);
		memcpy(newlist, list, sizeof(OBJTYPE)*oldcapacity);
		free(list);
		list= newlist;		
	}
}

template <class OBJTYPE>
int ArrayList<OBJTYPE>::empty()
{
	return (count==0);
}


template <class OBJTYPE>
int ArrayList<OBJTYPE>::size()
{
	return (count);
}

template <class OBJTYPE>
void ArrayList<OBJTYPE>::removeAll()
{
	memset(list, 0, sizeof(OBJTYPE)*count);
	count=0;
}

template <class OBJTYPE>
int ArrayList<OBJTYPE>:: find(OBJTYPE p)
{
	int i;
	for (i=0; i<count; i++)
		if ( list[i]== p)
			return i;

	return -1;
}

template <class OBJTYPE>
int ArrayList<OBJTYPE>:: contain(OBJTYPE p)
{
	if ( find(p) >=0)
		return 1;

	return 0;
}


template <class OBJTYPE>
int ArrayList<OBJTYPE>:: uniqueAdd(OBJTYPE p)
{
	int ret;
	ret=find(p);

	if ( ret <0)
		ret= addTail(p);
	
	return ret;
}

template <class OBJTYPE>
void ArrayList<OBJTYPE>:: setAt(int index, OBJTYPE p)
{
	list[index]=p;
}

#endif

