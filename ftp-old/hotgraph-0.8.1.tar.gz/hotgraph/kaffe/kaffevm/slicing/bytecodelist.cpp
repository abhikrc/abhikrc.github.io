/***************************************************************************
                          bytecodelist.cpp  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "bytecodelist.h"
#include "jbytecoderef.h"
#include "slicing.h"
#include "jbytecode.h"

BytecodeList::BytecodeList(){
	count=0;
    list= new JBytecodeRef(NULL);
}

BytecodeList::~BytecodeList(){
    JBytecodeRef *item;
    while(list->getNext()!= list)
    {
        item= list->getNext();
        delete item;
    }
    delete list;
	list=NULL;
}

void BytecodeList::append(BytecodeList *bytecodeList)
{
    if (bytecodeList==NULL)
        return;

    JBytecodeRef *ite= bytecodeList->list->getNext();
	int add=0;
    
    while(ite != bytecodeList->list)
    {
        if (contain(ite))
        {
            JBytecodeRef *nouse=ite;
            ite= ite->getNext();
            delete nouse;    
        }
        else
        {
			add++;
            ite= ite->getNext();
        }
    }

    if ( bytecodeList->list != bytecodeList->list->getNext())
    {
		list->getPrev()->connect(bytecodeList->list->getNext());
		bytecodeList->list->getPrev()->connect(list);
		bytecodeList->list->around();
    }
	count= count+add;
	delete bytecodeList;
}

int BytecodeList::remove(JBytecodeRef *ref){
    ref->getPrev()->connect(ref->getNext());
	return 1;
}

int BytecodeList::contain(JBytecodeRef *ref){
    JBytecodeRef *ite= list->getNext();

    while( ite != list)
    {
        if (ite->getBytecode() == ref->getBytecode())
            return 1;

        ite= ite->getNext();        
    }
    return 0;
}

void BytecodeList::append(JBytecode *bytecode){
    JBytecodeRef *ref= new JBytecodeRef(bytecode);
	
	list->getPrev()->append(ref);
	count++;
}

void BytecodeList::dumpList()
{
	JBytecodeRef *ite= list->getNext();
	
	while (ite != list)
	{
		ite->getBytecode()->dumpBytecode();
		ite= ite->getNext();
	}
	printf("\n");
}

JBytecodeRef* BytecodeList::getFirst()
{
	if (list->getNext() != list)
		return list->getNext();
	else
		return NULL;

}

int BytecodeList::getCount()
{
	return count;
}

JBytecodeRef* BytecodeList::getLast(){
    return list->getPrev();    
}

BytecodeList* BytecodeList::clone()
{
    BytecodeList *newList= new BytecodeList();
    JBytecodeRef *ite= list->getNext();
    
    while( ite != list)
    {
        newList->append(ite->getBytecode());
        ite= ite->getNext();        
    }
    return newList;                
}
