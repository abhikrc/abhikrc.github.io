#include "linenumber.h"
#include "slicing.h"
#include "linetable.h"

LineNumber::LineNumber(int length)
{
	this->length= length;
	lineTab= new LineTable[length];
}

LineNumber::~LineNumber()
{
	delete lineTab;
	lineTab=NULL;
}
