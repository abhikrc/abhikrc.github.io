/***************************************************************************
                          jloadlocal.h  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef JLOADSTATIC_H
#define JLOADSTATIC_H

#include "jbytecode.h"
#include "accessstatic.h"

class JMethod;

/**
  *@author wt
  */

class JLoadStatic : public JBytecode, public AccessStatic
{
private:
	int accessClassNameId;
    int operand;
	JMethod *staticInit;
public: 
    int fieldSize;
	JLoadStatic(JMethod *, int, int, int, int, int);
	~JLoadStatic();
    int getOperand();
	int getClassNameId(); 
	virtual JMethod *getStaticInit();
};

#endif
