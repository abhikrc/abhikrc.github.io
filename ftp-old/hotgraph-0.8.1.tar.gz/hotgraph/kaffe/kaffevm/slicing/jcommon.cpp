#include "jcommon.h"
#include "bytecodelist.h"
#include "slicing.h"

JCommon::JCommon(JMethod *meth, int operation, int pc): JBytecode(meth, operation, pc, CommonBytecode)
{
}

JCommon::~JCommon()
{
}

void JCommon::dumpType()
{
	printf("JCommon\n");
}
