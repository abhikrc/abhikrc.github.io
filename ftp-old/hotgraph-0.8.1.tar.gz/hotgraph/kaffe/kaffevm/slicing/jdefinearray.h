#ifndef JDEFINARRAY_H
#define JDEFINARRAY_H

#include "jbytecode.h"

class BytecodeList;
class JMethod;
class JDefineArray: public JBytecode
{
public:
	JDefineArray(JMethod*, int, int);//, int, int);
	~JDefineArray();

};

#endif 
