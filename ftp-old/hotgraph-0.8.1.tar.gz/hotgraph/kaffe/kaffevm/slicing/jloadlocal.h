/***************************************************************************
                          jloadlocal.h  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef JLOADLOCAL_H
#define JLOADLOCAL_H

#include "jbytecode.h"
#include "accesslocal.h"

/**
  *@author wt
  */

class JLoadLocal : public JBytecode, public AccessLocal
{
public: 
	JLoadLocal(JMethod *, int, int, int);
	~JLoadLocal();
};

#endif

