#include "callframe.h"
#include "slicing.h"
#include "jmethod.h"

CallFrame::CallFrame(JMethod *meth, CallFrame *prev, int isSlice)
{
    if (isSlice)
       	slice=IncludedSlice;
    else
        slice= NotIncludedSlice;
	currentPC= nextPC= -1;
	this->prev= prev;
	this->meth= meth;
	localCount= meth->getLocalCount();
    if (localCount>0)
    	locals= (int *)cleanMalloc(sizeof(int)*localCount);
    else
        locals=NULL;

    basicBlockIsSlice=(int *)cleanMalloc(sizeof(int)*meth->getBasicBlockCount());
    
    if (meth->getStackSize()>0)
        operStack= (int *)cleanMalloc(sizeof(int)*meth->getStackSize());
    else
        operStack= NULL;

    operStackTop= -1;
    nextPCExplicit = 0;
    //invokedByNonStaticInitNative= 0;
	//currentFrameIsFresh= 0;
	invokeList= NULL;
}

CallFrame* CallFrame::getPrev()
{
	return prev;
}

CallFrame::~CallFrame()
{
	free(locals);
    free(basicBlockIsSlice);
    free(operStack);
}

int CallFrame::hasUseLocal(int index)
{
	if (locals[index])
	{
		locals[index]=0;
		return 1;
	}
	return 0;
}

void CallFrame::useLocal(int index)
{
	locals[index]=1;
}

void CallFrame::updateOperStack(int n, int isSlice)
{
	if(operStackTop-n < -1)
	{
		printf("oper stack error, update, %d\n", executedBytecodeInstanceCount);
		exit(1);
	}

	for(int i = 0; i < n; i++)
	{
		operStack[operStackTop - i] = isSlice;
	}
}

void CallFrame::updateOperStackMiddle(int top, int bottom, int isSlice)
{
	if(operStackTop-bottom-1 < -1)
	{
		printf("oper stack error, update middle, %d\n", executedBytecodeInstanceCount);
		exit(1);
	}
	
	for(int i=top;i<=bottom;i++)
	{
		operStack[operStackTop - i] = isSlice;
	}
}

int CallFrame::popOperStack(int n)
{
    int newOperStackTop= operStackTop-n;

    if ( newOperStackTop < -1)
    {
        printf("oper stack error, %d\n", executedBytecodeInstanceCount);
        exit(1);
    }

	int result= 0;
	
    for(; operStackTop> newOperStackTop; operStackTop--)
    {
        if (operStack[operStackTop])
        {
            operStackTop= newOperStackTop;
            result= 1;
            break;
        }
    }
    

    return result;
}

void CallFrame::pushOperStack(int n, int isSlice)
{
    int newOperStackTop= operStackTop+n;
	
    if ( newOperStackTop >= meth-> getStackSize())
    {
        printf("oper stack overflow, %d\n", executedBytecodeInstanceCount);
        exit(1);
    }
    

    for(; operStackTop < newOperStackTop; operStackTop++)
    {
        operStack[operStackTop+1]=isSlice;
    }
}

int CallFrame::getOperStackTop()
{
    return operStackTop;
}

















