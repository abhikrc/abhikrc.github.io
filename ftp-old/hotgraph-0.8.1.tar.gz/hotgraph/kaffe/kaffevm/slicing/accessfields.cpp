#include <stdlib.h>
#include "accessfields.h"
#include <map>

using namespace std;

class fieldidentitykey
{
public:
	int objectid;
	int fieldid;
	fieldidentitykey(int oid, int fid)
	{
		objectid= oid;
		fieldid= fid;
	}
};

bool operator<(fieldidentitykey a, fieldidentitykey b)
{
	if(a.objectid < b.objectid)
		return 0 < 1;
	else if(a.objectid > b.objectid)
		return 0 > 1;
	else
	{
		if(a.fieldid < b.fieldid)
			return 0 < 1;
		else
			return 0 > 1;
	}
}

bool operator==(fieldidentitykey a, fieldidentitykey b)
{
	if(a.objectid == b.objectid)
	{
		if(a.fieldid == b.fieldid)
			return 0 < 1;
	}
	return 0 > 1;
}

class fieldidentityvalue
{
public:
	int defclassid;
	int defmethodid;
	int defsigid;
	int defpc;
	fieldidentityvalue(int c, int m, int s, int pc)
	{
		defclassid= c;
		defmethodid= m;
		defsigid= s;
		defpc= pc;
	}
};

//
//fieldidentity *staticFieldsList = NULL;
//fieldidentity *objectFieldsList = NULL;
//fieldidentity *arrayElementsList= NULL;

map<fieldidentitykey, fieldidentityvalue> staticFieldsList;
map<fieldidentitykey, fieldidentityvalue> objectFieldsList;
map<fieldidentitykey, fieldidentityvalue> arrayElementsList;

typedef enum _fieldType
{
	StaticField,
	ObjectField,
	ArrayElement
} FieldType;

map<fieldidentitykey, fieldidentityvalue>::iterator containField(FieldType type, int classid, int fieldid);
int getFieldDefine(FieldType type, int classid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc);
void insertField(FieldType type, int classid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc);


extern "C" void insertStaticField(int classid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc)
{
	insertField(StaticField, classid, fieldid, defclassid, defmethodid, defsigid, defpc);
}

extern "C" void insertObjectField(int objectid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc)
{
	insertField(ObjectField, objectid, fieldid, defclassid, defmethodid, defsigid, defpc);
}

extern "C" void insertArrayElement(int objectid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc)
{
	insertField(ArrayElement, objectid, fieldid, defclassid, defmethodid, defsigid, defpc);
}

void insertField(FieldType type, int classid, int fieldid, int defclassid, int defmethodid, int defsigid, int defpc)
{
	map<fieldidentitykey, fieldidentityvalue>::iterator p= containField(type, classid, fieldid);
	int hasentry= 1;
	if(type == StaticField)
	{
		if(p == staticFieldsList.end())
		{
			hasentry= 0;
			fieldidentitykey key(classid, fieldid);
			fieldidentityvalue value(defclassid, defmethodid, defsigid, defpc);
			staticFieldsList.insert(pair<fieldidentitykey, fieldidentityvalue>(key, value));
		}
	}
	else if(type == ObjectField)
	{
		if(p == objectFieldsList.end())
		{
			hasentry= 0;
			fieldidentitykey key(classid, fieldid);
			fieldidentityvalue value(defclassid, defmethodid, defsigid, defpc);
			objectFieldsList.insert(pair<fieldidentitykey, fieldidentityvalue>(key, value));
		}
	}
	else
	{
		if(p == arrayElementsList.end())
		{
			hasentry= 0;
			fieldidentitykey key(classid, fieldid);
			fieldidentityvalue value(defclassid, defmethodid, defsigid, defpc);
			arrayElementsList.insert(pair<fieldidentitykey, fieldidentityvalue>(key, value));
		}
	}

	if(hasentry)
	{
		p->second.defclassid= defclassid;
		p->second.defmethodid= defmethodid;
		p->second.defsigid= defsigid;
		p->second.defpc= defpc;
	}
	
	/*fieldidentity* curr= containField(type, classid, fieldid);
	if(curr == NULL)
	{
		fieldidentity *newfi = (fieldidentity*)cleanMalloc(sizeof(fieldidentity));
		newfi->objectid= classid;
		newfi->fieldid= fieldid;
		newfi->defclassid= defclassid;
		newfi->defmethodid= defmethodid;
		newfi->defsigid= defsigid;
		newfi->defpc= defpc;
		if(type == StaticField)
		{
			newfi->next= staticFieldsList;
			staticFieldsList= newfi;
		}
		else if(type == ObjectField)
		{
			newfi->next= objectFieldsList;
			objectFieldsList= newfi;
		}
		else
		{
			newfi->next= arrayElementsList;
			arrayElementsList= newfi;
		}
	}
	else
	{
		curr->defclassid= defclassid;
		curr->defmethodid= defmethodid;
		curr->defsigid= defsigid;
		curr->defpc= defpc;
	}*/
}



extern "C" int getStaticFieldDefine(int classid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc)
{
	return getFieldDefine(StaticField, classid, fieldid, defclassid, defmethodid, defsigid, defpc);
}

extern "C" int getObjectFieldDefine(int objectid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc)
{
	int result= getFieldDefine(ObjectField, objectid, fieldid, defclassid, defmethodid, defsigid, defpc);
	//since some object may be created internally, e.g. string
	/*if(result==0)
	{
		printf("error: cannot find object field entry %d %d\n", objectid, fieldid);
		exit(1);
	}*/
	return result;
}

extern "C" int getArrayElementDefine(int objectid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc)
{
	int result= getFieldDefine(ArrayElement, objectid, fieldid, defclassid, defmethodid, defsigid, defpc);
	//when array index out of bound
	//we cannot find define
	/*if(result==0)
	{
		printf("error: cannot find array element entry %d %d\n", objectid, fieldid);
		exit(1);
	}*/
	return result;
}

int getFieldDefine(FieldType type, int classid, int fieldid, int* defclassid, int* defmethodid, int* defsigid, int* defpc)
{
	map<fieldidentitykey, fieldidentityvalue>::iterator p=containField(type, classid, fieldid);
	int hasentry= 0;
	if(type == StaticField)
	{
		if(p != staticFieldsList.end())
		{
			hasentry= 1;
		}
	}
	else if(type == ObjectField)
	{
		if(p != objectFieldsList.end())
		{
			hasentry= 1;
		}
	}
	else
	{
		if(p != arrayElementsList.end())
		{
			hasentry= 1;
		}		
	}
	if(hasentry)
	{
		//printf("get field define: OK\n");
		*defclassid= p->second.defclassid;
		*defmethodid= p->second.defmethodid;
		*defsigid= p->second.defsigid;
		*defpc= p->second.defpc;
		return 1;
	}
	/*fieldidentity *curr= containField(type, classid, fieldid);
	if(curr!=NULL)
	{
		*defclassid= curr->defclassid;
		*defmethodid= curr->defmethodid;
		*defsigid= curr->defsigid;
		*defpc= curr->defpc;
		return 1;
	}
	//printf("error: cannot find %d field entry %d %d\n", type, classid, fieldid);
	//exit(1);
	*/	
	return 0;
}

map<fieldidentitykey, fieldidentityvalue>::iterator
containField(FieldType type, int classid, int fieldid)
{
	map<fieldidentitykey, fieldidentityvalue>::iterator p;
	//fieldidentity *curr= NULL;
	if(type == StaticField)
	{
		p= staticFieldsList.find(fieldidentitykey(classid, fieldid));
		//curr= staticFieldsList;
	}
	else if(type == ObjectField)
	{
		p= objectFieldsList.find(fieldidentitykey(classid, fieldid));
		//curr= objectFieldsList;
	}
	else
	{
		p= arrayElementsList.find(fieldidentitykey(classid, fieldid));
		//curr= arrayElementsList;
	}
//	for(; curr!=NULL; curr= curr->next)
//	{
//		if(curr->objectid == classid && curr->fieldid == fieldid)
//		{
//			return curr;
//		}
//	}
//	return NULL;
	return p;
}

