/***************************************************************************
                          jloadlocal.cpp  -  description
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by wt
    email                : wt@soccf-pls-003.ddns.comp.nus.edu.sg
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "jloadlocal.h"

JLoadLocal::JLoadLocal(JMethod *meth, int operation, int pc, int operand): 
JBytecode(meth, operation, pc, LoadLocalBytecode),
AccessLocal(operand)
{
	;
}

JLoadLocal::~JLoadLocal()
{
;
}

