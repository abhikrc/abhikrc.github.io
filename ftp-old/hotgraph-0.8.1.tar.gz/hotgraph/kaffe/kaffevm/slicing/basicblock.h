#ifndef BASICBLOCK_H
#define BASICBLOCK_H

#include "arraylist.h"
#include "jbytecode.h"
#include "linklist.h"

class JMethod;
class CallFrame;

class BasicBlock
{
public:
	int	id;
	int	startInst;		/* pc of the first instruction */
	int	endInst;		    /* pc of the last instruction */
    int controlListSize;
	int	*control;		/* at first, store control flow, then store control dependent, which basic block is control dependent on this one*/
	JMethod *meth;

	BasicBlock();
	~BasicBlock();
	void dumpCallGraph();	
};

#endif
