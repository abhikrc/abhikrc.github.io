#ifndef JCLASS_H
#define JCLASS_H

#include "arraylist.h"
class JMethod;
class Hjava_lang_Class;
struct _class_trace;

class JClass
{
private:
	
    int nameId;                // the name id in the name list
	int id;                    // the id in the class list(classes variables)
	int methodCount;           // the number of methods contained
    int fileNameId;
	
	JMethod *staticInit;
	int checkedStaticInit;

	int staticFieldCount;	
	int *staticFields;
	int nonStaticFieldCount;
	int *nonStaticFields;
	struct Hjava_lang_Class *sourceClass;

public:
    JMethod *methods;
    int isSystemClass;
    JClass *nextClass;

	int* getStaticFields();
	int* getNonStaticFields();
	int getNonStaticFieldCount();
	int getStaticFieldCount();
	int getBytecodeCount();
	int getTracedBytecodeCount();
	int	getExecutedBytecode();
    void dumpExecutedBytecode();
	
	JMethod* getMethod(char*, char*);
	int hasCheckedStaticInit();
	void checkeStaticInit();
	
	JMethod* getStaticInit();
    JMethod* getMethods();
    struct Hjava_lang_Class *getSourceClass();
	JClass* getSuperJClass();	

	void dumpSlice(FILE*);
	void dumpSliceDifference(FILE*);
	int getNameId();
	int getMethodCount();
    const char* getClassName();
	JMethod* getMethod(int, int);
    int getFileNameId();
    const char* getFileName();
	
	int init(struct _class_trace*, int);
	
    JClass();
    ~JClass();

	void buildCallGraph();
	void dumpCallGraph();
};


#endif  //JCLASS_H
