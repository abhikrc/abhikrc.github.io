#ifndef JNEWMULTIARRAY_H
#define JNEWMULTIARRAY_H

#include "jbytecode.h"

/**
  *@author wt
  */

class JNewMultiArray : public JBytecode
{
	int dimension;	
public:
	int getDimension();		
	JNewMultiArray(JMethod *,int, int, int);
	~JNewMultiArray();
};

#endif
