#include "criterions.h"
#include "slicing.h"
#include "cnamelist.h"
#include "stdio.h"
#include "jbytecode.h"

char *criterionFileName=NULL;
int bytecodeInput;
int foreclipse=0;

Criterions::Criterions()
{
	count= 0;
#ifdef MethodCriterion
	initMethodCriterion();
#else
	init();
#endif
}

void Criterions::init()
{
	FILE *fp=fopen(criterionFileName, "r");
    char line[MAXLINECHAR];
    int i;

    if (fp ==NULL)
    {
        printf("error, cannot open criterion file %s\n", criterionFileName);
        exit(1);
    }
    
    fscanf(fp, "%d\n", &count);

    if (count>0)
    {
        if (foreclipse)
        {
            fileNameIds= (int *)cleanMalloc(sizeof(int)*count);
            classNameIds=NULL;
	        methNameIds=NULL;
        	sigNameIds=NULL;
	        pcs=(int *)cleanMalloc(sizeof(int)*count);
            isSingleOccurrence=(int *)cleanMalloc(sizeof(int)*count);

            for(i=0; i<count; i++)
            {
                fscanf(fp, "%s\n", line);
            	fileNameIds[i]=fileNames->getNameId(line);
 	      
                fscanf(fp, "%d\n", &(pcs[i]));
                fscanf(fp, "%s\n", line);
                if (strcmp(line, "single")==0)
                    isSingleOccurrence[i]=1;
                else
                    if (strcmp(line, "multiple")==0)
                        isSingleOccurrence[i]=0;
                else
                    printf("error, criterion should be either single, or multiple occurrence of a line/bytecode\n");
            }
        }
        else
        {
            fileNameIds=NULL;
        	classNameIds=(int *)cleanMalloc(sizeof(int)*count);
	        methNameIds=(int *)cleanMalloc(sizeof(int)*count);
        	sigNameIds=(int *)cleanMalloc(sizeof(int)*count);
	        pcs=(int *)cleanMalloc(sizeof(int)*count);
            isSingleOccurrence=(int *)cleanMalloc(sizeof(int)*count);

            for(i=0; i<count; i++)
            {
                fscanf(fp, "%s\n", line);
                formatClassName(line);
            	classNameIds[i]=classNames->getNameId(line);
                fscanf(fp, "%s\n", line);
 	            methNameIds[i]=methodNames->getNameId(line);
                fscanf(fp, "%s\n", line);
	            sigNameIds[i]=sigs->getNameId(line);
                fscanf(fp, "%d\n", &(pcs[i]));
                fscanf(fp, "%s\n", line);
                if (strcmp(line, "single")==0)
                    isSingleOccurrence[i]=1;
                else
                    if (strcmp(line, "multiple")==0)
                        isSingleOccurrence[i]=0;
                    else
                        printf("error, criterion should be either single, or multiple occurrence of a line/bytecode\n");
            }
        }

    }
    else
    {
        classNameIds=NULL;
	    methNameIds=NULL;
    	sigNameIds=NULL;
	    pcs=NULL;        
    }
    fclose(fp);
}

#ifdef MethodCriterion
void Criterions::initMethodCriterion()
{
	//not considering method signature yet
	currentMCClassId=-1;
	currentMCMethodId=-1;
	
	//FILE *fp=fopen("_methodcriterion", "r");
	FILE *fp=fopen(criterionFileName, "r");
	
    char line1[MAXLINECHAR];
    char line2[MAXLINECHAR];
    int i;

    if (fp ==NULL)
    {
        printf("warning: no method criterion file found\n");
        return;
    }
    
    if(feof(fp))
    	return;
    
    fscanf(fp, "%d\n", &mcCount);
    
    if(mcCount>0)
    {
		mcClassNameIds=(int *)cleanMalloc(sizeof(int)*mcCount);
	    mcMethNameIds=(int *)cleanMalloc(sizeof(int)*mcCount);

        for(i=0; i<mcCount; i++)
        {
            fscanf(fp, "%s %s\n", line1, line2);
            formatClassName(line1);
          	mcClassNameIds[i]=classNames->getNameId(line1);
 	        mcMethNameIds[i]=methodNames->getNameId(line2);
            printf("mc: class %s %d, meth %s %d\n", line1, mcClassNameIds[i], line2, mcMethNameIds[i]);
        }
	}
    fclose(fp);
}

void Criterions::mcPushCallFrame(int classNameId, int methodNameId)
{
	if(currentMCClassId != -1)
		return;
	
	if(containMethod(classNameId, methodNameId))
	{
		currentMCClassId = classNameId;
		currentMCMethodId = methodNameId;
	}
}

void Criterions::mcPopCallFrame(int classNameId, int methodNameId)
{
	if(currentMCClassId == -1)
		return;
	
	if(currentMCClassId == classNameId && currentMCMethodId == methodNameId)
	{
		currentMCClassId = -1;
		currentMCMethodId = -1;
	}
}

int Criterions::inMethodCriterion()
{
	return currentMCClassId != -1;
}

int Criterions::containMethod(int classNameId, int methodNameId)
{
	int i;
	for (i=0; i<mcCount; i++)
	{        
        if(mcMethNameIds[i]== methodNameId && mcClassNameIds[i]== classNameId)
        {
            return 1;
        }		
	}

	return 0;
}
#endif

int Criterions::contain(int fileNameId, JBytecode *jBytecode)
{
    int i;
	for (i=0; i<count; i++)
	{
        if (    fileNameIds[i]== fileNameId)
        {
           if ( !isSingleOccurrence[i] ||  ! jBytecode->hasCheckedCriterion )
            {
                if (pcs[i]== jBytecode->lineNum)
                {                        
                    return 1;
                }
                
            }
        }
	}

	return 0;
}
	
int Criterions::contain(int classNameId, int methNameId, int sigNameId, JBytecode *jBytecode)
{
	int i;
	for (i=0; i<count; i++)
	{        
        if (    methNameIds[i]== methNameId
			&&	classNameIds[i]== classNameId
			&&  sigNameIds[i]== sigNameId)
        {

           if ( !isSingleOccurrence[i] ||  ! jBytecode->hasCheckedCriterion )
            {

                if (bytecodeInput)
                {
                    if (pcs[i]== jBytecode->getPC())
                    {
                        return 1;
                    }
                }
                else
                {
                    if (pcs[i]== jBytecode->lineNum)
                    {                        
                        return 1;
                    }
                }
            }
        }		
	}

	return 0;
}

Criterions::~Criterions()
{
    free(fileNameIds);
	free(classNameIds);
	free(methNameIds);
	free(sigNameIds);
	free(pcs);
    fileNameIds=NULL;
	classNameIds=NULL;
	methNameIds=NULL;
	sigNameIds=NULL;
	pcs=NULL;
}

