#ifndef BTREE_H
#define BTREE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "slicing.h"


typedef longint KeyType;

#define FANOUT	8

typedef struct
{
	unsigned int op1;
	unsigned int op2;
	unsigned int count;
}Content;

typedef enum 
{
	InternalNode=0,
	LeafNode
}BTreeNodeType;

typedef struct _BTreeNode
{
	int childCount;
	BTreeNodeType type;	// 0 for internal, 1 for leaf node
	KeyType key[FANOUT];
	void *child[FANOUT+1];

	struct _BTreeNode *parent;
}BTreeNode;

typedef Content*	PContent;

BTreeNode* createNewBTreeNode(BTreeNodeType);
void freeBTreeNode(BTreeNode *root);

void insertNode(BTreeNode**, KeyType, void*);
void insertEntry(BTreeNode**, KeyType, void*, BTreeNode*);
void simpleInsert(KeyType, void*, BTreeNode*);

void outputTree(BTreeNode*);

int deleteEntry(BTreeNode**, KeyType, void*, BTreeNode*, int);
int deleteNode(BTreeNode**, KeyType, void*, int);
int simpleDelete(KeyType, void*, BTreeNode*, int);

int getBTreeSize(BTreeNode*);
int queryNode(BTreeNode*, KeyType);

inline PContent createNewContent(unsigned int op1, unsigned int op2)
{
	PContent	newContent;
	newContent= (PContent)malloc(sizeof(Content));	
	newContent->op1= op1;
	newContent->op2= op2;
	newContent->count= 1;
	return newContent;
}

inline void freeContent(PContent pContent)
{
	free(pContent);
}

void *cleanMalloc(unsigned int);

#endif
