#include "jbytecode.h"
#include "slicing.h"
#include "bytecodelist.h"
#include "jbytecode.h"

JBytecode::JBytecode(JMethod *meth, int operation, int pc, BytecodeType type)
{
    this->meth= meth;
	this->type= type;
	this->operation= operation;
	this->pc= pc;
    slice= NotIncludedSlice;
	dOper= NULL;
	prev= NULL;
	prevBytecode= NULL;
	executed= 0;
    lineNum=0;    
    hasCheckedCriterion=0;
    sliceOutputed= 0;
}

JBytecode::~JBytecode()
{
}

int JBytecode::parseOperation(char *inst)
{
	int i;
	for (i=0; i<BYTECODENUM; i++)
	{
		if ( strcmp(inst, bytecodeName[i]) ==0 )
			return i;
	}
	return -1;
}

void JBytecode::dumpBytecode(FILE *fp)
{
	fprintf(fp, "%d: %s, ", pc, bytecodeName[operation]);
}




void JBytecode::setPC(int pc)
{
	this->pc= pc;
}

int JBytecode::getPC()
{
	return pc;
}

void JBytecode::setBasicBlock(int id)
{
	basicBlock= id;
}

int JBytecode::getBasicBlockId()
{
	return basicBlock;
}

int JBytecode::getOperation()
{
	return operation;
}

void JBytecode::dumpType()
{
	printf("JBytecode\n");
}

void JBytecode::setOperation(int operation)
{	
	this->operation= operation;
}


