#include "linetable.h"

void LineTable::init(int lineNum, int startPC)
{
	this->lineNum= lineNum;
	this->startPC= startPC;
	slice= 0;
}


int LineTable::isSlice()
{
	return slice;
}

void LineTable::setSlice()
{
	slice=1;
}

int LineTable::getLineNum()
{
	return lineNum;
}

int LineTable::getStartPC()
{
	return startPC;
}
