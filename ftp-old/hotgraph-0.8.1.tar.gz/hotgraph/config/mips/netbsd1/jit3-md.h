#include "mips/netbsd1/jit-md.h"
