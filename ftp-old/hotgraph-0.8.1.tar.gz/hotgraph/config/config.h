/* config/config.h.  Generated automatically by configure.  */
/* config/config.h.in.  Generated automatically from configure.in by autoheader 2.13.  */

/* Define if type char is unsigned and you are not using gcc.  */
#ifndef __CHAR_UNSIGNED__
/* #undef __CHAR_UNSIGNED__ */
#endif

/* Define if you have a working `mmap' system call.  */
#define HAVE_MMAP 1

/* Define if you have the strftime function.  */
#define HAVE_STRFTIME 1

/* Define if your struct tm has tm_zone.  */
#define HAVE_TM_ZONE 1

/* Define if you don't have tm_zone but do have the external array
   tzname.  */
/* #undef HAVE_TZNAME */

/* Define as __inline if that's what the C compiler calls it.  */
/* #undef inline */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define if your <sys/time.h> declares struct tm.  */
/* #undef TM_IN_SYS_TIME */

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* Define if the X Window System is missing or not being used.  */
#define X_DISPLAY_MISSING 1

/* The number of bytes in a __int64.  */
#define SIZEOF___INT64 0

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The number of bytes in a long long.  */
#define SIZEOF_LONG_LONG 8

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* The number of bytes in a void*.  */
#define SIZEOF_VOIDP 4

/* Define if you have the MD2Init function.  */
/* #undef HAVE_MD2INIT */

/* Define if you have the MD4Init function.  */
/* #undef HAVE_MD4INIT */

/* Define if you have the MD5Init function.  */
/* #undef HAVE_MD5INIT */

/* Define if you have the __get_eh_info function.  */
/* #undef HAVE___GET_EH_INFO */

/* Define if you have the __terminate_func function.  */
/* #undef HAVE___TERMINATE_FUNC */

/* Define if you have the __throw function.  */
/* #undef HAVE___THROW */

/* Define if you have the alarm function.  */
#define HAVE_ALARM 1

/* Define if you have the atexit function.  */
#define HAVE_ATEXIT 1

/* Define if you have the ceil function.  */
#define HAVE_CEIL 1

/* Define if you have the chdir function.  */
#define HAVE_CHDIR 1

/* Define if you have the drem function.  */
#define HAVE_DREM 1

/* Define if you have the execve function.  */
#define HAVE_EXECVE 1

/* Define if you have the execvp function.  */
#define HAVE_EXECVP 1

/* Define if you have the fcntl function.  */
#define HAVE_FCNTL 1

/* Define if you have the finite function.  */
#define HAVE_FINITE 1

/* Define if you have the floor function.  */
#define HAVE_FLOOR 1

/* Define if you have the fmod function.  */
#define HAVE_FMOD 1

/* Define if you have the fmodf function.  */
#define HAVE_FMODF 1

/* Define if you have the fork function.  */
#define HAVE_FORK 1

/* Define if you have the fsync function.  */
#define HAVE_FSYNC 1

/* Define if you have the ftime function.  */
#define HAVE_FTIME 1

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the getpagesize function.  */
#define HAVE_GETPAGESIZE 1

/* Define if you have the getrusage function.  */
#define HAVE_GETRUSAGE 1

/* Define if you have the getsockname function.  */
#define HAVE_GETSOCKNAME 1

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the getuid function.  */
#define HAVE_GETUID 1

/* Define if you have the getwd function.  */
#define HAVE_GETWD 1

/* Define if you have the hstrerror function.  */
#define HAVE_HSTRERROR 1

/* Define if you have the iconv function.  */
#define HAVE_ICONV 1

/* Define if you have the ioctl function.  */
#define HAVE_IOCTL 1

/* Define if you have the isinf function.  */
#define HAVE_ISINF 1

/* Define if you have the isnan function.  */
#define HAVE_ISNAN 1

/* Define if you have the kill function.  */
#define HAVE_KILL 1

/* Define if you have the localtime function.  */
#define HAVE_LOCALTIME 1

/* Define if you have the madvise function.  */
#define HAVE_MADVISE 1

/* Define if you have the mallopt function.  */
#define HAVE_MALLOPT 1

/* Define if you have the memalign function.  */
#define HAVE_MEMALIGN 1

/* Define if you have the memcpy function.  */
#define HAVE_MEMCPY 1

/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1

/* Define if you have the mergesort function.  */
/* #undef HAVE_MERGESORT */

/* Define if you have the mkdir function.  */
#define HAVE_MKDIR 1

/* Define if you have the mprotect function.  */
#define HAVE_MPROTECT 1

/* Define if you have the on_exit function.  */
#define HAVE_ON_EXIT 1

/* Define if you have the remainder function.  */
#define HAVE_REMAINDER 1

/* Define if you have the remainderf function.  */
#define HAVE_REMAINDERF 1

/* Define if you have the rint function.  */
#define HAVE_RINT 1

/* Define if you have the sbrk function.  */
#define HAVE_SBRK 1

/* Define if you have the select function.  */
#define HAVE_SELECT 1

/* Define if you have the setitimer function.  */
#define HAVE_SETITIMER 1

/* Define if you have the sigaction function.  */
#define HAVE_SIGACTION 1

/* Define if you have the sigaddset function.  */
#define HAVE_SIGADDSET 1

/* Define if you have the sigemptyset function.  */
#define HAVE_SIGEMPTYSET 1

/* Define if you have the signal function.  */
#define HAVE_SIGNAL 1

/* Define if you have the sigprocmask function.  */
#define HAVE_SIGPROCMASK 1

/* Define if you have the sigsetmask function.  */
#define HAVE_SIGSETMASK 1

/* Define if you have the snprintf function.  */
#define HAVE_SNPRINTF 1

/* Define if you have the socket function.  */
#define HAVE_SOCKET 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the strtod function.  */
#define HAVE_STRTOD 1

/* Define if you have the sync function.  */
#define HAVE_SYNC 1

/* Define if you have the time function.  */
#define HAVE_TIME 1

/* Define if you have the uname function.  */
#define HAVE_UNAME 1

/* Define if you have the valloc function.  */
#define HAVE_VALLOC 1

/* Define if you have the vsnprintf function.  */
#define HAVE_VSNPRINTF 1

/* Define if you have the waitpid function.  */
#define HAVE_WAITPID 1

/* Define if you have the <X11/extensions/XShm.h> header file.  */
/* #undef HAVE_X11_EXTENSIONS_XSHM_H */

/* Define if you have the <alloca.h> header file.  */
#define HAVE_ALLOCA_H 1

/* Define if you have the <asm/sigcontext.h> header file.  */
#define HAVE_ASM_SIGCONTEXT_H 1

/* Define if you have the <asm/signal.h> header file.  */
#define HAVE_ASM_SIGNAL_H 1

/* Define if you have the <bsd/libc.h> header file.  */
/* #undef HAVE_BSD_LIBC_H */

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 1

/* Define if you have the <dl.h> header file.  */
/* #undef HAVE_DL_H */

/* Define if you have the <dlfcn.h> header file.  */
#define HAVE_DLFCN_H 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <features.h> header file.  */
#define HAVE_FEATURES_H 1

/* Define if you have the <gmp.h> header file.  */
#define HAVE_GMP_H 1

/* Define if you have the <iconv.h> header file.  */
#define HAVE_ICONV_H 1

/* Define if you have the <jpeglib.h> header file.  */
/* #undef HAVE_JPEGLIB_H */

/* Define if you have the <kernel/OS.h> header file.  */
/* #undef HAVE_KERNEL_OS_H */

/* Define if you have the <mach-o/rld.h> header file.  */
/* #undef HAVE_MACH_O_RLD_H */

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <netdb.h> header file.  */
#define HAVE_NETDB_H 1

/* Define if you have the <netinet/in.h> header file.  */
#define HAVE_NETINET_IN_H 1

/* Define if you have the <netinet/in_systm.h> header file.  */
#define HAVE_NETINET_IN_SYSTM_H 1

/* Define if you have the <netinet/tcp.h> header file.  */
#define HAVE_NETINET_TCP_H 1

/* Define if you have the <png.h> header file.  */
/* #undef HAVE_PNG_H */

/* Define if you have the <poll.h> header file.  */
#define HAVE_POLL_H 1

/* Define if you have the <pwd.h> header file.  */
#define HAVE_PWD_H 1

/* Define if you have the <sigcontext.h> header file.  */
/* #undef HAVE_SIGCONTEXT_H */

/* Define if you have the <signal.h> header file.  */
#define HAVE_SIGNAL_H 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/filio.h> header file.  */
/* #undef HAVE_SYS_FILIO_H */

/* Define if you have the <sys/ioctl.h> header file.  */
#define HAVE_SYS_IOCTL_H 1

/* Define if you have the <sys/ipc.h> header file.  */
/* #undef HAVE_SYS_IPC_H */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/param.h> header file.  */
#define HAVE_SYS_PARAM_H 1

/* Define if you have the <sys/poll.h> header file.  */
#define HAVE_SYS_POLL_H 1

/* Define if you have the <sys/resource.h> header file.  */
#define HAVE_SYS_RESOURCE_H 1

/* Define if you have the <sys/select.h> header file.  */
#define HAVE_SYS_SELECT_H 1

/* Define if you have the <sys/shm.h> header file.  */
/* #undef HAVE_SYS_SHM_H */

/* Define if you have the <sys/socket.h> header file.  */
#define HAVE_SYS_SOCKET_H 1

/* Define if you have the <sys/stat.h> header file.  */
#define HAVE_SYS_STAT_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <sys/utsname.h> header file.  */
#define HAVE_SYS_UTSNAME_H 1

/* Define if you have the <sys/wait.h> header file.  */
#define HAVE_SYS_WAIT_H 1

/* Define if you have the <time.h> header file.  */
#define HAVE_TIME_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <utime.h> header file.  */
#define HAVE_UTIME_H 1

/* Define if you have the <winbase.h> header file.  */
/* #undef HAVE_WINBASE_H */

/* Define if you have the <windows.h> header file.  */
/* #undef HAVE_WINDOWS_H */

/* Define if you have the <winnt.h> header file.  */
/* #undef HAVE_WINNT_H */

/* Define if you have the <winsock.h> header file.  */
/* #undef HAVE_WINSOCK_H */

/* Define if you have the <wintypes.h> header file.  */
/* #undef HAVE_WINTYPES_H */

/* Define if you have the <wtypes.h> header file.  */
/* #undef HAVE_WTYPES_H */

/* Define if you have the <zlib.h> header file.  */
#define HAVE_ZLIB_H 1

/* Define if you have the Csup library (-lCsup).  */
/* #undef HAVE_LIBCSUP */

/* Define if you have the Xext library (-lXext).  */
/* #undef HAVE_LIBXEXT */

/* Define if you have the ffi library (-lffi).  */
/* #undef HAVE_LIBFFI */

/* Define if you have the gcc library (-lgcc).  */
/* #undef HAVE_LIBGCC */

/* Define if you have the gmp library (-lgmp).  */
#define HAVE_LIBGMP 1

/* Define if you have the jpeg library (-ljpeg).  */
/* #undef HAVE_LIBJPEG */

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Define if you have the md library (-lmd).  */
/* #undef HAVE_LIBMD */

/* Define if you have the mw library (-lmw).  */
/* #undef HAVE_LIBMW */

/* Define if you have the nsl library (-lnsl).  */
/* #undef HAVE_LIBNSL */

/* Define if you have the png library (-lpng).  */
/* #undef HAVE_LIBPNG */

/* Define if you have the pthread library (-lpthread).  */
/* #undef HAVE_LIBPTHREAD */

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */

/* Define if you have the ungif library (-lungif).  */
/* #undef HAVE_LIBUNGIF */

/* Define if you have the z library (-lz).  */
#define HAVE_LIBZ 1

/* Name of package */
#define PACKAGE "kaffe"

/* Version number of package */
#define VERSION "1.0.7"

/* If the vm is static or all libraries are static */
/* #undef NO_SHARED_VMLIBRARY */

/* Define to the extension used for shared libraries, say, .so.  */
#define LTDL_SHLIB_EXT ".so"

/* Define if C symbol names start with underscore */
/* #undef HAVE_UNDERSCORED_C_NAMES */

/* Kaffe version number */
#define KAFFEVERSION "1.0.7"

/* Define the version we're compiling for */
#define ARCHOS "i386-linux"

/* How are pointers aligned */
#define ALIGNMENTOF_VOIDP 4

/* Define if signal handlers must be reset upon delivery */
/* #undef KAFFE_SIGNAL_ONE_SHOT */

/* Define to int if ssize_t is not defined */
/* #undef ssize_t */

/* Do we have the right version of libungif */
/* #undef HAVE_GIF_LIB_H */

/* Do we enable stats in the vm? */
/* #undef KAFFE_STATS */

/* Enable GCJ support.  */
/* #undef HAVE_GCJ_SUPPORT */

/* Enable MIPS II instructions */
#define HAVE_MIPSII_INSTRUCTIONS 1

/* Do we have int8 */
/* #undef HAVE_INT8 */

/* Do we have uint8 */
/* #undef HAVE_UINT8 */

/* Do we have int16 */
/* #undef HAVE_INT16 */

/* Do we have uint16 */
/* #undef HAVE_UINT16 */

/* Do we have int32 */
/* #undef HAVE_INT32 */

/* Do we have uint32 */
/* #undef HAVE_UINT32 */

/* Do we have int64 */
/* #undef HAVE_INT64 */

/* Do we have uint64 */
/* #undef HAVE_UINT64 */

/* Do we have bool */
/* #undef HAVE_BOOL */

/* Do we have sigcontext */
/* #undef HAVE_STRUCT_SIGCONTEXT */

/* Do we have sigcontext_struct */
/* #undef HAVE_STRUCT_SIGCONTEXT_STRUCT */

/* Define if LONG_MIN / -1l produces an arithmetic exception */
#define LONG_DIVISION_BROKEN 1

/* Define if LONG_MIN % -1l produces an arithmetic exception */
#define LONG_MODULO_BROKEN 1

/* Define if LONG_LONG_MIN % -1ll produces an arithmetic exception */
/* #undef LONG_LONG_MODULO_BROKEN */

/* Define if strtod("-0.0") is broken */
/* #undef STRTOD_m0_BROKEN */

/* Do we have amask instruction on alpha */
/* #undef HAVE_ALPHA_ASM_AMASK */

/* Is function select declared */
#define HAVE_DECLARED_SELECT 1

/* Is function swab declared */
/* #undef HAVE_DECLARED_SWAB */

/* Define default KAFFEHOME */
#define DEFAULT_KAFFEHOME "/home/guol/hotgraph-bin//jre/lib"

