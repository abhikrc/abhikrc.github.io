package pmlParser;

import java.io.InputStream;
import pmlADT.*;
import pmlADT.AST_Program;
import pmlException.PmlParseException;

/**
 * For parsing an input stream of full Promela code into a syntax tree.
 * @author Choo Wei Chern
 */
public class SourceParser {
    private AST_Program ast;
    private TraceStepNodesTable snTable;
    private VarTable vt;
    private ProcTypeTable pt;
    private MtypeSymbolsTable mt;
    private StmtTable stmtTable;
    
    public SourceParser(InputStream codeStream){        
        snTable = new TraceStepNodesTable();
        vt = new VarTable();
        pt = new ProcTypeTable();
        mt = new MtypeSymbolsTable();
        stmtTable = new StmtTable();   
        ParserCore psCore= new ParserCore(vt, snTable, pt, mt, stmtTable);
            
        try{
            ast = psCore.fullParse(codeStream);            
        } catch (PmlParseException e){
            System.out.println("Parsing error: " + e.getMessage());
            throw new RuntimeException("Source parsing failed.\n"+e.getMessage());
        }        
    }

    public AST_Program getAST() {
        return ast;
    }
    public TraceStepNodesTable getSnTable() {
        return snTable;
    }
    public VarTable getVarTable() {
        return vt;
    }

    public ProcTypeTable getProcTypeTable() {
        return pt;
    }

    public MtypeSymbolsTable getMtypeTable() {
        return mt;
    }
    
    public StmtTable getStmtTable(){
        return stmtTable;
    }
    
}
