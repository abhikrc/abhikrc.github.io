package pmlParser;

import java.io.InputStream;
import pmlADT.*;
import pmlException.PmlParseException;

/**
 * Core parser for Promela.
 * Grammar rules based on http://www.spinroot.com/spin/Man/grammar.html.
 * Does not fully parse Never/Trace modules (these modules will be parsed into a dummy node).
 * Does not parse embedded C codes.
 * @author Choo Wei Chern
 */
public class ParserCore { 
    private PmlTokenizer ptk;
    private Integer currentScope; // -1 for global, else stores the proctype ID
    private final static int INITSCOPE = 0; // For special proctype "init"
    private final static int GLOBALSCOPE = -1;
    private final static int ALLSCOPE = -2; // For trace parsing. The all encompasing scope
    
    private VarTable vt;            // Needed externally by source parser to pass to trace parser
    private MtypeSymbolsTable mt;   // not needed externally yet.
    private TraceStepNodesTable snTable; // Used externally
    private ProcTypeTable pTable;   // Needed externally, mainly for printing purposes
    private StmtTable stmtTable;   // Used externally
    
    private final static int VARREF_IDENTIFIER = 0;
    private final static int UNREG_IDENTIFIER = 99;
     
    /**
     * Constructor.
     * The parameters can serve as the initialiser (in dynamic step parsing), as well as to serve as a form of return (in static source parsing), as they can be modified after parsing.
     * @param vt        the variable table. This table can be modified after parsing.
     * @param snTable   the traceStepNode table. This table can be modified after parsing.
     * @param pt        the processType table. This table can be modified after parsing.
     * @param mt        the mtype symbol table. This table can be modified after parsing.
     * @param stmtTable the statment table. This table can be modified after parsing.
     */
    public ParserCore(VarTable vt, TraceStepNodesTable snTable, ProcTypeTable pt, MtypeSymbolsTable mt, StmtTable stmtTable){        
        if (vt != null) { this.vt = vt; }
        else { this.vt = new VarTable(); }
        
        if (mt != null) { this.mt = mt; }
        else { mt = new MtypeSymbolsTable(); }
        
        if (pt != null) { this.pTable = pt; }
        else { pTable = new ProcTypeTable(); }
        
        if (snTable != null) { this.snTable = snTable; }
        else { this.snTable = new TraceStepNodesTable(); }
        
        if (stmtTable != null){ this.stmtTable = stmtTable; }
        else{ this.stmtTable = new StmtTable(); }
        
    }
    
    /**
     * Do a static parsing of a complete promela code.
     * @param codeStream the promela code to parse.
     * @return the head of the parsed syntax tree.
     * @throws pmlException.PmlParseException
     */
    public AST_Program fullParse(InputStream codeStream) throws PmlParseException{
        ptk = new PmlTokenizer(codeStream);
                
        AST_Program retVal = parseProgram();
        if (ptk.hasMoreTokens()){
            String msg = "Near line " + ptk.currentLineString() + ": Excess tokens";
            throw new PmlParseException(msg);
        }
        return retVal;
    }
    
    /**
     * Parse a phrase into a statement. This can be used as the starting point in for parsing a dynamic trace. The same method is being used for static source parsing.
     * @param ptk   the stream of tokens representing the phrase to be parsed.
     * @param encParent the node of enclosing structures like If/Do of the parsed statement
     * @return a node of statement.
     * @throws pmlException.PmlParseException
     */
    public AST_Stmt stmtParse(PmlTokenizer ptk, AST_Node encParent) throws PmlParseException{
        this.ptk = ptk;
        
        currentScope = ALLSCOPE;
        
        AST_Stmt retVal = null;
        try {
            retVal = parseStmt(encParent);
        } catch(PmlParseException e){
            throw e;
        }
        
        if (ptk.hasMoreTokens()){
            String msg = "Trace parsing error: Excess tokens";
            throw new PmlParseException(msg);
        }
        
        return retVal;
    }
    
    private int identifierType(String ident){
        if (currentScope.intValue() == ALLSCOPE){
            // In trace parsing
            // Search varTable without scope
            if (vt.varExists(ident)) return VARREF_IDENTIFIER;
            else return UNREG_IDENTIFIER;
        }
        
        if (getVarIndex(ident) != null) {
            return VARREF_IDENTIFIER;
        }
        
        
        
        
        return UNREG_IDENTIFIER;
    }
    private Integer getVarIndex(String varName){
        Integer retVal;
        
        if (currentScope.intValue() == ALLSCOPE){
            // In trace parsing
            // Search varTable without scope
            if (vt.varExists(varName)) return -99;
            else return null;
        }
        
        
        retVal = vt.getIndex(varName,currentScope);
        if (retVal == null){
            retVal = vt.getIndex(varName,GLOBALSCOPE);
        }
        return retVal;
    }
    
    private void addMtype(String symName) throws PmlParseException{
        if (mt.isMtypeSymbol(symName)) {
            String msg = "Near line " + ptk.currentLineString() + ": Redeclaration of mtype";
            throw new PmlParseException(msg);
        }
        mt.insertMtypeSymbol(symName);
    }
    
    private String consume() {
        return ptk.getNextToken(); // Consume next token
    }
    private void consumeSeparator() {
        while (peekMatch(";") || peekMatch("->")){
            consume();
        }
    }
    
    private String match(String toMatch) throws PmlParseException{
        if (!ptk.hasMoreTokens()){
            String msg = "Near line " + ptk.currentLineString() + ": Unexpected end of program. Expected: " + toMatch;
            throw new PmlParseException(msg);
        }
        
        String nextString = ptk.getNextToken();
        if (!(nextString.compareTo(toMatch)==0)){
            // Not match
            String msg = "Near line " + ptk.currentLineString() + ": Expected " + toMatch + " instead of " + nextString;
            throw new PmlParseException(msg);
        }
        
        return nextString;
    }
    private boolean peekMatch(String toMatch) {
        if (!ptk.hasMoreTokens()){
            return false;
        }
        
        String peekString = ptk.peekNextToken();
        if (peekString.compareTo(toMatch)==0){
            return true;
        } else return false;
    }
    private String peekAhead(int ahead){
        // Peek ahead of 0 will peek the next token
        // Peek ahead of 1 will peek the token after the first token
        // Peek ahead of n will peek the token after the nth token
        return ptk.lookAhead(ahead);
    }
    private boolean peekAheadIsTypeName(int ahead){
        // Peek ahead of 0 will peek the next token
        // Peek ahead of 1 will peek the token after the first token
        // Peek ahead of n will peek the token after the nth token
        String toPeek = peekAhead(ahead);
        if (toPeek.compareToIgnoreCase("hidden")==0 ||
            toPeek.compareToIgnoreCase("show") ==0 ||
            toPeek.compareToIgnoreCase("bit") ==0 ||
            toPeek.compareToIgnoreCase("bool")== 0 || 
            toPeek.compareToIgnoreCase("byte") == 0 ||
            toPeek.compareToIgnoreCase("short") ==0 || 
            toPeek.compareToIgnoreCase("int") ==0 ||
            toPeek.compareToIgnoreCase("mtype")==0 ||
            toPeek.compareToIgnoreCase("chan")==0){
            return true;
        }
        else {
            // TODO: Check if is utype
            if (toPeek.compareToIgnoreCase("TODO_CHECK_UTYPE")==0) return true;
        }
        return false;
    }
    private boolean peekIsTypeName(){
        // check for simple types
        if (peekMatch("hidden") || peekMatch("show") || peekMatch("bit") || peekMatch("bool") || 
                peekMatch("byte") || peekMatch("short") || peekMatch("int") || peekMatch("mtype") || peekMatch("chan")){
            return true;
        }
        else {
            // TODO: Check if is utype
            if (nextIsWord() && ptk.peekNextToken().compareToIgnoreCase("TODO_CHECK_UTYPE")==0) return true;
        }
        return false;
    }
    private boolean peekIsAndOr(){
        return (peekMatch("&&") || peekMatch("||"));
    }
    private boolean peekIsConst(){
        return (peekMatch("true") || peekMatch("false") || peekMatch("skip") ||
                nextIsNum() || mt.isMtypeSymbol(peekAhead(0)));
    }
    private boolean peekIsUnarop(){
        return (peekMatch("~") || peekMatch("-") || peekMatch("!"));
    }
    private boolean peekIsBinarop(){
        return (peekMatch("+") || peekMatch("-") || peekMatch("*") || peekMatch("/") ||
                peekMatch("%") || peekMatch("&") || peekMatch("^") || peekMatch("!") || 
                peekMatch(">") || peekMatch("<") || peekMatch(">=") || peekMatch("<=") || 
                peekMatch("==") || peekMatch("!=") || peekMatch("<<") || peekMatch(">>"));
    }
    private boolean peekIsAnyExpr_NonVarref(){
        // returns true next token matches anyExpr type but is not a varref
        return (peekMatch("(") || peekIsUnarop() || peekMatch("len") ||
                peekIsConst() || peekMatch("timeout") || peekMatch("run") );
    }
    private boolean peekIsExpr_NonVarref(){
        return (peekMatch("(") || peekIsAnyExpr_NonVarref());
    }
    
    private boolean nextIsWord(){
        return ptk.nextIsWord();
    }
    private boolean nextIsNum(){
        return ptk.nextIsNum();
    }
    private boolean nextIsPunct(){
        return ptk.nextIsPunct();        
    }
    private boolean nextIsString(){
        return ptk.nextIsString();        
    }
    
    private AST_Program parseProgram() throws PmlParseException{
        // Program specs has one or more "modules"
        AST_Program prog = new AST_Program();
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Module mod = parseModule();
        prog.addModule(mod);
        last = mod.getPhyEndLine();
        while (ptk.hasMoreTokens()){
            mod = parseModule();
            prog.addModule(mod);
            last = mod.getPhyEndLine();
        }
        prog.setLines(first, last);
        return prog;
    } 
    
    private AST_Module parseModule() throws PmlParseException{
        currentScope = GLOBALSCOPE; 
        AST_Module mod;
        
        if (peekMatch("active") || peekMatch("proctype")){
            AST_Process_ProcType procType = parseProctype();
            mod = procType;
        }
        else if (peekMatch("init")){
            AST_Process_Init init = parseInit();
            mod = init;
        }
        else if (peekMatch("never") || peekMatch("trace")){
            System.out.println("Note: Current version ignores never and trace modules");
            int first = ptk.currentLineNo();
            int last = -1;
            
            consume(); // Consume never / trace;
            match("{");
            int bracket = 1;
            while (bracket != 0){
                last = ptk.currentLineNo();
                String tmp = consume();
                if (tmp.compareTo("{")==0) bracket++;
                else if (tmp.compareTo("}")==0) bracket--;
            }
            mod = new AST_Module_Dummy();
            mod.setLines(first, last);
        }
        else if (peekMatch("typedef")){
            AST_Module_Utype utype = parseUtype();
            mod = utype;
        }
        else if (peekMatch("mtype")){
            AST_Module_Mtype mtype = parseMtype();
            mod = mtype;
        }
        else if (peekIsTypeName()){
            AST_Module_GlobalDecl globalDec = parseGlobDecl();
            mod = globalDec;
            if (peekMatch(";")||peekMatch("->")){
                consumeSeparator();
            }
        } 
        else {
            String msg = "Near line " + ptk.currentLineString() + ": Unrecognised word " + ptk.peekNextToken() + " found. ";
            throw new PmlParseException(msg);
        }
        return mod;
    }
    private AST_Process_ProcType parseProctype() throws PmlParseException{
        // Assign ID to proctype
        // Set scope to ID
        // Parse declaration in the parameter
        // Parse sequence
        AST_Process_ProcType procType = new AST_Process_ProcType();
        
        int first,last;
        first = ptk.currentLineNo();
        
        if (peekMatch("active")){
            match("active");
            if (peekMatch("[")){
                match("[");
                if (peekIsConst()){
                    AST_Const cons = parseConstant();
                    procType.setInitialActive(cons.getIntValue());
                }
                else {
                    String msg = "Near line " + ptk.currentLineString() + ": Expected constant";
                    throw new PmlParseException(msg);
                } // Match compulsory constant in bracket
                match("]"); // Match compulsory closing bracket
            } // Match optional brackets
        } // Match optional ACTIVE
        
        match("proctype"); //Match compulsary keyword
        
        if (nextIsWord()){
            String procName = ptk.getNextToken();
            procType.setProcName(procName);
            
            int procId = pTable.addProc(procType);
            currentScope = procId;
        } 
        else {
            String msg = "Near line " + ptk.currentLineString() + ": Expected proctype name";
            throw new PmlParseException(msg);
        }
        
        match("(");
        
        if (peekIsTypeName()){
            AST_DeclList dlList = parseDeclarationList();
            procType.setDeclList(dlList);
        } // Match optional declaration list
        
        match(")");
        
        if (peekMatch("priority")){
            match("priority");
            if (peekIsConst()){
                AST_Const cons = parseConstant(); // Remove the constant
                procType.setPriority(cons.getIntValue());
            }
            else {
                String msg = "Near line " + ptk.currentLineString() + ": Expected constant";
                throw new PmlParseException(msg);
            } // Match compulsory constant
        } // Match optional priority
        
        if (peekMatch("provided")){
            match("provided");
            match("(");
            AST_Expr expr = parseExpr(null);
            procType.setEnablingExpr(expr);
            match(")");
        } // Match optional enabler
        
        match("{");
        AST_Sequence seq = parseSequence(procType,false);
        procType.setSequence(seq);
        
        last = ptk.currentLineNo();
        match("}");
        
        procType.setLines(first, last);
        return procType;
    }
    private AST_Process_Init parseInit() throws PmlParseException{
        currentScope = INITSCOPE;
        
        AST_Process_Init procInit = new AST_Process_Init();
        int first,last;
        first = ptk.currentLineNo();

        match("init");
        
        if(peekMatch("priority")){
            match("priority");
            if (peekIsConst()){
                AST_Const cons = parseConstant(); // Remove the constant
                procInit.setPriority(cons.getIntValue());
            }
            else {
                String msg = "Near line " + ptk.currentLineString() + ": Expected constant";
                throw new PmlParseException(msg);
            } // Match compulsory constant
        } // Match optional priority
        
        match("{");
        AST_Sequence seq = parseSequence(procInit,false);
        procInit.setSequence(seq);
        
        last = ptk.currentLineNo();
        match("}");
        
        procInit.setLines(first, last);
        
        pTable.setInit(procInit);
        return procInit;
    }
    private AST_Module_GlobalDecl parseGlobDecl() throws PmlParseException{
        AST_Module_GlobalDecl globalDec = new AST_Module_GlobalDecl();
        int first,last;
        first = ptk.currentLineNo();
        
        AST_DeclList dlList = parseDeclarationList();
        globalDec.setGlobalDeclList(dlList);

        last = dlList.getPhyEndLine();
        globalDec.setLines(first, last);
        return globalDec;
    }
    private AST_Module_Utype parseUtype() throws PmlParseException{
        AST_Module_Utype retObj = new AST_Module_Utype();
        int first,last;
        first = ptk.currentLineNo();
        
        match("typedef");
        match("{");
        AST_DeclList dlList = parseDeclarationList();
        retObj.setMemberDeclList(dlList);
        
        last = ptk.currentLineNo();
        match("}");
        
        retObj.setLines(first, last);
        return retObj;
    }
    private AST_Module_Mtype parseMtype() throws PmlParseException{
        AST_Module_Mtype retObj = new AST_Module_Mtype();
        int first,last;
        first = ptk.currentLineNo();
          
        match("mtype");
        if (peekMatch("=")) match("="); // Consume optional = sign
        match("{");
        String symName = consume();
        addMtype(symName);
        retObj.addSymbolicName(symName);
        
        while(peekMatch(",")){
            match(",");
            symName = consume();
            addMtype(symName);
            retObj.addSymbolicName(symName);
        }
        
        last = ptk.currentLineNo();
        match("}");
        
        if (peekMatch(";")) consume(); // Optional ";"
        
        retObj.setLines(first, last);
        return retObj;
    }    
    
    private AST_DeclList parseDeclarationList() throws PmlParseException{
        AST_DeclList dlList = new AST_DeclList();
        int first,last;
        first = ptk.currentLineNo();
        last = first;
        AST_Decl dl;
        
        //Add compulsory declaration
        dl = parseDeclarationUnit();
        dlList.addDecl(dl);
        last = dl.getPhyEndLine();
        
        while ((peekMatch(";") || peekMatch("->"))){
            if (peekAheadIsTypeName(1) && peekAhead(1).compareToIgnoreCase("mtype")!=0){
                // If following is still a "normal" declaration (not mtype), then continue
                consumeSeparator();
                dl = parseDeclarationUnit();
                dlList.addDecl(dl);
                last = dl.getPhyEndLine();
            }
            else{
                break;
            }
        }
        
        dlList.setLines(first, last);
        return dlList;
    }
    private AST_Decl parseDeclarationUnit() throws PmlParseException{
        AST_Decl dl = new AST_Decl();
        int first,last;
        first = ptk.currentLineNo();

        if (peekMatch("hidden") || peekMatch("show")){
            consume();
        } // Match optional "visible"

        // TODO: Parse utype
        if (peekMatch("bit") || peekMatch("bool") || peekMatch("byte") || peekMatch("short") 
            || peekMatch("int") || peekMatch("mtype") || peekMatch("chan")){
           String type = consume(); 
           dl.setVarType(type);
        } 
        else{
            String msg = "Near line " + ptk.currentLineString() + ": Expected variable typename";
            throw new PmlParseException(msg);
        } // Match compulsory typename
        
        AST_IVar iv = parseDeclarationIndividualVar();
        dl.addIVar(iv);
        last = iv.getPhyEndLine();
        while (peekMatch(",")){
            match(","); 
            iv = parseDeclarationIndividualVar();
            dl.addIVar(iv);
            last = iv.getPhyEndLine();
        }
        dl.setLines(first, last);
        return dl;
    }
    private AST_IVar parseDeclarationIndividualVar() throws PmlParseException{
        AST_IVar iv = new AST_IVar();
        int first,last;
        first = ptk.currentLineNo();
        
        if (nextIsWord()){
            last = ptk.currentLineNo();
            String varName = consume();
            vt.insertVar(varName,currentScope);
            
            iv.setVarName(varName);
        } 
        else {
            String msg = "Near line " + ptk.currentLineString() + ": Expected variable name";
            throw new PmlParseException(msg);
        }// Match compulsory variable name
        
        // identify separate array elements
        if (peekMatch("[")){
            match("[");
            if (peekIsConst()){
                AST_Const cons = parseConstant(); // Remove the constant
                iv.setSize(cons);
            }
            else {
                String msg = "Near line " + ptk.currentLineString() + ": Expected constant";
                throw new PmlParseException(msg);
            } // Match compulsory constant in bracket
            last = ptk.currentLineNo();
            match("]"); // Match compulsory closing bracket
        }
    
        if (peekMatch("=")){
            // parse-->   = any_expr | = ch_init
            match("=");
            if (peekMatch("[")){
                AST_ChInit cInit = parseChInit();
                iv.setInitChan(cInit);
                last = cInit.getPhyEndLine();
            }
            else {
                AST_Expr_AnyExpr anyExpr =  parseAnyExpr(null);
                iv.setInitExpr(anyExpr);
                last = anyExpr.getPhyEndLine();
            }
        }   
        iv.setLines(first, last);
        return iv;
    }
    
    private AST_Sequence parseSequence(AST_Node encParent, boolean hasGuard) throws PmlParseException{
        // sequence: step [ ';' step ] *
        AST_Sequence seq = new AST_Sequence();
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Step step = parseStep(encParent); // Compulsory step
        seq.addStep(step);
        step.setIsGuard(hasGuard); //First step in sequence may be a guard 
        
        // Do follows relation
        AST_Step.linkFollows(null, step);
        AST_Step prevStep = step;
        
        last = step.getPhyEndLine();
        while( peekMatch(";") || peekMatch("->") ){
            consumeSeparator();
            step = parseStep(encParent);
            
            // Do follows relation
            AST_Step.linkFollows(prevStep, step);
            prevStep = step;
            
            seq.addStep(step);
            last = step.getPhyEndLine();            
        }
        // Do follows relation
        AST_Step.linkFollows(step, null);
        
        seq.setLines(first, last);
        return seq;
    }
    private AST_Step parseStep(AST_Node encParent) throws PmlParseException{
       /*
        step    : stmnt	[ UNLESS stmnt ]
	| decl_lst
	| XR varref [',' varref ] *         (has no effect on simulation runs)
	| XS varref [',' varref ] *         (has no effect on simulation runs)
        */
        AST_Step retStep;
        int first,last;
        first = ptk.currentLineNo();
        
        if (peekMatch("xr")){
            AST_Step_XR xrStep = new AST_Step_XR();
                
            match("xr");
            AST_VarRef varRef= parseVarRef();
            xrStep.addVarRef(varRef);
            last = varRef.getPhyEndLine();
            while (peekMatch(",")){
                match(",");
                varRef = parseVarRef();
            
                last = varRef.getPhyEndLine();
                xrStep.addVarRef(varRef);
            }
            
            retStep = xrStep;
        }
        else if (peekMatch("xs")){
            AST_Step_XS xsStep = new AST_Step_XS();
            
            match("xs");
            AST_VarRef varRef= parseVarRef();
            xsStep.addVarRef(varRef);
            last = varRef.getPhyEndLine();
            while (peekMatch(",")){
                match(",");
                varRef = parseVarRef();
                
                last = varRef.getPhyEndLine();
                xsStep.addVarRef(varRef);
            }
            
            retStep = xsStep;
        }
        else if ( peekIsTypeName() ){
            AST_Step_DeclList dlStep = new AST_Step_DeclList();
            AST_DeclList dl= parseDeclarationList();
            dlStep.setDeclList(dl);
            last = dl.getPhyEndLine();
            retStep = dlStep;
        }
        else {
            AST_Step_Stmt stmtStep = new AST_Step_Stmt();
            AST_Stmt firststmt = parseStmt(encParent);
            last = firststmt.getPhyEndLine();
            
            stmtStep.setMainStmt(firststmt);
            
            if (peekMatch("unless")){
                AST_Stmt unStmt = parseStmt(encParent);
                stmtStep.setUnlessStmt(unStmt);
                last = unStmt.getPhyEndLine();
            }
            
            retStep = stmtStep;
        }
        
        retStep.setLines(first, last);
        return retStep;
    }
    private AST_Stmt parseStmt(AST_Node encParent) throws PmlParseException{
        /*
            stmnt	: IF options FI		// selection 
                    | DO options OD		// iteration 
                    | ATOMIC '{' sequence '}'	// atomic sequence 
                    | D_STEP '{' sequence '}'	// deterministic atomic 
                    | '{' sequence '}'	// normal sequence 
                    | send
                    | receive
                    | assign
                    | ELSE			// used inside options 
                    | BREAK			// used inside iterations 
                    | GOTO name
                    | name ':' stmnt	// labeled statement 
                    | PRINTF '(' string [ ',' arg_lst ] ')'
                    | PRINTM '(' expr ')'
                    | ASSERT expr    
                    | expr			// condition 
            c       | c_code '{' ... '}'	// not interpreted
            c       | c_expr '{' ... '}'
            c       | c_decl '{' ... '}'
            c       | c_track '{' ... '}'
            c       | c_state '{' ... '}'
            
        */
        AST_Stmt retStmt;
        
        if (peekMatch("if")){
            AST_Stmt_If ifStmt = parseIf(encParent); 
            retStmt = ifStmt;
        }
        else if (peekMatch("do")){
            AST_Stmt_Do doStmt = parseDo(encParent); 
            retStmt = doStmt; 
        }
        else if (peekMatch("atomic")){ 
            AST_Stmt_Atomic atomStmt = parseAtomic(encParent); 
            retStmt = atomStmt;
        }
        else if (peekMatch("d_step")){ 
            AST_Stmt_DStep dstepStmt = parseD_Step(encParent); 
            retStmt = dstepStmt;
        }
        else if (peekMatch("{")){
            AST_Stmt_Bracket brackStmt = parseBrackStmt(encParent);
            retStmt = brackStmt;
        }
        else if (peekMatch("else")){
            AST_Stmt_Else elseStmt = parseElse(encParent); 
            retStmt = elseStmt;
        }
        else if (peekMatch("break")){
            AST_Stmt_Break brkStmt = parseBreak(encParent); 
            retStmt = brkStmt;
        }
        else if (peekMatch("goto")){
            AST_Stmt_Goto gotoStmt = parseGoto(encParent); 
            retStmt = gotoStmt;
        }
        else if (peekMatch("printf")){ 
            AST_Stmt_Printf prnStmt = parsePrintf(encParent); 
            retStmt = prnStmt;
        }
        else if (peekMatch("printm")){ 
            AST_Stmt_Printm prnStmt = parsePrintm(encParent); 
            retStmt = prnStmt;
        }
        else if (peekMatch("assert")){ 
            AST_Stmt_Assert assertStmt = parseAssert(encParent); 
            retStmt = assertStmt;
        }
        else if (peekMatch("c_code") || peekMatch("c_expr") || peekMatch("c_decl") || 
                 peekMatch("c_track") || peekMatch("c_state") ){
            // /* embedded C code */
            String msg = "Near line " + ptk.currentLineString() + ": Embedded C code not supported.";
            throw new PmlParseException(msg);
        }
        else if (peekIsExpr_NonVarref()){
            //  | expr --- Not starting with a varref
            AST_Stmt_Expr exprStmt = parseExprStmt(null,encParent);
            retStmt = exprStmt;
        }
        else {
            //	| send
            //	| receive
            //  | assign
            //  | expr --- starting with a varref
            //  | name ':' stmnt	// labeled statement 
            String nextToken = peekAhead(0);
            
            if (identifierType(nextToken) == VARREF_IDENTIFIER){
                // Send, receive, assign or expr
                AST_VarRef preread = parseVarRef();
                
                if (peekMatch("!") || peekMatch("!!")){ 
                    AST_Stmt_Send sendStmt = parseSend(preread,encParent);
                    retStmt = sendStmt;
                }
                else if (peekMatch("?") || peekMatch("??")){
                    AST_Stmt_Receive recStmt = parseReceive(preread,encParent); 
                    retStmt = recStmt;
                }
                else if (peekMatch("=") || peekMatch("++") || peekMatch("--")){ 
                    AST_Stmt_Assign assignStmt = parseAssign(preread,encParent);                 
                    retStmt = assignStmt;
                }
                else {
                    AST_Stmt_Expr exprStmt = parseExprStmt(preread,encParent);
                    retStmt = exprStmt;
                }
            }
            else if (nextIsWord() && peekAhead(1).compareToIgnoreCase(":")==0){
                AST_Stmt_LabeledStmt lbStmt = parseLabeledStmt(encParent);
                retStmt = lbStmt;
            }
            else {
                String msg = "Near line " + ptk.currentLineString() + ": Unrecognised identifier near " + nextToken;
                throw new PmlParseException(msg);
            }
        }
        return retStmt;
    }
    
    private AST_Stmt_If parseIf(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_If ifStmt = new AST_Stmt_If(stmtTable, first, encParent);

        match("if");
        AST_Options opt = parseOptions(ifStmt, true); //changed
        ifStmt.setOptions(opt);
        
        last = ptk.currentLineNo();
        match("fi");

        ifStmt.setLines(first, last);
        return ifStmt;
    }
    private AST_Stmt_Do parseDo(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_Do doStmt = new AST_Stmt_Do(stmtTable, first, encParent);
        
        match("do");
        AST_Options opt = parseOptions(doStmt, true); //changed
        doStmt.setOptions(opt);
        last = ptk.currentLineNo();
        match("od");
        
        doStmt.setLines(first, last);
        return doStmt;
    }
    private AST_Stmt_Atomic parseAtomic(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_Atomic aStmt = new AST_Stmt_Atomic(stmtTable, first, encParent);
      
        match("atomic");
        match("{");
        AST_Sequence seq = new AST_Sequence();
        seq = parseSequence(aStmt, true);
        aStmt.setAtomicSequence(seq);
        
        last = ptk.currentLineNo();
        match("}");

        aStmt.setLines(first, last);
        return aStmt;
    }
    private AST_Stmt_DStep parseD_Step(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_DStep dStmt = new AST_Stmt_DStep(stmtTable, first, encParent);

        match("d_step");
        match("{");
        AST_Sequence seq = parseSequence(dStmt,true);
        dStmt.setDStepSequence(seq);
        
        last = ptk.currentLineNo();
        match("}");
        
        dStmt.setLines(first, last);
        return dStmt;
    }
    private AST_Stmt_Else parseElse(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        last = first;
        match("else");
        AST_Stmt_Else ret = new AST_Stmt_Else(snTable, stmtTable, first, encParent);
        ret.setLines(first, last);
        return ret;
    }
    private AST_Stmt_Break parseBreak(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        last = first;
        match("break");
        AST_Stmt_Break ret = new AST_Stmt_Break(snTable, stmtTable, first, encParent);
        ret.setLines(first, last);
        return ret;
    }
    private AST_Stmt_Goto parseGoto(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();  
             
        match("goto");
        last = ptk.currentLineNo();
        String gotoName = consume();
        AST_Stmt_Goto gtStmt = new AST_Stmt_Goto(snTable, stmtTable, first, encParent);   
        gtStmt.setGotoLabel(gotoName);
        
        gtStmt.setLines(first, last);
        return gtStmt;
    }
    private AST_Stmt_Printf parsePrintf(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_Printf prnStmt = new AST_Stmt_Printf(snTable, stmtTable, first, encParent);
        
        match("(");
        
        String strContent = consume();
        prnStmt.setPrintString(strContent);
        
        if (peekMatch(",")){
            match(",");
            AST_ArgList argList = parseArgList(null);
            prnStmt.setPrintArgList(argList);
        }
        last = ptk.currentLineNo();
        match(")");
        
        prnStmt.setLines(first, last);
        return prnStmt;
    }
    private AST_Stmt_Printm parsePrintm(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_Printm prnStmt = new AST_Stmt_Printm(snTable, stmtTable, first, encParent);
        
        match("(");
        AST_Expr printExpr = parseExpr(null);
        prnStmt.setPrintExpr(printExpr);
        
        last = ptk.currentLineNo();
        match(")");
        
        prnStmt.setLines(first, last);
        return prnStmt;
    }
    private AST_Stmt_Assert parseAssert(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_Assert assertStmt = new AST_Stmt_Assert(snTable, stmtTable, first, encParent);
        
        match("assert");
        AST_Expr expr = parseExpr(null);
        assertStmt.setAssertExpr(expr);
        
        last = expr.getPhyEndLine();
        assertStmt.setLines(first, last);
        return assertStmt;
    }
    private AST_Stmt_Send parseSend(AST_VarRef preread, AST_Node encParent) throws PmlParseException{
        int first,last;
        if (preread!=null) {
            first = preread.getPhyStartLine();
            last = preread.getPhyEndLine();
        }
        else{
            first = ptk.currentLineNo();
        }

        AST_Stmt_Send sendStmt = new AST_Stmt_Send(snTable, stmtTable, first, encParent);
        
        AST_VarRef varRef;
        if (preread == null) { varRef = parseVarRef(); }
        else { varRef = preread; }
        
        sendStmt.setChannel(varRef);
        
        if (peekMatch("!")){
            // Normal FIFO send
            match("!");
            sendStmt.setSendType(AST_Stmt_Send.FIFO_SEND);
            AST_SendArgs sendArgs = parseSendArgList();
            last = sendArgs.getPhyEndLine();
            sendStmt.setSendArgs(sendArgs);
        }
        else {
            match("!!");
            sendStmt.setSendType(AST_Stmt_Send.SORTED_SEND);
            AST_SendArgs sendArgs = parseSendArgList();
            last = sendArgs.getPhyEndLine();
            sendStmt.setSendArgs(sendArgs);
        }
        
        sendStmt.setLines(first, last);
        return sendStmt;
    }
    private AST_Stmt_Receive parseReceive(AST_VarRef preread, AST_Node encParent) throws PmlParseException{
        // receive  : varref '?' recv_args		-- normal receive 
	//          | varref '?' '?' recv_args          -- random receive 
	//          | varref '?' '<' recv_args '>'	-- received msg not removed
	//          | varref '?' '?' '<' recv_args '>'	-- received msg not removed 

        int first,last;
        if (preread!=null) {
            first = preread.getPhyStartLine();
            last = preread.getPhyEndLine();
        }
        else{
            first = ptk.currentLineNo();
            
        }
        
        AST_Stmt_Receive recvStmt = new AST_Stmt_Receive(snTable, stmtTable, first, encParent);
        
        AST_VarRef varRef;
        if (preread == null) { varRef = parseVarRef(); }
        else { varRef = preread; }
        
        recvStmt.setChannel(varRef);
        
        if (peekMatch("?")){
            // receive only if first msg match
            match("?");
            
            if (peekMatch("<")){
                recvStmt.setRecvType(AST_Stmt_Receive.IN_ORDER_NOREMOVE);
                match("<");
                AST_RecvArgList recvArgs = parseRecvArgList();
                recvStmt.setRecvArgs(recvArgs);
                
                last = ptk.currentLineNo();
                match(">");
            }
            else{
                recvStmt.setRecvType(AST_Stmt_Receive.IN_ORDER_REMOVE);
                AST_RecvArgList recvArgs = parseRecvArgList();
                
                last = recvArgs.getPhyEndLine();
                recvStmt.setRecvArgs(recvArgs);
            }
        }
        else{
            match("??");
            if (peekMatch("<")){
                recvStmt.setRecvType(AST_Stmt_Receive.ANY_ORDER_NOREMOVE);
                match("<");
                AST_RecvArgList recvArgs = parseRecvArgList();
                recvStmt.setRecvArgs(recvArgs);

                last = ptk.currentLineNo();
                match(">");
            }
            else{
                recvStmt.setRecvType(AST_Stmt_Receive.ANY_ORDER_REMOVE);
                AST_RecvArgList recvArgs = parseRecvArgList();
                
                last = recvArgs.getPhyEndLine();
                recvStmt.setRecvArgs(recvArgs);
            }
        }
        
        recvStmt.setLines(first, last);
        return recvStmt;
    }
    private AST_Stmt_Assign parseAssign(AST_VarRef preread, AST_Node encParent) throws PmlParseException{
        AST_VarRef assignVar;
        AST_Stmt_Assign assignStmt;
        int first,last;
        if (preread!=null) {
            first = preread.getPhyStartLine();
            last = preread.getPhyEndLine();
        }
        else{
            first = ptk.currentLineNo();
        }
        
        if (preread == null) { assignVar = parseVarRef(); }
        else { assignVar = preread; }
        
        if (peekMatch("=")){
            match("=");
            AST_Expr_AnyExpr anyExpr = parseAnyExpr(null);
            
            AST_Assign_Standard stdAssign = new AST_Assign_Standard(snTable, stmtTable, first, encParent);
            stdAssign.setLhs(assignVar);
            stdAssign.setRhs(anyExpr);
            
            last = anyExpr.getPhyEndLine();
            assignStmt = stdAssign;
        }
        else if (peekMatch("++")){
            last = ptk.currentLineNo();
            match("++");
            AST_Assign_Incr incrAssign = new AST_Assign_Incr(snTable, stmtTable, first, encParent);
            incrAssign.setVar(assignVar);
           
            assignStmt = incrAssign;
        }
        else {
            last = ptk.currentLineNo();
            match("--");
            AST_Assign_Decr decrAssign = new AST_Assign_Decr(snTable, stmtTable, first, encParent);
            decrAssign.setVar(assignVar);
                
            assignStmt = decrAssign;
        }
        
        assignStmt.setLines(first, last);
        return assignStmt;
    }
    private AST_Stmt_LabeledStmt parseLabeledStmt(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_LabeledStmt lbStmt = new AST_Stmt_LabeledStmt(stmtTable, first, encParent);
        
        String label = consume();
        lbStmt.setLabel(label);
        match(":");
        AST_Stmt actualStmt = parseStmt(lbStmt);
        lbStmt.setActualStmt(actualStmt);
        
        last = actualStmt.getPhyEndLine();
        lbStmt.setLines(first, last);
        return lbStmt;
    }
    private AST_Stmt_Expr parseExprStmt(AST_VarRef preread, AST_Node encParent) throws PmlParseException{
        int first,last;  
        AST_Expr expr = parseExpr(preread);
                
        first = expr.getPhyStartLine();
        last = expr.getPhyEndLine();

        AST_Stmt_Expr exprStmt = new AST_Stmt_Expr(snTable, stmtTable, first, encParent);
        exprStmt.setExpr(expr);
        
        exprStmt.setLines(first, last);
        return exprStmt;
    }
    private AST_Stmt_Bracket parseBrackStmt(AST_Node encParent) throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Stmt_Bracket brackStmt = new AST_Stmt_Bracket(stmtTable, first, encParent);

        match("{");
        AST_Sequence seq = parseSequence(brackStmt,false);
        brackStmt.setContentSequence(seq);
        
        last = ptk.currentLineNo();
        match("}");         
       
        brackStmt.setLines(first, last);
        return brackStmt;
    }
    
    private AST_Options parseOptions(AST_Node encParent, boolean hasGuard) throws PmlParseException{
        AST_Options opt = new AST_Options();
        int first,last;
        first = ptk.currentLineNo();
        
        match("::");
        AST_Sequence tmpSeq; 
        tmpSeq = parseSequence(encParent, hasGuard);
        opt.addOption(tmpSeq);
        last = tmpSeq.getPhyEndLine();
        while (peekMatch("::")){
            match("::");
            tmpSeq = parseSequence(encParent, hasGuard);
            opt.addOption(tmpSeq);
            last = tmpSeq.getPhyEndLine();
        }
        
        opt.setLines(first, last);
        return opt;
    }
    
    private AST_Expr parseExpr(AST_VarRef preread) throws PmlParseException{
        /*  Expr is a superset of any_expr 
        expr	: any_expr
                | '(' expr ')'
                | expr andor expr
                | chanpoll '(' varref ')'	--may not be negated
         */
        AST_Expr exprObj;
        int first,last;
        if (preread!=null) {
            first = preread.getPhyStartLine();
            last = preread.getPhyEndLine();
        }
        else{
            first = ptk.currentLineNo();
        }
        
        if (preread != null){
            // A varref has already been consumed before this method is called.
            // Continue parsing from the varref
            // Only possibility of expr which starts with varref is in any_expr
            AST_Expr_AnyExpr tmpAnyExpr = parseAnyExpr(preread);
            last = tmpAnyExpr.getPhyEndLine();
            exprObj = tmpAnyExpr;
        }
        else if (peekMatch("(")){
            //   '(' expr ')'
            AST_Expr_Bracket brackExpr = new AST_Expr_Bracket();
            match("(");
            
            AST_Expr contentExpr = parseExpr(null);
            brackExpr.setContentExpr(contentExpr);

            last = ptk.currentLineNo();
            match(")");
            
            exprObj = contentExpr;
        }
        else if (peekMatch("full") || peekMatch("empty") || peekMatch("nfull") || peekMatch("nempty") ){
            //    chanpoll '(' varref ')'
            AST_Expr_Chanpoll exprCh = new AST_Expr_Chanpoll();
            
            String pollType = consume();
            exprCh.setPollType(pollType);
            
            match("(");
            AST_VarRef varObj = parseVarRef();
            exprCh.setChannel(varObj);
            
            last = ptk.currentLineNo();
            match(")");
            
            exprObj = exprCh;
        }
        else {
            // any_expr
            AST_Expr_AnyExpr tmpAnyExpr = parseAnyExpr(null);
            last = tmpAnyExpr.getPhyEndLine();
            exprObj = tmpAnyExpr;
        } 
        
        // For and, or
        if (peekIsAndOr()){
            //  expr andor expr
            AST_Expr_AndOr andOrObj = new AST_Expr_AndOr();
            String op = consume(); // Consume && or || 
            andOrObj.setLeftExpr(exprObj);
            andOrObj.setAndOrType(op);
            AST_Expr secExpr = parseExpr(null);
            
            andOrObj.setRighttExpr(secExpr);
            last = secExpr.getPhyEndLine();
                
            andOrObj.setLines(first, last);
            return andOrObj;
        }
        
        exprObj.setLines(first, last);
        return exprObj;
    }
    private AST_Expr_AnyExpr parseAnyExpr(AST_VarRef preread) throws PmlParseException{
        /*
         any_expr: '(' any_expr ')'
                    | '(' any_expr '-' '>' any_expr ':' any_expr ')'
                    | any_expr binarop any_expr
                    | unarop any_expr
                    | LEN '(' varref ')'	/* nr of messages in chan 
                    | poll
                    | varref
                    | const 
                    | TIMEOUT
       (never)      | NP_			/* non-progress system state 
       (never)      | ENABLED '(' any_expr ')'		/* refers to a pid 
       (never)      | PC_VALUE '(' any_expr ')'		/* refers to a pid 
       (never)      | name '[' any_expr ']' '@' name	/* refers to a pid 
                    | RUN name '(' [ arg_lst ] ')' [ priority ]
         */
        
        AST_Expr_AnyExpr anyExprObj;
        int first,last;
        if (preread!=null) {
            first = preread.getPhyStartLine();
            last = preread.getPhyEndLine();
        }
        else{
            first = ptk.currentLineNo();
            last = ptk.currentLineNo();
        }
        
        if (preread != null){
            // A varref has been read before this method is called. 
            // Continue parsing from this varref.
            
            // Possiblities: varref | poll
            
            if (peekMatch("?") || peekMatch("??")){
                // poll type
                //      varref '?' '[' recv_args ']'	/* poll without side-effect */
                //    | varref '?' '?' '[' recv_args ']'	/* ditto */
                AST_AnyExpr_Poll tmpRetObj = new AST_AnyExpr_Poll();
                tmpRetObj.setPolledChannel(preread);
                String pollType = consume();
                tmpRetObj.setPollType(pollType);
                match("[");
                AST_RecvArgList tmpRecvArgs = parseRecvArgList();
                tmpRetObj.setRecvArgList(tmpRecvArgs);
                
                last = ptk.currentLineNo();
                match("]");
                
                anyExprObj = tmpRetObj;
            } 
            else {
                // Not poll, so Varref type.
                AST_AnyExpr_VarRef tmpRetObj = new AST_AnyExpr_VarRef();
                tmpRetObj.setReference(preread);
                anyExprObj = tmpRetObj;
            }
        }
        else if (peekMatch("(")){
            //   '(' any_expr ')'
            // | '(' any_expr '-' '>' any_expr ':' any_expr ')'   
            match("(");
            
            AST_Expr_AnyExpr tmpAnyExpr;
            
            tmpAnyExpr = parseAnyExpr(null);

            if (peekMatch(")")){
                // Bracket type;
                last = ptk.currentLineNo();
                match(")");
                AST_AnyExpr_Bracket brackObj = new AST_AnyExpr_Bracket();
                brackObj.setContentAnyExpr(tmpAnyExpr);
                
                anyExprObj = brackObj;
            }
            else {
                // Conditional expression
                AST_AnyExpr_CondExpr condObj = new AST_AnyExpr_CondExpr();
                
                match("->");
                
                AST_Expr_AnyExpr firstOpt;
                firstOpt = parseAnyExpr(null);
                match(":");
                
                AST_Expr_AnyExpr secondOpt;
                secondOpt = parseAnyExpr(null);
                last = ptk.currentLineNo();
                match(")");
                
                condObj.setCondition(tmpAnyExpr);
                condObj.setTrueOption(firstOpt);
                condObj.setFalseOption(secondOpt);
                
                anyExprObj = condObj;
            }
        }
        else if (peekIsUnarop()){
            //   | unarop any_expr
            AST_AnyExpr_Unarop unaObj = new AST_AnyExpr_Unarop();
            String op = consume();
            unaObj.setOperation(op);
            
            AST_Expr_AnyExpr tmp = parseAnyExpr(null);
            unaObj.setOperand(tmp);
            
            last = tmp.getPhyEndLine();
            anyExprObj = unaObj;
        }
        else if (peekMatch("len")){
            //   | LEN '(' varref ')'
            AST_AnyExpr_Len lenObj = new AST_AnyExpr_Len();
            
            match("len");
            match("(");
            AST_VarRef varObj = parseVarRef();
            
            lenObj.setVarRef(varObj);
            
            last = ptk.currentLineNo();
            match(")");
            
            anyExprObj = lenObj;
        }
        else if (peekMatch("timeout")){
            AST_AnyExpr_Timeout tObj = new AST_AnyExpr_Timeout();
            
            last = ptk.currentLineNo();
            match("timeout");
            
            anyExprObj = tObj;
        }
        else if (peekIsConst()){
            // constant
            AST_Const consObj = parseConstant();
            AST_AnyExpr_Const consAny = new AST_AnyExpr_Const();
            consAny.setConst(consObj);
            
            last = consObj.getPhyEndLine();
            anyExprObj = consAny;
        }
        else if (peekMatch("run")){
            // | RUN name '(' [ arg_lst ] ')' [ priority ]
            AST_AnyExpr_Run runObj = new AST_AnyExpr_Run();
            match("run");
            if (nextIsWord()){
                last = ptk.currentLineNo();
                String procTypeName = consume();
                
                runObj.setProcName(procTypeName);
            } 
            else {
                String msg = "Near line " + ptk.currentLineString() + ": Expected proctype name";
                throw new PmlParseException(msg);
            }
            
            match("(");
            if (peekMatch(")")){
                last = ptk.currentLineNo();
                match(")");
            }
            else {
                AST_ArgList aList = parseArgList(null);
                runObj.setRunArgs(aList);

                last = ptk.currentLineNo();
                match(")");
                if (peekMatch("priority")){
                    match("priority");
                    if (peekIsConst()){
                        AST_Const cons = parseConstant(); // Remove the constant
                        last = cons.getPhyEndLine();
                        runObj.setRunPriority(cons);
                    }
                    else {
                        String msg = "Near line " + ptk.currentLineString() + ": Expected constant";
                        throw new PmlParseException(msg);
                    } // Match compulsory constant
                } // Match optional priority
            }
            
            anyExprObj = runObj;
        }
        else {
            //  | poll
            //  | varref
            
            AST_VarRef varObj = parseVarRef();
            
            if (peekMatch("?") || peekMatch("??")){
                // poll type
                //      varref '?' '[' recv_args ']'	/* poll without side-effect */
                //    | varref '?' '?' '[' recv_args ']'	/* ditto */
                
                AST_AnyExpr_Poll tmpRetObj = new AST_AnyExpr_Poll();
                tmpRetObj.setPolledChannel(varObj);
                String pollType = consume();
                tmpRetObj.setPollType(pollType);
                match("[");
                AST_RecvArgList tmpRecvArgs = parseRecvArgList();
                tmpRetObj.setRecvArgList(tmpRecvArgs);
               
                last = ptk.currentLineNo();
                match("]");
                
                anyExprObj = tmpRetObj;
            }
            else {
                // Not poll, so Varref type.
                AST_AnyExpr_VarRef tmpRetObj = new AST_AnyExpr_VarRef();
                tmpRetObj.setReference(varObj);
                last = varObj.getPhyEndLine();
                anyExprObj = tmpRetObj;       
            }
        }
        // The 4 any_expr for never claims not processed. 
        
        //| any_expr binarop any_expr
        if (peekIsBinarop()){
            AST_Expr_AnyExpr firstAny = anyExprObj;
            firstAny.setLines(first, last);
            
            String op = consume(); // consume the binaryop
            AST_Expr_AnyExpr secAny = parseAnyExpr(null);
            
            AST_AnyExpr_Binarop binObj = new AST_AnyExpr_Binarop();
            binObj.setLeftOperand(firstAny);
            binObj.setOperation(op);
            binObj.setRightOperand(secAny);
            last = secAny.getPhyEndLine();
            
            binObj.setLines(first, last);
            return binObj;
        }
        
        anyExprObj.setLines(first, last);
        return anyExprObj;
    }
    
    private AST_VarRef parseVarRef() throws PmlParseException{
        //  name [ '[' any_expr ']' ] [ '.' varref ]
        AST_VarRef retObj = new AST_VarRef();
        int first,last;
        first = ptk.currentLineNo();
        last = ptk.currentLineNo();
        
        if (nextIsWord()){
            String varName = ptk.getNextToken();

            // Get varIndex;
            Integer varInd = getVarIndex(varName);
            if (varInd == null){
                String msg = "Near line " + ptk.currentLineString() + ": Undeclared variable '"+ varName +"'";
                throw new PmlParseException(msg);
            }
            
            retObj.setVarName(varName);
            retObj.setVarInd(varInd);
        } 
        else {
            String msg = "Near line " + ptk.currentLineString() + ": Expected variable name";
            throw new PmlParseException(msg);
        }
        
        if (peekMatch("[")){
            match("[");
            AST_Expr_AnyExpr tmpExpr = parseAnyExpr(null);
            
            last = ptk.currentLineNo();
            match("]");
            
            retObj.setArrayExpr(tmpExpr);
        }
        if (peekMatch(".")){
            match(".");
            AST_VarRef child = parseVarRef();
            
            last = child.getPhyEndLine();
            retObj.setTypeDefChild(child);
        }
        
        retObj.setLines(first, last);
        return retObj;
    }
    private AST_Const parseConstant() throws PmlParseException{
        int first,last;
        first = ptk.currentLineNo();
        last = ptk.currentLineNo();

        String cons = consume();
        AST_Const consObj = new AST_Const(cons);
        
        consObj.setLines(first, last);
        return consObj;
    }
    
    private AST_ChInit parseChInit() throws PmlParseException{
        // ch_init : '[' const ']' OF '{' typename [ ',' typename ] * '}'

        AST_ChInit chObj = new AST_ChInit();
        int first,last;
        first = ptk.currentLineNo();
        
        match("[");
        if (peekIsConst()){
            AST_Const tmpCons = parseConstant();
            chObj.setSize(tmpCons);
        }
        else {
            String msg = "Near line " + ptk.currentLineString() + ": Expected constant";
            throw new PmlParseException(msg);
        }
        match("]");
        match("of");
        match("{");
        if (peekIsTypeName()){
            String type = consume();
            chObj.addType(type);
        } // First compulsory typename
        else {
            String msg = "Near line " + ptk.currentLineString() + ": Expected typename";
            throw new PmlParseException(msg);
        }
        while( peekMatch(",") ){
            match(",");
            if (peekIsTypeName()){
                String type = consume();
                chObj.addType(type);
            } // Optional typename
            else {
                String msg = "Near line " + ptk.currentLineString() + ": Expected typename";
                throw new PmlParseException(msg);
            }
        } // optional additional typename

        last = ptk.currentLineNo();
        match("}");
        
        chObj.setLines(first, last);
        return chObj;
    }
   
    private AST_ArgList parseArgList(AST_Expr_AnyExpr preread) throws PmlParseException{
        // arg_lst  : any_expr [ ',' any_expr ] *
        AST_ArgList retObj = new AST_ArgList();
        int first,last;
        if (preread!=null) {
            first = preread.getPhyStartLine();
            last = preread.getPhyEndLine();
        }
        else{
            first = ptk.currentLineNo();
        }
        
        // firstAnyExpr = preread or firstAnyExpr = parseAnyExpr
        if (preread == null) {
            AST_Expr_AnyExpr tmpAnyExpr = parseAnyExpr(null);
            
            last = tmpAnyExpr.getPhyEndLine();
            retObj.addAnyExpr(tmpAnyExpr);
        }
        else {
            retObj.addAnyExpr(preread);
            last = preread.getPhyEndLine();
        }
        while (peekMatch(",")){
            match(",");
            AST_Expr_AnyExpr tmpAnyExpr = parseAnyExpr(null);
            
            last = tmpAnyExpr.getPhyEndLine();
            retObj.addAnyExpr(tmpAnyExpr);
        }
        
        retObj.setLines(first, last);
        return retObj;
    }
    private AST_RecvArgList parseRecvArgList() throws PmlParseException{
        //recv_args : recv_arg [ ',' recv_arg ] *  |  recv_arg '(' recv_args ')'
        AST_RecvArgList retObj = null;
        int first,last;
        first = ptk.currentLineNo();
        
        AST_RecvArg tmpArg = parseRecvArg();
        last = tmpArg.getPhyEndLine();
        
        if (peekMatch("(")){
            AST_RecvArgList_Type2 t2Obj = new AST_RecvArgList_Type2();
            t2Obj.setMainRecvArg(tmpArg);
            
            match("(");
            AST_RecvArgList subArgList = parseRecvArgList();
            t2Obj.setSubRecvArgList(subArgList);
            
            last = ptk.currentLineNo();
            match(")");
            
            retObj = t2Obj;
        }
        else {
            AST_RecvArgList_Type1 t1Obj = new AST_RecvArgList_Type1();
            t1Obj.addRecvArg(tmpArg);
            int locallast = tmpArg.getPhyEndLine();
            while( peekMatch(",") ){
                match(",");
                tmpArg = parseRecvArg();
                t1Obj.addRecvArg(tmpArg);
                locallast = tmpArg.getPhyEndLine();
            }
            t1Obj.setPhyEndLine(locallast);
            last = locallast;
            retObj = t1Obj;
        } 
        
        retObj.setLines(first, last);
        return retObj;
    }
    private AST_RecvArg parseRecvArg() throws PmlParseException{
        //recv_arg : varref | EVAL '(' varref ')' | [ '-' ] const
        AST_RecvArg retObj;
        int first,last;
        first = ptk.currentLineNo();
        
        if (peekMatch("eval")){
            AST_RecvArg_VarRef tmpArg = new AST_RecvArg_VarRef();
            match("eval");
            match("(");
            AST_VarRef tmpVar = parseVarRef();
            tmpArg.setArg(tmpVar);
            
            last = ptk.currentLineNo();
            match(")");
            
            retObj = tmpArg;
        }
        else if (peekMatch("-") || peekIsConst()){
            AST_RecvArg_Const tmpArg = new AST_RecvArg_Const();
            tmpArg.setNegated(false);
            if(peekMatch("-")){
                match("-");
                tmpArg.setNegated(true);
            }
            AST_Const tmpCons = parseConstant(); // Consume the constant
            tmpArg.setConst(tmpCons);
            
            last = tmpCons.getPhyEndLine();
            retObj = tmpArg;
        }
        else {
            AST_RecvArg_VarRef tmpArg = new AST_RecvArg_VarRef();
            AST_VarRef tmpVar = parseVarRef();
            
            tmpArg.setArg(tmpVar);
            
            last = tmpVar.getPhyEndLine();
            retObj = tmpArg;
        }
        
        retObj.setLines(first, last);
        return retObj;
    }
    private AST_SendArgs parseSendArgList() throws PmlParseException{
        // send_args: arg_lst | any_expr '(' arg_lst ')'
        AST_SendArgs retObj = null;
        int first,last;
        first = ptk.currentLineNo();
        
        AST_Expr_AnyExpr tmpAnyExpr = parseAnyExpr(null);
        
        if (peekMatch("(")){
            AST_SendArgs_Type2 t2Obj = new AST_SendArgs_Type2();
            t2Obj.setExpr(tmpAnyExpr);
            
            match("(");
            
            AST_ArgList tmpArgList = parseArgList(null);
            t2Obj.setArgList(tmpArgList);
        
            last = ptk.currentLineNo();
            match(")");
            
            retObj = t2Obj;
        }
        else{
            AST_SendArgs_Type1 t1Obj = new AST_SendArgs_Type1();
            
            AST_ArgList tmpArgList = parseArgList(tmpAnyExpr);
            t1Obj.setArgList(tmpArgList);
            t1Obj.setPhyEndLine(tmpArgList.getPhyEndLine());
            
            last = t1Obj.getPhyEndLine();
            retObj = t1Obj;
        }
        
        retObj.setLines(first, last);
        return retObj;
    }
}
 