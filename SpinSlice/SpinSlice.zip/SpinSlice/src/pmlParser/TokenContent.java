package pmlParser;

/**
 * Token class.
 * @author Choo Wei Chern
 */
public class TokenContent {
    public static final int WORDTYPE = 1;
    public static final int NUMTYPE = 2;
    public static final int PUNCTYPE = 3;
    public static final int STRINGTYPE = 4;
    
    private String value;
    private int type;
    private int lineNo;

    public TokenContent(String v, int t, int l){
        value = v;
        type = t;
        lineNo = l;
    }
    public String getValue() { return value; }
    public int getType() { return type; }
    public int getLine() { return lineNo; }
}
