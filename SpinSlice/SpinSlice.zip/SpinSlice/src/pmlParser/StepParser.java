package pmlParser;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.StringTokenizer;
import pmlException.PmlParseException;
import pmlADT.*;
import pmlAnalyser.adt.AllProcVarsState;
import pmlAnalyser.adt.CriterionTuple;
import pmlAnalyser.adt.ProcIdTable;
import pmlAnalyser.adt.TraceListTuple;
import pmlAnalyser.adt.Trace_List;
import pmlException.PmlNodeDeterminationException;

/**
 * For parsing dynamic trace. 
 * @author Choo Wei Chern
 */
public class StepParser {
    private PmlTokenizer ptk;
    ParserCore psCore;
    
    private TraceStepNodesTable snTable;
    private StmtTable stmtTable;
    private ProcIdTable pIdTable;
    private VarTable vt;
     // ADDED FOR CYCLE
    private boolean hasCycle = false;
    
    // Private variables for tracelist generation
    private int targetPid; 
    private int status = ALLOKAY;
    private final static int ALLOKAY = 0;
    private final static int ASSERT_FAILURE = 1;
    private final static int END_OF_TRAIL = 2;
    
    public StepParser(VarTable vt, MtypeSymbolsTable mt, ProcIdTable pIdTable, TraceStepNodesTable snTable_ReadOnly, StmtTable stmtTable_ReadOnly){        
        ptk = null;        
        psCore= new ParserCore(vt, null, null, mt, null);    
        
        snTable = snTable_ReadOnly;
        stmtTable = stmtTable_ReadOnly;
        this.vt = vt;
        
        this.pIdTable = pIdTable;
    }

    private AST_Stmt parseStmt(String toParse) throws PmlParseException {
        ptk = new PmlTokenizer(toParse);
        
        AST_Stmt stmt = psCore.stmtParse(ptk, null);
       
        return stmt;
    }
    
    
    /** 
     * Takes in a dynamic trace and generates: tracelist, reasonlist, criterionlist, variableInfolist and returns the type of error trace.
     * @param traceStream the stream of trace
     * @param returnTraceList the list of trace which will be populated by this method
     * @param returnCriterionList the list of criterion which will be populated by this method
     * @param returnVarInfoList the list of variable information at each step.
     * @param ltlVars string of variables involved in the violated ltl/buchi automata property. Variables are space separated.
     * @return  true if trace is due to assertion failure, false otherwise
     **/
    public boolean generateTraceAndCriterionList(InputStream traceStream, Trace_List returnTraceList, ArrayList<CriterionTuple> returnCriterionList, ArrayList<AllProcVarsState> returnVarInfoList, String ltlVars) throws PmlParseException,PmlNodeDeterminationException {
        // Start parsing the traceStream
        /* Trace is parsed in the following manner
         * For each line, get first char (fc) of line.
         * if fc is of space or number, then parse as Step
         * if fc is of tab, then parse as tab, parse as variable info (not implemented)
         * if fc is of char, then parse as spin info (watch out for errror info)
         * 
         * For each Step, tokenize it.
         * For 1st token, get the step number. Parse only if it is "new". 
         * Find token "proc". The next token will be the procID.
         * Find token "line". The next token will be the lineNo.
         * Find token "[xxxxxx]". Trim the braces and to parse the actual step.
         * 
         */
        boolean isAssertFailure;
        
        targetPid = 0;
        
        Scanner sc = new Scanner(traceStream);
        // ADDED FOR CYCLE : note the change in while condition below
        while (sc.hasNextLine() && (status == ALLOKAY) ){
            String line = sc.nextLine();
            // ADDED FOR CYCLE
            if (line.contains("START OF CYCLE")){
                processSpinInfo(line);
            }// END OF ADDED FOR CYCLE
            else if (line.charAt(0)==' ' || Character.isDigit(line.charAt(0))){
                processStep(returnTraceList, line);
            }else if (line.charAt(0)=='\t'){
                int sizeOftraceList = returnTraceList.totalSize();
                processVarInfo(returnVarInfoList,sizeOftraceList, line);
            }else if (Character.isLetter(line.charAt(0))){
                processSpinInfo(line);
            }
        } // Scan till "error" in trace encountered
        
        
        
        if (status == ASSERT_FAILURE){
            // Scan the first line after the "error" msg to gets the failed assertion line
            while (sc.hasNextLine() && status == ASSERT_FAILURE){
                String line = sc.nextLine();
                        if (line.charAt(0)==' '|| Character.isDigit(line.charAt(0))){
                    processStep(returnTraceList, line);
                    
                    // Assertion line will be the last line in the linear trace.
                    // Get the relevant info and put into criterion list
                    TraceListTuple tlTup = returnTraceList.getLinear(returnTraceList.linearSize()-1);
                    int sPid = tlTup.getSourcePID();
                    int nodeId = tlTup.getNodeID();
                    int lineNo = returnTraceList.linearSize();
                    
                    returnCriterionList.add(new CriterionTuple(sPid, lineNo, nodeId));
                }/*else if (line.charAt(0)=='\t'){
                    int sizeOftraceList = returnTraceList.size();
                    processVarInfo(returnVarInfoList,sizeOftraceList,line);
                }*/
                else if (Character.isLetter(line.charAt(0))){
                    processSpinInfo(line);
                }
            }
            isAssertFailure = true;
            // Read up the final varinfo
            while (sc.hasNextLine()){
                String line = sc.nextLine();
                if (line.charAt(0)=='\t'){
                    int sizeOftraceList = returnTraceList.totalSize();
                    processVarInfo(returnVarInfoList,sizeOftraceList,line);
                }
            }
        }
        // ADDED FOR CYCLE: note change in if condition
        else if (ltlVars.isEmpty() && hasCycle == false ) {
            // Error trace not due to assertion failure
            // Deadlock
            while (sc.hasNextLine()){
                String line = sc.nextLine();
                if (line.charAt(0)==' '|| Character.isDigit(line.charAt(0))){
                    processRemainingStmt(returnCriterionList, line);
                }else if (line.charAt(0)=='\t'){
                    int sizeOftraceList = returnTraceList.totalSize();
                    processVarInfo(returnVarInfoList,sizeOftraceList,line);
                }
                /*}else if (Character.isLetter(line.charAt(0))){
                    processSpinInfo(line);
                }*/
            }
            isAssertFailure = false;
        }else {
            isAssertFailure = false;
            // LTL / Buchi automata violation. Generate criterion
            // Go through the trace from the last statement and look for the variable that last modifies the statements.
        
            ArrayList<Integer> varIndexList = new ArrayList<Integer>();
            StringTokenizer st = new StringTokenizer(ltlVars);
            while (st.hasMoreTokens()){
                Integer ind = vt.getIndex(st.nextToken(), VarTable.GLOBAL);
                if (ind != null){
                    varIndexList.add(ind);
                }
            }
                
            for (int i = returnTraceList.linearSize()-1; i >= 0; i --){
                TraceListTuple tlTup = returnTraceList.getLinear(i);
                INF_TraceStep step = snTable.getStmt(tlTup.getNodeID());
                
                for (int j = 0; j < varIndexList.size(); j ++){
                    if (step.getMods().contains(varIndexList.get(j))){
                        int sPid = tlTup.getSourcePID();
                        int nodeId = tlTup.getNodeID();
                        returnCriterionList.add(new CriterionTuple(sPid, i+1, nodeId));
                        varIndexList.remove(j); // ** REMOVAL OF ELEMENT.NOTE THAT THIS MEANS THE FOR LOOP SHOULD NOT CONTINUE
                        break;
                    }
                }
            }   
        }
        
        // Ensure returnTraceList and returnVarInfo contains the same size
        ensureSameSize(returnVarInfoList,returnTraceList.totalSize());
        
        return isAssertFailure;
    }
    
    // For processing the possible criterion after the trace ended.
    private void processRemainingStmt(ArrayList<CriterionTuple> list,String line) throws PmlParseException, PmlNodeDeterminationException{
        // Process lines of the format:
        //  X:	proc  Y (<proc name>) line A "<program name>" (state C)
        // or
        //  X:	...... <valid end state>
        // As it process the remaining stmt, it should encounter:
        // X processess created. <--- do not parse
        StringTokenizer st = new StringTokenizer(line);
        
        if (line.contains("<valid end state>")){
            return;
        }
        
        String numStr = st.nextToken();
        if (!numStr.contains(":")){
            return;
            // Ignore lines of X processess created. <--- do not parse
        }
        String stepNoStr = numStr.replace(":", "");
        
        int sourcePid;
        int lineNo;

        while (st.nextToken().compareTo("proc") != 0){
            // Scan until "proc" token
        }
        
        //ADDED
        numStr = st.nextToken();
        if (numStr.equals("-")){
            // "proc -" for never claims
            // ignore the entire line
            return;
        }
        //End of ADDED
        sourcePid = Integer.parseInt(numStr);

        while (st.nextToken().compareTo("line") != 0){
            // Scan until "line" token
        }
        lineNo = Integer.parseInt(st.nextToken());

        // Get the AST_Stmt in this physical line
        AST_Stmt tmpstmt = stmtTable.getStmt(lineNo);
        
        // From this stmt, get the possible criterion
        // for instance, the criterion for :
        // do 
        // :: x == 1 -> x = 2
        // :: y == 1 -> y = 2
        // od
        // will be (x==1) and (y==2)
        HashSet<INF_TraceStep> possibleCrit = tmpstmt.getTraceStepsForCriterion();
        Iterator<INF_TraceStep> itCrit = possibleCrit.iterator();
        while (itCrit.hasNext()){
            INF_TraceStep step = itCrit.next();
            int nodeId = step.getTraceStepNo();
            list.add(new CriterionTuple(sourcePid, -1, nodeId)); 
        }
            
    }
    
    // For processing the trace into steps.    
    private void processStep(Trace_List list,String line) throws PmlParseException, PmlNodeDeterminationException {
        // Process lines of the format:
        //  X:	proc  Y (<proc name>) line A "<program name>" (state C)	[<promela step>]
        // or
        //  X:  proc Y terminates
        // X processess created. <--- do not parse
        StringTokenizer st = new StringTokenizer(line);
        
        String numStr = st.nextToken();
        if (!numStr.contains(":")){
            return;
            // Ignore lines of X processess created. <--- do not parse
        }
        String stepNoStr = numStr.replace(":", "");
        int stepNo = Integer.parseInt(stepNoStr);
        
        int sourcePid;
        int lineNo;
        String stepStr = "";

        while (st.nextToken().compareTo("proc") != 0){
            // Scan until "proc" token
        }
        sourcePid = Integer.parseInt(st.nextToken());

        
        String nextTok = st.nextToken();
        while (nextTok.compareTo("line") != 0 
               && nextTok.compareTo("terminates") != 0 ){
            // Scan until "line" or "terminates" token
            nextTok = st.nextToken();
        }
        
        if (nextTok.compareTo("terminates") == 0){
            return;
        }
        
        lineNo = Integer.parseInt(st.nextToken());

        String tmp="";
        while (st.hasMoreTokens()){
            tmp = st.nextToken();
            if (tmp.charAt(0)=='['){
                // [xxx token found
                break;
            }
        }

        int pos = line.indexOf(tmp);
        stepStr = line.substring(pos);

        stepStr = stepStr.substring(1,stepStr.length()-1);

        AST_Stmt stmt = parseStmt(stepStr);
        int nodeNo = snTable.getNodeNumber(stmt, lineNo);

        // Check if this line contains a run expression.
        // If it does not contains a run expression, targetPid will be itself
        if (stmt instanceof AST_Stmt_Expr){
            AST_Stmt_Expr castedStmt = (AST_Stmt_Expr)stmt;
            AST_Expr tmpExpr = castedStmt.getExpr();
            if (!(tmpExpr instanceof AST_AnyExpr_Run)){
                // Not a run stmt
                targetPid = sourcePid;
            }
        }else {
            // Not a run stmt
            targetPid = sourcePid;
        }

         // ADDED FOR CYCLE
        if (!hasCycle){
            list.addLinear(new TraceListTuple(sourcePid, targetPid, nodeNo));   
        }else{
            list.addCyclic(new TraceListTuple(sourcePid, targetPid, nodeNo));   
        }
 
    }
    
    private void ensureSameSize(ArrayList<AllProcVarsState> apvsList, int traceListSize){
        int apvsListSize = apvsList.size();
        AllProcVarsState previousApvs;
        if (apvsListSize == 0){
            previousApvs = new AllProcVarsState();
        }else{
            previousApvs = apvsList.get(apvsListSize-1);
        }
        
        // Populate apvsList until the size matches that of traceList
        while (apvsList.size() < traceListSize){
            apvsList.add(previousApvs.duplicate());
        }
    }
    
    // For processing variable information which can be displayed.
    // traceListSize is needed as the index of apvsList should match that of the traceList
    private void processVarInfo(ArrayList<AllProcVarsState> apvsList, int traceListSize, String line){
        // Process lines of the format:
        // <varName> = <value>   (for global vars)
        // <procName>(<id>):<varName> = <value>  (for local vars)
        // transition failed  <-- this should be ignored
        
        if (line.contains("transition failed")){
            return;
        }
        
        ensureSameSize(apvsList, traceListSize);
        
        // Parse the variable info and update
        // <varName> = <value>   (for global vars)
        // <procName>(<id>):<varName> = <value>  (for local vars)
        StringTokenizer st = new StringTokenizer(line," =");
        String varPartStr = st.nextToken();
        varPartStr = varPartStr.trim();
        Integer value = Integer.parseInt(st.nextToken());
        
        // Check if local or global var.
        int procId;
        String varStr;
        int colonPos = varPartStr.lastIndexOf(':');
        if (colonPos == -1){
            // No colon found, global vars
            procId = -1;
            varStr = varPartStr;
        }else{
            int firstBrackPos = varPartStr.indexOf('(');
            int secondBrackPos = varPartStr.indexOf(')');
            
            String procStr = varPartStr.substring(firstBrackPos+1,secondBrackPos);
            procId = Integer.parseInt(procStr);
            varStr = varPartStr.substring(colonPos+1);
        }
        
        // Update the last element
        apvsList.get(apvsList.size()-1).updateVarState(procId, varStr, value);
    }
    // Process spin generated message which provide hints to the "states" of trace.
    private void processSpinInfo(String line){
        // Process lines of the format:
        // "Starting xxx with pid Y"
        // "spin: text of failed assertion: assert((cnt==1))"
        // "spin: trail ends after 19 steps"
        // "  <<<<<START OF CYCLE>>>>>"
        // ignores "Starting :never: ...." (added)
        StringTokenizer st = new StringTokenizer(line);
        String tmp = st.nextToken();
        if (tmp.compareToIgnoreCase("Starting")==0){            
            String procName = st.nextToken();
            
            //Added
            if (procName.equals(":never:")){
                // Ignores this line and returns
                return;
            }
            //end of added
            
            while (st.hasMoreTokens()){
                tmp = st.nextToken();
                // proceeds to last token
            }

            pIdTable.addProcName(procName);
            targetPid = Integer.parseInt(tmp);    
        }
        else if (tmp.compareToIgnoreCase("spin:")==0){ 
           if (line.contains("failed assertion")){
               status = ASSERT_FAILURE;
           }
           else if (line.contains("trail ends after")){
               status = END_OF_TRAIL;
           }
        }
        // ADDED FOR CYCLE
        else if (line.contains("START OF CYCLE")){
            hasCycle = true;
        }
        
    }
    
}
