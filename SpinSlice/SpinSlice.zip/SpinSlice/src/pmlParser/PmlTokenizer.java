package pmlParser;

import java.util.LinkedList;
import java.io.InputStream;
import java.util.Scanner;

/**
 * Tokenizer class.
 * @author Choo Wei Chern
 */
public class PmlTokenizer { 
        LinkedList<TokenContent> tokenlist;
        
        public PmlTokenizer(InputStream codeStream) {
            startTokenize(codeStream);
        }
        public PmlTokenizer(String str) {
            startTokenize(str);
        }
        
        public boolean hasMoreTokens() {
            return (tokenlist.peekFirst() != null);
        }
        public String getNextToken() {
            if (!hasMoreTokens()) return null;
            else return (tokenlist.removeFirst().getValue());
        }
        public String currentLineString(){
            if (!hasMoreTokens()) return "-";
            else return String.valueOf(tokenlist.peekFirst().getLine());
        }
        public Integer currentLineNo(){
            if (!hasMoreTokens()) return null;
            else return (tokenlist.peekFirst().getLine());
        }
        public String peekNextToken() {
            if (!hasMoreTokens()) return null;
            else return (tokenlist.peekFirst().getValue());
        }
        public String lookAhead(int ahead){
            try {
                return tokenlist.get(ahead).getValue();
            }
            catch (IndexOutOfBoundsException e ){
                return null;
            }
        }
        
        public boolean nextIsWord(){
            return (hasMoreTokens() && tokenlist.peekFirst().getType() == TokenContent.WORDTYPE);
        }
        public boolean nextIsNum(){
            return (hasMoreTokens() && tokenlist.peekFirst().getType() == TokenContent.NUMTYPE);
        }
        public boolean nextIsPunct(){
            return (hasMoreTokens() && tokenlist.peekFirst().getType() == TokenContent.PUNCTYPE);
        }
        public boolean nextIsString(){
            return (hasMoreTokens() && tokenlist.peekFirst().getType() == TokenContent.STRINGTYPE);
        }
            
        private void startTokenize(InputStream s) {
            tokenlist = new LinkedList<TokenContent>();
            Scanner sc = new Scanner(s);

            boolean isComment = false;
            Integer lineCount = 1;
            
            while (sc.hasNextLine()){
                String line = sc.nextLine();
                isComment = tokenizeLine(line,isComment,lineCount);
                lineCount++;
            }
        }
        private void startTokenize(String s) {
            tokenlist = new LinkedList<TokenContent>();
            Scanner sc = new Scanner(s);

            boolean isComment = false;
            Integer lineCount = 1;
            
            while (sc.hasNextLine()){
                String line = sc.nextLine();
                isComment = tokenizeLine(line,isComment,lineCount);
                lineCount++;
            }
        }
        private boolean tokenizeLine(String s, boolean isComment, int lineCount) {
            int n = s.length();
            int i = 0;
            
            while (i<n){
                if (isComment) {
                    // Current section is part of comments. Check for */
                    if (s.charAt(i) == '*'){
                        if ( ((i+1)<n) && s.charAt(i+1) == '/'  ){
                            i++; // for the second '/'
                            isComment = false;
                        }   
                    }
                    i++;
                    continue;
                }
                else if ( Character.isWhitespace(s.charAt(i)) ){
                    // White space or newlines chars. Ignore
                    i++;
                    continue;
                }
                else if( Character.isDigit(s.charAt(i)) ){
                    // A digit type
                    String tmp = "" + s.charAt(i);
                    i++;
                    while (i < n && Character.isDigit(s.charAt(i)) ) {
                        tmp += s.charAt(i);
                        i++;
                    }
                    tokenlist.add(new TokenContent(tmp,TokenContent.NUMTYPE,lineCount));
                }
                else if( Character.isLetter(s.charAt(i)) ){
                    // A word type
                    
                    String tmp = "" + s.charAt(i);
                    i++;
                    while (i < n && (Character.isDigit(s.charAt(i)) || Character.isLetter(s.charAt(i)) || s.charAt(i)=='_' ) ) {
                        tmp += s.charAt(i);
                        i++;
                    } // word can contain underscore character _
                    tokenlist.add(new TokenContent(tmp,TokenContent.WORDTYPE,lineCount));
                }
                else {
                    // Punctuation type
                    
                    if (s.charAt(i) == '/'){
                        if ( ((i+1)<n) && s.charAt(i+1) == '*' ){
                            // Start of comments.
                            i++; // for first '/'
                            i++; // for second '*'
                            isComment = true;
                            continue;
                        }
                    }
                    else if (s.charAt(i) == '"'){
                        // String type. Read in all until closing "
                        
                        String strContent = "\"";
                        i++;
                        while(s.charAt(i) != '"'){
                            strContent = strContent + s.charAt(i);
                            i++;
                        }
                        strContent = strContent + "\"";
                        i++; //for closing "
                        tokenlist.add(new TokenContent(strContent,TokenContent.STRINGTYPE,lineCount));
                        continue;
                    }
                    else {
                        ////// Other "non-special" punctionations
                        String tmp = "" + s.charAt(i);
                        if (s.charAt(i)== '-' && ((i+1)<n) && s.charAt(i+1) == '>'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for ->
                        else if (s.charAt(i)== '+' && ((i+1)<n) && s.charAt(i+1) == '+'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for ++
                        else if (s.charAt(i)== '-' && ((i+1)<n) && s.charAt(i+1) == '-'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for --
                        else if (s.charAt(i)== '&' && ((i+1)<n) && s.charAt(i+1) == '&'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for &&
                        else if (s.charAt(i)== '|' && ((i+1)<n) && s.charAt(i+1) == '|'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for ||
                        else if (s.charAt(i)== '!' && ((i+1)<n) && s.charAt(i+1) == '!'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for !!
                        else if (s.charAt(i)== '?' && ((i+1)<n) && s.charAt(i+1) == '?'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for ??
                        else if (s.charAt(i)== '>' && ((i+1)<n) && s.charAt(i+1) == '='){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for >=
                        else if (s.charAt(i)== '<' && ((i+1)<n) && s.charAt(i+1) == '='){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for <=
                        else if (s.charAt(i)== '=' && ((i+1)<n) && s.charAt(i+1) == '='){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for ==
                        else if (s.charAt(i)== '!' && ((i+1)<n) && s.charAt(i+1) == '='){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for !=
                        else if (s.charAt(i)== '<' && ((i+1)<n) && s.charAt(i+1) == '<'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for <<
                        else if (s.charAt(i)== '>' && ((i+1)<n) && s.charAt(i+1) == '>'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for >>
                        else if (s.charAt(i)== ':' && ((i+1)<n) && s.charAt(i+1) == ':'){
                            tmp = tmp + s.charAt(i+1);
                            i++; // for the 2nd character
                        } // Combined token for ::

                        i++;
                        tokenlist.add(new TokenContent(tmp,TokenContent.PUNCTYPE,lineCount));

                    }
                }
            }
            return isComment; // return the current state of comments
        }
        
    }
