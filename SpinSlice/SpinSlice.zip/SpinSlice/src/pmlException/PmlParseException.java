package pmlException;

/**
 * General exception produced when parsing problems are encountered.
 * @author Choo Wei Chern
 */
public class PmlParseException extends Exception {
    public PmlParseException(String msg) { 
        super(msg); 
    }
}
