package pmlException;

/**
 * Exception produced when the parser is unable to translate a line in the dynamic trace to the actual node in the syntax tree.
 * @author Choo Wei Chern
 */
public class PmlNodeDeterminationException extends Exception {
    public PmlNodeDeterminationException(String msg) { 
        super(msg); 
    }
}
