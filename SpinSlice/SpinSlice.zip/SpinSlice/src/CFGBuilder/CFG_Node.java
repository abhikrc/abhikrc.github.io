/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CFGBuilder;

import infiniteCheck.InfiniteCheckHelper;

import java.util.ArrayList;
import pmlADT.AST_Step;
import pmlAnalyser.adt.TraceListTuple;

/**
 *
 * @author lss
 */
public class CFG_Node {
    private AST_Step startStep;
    private AST_Step endStep; //if endStep == NULL, then there is only one stmnt (startStep) in this node
    private ArrayList<CFG_Node> nxt;
    private ArrayList<CFG_Node> pre;
    public boolean visited; //for traversal and print out 
    
    public boolean startNode = false;
    
    public CFG_Node(AST_Step start, AST_Step end){
        this.startStep = start;
        this.endStep = end;
        this.nxt = new ArrayList<CFG_Node>();
        this.pre = new ArrayList<CFG_Node>();
        visited = false;
    }

     public ArrayList<CFG_Node> getPre() {
        return pre;
    }

    public void setPre(ArrayList<CFG_Node> pre) {
        this.pre = pre;
    }

    public void addPre(CFG_Node parent) {
        this.pre.add(parent);
    }

    public AST_Step getEndStep() {
        return endStep;
    }

    public void setEndStep(AST_Step endStep) {
        this.endStep = endStep;
    }

    public ArrayList<CFG_Node> getNxt() {
        return nxt;
    }

    public void setNxt(ArrayList<CFG_Node> nxt) {
        this.nxt = nxt;
    }

    public void addNxt(CFG_Node nd) {
        this.nxt.add(nd);
    }

    public AST_Step getStartStep() {
        return startStep;
    }

    public void setStartStep(AST_Step startStep) {
        this.startStep = startStep;
    }

//	public int getFirstBlockedStep(ArrayList<TraceListTuple> trace, TraceListTuple pre_tlp, 
//			AST_Step blockedStep) {
//		AST_Step tmpStep = this.startStep;
//		while(!tmpStep.equals(endStep)) {
//			if(tmpStep.getTraceStepNo() != null 
//					&& InfiniteCheckHelper.getTraceTuple(tmpStep.getTraceStepNo(), trace, pre_tlp) < 0){
//				return tmpStep;
//			}
//			tmpStep = tmpStep.followsBy();
//		}
//		return null;
//	}
}
