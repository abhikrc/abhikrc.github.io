/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CFGBuilder;

import infiniteCheck.InfiniteCheckHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import pmlADT.AST_Module;
import pmlADT.AST_Process_Init;
import pmlADT.AST_Process_ProcType;
import pmlADT.AST_Program;
import pmlADT.AST_Sequence;
import pmlADT.AST_Step;
import pmlADT.AST_Step_Stmt;
import pmlADT.AST_Stmt;
import pmlADT.AST_Stmt_Atomic;
import pmlADT.AST_Stmt_Do;
import pmlADT.AST_Stmt_Goto;
import pmlADT.AST_Stmt_If;
import pmlADT.AST_Stmt_LabeledStmt;
import pmlADT.INF_TraceStep;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.ProcVarPair;
import pmlAnalyser.adt.TraceListTuple;

/**
 * 
 * @author lss
 */
public class CFG_Builder {
	// public static ArrayList<CFG_Node> tmpNodeCol = new ArrayList<CFG_Node>();
	//public static ArrayList<CFG_Node> labelNodes; /* startStep is a label */
	//private static ArrayList<String> labels; /* 1: 1 match with label nodes */
	public static HashMap<String, CFG_Node> labelNodeMap = new HashMap<String, CFG_Node>();
	public static ArrayList<CFG_Node> gotoNodes; /* endStep is a GOTO stmnt */
	public static ArrayList<CFG_Node> hasBreakNodes;
	public static HashMap<CFG_Node, CFG_Node> doAfterMap; /*
														 * map Do node with the
														 * stmnts after Do
														 * sequence
														 */
	public static ArrayList<CFG_Node> procNodes = new ArrayList<CFG_Node>();
	public static ArrayList<CFG_Node> allNodesCol = new ArrayList<CFG_Node>(); /*
																				 * store
																				 * all
																				 * nodes
																				 * for
																				 * all
																				 * processes
																				 */
	// private static AST_Step curBlockedStep = null;

	public static final int NO_BLOCKED_STEP = 1;
	public static final int NON_FAIR = 2;
	public static final int BLOCKED_STEP_FOUND = 3;

	public static HashMap<CFG_Node, ArrayList<AST_Step>> getModNodes(
			Integer varInd) {
		HashMap<CFG_Node, ArrayList<AST_Step>> modsNodeSteps = new HashMap<CFG_Node, ArrayList<AST_Step>>(
				50);
		AST_Step tmpStep = null;
		
		for(CFG_Node cn : allNodesCol){
			tmpStep = cn.getStartStep();
			if(!(tmpStep instanceof AST_Step_Stmt)){
				continue;
			}
			ArrayList<AST_Step> modSteps = new ArrayList<AST_Step>();
			while(true){
				HashSet<Integer> mods = tmpStep.getMods();
				if(mods != null && mods.contains(varInd)){
					modSteps.add(tmpStep);
				}
				if(tmpStep == cn.getEndStep()){
					break;
				}
				tmpStep = tmpStep.followsBy();
			}
			if(!modSteps.isEmpty()){
				modsNodeSteps.put(cn, modSteps);
			}
		}
		return modsNodeSteps;
	}
	
//	public static HashMap<CFG_Node, ArrayList<AST_Step>> getModNodesInTrace(Integer varInd,
//			ArrayList<TraceListTuple> trace) {
//		HashMap<CFG_Node, ArrayList<AST_Step>> modsNodeSteps = new HashMap<CFG_Node, ArrayList<AST_Step>>(
//				50);
//		AST_Step tmpStep = null;
//		
//		for(CFG_Node cn : allNodesCol){
//			tmpStep = cn.getStartStep();
//			ArrayList<AST_Step> modSteps = new ArrayList<AST_Step>();
//			while(true){
//				HashSet<Integer> mods = tmpStep.getMods();
//				if(mods != null && mods.contains(varInd)){
//					Integer traceNo = tmpStep.getTraceStepNo();
//					if (traceNo != null && getTraceTuple(traceNo, trace) != null) {
//						modSteps.add(tmpStep);
//					}
//				}
//				if(tmpStep == cn.getEndStep()){
//					break;
//				}
//				tmpStep = tmpStep.followsBy();
//			}
//			if(!modSteps.isEmpty()){
//				modsNodeSteps.put(cn, modSteps);
//			}
//		}
//			
//			return modsNodeSteps;
//	}
	

	// determine if the step is blocked
	public static AST_Step isBlockedStep(AST_Step tmpStep,
			ArrayList<TraceListTuple> trace, TraceListTuple pre_tlp) { // pre_tlp
																		// ==
																		// null
																		// if
																		// tmpStep
																		// is
																		// the
																		// startStep
		Integer traceStepNo;
		if (tmpStep instanceof AST_Step_Stmt) {
			if (tmpStep.typeOfStep() == AST_Step.TYPE_ATOMIC) {
				AST_Sequence asts = ((AST_Stmt_Atomic) ((AST_Step_Stmt) tmpStep)
						.getMainStmt()).getAtomicSequence();
				ArrayList<AST_Step> asteps = asts.getSteps();
				for (AST_Step astep : asteps) {
					if ((traceStepNo = astep.getTraceStepNo()) != null) {
						if (InfiniteCheckHelper.getTraceTuple(traceStepNo,
								trace, pre_tlp) < 0) {
							// found first blocked step
							return astep;
						}
					}
				}
			} else {
				if ((traceStepNo = tmpStep.getTraceStepNo()) != null) {
					if (InfiniteCheckHelper.getTraceTuple(traceStepNo, trace,
							pre_tlp) < 0) {
						// found first blocked step
						return tmpStep;
					}
				}
			}
		}
		return null;
	}

	// search for the first blocked step in a CFG_Node
	// return the blocked step or null
	public static AST_Step searchBlockedStepInNode(CFG_Node node,
			ArrayList<TraceListTuple> trace, TraceListTuple pre_tlp) {
		AST_Step tmpStep = node.getStartStep();
		AST_Step endStep = node.getEndStep();
		AST_Step blockedStep = null;
		while (true) {
			if ((blockedStep = isBlockedStep(tmpStep, trace, pre_tlp)) != null) {
				break;
			}
			if (tmpStep == endStep) {
				break;
			}
			tmpStep = tmpStep.followsBy();
		}
		return blockedStep;
	}

	// check if the CFG_Node is executed, return true or false and sliceSteps
	public static boolean isNodeExecuted(CFG_Node node,
			ArrayList<TraceListTuple> trace,
			HashSet<TraceListTuple> pre_tlps) {
		// p is DO/IF node
		boolean executed = false;
		int stepType = node.getEndStep().typeOfStep();
		if ((stepType == AST_Step.TYPE_DO || stepType == AST_Step.TYPE_IF) 
				&& !node.startNode) {
			ArrayList<CFG_Node> pNodes = node.getPre();
			for (CFG_Node pn : pNodes) {
				boolean ret = isNodeExecuted(pn, trace, pre_tlps);
				executed = executed || ret;
			}
		} else {
			TraceListTuple tlp = new TraceListTuple();
			if (isBlockedStep(node.getEndStep(), trace, tlp) == null) { // parent's
																		// endstep
																		// is
																		// not
																		// blocked
				pre_tlps.add(tlp);
				executed = true;
			}
		}
		return executed;
	}

	// can't handler cases where the blocked step is in another branch of DO/IF
	// loop
	public static void searchFirstBlockedSteps(CFG_Node node, ArrayList<TraceListTuple> trace, 
			HashSet<TraceListTuple> pre_tlps, HashSet<AST_Step> blockedSteps) {

		ArrayList<CFG_Node> searchNodes = new ArrayList<CFG_Node>();
		searchNodes.add(node);
		CFG_Node curNode;
		int i = 0;
		while (i < searchNodes.size()) {
			curNode = searchNodes.get(i);
			if (!curNode.visited) {
				int stepType = curNode.getStartStep().typeOfStep();
				if (stepType == AST_Step.TYPE_DO
						|| stepType == AST_Step.TYPE_IF) {
					// mark itself as visited and search if its parents
					// executed.
					HashSet<TraceListTuple> tlps = new HashSet<TraceListTuple>();
					if (isNodeExecuted(curNode, trace, tlps)) {

					} else{
						ArrayList<CFG_Node> children = curNode.getNxt();
						for(CFG_Node child : children){
							child.visited = true;
						}
						if(!curNode.startNode){
							//searchNodes.addAll(curNode.getPre());
							ArrayList<CFG_Node> pNodes = curNode.getPre();
							for(CFG_Node p : pNodes){
								if(!p.visited){
									searchNodes.add(p);
								}
							}
						}
						
					}
					curNode.visited = true;
				} else {// node is linear --> search from start till end for
						// blocked step
					TraceListTuple pre_tlp = new TraceListTuple();
					AST_Step blockedStep = searchBlockedStepInNode(curNode,
							trace, pre_tlp);

					if (blockedStep != null) {// blocked within the CFG_Node
						// curBlockedStep = blockedStep;						
						if (blockedStep == curNode.getStartStep()) {
							if(curNode.startNode){
								//curBlockedStep = blockedStep;
								blockedSteps.add(blockedStep);
							}
							else{
								// need to check whether this start step is really
								// the first blocked step
								boolean reallyBlocked = false;
								ArrayList<CFG_Node> pNodes = curNode.getPre();
								// the start step of current node is really blocked
								HashSet<TraceListTuple> sliceSteps = new HashSet<TraceListTuple>();
								for (CFG_Node p : pNodes) {
									if (isNodeExecuted(p, trace, sliceSteps)) {
										reallyBlocked = true;
									}
								}
								if (reallyBlocked) {
									// startStep really is blocked
									// update curBlockedStep and pre_tlps
									//curBlockedStep = blockedStep;
									blockedSteps.add(blockedStep);
									pre_tlps.addAll(sliceSteps);
									//break;
								} else {
									for(CFG_Node p : pNodes){
										if(!p.visited){
											searchNodes.add(p);
										}
									}
								}
							}
						} else {
							// blocked step is not the start step of a node
							// update curBlockedStep and pre_tlps
							//curBlockedStep = blockedStep;
							blockedSteps.add(blockedStep);
							pre_tlps.add(pre_tlp);
							//break;
						}
					}
					curNode.visited = true;
				}
			}
			i++;
		}
		resetVisited();
	}

	/*
	 * recursive version
	 */
	public static int BFS_Ctrl(CFG_Node topNode, // input parameter
			AST_Step targetStep, // input parameter
			ArrayList<TraceListTuple> trace, // input parameter
			HashSet<ProcStepPair> sliceList, // return parameter
			HashSet<AST_Step> relevantList, // return parameter
			HashSet<Integer> varSet) // return parameter
	{
		HashSet<AST_Step> blockedSteps = new HashSet<AST_Step>();
		HashSet<TraceListTuple> pre_tlps = new HashSet<TraceListTuple>();
		int ret = 0;
		
		searchFirstBlockedSteps(topNode, trace, pre_tlps, blockedSteps);

		// curBlockedStep == null if no step blocked, scheduling issue, non-fair
		if (blockedSteps == null || blockedSteps.size() == 0) {
			return NO_BLOCKED_STEP;
		}
		
		ret = BLOCKED_STEP_FOUND;
		
		for(AST_Step bStep : blockedSteps){
			if (bStep == targetStep) {
				ret = NON_FAIR;
			}
			if (bStep instanceof AST_Step_Stmt) {
				AST_Stmt mstmt = ((AST_Step_Stmt) bStep).getMainStmt();
				if (mstmt instanceof INF_TraceStep
						&& ((INF_TraceStep) mstmt).hasAlwaysTrueExecute()) {
					ret = NON_FAIR;
				}
			} else {
				return NO_BLOCKED_STEP;
			}
		}

		// update sliceList, previous step
		int nodeId = -1;
		for (TraceListTuple tlp : pre_tlps) {
			nodeId = tlp.getNodeID();
			if(nodeId > 0){
				sliceList
						.add(new ProcStepPair(nodeId, tlp.getSourcePID()));
			}
		}

		// update relevantList
		relevantList.addAll(blockedSteps);

		// update varSet
//		HashSet<Integer> procVarMap = curBlockedStep.getUses(); 
//		for (Integer varId : ProcVarMap) {
//			varSet.add(new ProcVarPair(varId, -1));
//		}
		for(AST_Step step : blockedSteps){
			varSet.addAll(step.getUses());
		}
		return ret;
	}


	private static void resetVisited() {
		for (int i = 0; i < allNodesCol.size(); i++) {
			allNodesCol.get(i).visited = false;
		}
	}

	public static void buildFullCFG(AST_Program astProg) {
		ArrayList<AST_Module> moduleList = astProg.getModList();
		ArrayList<CFG_Node> endNodes = new ArrayList<CFG_Node>();
		CFG_Node startNode;
		AST_Sequence seq = null;
		boolean isProc = false;
		for (int i = 0; i < moduleList.size(); i++) {
//			labelNodes = new ArrayList<CFG_Node>();
//			labels = new ArrayList<String>();
			gotoNodes = new ArrayList<CFG_Node>();
			hasBreakNodes = new ArrayList<CFG_Node>();
			doAfterMap = new HashMap<CFG_Node, CFG_Node>(50);

			isProc = false;
			AST_Module module = moduleList.get(i);
			if (module instanceof AST_Process_Init) {
				seq = ((AST_Process_Init) module).getSequence();
				isProc = true;
			} else if (module instanceof AST_Process_ProcType) {
				seq = ((AST_Process_ProcType) module).getSequence();
				isProc = true;
			}
			if (isProc) {
				startNode = createCFG(seq.getStep(0), endNodes);
				startNode.startNode = true;
				procNodes.add(startNode);
				redirectGotoLabel();
				redirectDoBreak();
			}
		}
	}

	public static String toStringCFG() {
		String s = "";
		for (int i = 0; i < procNodes.size(); i++) {
			s += toStringNode(procNodes.get(i));
			s += "\n\n\n";
		}
		return s;
	}

	public static String toStringNode(CFG_Node startNode) {
		String s = "";
		AST_Step startStep, endStep;
		if (startNode != null) {
			startStep = startNode.getStartStep();
			endStep = startNode.getEndStep();
			if (startStep.typeOfStep() == AST_Step.TYPE_DO) {
				s += " startStep["// + startStep.followsBy().toString()
						+ "](Do) --> endStep(OD) ";
			} else {
				AST_Step startFollowsBy = startStep.followsBy();
				AST_Step endFollowsBy = startNode.getEndStep().followsBy();
				s += "startStep[" + "](" + startStep.toString() + ") --> ";
				s += "endStep[" + "](" + startNode.getEndStep().toString()
						+ ") ";
			}
			// if(endStep.typeOfStep() == AST_Step.TYPE_IF){
			// System.out.println("Uses"+((AST_Step_Stmt)endStep).getUses().toString());
			// }

			if (!startNode.visited) {
				startNode.visited = true;
				ArrayList<CFG_Node> nxtNodes = startNode.getNxt();
				s += "\n// NXT={";
				for (int i = 0; i < nxtNodes.size(); i++) {
					s += toStringNode(nxtNodes.get(i));
				}
				s += "}";
			} else {
				s += " <= VISITED!!";
			}
		}

		return s;
	}

	/*
	 * return start node endNodes : the set of end statements
	 */
	private static CFG_Node createCFG(AST_Step startStep,
			ArrayList<CFG_Node> endNodes) {
		if (startStep == null) {
			return null;
		}
		AST_Step prevStep = null;
		AST_Step currStep = startStep;
		// boolean isBranch = false;
		CFG_Node startNode;

		/* repeat till end of sequence, branch, or a predicate statement */
		// while(!isBranch && currStep != null) {
		while (currStep != null) {
			int currStepType = currStep.typeOfStep();
			if (currStepType == AST_Step.TYPE_IF) {
				// isBranch = true;

				/* create a node just for this IF stmnt */
				CFG_Node ifNode = new CFG_Node(currStep, currStep);

				if (prevStep != null) {
					startNode = new CFG_Node(startStep, prevStep);
					allNodesCol.add(startNode);
					startNode.addNxt(ifNode);
					ifNode.addPre(startNode);
				} else {
					startNode = ifNode;
				}

				/* create a node for everything before and include the IF stmnt */
				// startNode = new CFG_Node(startStep, currStep); /* ss: what if
				// currStep == startStep ??*/
				// allNodesCol.add(startNode);
				ArrayList<CFG_Node> ifEndNodes = new ArrayList<CFG_Node>();

				AST_Stmt_If ifStmt = (AST_Stmt_If) ((AST_Step_Stmt) currStep)
						.getMainStmt();
				ArrayList<AST_Sequence> allOptions = ifStmt.getOptions()
						.getOptionSeqList();

				/* create a subtree for each option sequence */
				for (int i = 0; i < allOptions.size(); i++) {
					AST_Sequence optionSeq = allOptions.get(i);
					ArrayList<CFG_Node> optionNodeEnds = new ArrayList<CFG_Node>();
					CFG_Node optionStartNode = createCFG(optionSeq.getStep(0),
							optionNodeEnds);
					ifEndNodes.addAll(optionNodeEnds);
					ifNode.addNxt(optionStartNode);
					optionStartNode.addPre(ifNode);
				}

				ArrayList<CFG_Node> restEndNodes = new ArrayList();
				CFG_Node restStart = createCFG(currStep.followsBy(),
						restEndNodes);

				if (restStart == null) {
					/* nothing after this if stmnt */
					endNodes.addAll(ifEndNodes);
				} else {
					/*
					 * there is some stmnt after this if stmnt link the end of
					 * each option sequence to the subtree after this IF stmnt
					 */
					for (int i = 0; i < ifEndNodes.size(); i++) {
						CFG_Node optionNode = ifEndNodes.get(i);
						optionNode.addNxt(restStart);
						restStart.addPre(optionNode);
					}
					endNodes.addAll(restEndNodes);
				}
				return startNode;
			} else if (currStepType == AST_Step.TYPE_DO) {
				// isBranch = true;

				/* create a node just for this DO stmnt */
				CFG_Node doNode = new CFG_Node(currStep, currStep);
				allNodesCol.add(doNode);
				if (prevStep != null) {
					startNode = new CFG_Node(startStep, prevStep);
					allNodesCol.add(startNode);
					startNode.addNxt(doNode);
					doNode.addPre(startNode);
				} else {
					startNode = doNode;
				}

				ArrayList<CFG_Node> doEndNodes = new ArrayList<CFG_Node>();

				AST_Stmt_Do doStmt = (AST_Stmt_Do) ((AST_Step_Stmt) currStep)
						.getMainStmt();
				ArrayList<AST_Sequence> allOptions = doStmt.getOptions()
						.getOptionSeqList();

				/* create a subtree for each option sequence */
				for (int i = 0; i < allOptions.size(); i++) {
					AST_Sequence optionSeq = allOptions.get(i);
					ArrayList<CFG_Node> optionNodeEnds = new ArrayList<CFG_Node>();
					CFG_Node optionStartNode = createCFG(optionSeq.getStep(0),
							optionNodeEnds);
					doEndNodes.addAll(optionNodeEnds);
					doNode.addNxt(optionStartNode);
					optionStartNode.addPre(doNode);
				}
				/*
				 * link the end of each sequence to the start of DO stmnt;
				 * assume no break in sequence
				 */
				for (int i = 0; i < doEndNodes.size(); i++) {
					CFG_Node optionNode = doEndNodes.get(i);
					optionNode.addNxt(doNode);
					doNode.addPre(optionNode);
				}

				/*
				 * (temp) create a DISCONNECTED graph for the stmnts following
				 * this Do stmnt
				 */
				ArrayList<CFG_Node> restEndNodes = new ArrayList();
				CFG_Node restStart = createCFG(currStep.followsBy(),
						restEndNodes);

				// tmpNodeCol.add(restStart);
				// afterDoNodes.add(restStart);
				doAfterMap.put(doNode, restStart);
				endNodes = null;
				return startNode;
			} else if (currStepType == AST_Step.TYPE_LABEL) {// //////////
				boolean isFirst;
				startNode = null;
				if (prevStep != null) {
					/*
					 * create a node from the start to the stmnt before this
					 * labelled stmnt
					 */
					startNode = new CFG_Node(startStep, prevStep);
					allNodesCol.add(startNode);
					// isBranch = true;
					isFirst = false;
				} else {
					// isBranch = false;
					isFirst = true;
				}
				// System.out.println("label.followsBy() = "+currStep.followsBy());
				/* creat new step for labeledStmnt's main stmt */
				AST_Stmt mainStmnt = ((AST_Step_Stmt) currStep).getMainStmt();
				assert ((mainStmnt instanceof AST_Stmt_LabeledStmt));
				AST_Stmt actualStmnt = ((AST_Stmt_LabeledStmt) mainStmnt)
						.getActualStmt();
				AST_Step_Stmt actualStep = new AST_Step_Stmt();
				actualStep.setMainStmt(actualStmnt);
				actualStep.setFollowsBy(currStep.followsBy());
				actualStep.setFollowsFrom(currStep.followsFrom());
				currStep = actualStep;
				
				CFG_Node restStart = createCFG(actualStep, endNodes);
				
				labelNodeMap.put(((AST_Stmt_LabeledStmt) mainStmnt).getLabel(), restStart);
//				labels.add();				
//				labelNodes.add(restStart);

				if (isFirst) {
					startNode = restStart;
				} else {
					startNode.addNxt(restStart);
					restStart.addPre(startNode);
				}
				return startNode;
				// //System.out.println("currStep is LABEL prevStep = "+prevStep);
				// boolean isFirst = false;
				// startNode = null;
				// if(prevStep != null) {
				// /* create a node from the start to the stmnt before this
				// labelled stmnt */
				// startNode = new CFG_Node(startStep, prevStep);
				// allNodesCol.add(startNode);
				// isBranch = true;
				// }
				// // }else {
				// // /* this is the 1st stmnt in the sequence, no need to do
				// anything special */
				// // isBranch = false;
				// // prevStep = currStep;
				// // currStep = currStep.followsBy();
				// // continue;
				// // }
				// else {
				// isBranch = false;
				// isFirst = true;
				// AST_Stmt mainStmnt = ((AST_Step_Stmt)currStep).getMainStmt();
				// assert((mainStmnt instanceof AST_Stmt_LabeledStmt));
				// AST_Stmt actualStmnt = ((AST_Stmt_LabeledStmt
				// )mainStmnt).getActualStmt();
				// AST_Step_Stmt actualStep = new AST_Step_Stmt();
				// actualStep.setMainStmt(actualStmnt);
				// CFG_Node restStart = createCFG(actualStep, endNodes);
				//
				//
				// }
				//
				// /* create a subtree starting from the label
				// * should not be null
				// */
				// //ArrayList<CFG_Node> restEndNodes = new ArrayList();
				// AST_Stmt mainStmnt = ((AST_Step_Stmt)currStep).getMainStmt();
				// assert((mainStmnt instanceof AST_Stmt_LabeledStmt));
				// AST_Stmt actualStmnt = ((AST_Stmt_LabeledStmt
				// )mainStmnt).getActualStmt();
				// AST_Step_Stmt actualStep = new AST_Step_Stmt();
				// actualStep.setMainStmt(actualStmnt);
				//
				// CFG_Node restStart = createCFG(actualStep, endNodes);
				// if(!isFirst) {
				// startNode.addNxt(restStart);
				// restStart.addPre(startNode);
				// }else{
				// startNode = restStart;
				// }
				// //endNodes.addAll(restEndNodes);
				// labels.add(((AST_Stmt_LabeledStmt )mainStmnt).getLabel());
				// labelNodes.add(restStart);
				// //System.out.print("label stmnt: startStep("
				// // +restStart.getStartStep().toString()+")");
				// return startNode;
			} else if (currStepType == AST_Step.TYPE_GOTO) {
				// isBranch = true;
				// System.out.println("currStep is GOTO ");
				// if(prevStep != null){
				/* create a node from the start to the GOTO stmnt */
				startNode = new CFG_Node(startStep, currStep);
				allNodesCol.add(startNode);
				// }
				/*
				 * create a DISCONNECTED graph for the statements following this
				 * GOTO stmnt
				 */
				ArrayList<CFG_Node> restEndNodes = new ArrayList();
				CFG_Node restStart = createCFG(currStep.followsBy(),
						restEndNodes);
				// tmpNodeCol.add(restStart);
				endNodes = null;
				gotoNodes.add(startNode);
				return startNode;
			} else {
				prevStep = currStep;
				currStep = currStep.followsBy();
			}
		}// end while

		/*
		 * no ctrl/ready dependence in the whole sequence, and end of sequence
		 */
		startNode = new CFG_Node(startStep, prevStep);
		allNodesCol.add(startNode);
		endNodes.add(startNode); // only one node in the tree
		if (startStep.typeOfStep() == AST_Step.TYPE_LABEL) {
			// labelNodes.add(startNode);
		}
		if (prevStep.typeOfStep() == AST_Step.TYPE_BREAK) {
			hasBreakNodes.add(startNode);
		}
		return startNode;
	}

	private static void redirectGotoLabel() {
		String dstLabel;
		/* for GOTO and Labels */
		//System.out.println("\n\nstarting redirectGotoLabel");
		for (int i = 0; i < gotoNodes.size(); i++) {
			CFG_Node tmpNode = gotoNodes.get(i);
			AST_Stmt_Goto endStepStmt = (AST_Stmt_Goto) ((AST_Step_Stmt) (tmpNode
					.getEndStep())).getMainStmt();
			dstLabel = endStepStmt.getGotoLabel();
			
//			System.out.print("goto label = " + dstLabel);
			
			CFG_Node labelNode = labelNodeMap.get(dstLabel);
			if(labelNode != null){
//				System.out.println(" -> line = " + 
//						(((AST_Step_Stmt) (labelNode.getStartStep())).getMainStmt()).getPhyStartLine());
				tmpNode.addNxt(labelNode);
				labelNode.addPre(tmpNode);
			}
			else{
				System.out.println("ERROR: goto null");
			}
			
//			for (int j = 0; j < labels.size(); j++) {
//				String label = labels.get(j);
//				if (label.equals(dstLabel)) {
//					CFG_Node labelNode = labelNodes.get(j);
//					tmpNode.addNxt(labelNode);
//					labelNode.addPre(tmpNode);
//					return;
//				}
//			}
		}
	}

	private static void redirectDoBreak() {
		for (int i = 0; i < hasBreakNodes.size(); i++) {
			/* a node with break stmnt should have only one nxt node */
			CFG_Node currBreakNode = hasBreakNodes.get(i);
			CFG_Node breakNxtNode = currBreakNode.getNxt().get(0);

			CFG_Node afterDoNode = doAfterMap.get(breakNxtNode); // may be null
			ArrayList<CFG_Node> afterBreakNodes = new ArrayList<CFG_Node>();
			afterBreakNodes.add(afterDoNode);
			currBreakNode.setNxt(afterBreakNodes);

			ArrayList<CFG_Node> breakNodeList = new ArrayList<CFG_Node>();
			breakNodeList.add(currBreakNode);
			afterDoNode.setPre(breakNodeList);
		}
	}
}
