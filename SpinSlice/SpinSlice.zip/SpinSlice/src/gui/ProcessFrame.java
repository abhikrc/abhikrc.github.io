package gui;

import java.awt.Color;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author Choo Wei Chern
 */
public class ProcessFrame extends JFrame{
    int offset;
    int previousHighlight = 0;
    
    ArrayList<ProgramTextLine> programLines;
    JTextArea varTextArea;
    
    private final Color relevantTextColor = Color.BLACK;
    private final Color irrelevantTextColor = Color.LIGHT_GRAY;
   
    ProcessFrame(String procName, int procId, ArrayList<ProgramTextLine> oriList, int start, int end){
        super(procId + ": " + procName);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        offset = start;
        programLines = new ArrayList<ProgramTextLine>();
        
        
        setAlwaysOnTop(true);
        setLocationByPlatform(true);
        setResizable(true);
        setMinimumSize(new java.awt.Dimension(400, 400));
        setBackground(Color.white);
        setVisible(true);
        
        for (int i = start - 1; i < end; i++) {
            ProgramTextLine programTextLine = oriList.get(i);
            ProgramTextLine duplicate = programTextLine.duplicate(irrelevantTextColor);
            programLines.add(duplicate);
            panel.add(duplicate);
        }
        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBackground(Color.white);
        
        
        // Button sections
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        JButton showAllButton = new JButton("Show All");
        JButton hideButton = new JButton("Hide irrelevant");
        JButton toggleButton = new JButton("Toggle relevance");
        buttonPanel.add(showAllButton);
        buttonPanel.add(hideButton);
        buttonPanel.add(toggleButton);
        showAllButton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showAllClicked();
            }}
        );
        hideButton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hideClicked();
            }}
        );
        toggleButton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                toggleClicked();
            }}
        );
          
        
        varTextArea = new JTextArea();
        
        varTextArea.setEditable(false);
        varTextArea.setOpaque(false);
        JPanel varPanel = new JPanel();
        varPanel.add(varTextArea);
        
        JScrollPane scrollPaneVar = new JScrollPane(varPanel);
        scrollPaneVar.setMinimumSize(new java.awt.Dimension(400, 250));
            
            
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));    
        getContentPane().add(buttonPanel);
        getContentPane().add(scrollPane);
        getContentPane().add(scrollPaneVar);

    }
    
    public void showAllClicked(){
        for (int i = 0; i < programLines.size(); i++) {
            ProgramTextLine line = programLines.get(i);
            line.setVisible(true);
        }
        validate();
    }
    public void hideClicked(){
        for (int i = 0; i < programLines.size(); i++) {
            ProgramTextLine line = programLines.get(i);
            if (line.getForeground()==irrelevantTextColor){
                line.setVisible(false);
            }
        }
        validate();
    }
    public void toggleClicked(){
        for (int i = 0; i < programLines.size(); i++) {
            ProgramTextLine programTextLine = programLines.get(i);
            int selectStart = programTextLine.getSelectionStart();
            int selectEnd = programTextLine.getSelectionEnd();
            if (selectStart==selectEnd){
                continue;
            }
            Color currColor = programTextLine.getForeground();
            if (currColor == relevantTextColor){
                programTextLine.setForeground(irrelevantTextColor);
            }else{
                programTextLine.setForeground(relevantTextColor);
            }
            // clear selection
            programTextLine.setSelectionStart(0);
            programTextLine.setSelectionEnd(0);
        }   
        validate();
    }
    public void updateVarInfo(String newInfo){
        varTextArea.setText(newInfo);
    }
    public void highlightTracePosition(int line, Color c){
        if (line == 0) {
            resetTrace();
            return;
        } // Reset if line indicated is 0
        
        int index = line - offset; 
        // Check if the new trace position is visible
        // If not visible (due to hiding), do not update trace position
        if (!programLines.get(index).isVisible()){
            return;
        }
        
        programLines.get(previousHighlight).setBackground(Color.white);
        
        programLines.get(index).setBackground(c);
        previousHighlight = index;
        validate();
    }
    public void highlightRelevantLineFont(int line){
        int index = line - offset; 
        programLines.get(index).setForeground(relevantTextColor);
        validate();
    }
    
    public void resetTrace(){
        programLines.get(previousHighlight).setBackground(Color.white);
        previousHighlight = 0;
    }
}
