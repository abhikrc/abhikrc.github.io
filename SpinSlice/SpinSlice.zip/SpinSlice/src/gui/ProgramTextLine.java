package gui;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JTextField;

/**
 * A preformated JTextfield specially for displaying the Promela source
 * @author Choo Wei Chern
 */
public class ProgramTextLine extends JTextField {
    private int lineNo = 0;
    private final String TABSPACE = "    ";
 
    private String originalText;
    
    public ProgramTextLine(String text, Color defColor, int lineNo) {
        super();
        this.setFont(new Font("Courier New", Font.PLAIN, 11));
        this.setForeground(defColor);
        this.lineNo = lineNo;
        this.setOpaque(true);
        this.setBorder(BorderFactory.createEmptyBorder());
        originalText = text;
        this.setText(text);
        
        this.setMaximumSize(new Dimension(2147483647,10));
        this.setMinimumSize(new Dimension(10,10));
    }
    
    public ProgramTextLine duplicate(Color c){
        ProgramTextLine retObj = new ProgramTextLine(originalText, c, lineNo);
        return retObj;
    }
    
    @Override
    public void setText(String text) {
        // Replace the initial tabs with spaces
        originalText = text;
        
        int pos = 0;
        while (pos < text.length() && text.charAt(pos)=='\t'){
            pos++;
        }        
        int noOfTabs = pos;
        
        text = text.substring(pos);
        
        String spaces = "";
        for (int i = 0; i < noOfTabs; i++){
            spaces = spaces + TABSPACE;
        }
        
        text = spaces + text;
               
        if (lineNo != 0){
            text = "  " + lineNo + ":\t" + text;
        }
        
        super.setText(text);
    }
    
}
