/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package infiniteCheck;

import gui.ProgramTextLine;
import java.util.ArrayList;
import java.util.LinkedList;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.ProcVarPair;

/**
 *
 * @author lss
 */
public class StaticCtrlTree {
    private TreeNode root;

    public StaticCtrlTree(TreeNode root){
        this.root = root;
    }

    /*
     * Check the tree level by level,
     * if the current node is not in trace, but at least one of its children is in the trace,
     * then the current node is the "blocked" stmnt, and its variable are added to varSet
     * otherwise, the search continues. 
     */
    public ArrayList<ProcVarPair> BFS_Ctrl(ArrayList<ProcStepPair> sliceList,
            ArrayList<ProgramTextLine> relevantList){
        ArrayList<ProcVarPair> varSet = new ArrayList<ProcVarPair>();
        LinkedList<TreeNode> relNodeSet = new LinkedList<TreeNode>();
        boolean rel = false;

        relNodeSet.addAll(this.root.getChildren());
        
        TreeNode node;
        while(!relNodeSet.isEmpty()){
            node = relNodeSet.pop();
            rel = false;
            for (TreeNode child : node.getChildren()){
                ProcStepPair psp;
                if((psp = InfiniteCheckHelper.getTraceStep(child.getStmnt())) != null){//if in trace 
                    sliceList.add(psp);
                    rel = true;
                }
            }
            if(rel){
                relevantList.add(node.getStmnt()); // add THIS node to relevant set (as one of its childern are in slice)
                varSet.addAll(node.getProcVars());
            }
            else{
                relNodeSet.addAll(node.getChildren());
            }
        }
        return varSet;
    }
    
}

