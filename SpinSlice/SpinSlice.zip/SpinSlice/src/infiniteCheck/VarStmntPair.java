/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package infiniteCheck;
import pmlAnalyser.adt.ProcVarPair;

/**
 *
 * @author lss
 */
public class VarStmntPair {
    private ProcVarPair pvp;
    private String stmnt;

    public VarStmntPair(ProcVarPair pvp, String s){
        this.pvp = pvp;
        this.stmnt = s;
    }

    public ProcVarPair getProcVarPair(){
        return this.pvp;
    }

    public String getStmnt() {
        return this.stmnt;
    }
}
