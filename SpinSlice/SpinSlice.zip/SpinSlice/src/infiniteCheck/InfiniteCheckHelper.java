/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package infiniteCheck;

import gui.ProgramTextLine;
import java.util.ArrayList;
import java.util.LinkedList;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.ProcVarPair;
import pmlAnalyser.adt.TraceListTuple;

/**
 *
 * @author lss
 */
public class InfiniteCheckHelper {
    /*
     * given a stmnt in the program, return its corresponding step in the trace
     * Return null if the stmnt is not executed in the trace
     */
    public static ProcStepPair getTraceStep(ProgramTextLine stmnt) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public static int getTraceTuple(Integer traceNo, ArrayList<TraceListTuple> trace, TraceListTuple retTlp){
        //return line number
        TraceListTuple tlp;
        for(int i = 0; i<trace.size(); i++) {
            tlp = trace.get(i);
            if(trace.get(i).getNodeID() == traceNo){
                //retTlp = new TraceListTuple(tlp.getSourcePID(),tlp.getTargetPID(), tlp.getNodeID());
                retTlp.setNodeID(tlp.getNodeID());
                retTlp.setSourcePID(tlp.getSourcePID());
                retTlp.setTargetPID(tlp.getTargetPID());
                return (i+1);
            }
        }       
        return -1;
    }

    public static TraceListTuple getTraceTuple(Integer traceNo,
			ArrayList<TraceListTuple> trace) {
		TraceListTuple tlp = null;
		for (int i = 0; i < trace.size(); i++) {
			tlp = trace.get(i);
			if (trace.get(i).getNodeID() == traceNo) {
				//System.out.println(tlp.getNodeID());
				return tlp;
			}
		}
		return null;
	}
    

    /*
     * Given a stmnt appearing in the trace
     * apply data and ctrl dependency analysis on this stmnt in the trace
     * add the slicing stmnts into sliceList
     */
    static void DynamicDataCtrlDependencyAnalysis(ProcStepPair psp, ArrayList<ProcStepPair> sliceList) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /*
     * get all stmnts in the trace
     */
    static ArrayList<ProcStepPair> getAllStmmtsInTrace() {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /*
     * given a variable, return the set of stmtns in the program that modify this var
     */
    static LinkedList<ProgramTextLine> getAssignStmnts(ProcVarPair pvp) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    static LinkedList<ProgramTextLine> getAssignStmnts(String var) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /*
     * Given a stmnt in the program,
     * contruct a tree: the parent is control depedent on its childrens in the program
     * Each node in the tree is of type TreeNode
     */
    static StaticCtrlTree staticCtrlDependencyAnalysis(ProgramTextLine ptl) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
