package infiniteCheck;

import gui.ProgramTextLine;
import java.util.ArrayList;
import java.util.LinkedList;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.ProcVarPair;


public class InfiniteCheck {
    public static final int OK = 0;
    public static final int WARNING_NOT_FAIR = 1;

	public int checkWithStatic(String var, ArrayList<ProcStepPair> sliceList,
            ArrayList<ProgramTextLine> relevantList) { /* var provided by user */
//AnySlicing(Variable x, sliceSet(st), relevantSet(st))
//	Set S(p, v, st) = assignmentSt(x);	//wcc
        LinkedList<ProgramTextLine> ptlList = InfiniteCheckHelper.getAssignStmnts(var);
        ProgramTextLine ptl;
        ProcStepPair psp;
        while (!ptlList.isEmpty()){
            ptl = ptlList.pop();
            if(InfiniteCheckHelper.getTraceStep(ptl) == null){
                StaticCtrlTree sct = InfiniteCheckHelper.staticCtrlDependencyAnalysis(ptl);
                ArrayList<ProcVarPair> varSet = sct.BFS_Ctrl(sliceList, relevantList);
                if(varSet.isEmpty()){
                    sliceList = InfiniteCheckHelper.getAllStmmtsInTrace();
                    relevantList = null;
                    return WARNING_NOT_FAIR;
                }
                for (ProcVarPair pvp : varSet){
                    LinkedList<ProgramTextLine> tmpPtlList = InfiniteCheckHelper.getAssignStmnts(pvp);
                    for(ProgramTextLine tmpPtl : tmpPtlList){
                        if((psp = InfiniteCheckHelper.getTraceStep(tmpPtl)) != null){
                            InfiniteCheckHelper.DynamicDataCtrlDependencyAnalysis(psp, sliceList);
                        }
                        else{
                            ptlList.add(tmpPtl);
                        }
                    }
                }
            }
        }
        return OK;
	}
}