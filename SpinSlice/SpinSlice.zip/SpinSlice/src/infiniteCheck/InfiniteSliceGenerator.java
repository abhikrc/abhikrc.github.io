/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package infiniteCheck;

import CFGBuilder.*;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import pmlADT.AST_Step;
import pmlADT.AST_Step_Stmt;
import pmlADT.AST_Stmt;
import pmlADT.VarTable;
import pmlAnalyser.SliceGenerator;
import pmlAnalyser.adt.CriterionTuple;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.Reason;
import pmlAnalyser.adt.TraceListTuple;

/**
 * 
 * @author lss
 */
public class InfiniteSliceGenerator {
	public static final int OK = 0;
	public static final int WARNING_NOT_FAIR = 1;

	private SliceGenerator sG;
	public InfiniteSliceGenerator(InputStream codeStream) {
		sG = new SliceGenerator(codeStream);
		CFG_Builder.buildFullCFG(sG.getAST());
	}

    public InfiniteSliceGenerator(SliceGenerator sliceGenerator) {
		sG = sliceGenerator;
		CFG_Builder.buildFullCFG(sG.getAST());
	}

	public SliceGenerator getSG(){
		return sG;
	}

    public ArrayList<String> getCriterionList(String vars, ArrayList<TraceListTuple> trace){
        VarTable vt = sG.getVarTable();
		String[] varNames = vars.split(",");
        ArrayList<String> critList = new ArrayList<String>();

        for(String varName : varNames){
            Integer vIndex = vt.getIndex(varName, -1);

            if(vIndex == null){
                continue;
            }

            HashMap<CFG_Node, ArrayList<AST_Step>> modNodeSteps = CFG_Builder
                    .getModNodes(vIndex);
            Set<CFG_Node> modNodes = modNodeSteps.keySet();
            ArrayList<AST_Step> steps;

            for(CFG_Node mnode: modNodes){
                steps = modNodeSteps.get(mnode);
                for (AST_Step step : steps) {
                    Integer traceNo = step.getTraceStepNo();
                    TraceListTuple tlp = new TraceListTuple();
                    if (traceNo == null || InfiniteCheckHelper.getTraceTuple(traceNo, trace, tlp) < 0){
                        AST_Stmt stmt = ((AST_Step_Stmt)step).getMainStmt();
                        String critStr = " Line " + stmt.getPhyStartLine() + " --- " + stmt.toString();
                        critList.add(critStr);
                    }
                }
            }
        }
        return critList;
    }
	/**
	 * @param varInd
	 *            -- Integer indentifier of variable
	 * @param trace
	 *            -- counter-example list
	 * @param sliceList
	 *            -- returned sliceList
	 * @param revelentList
	 *            -- returned
	 * @param criList
	 *            -- returned
	 */
    
    public int infiniteChecking(String vars, ArrayList<TraceListTuple> trace,
			HashSet<ProcStepPair> sliceList,
			HashSet<AST_Step> relevantList, //ArrayList<CriterionTuple> criList
			HashSet<CriterionTuple> dynCriti){
        VarTable vt = sG.getVarTable();
		String[] varNames = vars.split(",");
        ArrayList<String> critList = new ArrayList<String>();

        for(String varName : varNames){
            Integer vIndex = vt.getIndex(varName, -1);

            if(vIndex == null){
                continue;
            }
            checkWithStatic(vIndex, trace, sliceList, relevantList, dynCriti);
        }
        return OK;
    }
    public int checkWithStatic(Integer varInd, ArrayList<TraceListTuple> trace,
			HashSet<ProcStepPair> sliceList,
			HashSet<AST_Step> relevantList, //ArrayList<CriterionTuple> criList
			HashSet<CriterionTuple> dynCriti //variable set for dynamic slicing
			) {
		// SliceAndReasons_List retList =
		// new SliceAndReasons_List(new ArrayList<HashSet<Reason>>(), new
		// ArrayList<ProcStepPair>());

		int ret;

		HashMap<CFG_Node, ArrayList<AST_Step>> modNodeSteps = CFG_Builder
				.getModNodes(varInd);
		Set<CFG_Node> modNodes = modNodeSteps.keySet();
		ArrayList<AST_Step> steps;
		HashSet<Integer> varSet = new HashSet<Integer>();

		for(CFG_Node mnode: modNodes){
			steps = modNodeSteps.get(mnode);
			for (AST_Step step : steps) {
				int line = -1;
				try{
					line = ((AST_Step_Stmt)step).getMainStmt().getPhyEndLine();
				}catch(Exception e){
				}
				System.out.println("\nSearching result for step " + step.toString()
						+ " @ line " + line + ":");

				Integer traceNo = step.getTraceStepNo();

				TraceListTuple tlp = new TraceListTuple();
				int lineNo = 0;
				if (traceNo != null && (lineNo = InfiniteCheckHelper.getTraceTuple(traceNo, trace, tlp)) > 0) {
					sliceList.add(new ProcStepPair(tlp.getNodeID(), tlp.getSourcePID()));
					dynCriti.add(new CriterionTuple(tlp.getSourcePID(), lineNo, tlp.getNodeID()));
					System.out.println("Step in trace");
				}
//				TraceListTuple tlp;
//				if (traceNo != null && (tlp = InfiniteCheckHelper.getTraceTuple(traceNo, trace)) != null) {
//					sliceList.add(new ProcStepPair(tlp.getNodeID(), tlp.getSourcePID()));
//					System.out.println("Step in trace");
//				}
				else{
					//TODO: need to handle return values of CFG_Builder.BFS_Ctrl()
					ret = CFG_Builder.BFS_Ctrl(mnode, step, trace, sliceList, relevantList, varSet);
					switch(ret){
					case CFG_Builder.BLOCKED_STEP_FOUND:
						System.out.println("BLOCKED_STEP_FOUND");
						break;
					case CFG_Builder.NO_BLOCKED_STEP:
						System.out.println("NO_BLOCKED_STEP");
						break;
					case CFG_Builder.NON_FAIR:
						System.out.println("NON_FAIR");
						break;
					}
				}
			}
		}

		for(Integer var : varSet){
			checkWithStatic(var, trace, sliceList, relevantList, dynCriti);//, criList);
		}

		return OK;
	}

//	public int checkWithStatic(Integer varInd, ArrayList<TraceListTuple> trace,
//			HashSet<ProcStepPair> sliceList,
//			HashSet<AST_Step> relevantList, //ArrayList<CriterionTuple> criList
//			ArrayList<CriterionTuple> dynCriti //variable set for dynamic slicing
//			) {
//		// SliceAndReasons_List retList =
//		// new SliceAndReasons_List(new ArrayList<HashSet<Reason>>(), new
//		// ArrayList<ProcStepPair>());
//
//		int ret;
//
//		HashMap<CFG_Node, ArrayList<AST_Step>> modNodeSteps = CFG_Builder
//				.getModNodes(varInd);
//		Set<CFG_Node> modNodes = modNodeSteps.keySet();
//		ArrayList<AST_Step> steps;
//		HashSet<Integer> varSet = new HashSet<Integer>();
//
//		for(CFG_Node mnode: modNodes){
//			steps = modNodeSteps.get(mnode);
//			for (AST_Step step : steps) {
//				int line = -1;
//				try{
//					line = ((AST_Step_Stmt)step).getMainStmt().getPhyEndLine();
//				}catch(Exception e){
//				}
//				System.out.println("\nSearching result for step " + step.toString()
//						+ " @ line " + line + ":");
//
//				Integer traceNo = step.getTraceStepNo();
//
//				TraceListTuple tlp = new TraceListTuple();
//				int lineNo = 0;
//				if (traceNo != null && (lineNo = InfiniteCheckHelper.getTraceTuple(traceNo, trace, tlp)) > 0) {
//					sliceList.add(new ProcStepPair(tlp.getNodeID(), tlp.getSourcePID()));
//					dynCriti.add(new CriterionTuple(tlp.getSourcePID(), lineNo, tlp.getNodeID()));
//					System.out.println("Step in trace");
//				}
////				TraceListTuple tlp;
////				if (traceNo != null && (tlp = InfiniteCheckHelper.getTraceTuple(traceNo, trace)) != null) {
////					sliceList.add(new ProcStepPair(tlp.getNodeID(), tlp.getSourcePID()));
////					System.out.println("Step in trace");
////				}
//				else{
//					//TODO: need to handle return values of CFG_Builder.BFS_Ctrl()
//					ret = CFG_Builder.BFS_Ctrl(mnode, step, trace, sliceList, relevantList, varSet);
//					switch(ret){
//					case CFG_Builder.BLOCKED_STEP_FOUND:
//						System.out.println("BLOCKED_STEP_FOUND");
//						break;
//					case CFG_Builder.NO_BLOCKED_STEP:
//						System.out.println("NO_BLOCKED_STEP");
//						break;
//					case CFG_Builder.NON_FAIR:
//						System.out.println("NON_FAIR");
//						break;
//					}
//				}
//			}
//		}
//
//		for(Integer var : varSet){
//			checkWithStatic(var, trace, sliceList, relevantList, dynCriti);//, criList);
//		}
//
//		return OK;
//	}

}
