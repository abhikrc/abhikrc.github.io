/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package infiniteCheck;

import gui.ProgramTextLine;
import java.util.ArrayList;
import pmlAnalyser.adt.ProcVarPair;

/**
 *
 * @author lss
 */
public class TreeNode {
    //private int procId;
    private ProgramTextLine stmnt; /* the stmnt in the program*/
    private ArrayList<ProcVarPair> procVars; /* if the stmnt is an assignment, then it is the var. that it modifies
                                              * if the stmnt is a guarded stmnt, then it is the vars that are used
                                              * (eg. (a>0 && c==0))
                                              */

    private TreeNode parent; 
    private ArrayList<TreeNode> children; /* the stmtns in the program that the current stmnt is ctrl dependent on */

    public TreeNode()
    {
        procVars = new ArrayList<ProcVarPair>();
        children = new ArrayList<TreeNode>();
    }

    public ArrayList<ProcVarPair> getProcVars() {
        return procVars;
    }

    public void setProcVars(ArrayList<ProcVarPair> procVars) {
        this.procVars = procVars;
    }

    public void addProcVar(ProcVarPair procVar) {
        this.procVars.add(procVar);
    }

    public void setStmnt(ProgramTextLine stmnt) {
        this.stmnt = stmnt;
    }

    public ProgramTextLine getStmnt(){
        return this.stmnt;
    }

    public void setParent(TreeNode tn){
        this.parent = tn;
    }

    public TreeNode getParent(){
        return this.parent;
    }

    public void addChild(TreeNode c) {
        this.children.add(c);
    }

    public ArrayList<TreeNode> getChildren(){
        return this.children;
    }
}
