package pmlADT;

import java.util.ArrayList;

/**
 * Node representing a series of declarations for a single variable type.
 * eg: bool x,y,z;
 * @author Choo Wei Chern
 */
public class AST_Decl extends AST_Node {
    private String varType;
    private ArrayList<AST_IVar> ivList;

    public AST_Decl() {
        ivList = new ArrayList<AST_IVar>();
    }
    
    public void addIVar(AST_IVar para){ ivList.add(para); }

    public ArrayList<AST_IVar> getIvList() { return ivList; }
    public String getVarType() {return varType; }
    public void setVarType(String varType) { this.varType = varType; }
 
    @Override
    public String toString(){
        String retStr = varType + " ";
        int size = ivList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + ivList.get(i).toString();
            if (i<size-1) retStr = retStr + ", ";
        }
        return retStr;
    }    
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
       
	retStr = retStr + varType + " ";
        int size = ivList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + ivList.get(i).toString_Debug(c, l);
            if (i<size-1) retStr = retStr + ", ";
        }
        
        return retStr;
    }
}
