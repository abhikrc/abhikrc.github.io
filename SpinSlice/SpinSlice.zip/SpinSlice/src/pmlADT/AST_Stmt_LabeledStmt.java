package pmlADT;

import java.util.HashSet;

/**
 * Node representing a labelled statement.
 * @author Choo Wei Chern
 */
public class AST_Stmt_LabeledStmt extends AST_Stmt {
    private String label;
    private AST_Stmt actualStmt;
    private AST_Node encParent;

    public AST_Stmt_LabeledStmt(StmtTable stmtT, int line, AST_Node enc) {
       stmtT.InsertStmt(this, line);
       encParent = enc;
    }

    public AST_Stmt getActualStmt() { return actualStmt; }
    public void setActualStmt(AST_Stmt para) { actualStmt = para; }
    public String getLabel() { return label; }
    public void setLabel(String para) { label = para; }
    
    @Override
    public String toString(){
        return label + ": " + actualStmt.toString() ;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
    
	retStr = retStr + label + ": " + actualStmt.toString_Debug(c, l) ;
        
        return retStr;
    }
    
    @Override
    public HashSet<INF_TraceStep> getTraceStepsForCriterion() {
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        retObj.addAll(actualStmt.getTraceStepsForCriterion());
        return retObj;
    }
    
    @Override
    public AST_Node getEnclosingParent() {
        return encParent;
    }
}
