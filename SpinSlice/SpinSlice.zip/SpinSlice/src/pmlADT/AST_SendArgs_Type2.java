package pmlADT;

import java.util.HashSet;

/**
 * Node representing a series of send arguments in the form:
 * any_expr '(' arg_lst ')'
 * @author Choo Wei Chern
 */
public class AST_SendArgs_Type2 extends AST_SendArgs {
    private AST_Expr_AnyExpr expr;
    private AST_ArgList argList;

    public AST_SendArgs_Type2() {}

    public AST_ArgList getArgList() { return argList; }

    public void setArgList(AST_ArgList para) { argList = para; }

    public AST_Expr_AnyExpr getExpr() { return expr; }

    public void setExpr(AST_Expr_AnyExpr para) { this.expr = para; }
    
    @Override
    public String toString(){
        return expr.toString() + "(" + argList.toString() + ")";
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
     
	retStr = retStr + expr.toString_Debug(c, l) + "(" + argList.toString_Debug(c, l) + ")";
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(argList.getUses());
        retObj.addAll(expr.getUses());
        return retObj;
    }

    @Override
    public boolean willSpawnNewProcess() {
        return argList.willSpawnNewProcess() || expr.willSpawnNewProcess();
    }
    
}
