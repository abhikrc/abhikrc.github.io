package pmlADT;

import java.util.HashSet;

/**
 * Node representing a receive argument in the form of EVAL.
 * @author Choo Wei Chern
 */
public class AST_RecvArg_Eval extends AST_RecvArg {
    private AST_VarRef arg;
    public AST_RecvArg_Eval() {}
    
    public void setArg(AST_VarRef para){ arg= para; }
    public AST_VarRef getArg(){ return arg; }
    
    @Override
    public String toString(){
        return "eval("+ arg.toString() + ")";
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
      
	retStr = retStr + "eval("+ arg.toString_Debug(c, l) + ")";
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(arg.getUses());
        retObj.add(arg.getVarInd());
        return retObj;
    }

    @Override
    public HashSet<Integer> getMods() {
        return new HashSet<Integer>();
    }
    
    
}
