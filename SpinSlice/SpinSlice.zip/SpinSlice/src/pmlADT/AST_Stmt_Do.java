package pmlADT;

import java.util.HashSet;
import pmlADT.StmtTable;

/**
 * Node representing a DO statement.
 * @author Choo Wei Chern
 */
public class AST_Stmt_Do extends AST_Stmt {
    private AST_Options options;
    private AST_Node encParent;
    
    public AST_Stmt_Do(StmtTable stmtT, int line, AST_Node enc) {
       stmtT.InsertStmt(this, line);
       encParent = enc;
    }

    public AST_Options getOptions() { return options; }
    public void setOptions(AST_Options options) { this.options = options; }

    @Override
    public String toString(){
        return "do\n" + options.toString() + "od";
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr + "do\n" + options.toString_Debug(c, l) + "od";
        
        return retStr;
    }
    
    @Override
    public HashSet<INF_TraceStep> getTraceStepsForCriterion() {
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        retObj.addAll(options.getTraceStepsForCriterion());
        return retObj;
    }
    
    @Override
    public AST_Node getEnclosingParent() {
        return encParent;
    }
}
