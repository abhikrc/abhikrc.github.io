package pmlADT;

/**
 * Abstract base class representing an "any_expression". 
 * @author Choo Wei Chern
 */
public abstract class AST_Expr_AnyExpr extends AST_Expr {
}
