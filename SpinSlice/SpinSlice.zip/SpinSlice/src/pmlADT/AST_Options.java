package pmlADT;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing a series of optional sequences. 
 * @author Choo Wei Chern
 */
public class AST_Options extends AST_Node {
    private ArrayList<AST_Sequence> optionSeqList;

    public AST_Options() {        
        optionSeqList = new ArrayList<AST_Sequence>();
    }
    
    public void addOption(AST_Sequence para) { this.optionSeqList.add(para);}
    public ArrayList<AST_Sequence> getOptionSeqList(){ return optionSeqList; }
    
    @Override
    public String toString(){
        String retStr = "::";
        int size = optionSeqList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + optionSeqList.get(i).toString();
            if (i<size-1) retStr = retStr + "::";
        }
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
       
	retStr = retStr + "::";
        int size = optionSeqList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + optionSeqList.get(i).toString_Debug(c, l);
            if (i<size-1) retStr = retStr + "::";
        }
        
        return retStr;
    }
    
    
    public HashSet<INF_TraceStep> getTraceStepsForCriterion(){
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        
        // For each option, get the guard statement.
        for (int i = 0; i < optionSeqList.size(); i++) {
            AST_Sequence seq = optionSeqList.get(i);
            retObj.addAll(seq.getTraceStepsForCriterion());
        }
        
        return retObj;
    }
}
