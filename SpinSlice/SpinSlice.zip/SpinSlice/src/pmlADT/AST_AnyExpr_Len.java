package pmlADT;

import java.util.HashSet;

/**
 * Node representing a len "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_Len extends AST_Expr_AnyExpr {
    private AST_VarRef vr;
    
    public AST_AnyExpr_Len() {}
    
    public void setVarRef(AST_VarRef para){ vr = para; }
    public AST_VarRef getVarRef(){ return vr; }
    
    @Override
    public String toString(){
        return vr.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
             
	retStr = retStr + vr.toString_Debug(c,l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(vr.getUses());
        retObj.add(vr.getVarInd());
        return retObj;
    }
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    @Override
    public boolean willSpawnNewProcess() {
        return false;
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return null;
    }
}
