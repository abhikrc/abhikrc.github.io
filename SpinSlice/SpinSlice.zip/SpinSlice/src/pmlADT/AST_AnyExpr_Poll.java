package pmlADT;

import java.util.HashSet;

/**
 * Node representing a poll "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_Poll extends AST_Expr_AnyExpr{
    private AST_VarRef channel;
    private String pollType;
    private AST_RecvArgList arglist;
    
    public AST_AnyExpr_Poll() {}

    public String getPollType() { return pollType; }
    public void setPollType(String pollType) { this.pollType = pollType; }
    public void setPolledChannel(AST_VarRef para){ channel = para; }
    public void setRecvArgList(AST_RecvArgList para){ arglist = para; }
    public AST_VarRef getPolledChannel(){ return channel; }
    public AST_RecvArgList getRecvArgList(){ return arglist; }
    
    @Override
    public String toString(){
        return channel.toString() + pollType + arglist.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
    
	retStr = retStr + channel.toString_Debug(c,l) + pollType + arglist.toString_Debug(c,l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(channel.getUses());
        retObj.add(channel.getVarInd());
        return retObj;
    }
    
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    @Override
    public boolean willSpawnNewProcess() {
        return false;
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return null;
    }
}
