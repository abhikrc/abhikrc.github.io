package pmlADT;

import java.util.Hashtable;
import java.util.ArrayList;
import pmlException.PmlNodeDeterminationException;

/**
 * Stores the collection of AST_Stmt.
 * @author Choo Wei Chern
 */
public class StmtTable { 
    ArrayList<AST_Stmt> stmtList;
    Hashtable<Integer, ArrayList<AST_Stmt>> lineToStmtHash;

    public StmtTable() {
        stmtList = new ArrayList<AST_Stmt>();
        lineToStmtHash = new Hashtable<Integer, ArrayList<AST_Stmt>>();
    }

    public void InsertStmt(AST_Stmt para, int line){
        stmtList.add(para);
        
        ArrayList<AST_Stmt> tmpList = lineToStmtHash.get(line);
        if (tmpList == null){
            ArrayList<AST_Stmt> newList = new ArrayList<AST_Stmt>();
            newList.add(para);
            lineToStmtHash.put(line, newList);
        }else{
            tmpList.add(para);
        }
    }
    public AST_Stmt getStmt(int line) throws PmlNodeDeterminationException {
        ArrayList<AST_Stmt> possibleList = lineToStmtHash.get(line);
       
       
        if (possibleList.size() == 0){
            throw new PmlNodeDeterminationException("No steps found at line "+line);
        }
        else if (possibleList.size() > 1){
            throw new PmlNodeDeterminationException("Multiple ambiguous steps found at line "+line+". Separation into multiple lines is needed.");
        }
        
        return possibleList.get(0);
    }
}
