package pmlADT;

/**
 * Node representing a single variable declaration unit.
 * @author Choo Wei Chern
 */
public class AST_IVar extends AST_Node {
    // ivar    : name [ '[' const ']' ] [ '=' any_expr | '=' ch_init ]
    
    private String varName;
    private AST_Const arrayConst;
    private AST_Expr_AnyExpr initExpr;
    private AST_ChInit initChan;

    public AST_IVar() {
    }

    public AST_ChInit getInitChan() { return initChan; }
    public void setInitChan(AST_ChInit initChan) { this.initChan = initChan; }
    public AST_Expr_AnyExpr getInitExpr() { return initExpr; }
    public void setInitExpr(AST_Expr_AnyExpr initExpr) { this.initExpr = initExpr; }
    public AST_Const getSize() { return arrayConst; }
    public void setSize(AST_Const para) { arrayConst = para; }
    public String getVarName() { return varName; }
    public void setVarName(String varName) { this.varName = varName; }

    @Override
    public String toString(){
        String retStr = varName;
        if (arrayConst!=null) retStr = retStr + "[" + arrayConst.toString() + "]";
        if (initExpr!=null) retStr = retStr + "=" + initExpr.toString();
        if (initChan!=null) retStr = retStr + "=" + initChan.toString();
        
        return retStr;
    }        
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
       
	retStr = retStr + varName;
        if (arrayConst!=null) retStr = retStr + "[" + arrayConst.toString_Debug(c, l) + "]";
        if (initExpr!=null) retStr = retStr + "=" + initExpr.toString_Debug(c, l);
        if (initChan!=null) retStr = retStr + "=" + initChan.toString_Debug(c, l);
        
        return retStr;
    }
}
