package pmlADT;

/**
 * Abstract base class representing an assignment statement.
 * @author Choo Wei Chern
 */
public abstract class AST_Stmt_Assign extends AST_Stmt implements INF_TraceStep{
    
}
