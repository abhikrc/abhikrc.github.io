package pmlADT;
import java.util.Hashtable;
import java.util.ArrayList;

/**
 * Stores the collection of processtype declarations as well as the mapping to an integer.
 * @author Choo Wei Chern
 */
public class ProcTypeTable {
    private Integer procNo = 1; // zero used for special init proc
    Hashtable<String, Integer> procNameHash;
    ArrayList<String> procNameList;
    ArrayList<AST_Module_Process> procList;
    
    public ProcTypeTable() {
        procNameHash = new Hashtable<String, Integer>();
        procNameList = new ArrayList<String>();
        procList = new ArrayList<AST_Module_Process>();
        
        procNameList.add(":init:");   // First element reserved for "init"
        procList.add(null);         // First element reserved for "init"
        procNameHash.put(":init:", 0); // First element reserved for "init"
    }
    public void setInit(AST_Module_Process proc){
        procList.remove(0);
        procList.add(0, proc);
    }
    public Integer addProc(AST_Module_Process proc){
        Integer retVal = procNo;
        procNameHash.put(proc.getProcName(), procNo);
        procNameList.add(proc.getProcName());
        procList.add(proc);
        
        procNo++;
        return retVal;
    }
    
    public String getProcName(Integer no){
        return procNameList.get(no);
    }
    
    public Integer getProcNo(String name){
        return procNameHash.get(name);
    }
    
    public AST_Module_Process getProcType(int no){
        return procList.get(no);
    }
    public AST_Module_Process getProcType(String name){
        int no = getProcNo(name);
        return getProcType(no);
    }
}
