package pmlADT;

import java.util.HashSet;

/**
 * Node representing a receive argument in the form of a constant.
 * @author Choo Wei Chern
 */
public class AST_RecvArg_Const extends AST_RecvArg{
    private AST_Const cons;
    private boolean negated;
    public AST_RecvArg_Const(){}

    public void setConst(AST_Const para){ cons = para; }
    public AST_Const getConst(){ return cons; }
    public boolean isNegated() { return negated; }
    public void setNegated(boolean negated) { this.negated = negated; }
    
    @Override
    public String toString(){
        String retStr = "";
        if (negated) retStr = "-";
        return retStr + cons.toString();
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr + "";
        if (negated) retStr = "-";
        retStr = retStr + cons.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        return new HashSet<Integer>();
    }
    
    // added
    @Override
    public HashSet<Integer> getMods(){
        return new HashSet<Integer>();
    }
    
}
