package pmlADT;

import java.util.HashSet;

/**
 * Node representing a receive argument in the form of a variable.
 * @author Choo Wei Chern
 */
public class AST_RecvArg_VarRef extends AST_RecvArg{
    private AST_VarRef arg;
    public AST_RecvArg_VarRef() {}
    
    public void setArg(AST_VarRef para){ arg= para; }
    public AST_VarRef getArg(){ return arg; }
    
    @Override
    public String toString(){
        return arg.toString();
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr + arg.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        //removed: retObj.add(arg.getVarInd());
        retObj.addAll(arg.getUses());
        return retObj;
    }

    @Override
    public HashSet<Integer> getMods() {
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.add(arg.getVarInd());
        return retObj;
    }
}
