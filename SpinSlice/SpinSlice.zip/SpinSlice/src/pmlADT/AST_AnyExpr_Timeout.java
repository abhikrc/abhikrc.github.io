package pmlADT;

import java.util.HashSet;

/**
 * Node representing a timeout "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_Timeout extends AST_Expr_AnyExpr {
    public AST_AnyExpr_Timeout() {}
    
    @Override
    public String toString(){
        return "timeout";
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
    
	retStr = retStr + "timeout";
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        return retObj;
    }
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    @Override
    public boolean willSpawnNewProcess() {
        return false;
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return null;
    }
}
