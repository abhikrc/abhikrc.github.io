package pmlADT;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing a step in the form of an exclusive receive declaration.
 * @author Choo Wei Chern
 */
public class AST_Step_XR extends AST_Step {
    private ArrayList<AST_VarRef> vrList;
    public AST_Step_XR() {
        vrList = new ArrayList<AST_VarRef>();
    }
    
    public void addVarRef(AST_VarRef para){ vrList.add(para); }
    public ArrayList<AST_VarRef> getVarRefList(){ return vrList; }
    
    @Override
    public String toString(){
        String retStr = "xr ";
        int size = vrList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + vrList.get(i).toString();
            if (i<size-1) retStr = retStr + ", ";
        }
        return retStr;
    }      
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
        retStr = retStr + "xr ";
        int size = vrList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + vrList.get(i).toString_Debug(c, l);
            if (i<size-1) retStr = retStr + ", ";
        }
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getMods() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public HashSet<Integer> getUses() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int typeOfStep() {
        return TYPE_OTHERS;
    }
    
    @Override
    public Integer getTraceStepNo() {
        return null;
    }
}
