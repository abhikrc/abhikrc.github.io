package pmlADT;

import java.util.HashSet;

/**
 * Node representing an atomic statement.
 * @author Choo Wei Chern
 */
public class AST_Stmt_Atomic extends AST_Stmt {
    private AST_Sequence atomicSequence;
    private AST_Node encParent;

    public AST_Stmt_Atomic(StmtTable stmtT, int line, AST_Node enc) {
       stmtT.InsertStmt(this, line);
       encParent = enc;
    }

    public AST_Sequence getAtomicSequence(){ return atomicSequence; }
    public void setAtomicSequence(AST_Sequence para){ atomicSequence = para; }
    
    @Override
    public String toString(){
        return "atomic{\n" + atomicSequence.toString() + "}";
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
    
	retStr = retStr + "atomic{\n" + atomicSequence.toString_Debug(c, l) + "}";
        
        return retStr;
    }

    @Override
    public HashSet<INF_TraceStep> getTraceStepsForCriterion() {
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        retObj.addAll(atomicSequence.getTraceStepsForCriterion());
        return retObj;
    }
    
    @Override
    public AST_Node getEnclosingParent() {
        return encParent;
    }
 
}
