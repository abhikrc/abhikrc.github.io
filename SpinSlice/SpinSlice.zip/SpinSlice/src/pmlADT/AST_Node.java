package pmlADT;

//import java.util.BitSet;

/**
 * Abstract base class for all AST nodes.
 * @author Choo Wei Chern
 */
public abstract class AST_Node {
    protected int phy_startline;
    protected int phy_endline;
    
    public void setLines(int first, int last){ phy_startline=first; phy_endline=last; }
    public void setPhyStartLine(int para){ phy_startline=para; }
    public void setPhyEndLine(int para){ phy_endline=para;  }
    public int getPhyStartLine(){ return phy_startline; }
    public int getPhyEndLine(){ return phy_endline; }
    
    @Override
    public abstract String toString();
    
    public abstract String toString_Debug(boolean c, boolean l);
}
