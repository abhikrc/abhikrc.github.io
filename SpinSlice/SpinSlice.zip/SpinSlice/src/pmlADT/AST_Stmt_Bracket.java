package pmlADT;

import java.util.HashSet;

/**
 * Node representing a bracketted statement of sequence: {sequence}.
 * @author Choo Wei Chern
 */
public class AST_Stmt_Bracket extends AST_Stmt {
    private AST_Sequence contentSequence;
    private AST_Node encParent;

    public AST_Stmt_Bracket(StmtTable stmtT, int line, AST_Node enc) {
       stmtT.InsertStmt(this, line);
       encParent = enc;
    }

    public AST_Sequence getContentSequence() { return contentSequence; }
    public void setContentSequence(AST_Sequence para) { contentSequence = para;}
        
    @Override
    public String toString(){
        return contentSequence.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
     
	retStr = retStr + contentSequence.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<INF_TraceStep> getTraceStepsForCriterion() {
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        retObj.addAll(contentSequence.getTraceStepsForCriterion());
        return retObj;
    }
    
    @Override
    public AST_Node getEnclosingParent() {
        return encParent;
    }
}
