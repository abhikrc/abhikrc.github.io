package pmlADT;

import java.util.ArrayList;

/**
 * Node representing a seriess of variables declaration.
 * e.g: bool x,y,z; byte a,b,c;
 * @author Choo Wei Chern
 */
public class AST_DeclList extends AST_Node {
    private ArrayList<AST_Decl> declList;

    public AST_DeclList() {
        declList = new ArrayList<AST_Decl>();
    }

    public void addDecl(AST_Decl para){ declList.add(para); }
    public ArrayList<AST_Decl> getDeclList() { return declList; }

    @Override
    public String toString(){
        String retStr = "";
        int size = declList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + declList.get(i).toString();
            if (i<size-1) retStr = retStr + "; ";
        }
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
        int size = declList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + declList.get(i).toString_Debug(c, l);
            if (i<size-1) retStr = retStr + "; ";
        } 
        
        return retStr;
    }
}
