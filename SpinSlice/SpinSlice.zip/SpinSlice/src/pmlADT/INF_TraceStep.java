package pmlADT;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * An interface to identify nodes that represent a step in the dynamic trace
 * @author Choo Wei Chern
 */
public interface INF_TraceStep {
    // Standard accessor/mutators
    public int getPhyStartLineNo();
    public int getPhyEndLineNo();
    public void setTraceStepNo(int no);
    public int getTraceStepNo();
    
    // Methods required for data/interference dependence checking
    public HashSet<Integer> getUses();
    public HashSet<Integer> getMods();
    
    // Methods required for ready dependence checking
    public boolean hasAlwaysTrueExecute();
    
    // Methods required for checking run parameters (related to data dependence)
    public boolean willSpawnNewProcess();
    public AST_AnyExpr_Run extractRun();
    
    // Method to get the guard condition it is control dependent on
    public INF_TraceStep getDirectControlDependent();
    public ArrayList<INF_TraceStep> getAllControlDependent();
    
}
