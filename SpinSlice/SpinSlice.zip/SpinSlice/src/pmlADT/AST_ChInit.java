package pmlADT;

import java.util.ArrayList;

/**
 * Node representing a channel initialisation.
 * @author Choo Wei Chern
 */
public class AST_ChInit extends AST_Node {
    private AST_Const size;
    private ArrayList<String> typeList;

    public AST_ChInit() {
        this.typeList = new ArrayList<String>();
    }

    public AST_Const getSize() {
        return size;
    }
    public void setSize(AST_Const size) {
        this.size = size;
    }
    public ArrayList<String> getTypeList() {
        return typeList;
    }
    public void addType(String para) {
        this.typeList.add(para);
    }
    
    @Override
    public String toString(){
        String retStr = "[" + size.toString() + "] of {";
        int lsize = typeList.size();
        for (int i = 0; i < lsize; i++){
            retStr = retStr + typeList.get(i).toString();
            if (i<lsize-1) retStr = retStr + ", ";
        }
        retStr = retStr + "}";
        return retStr;
    }    
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr +  "[" + size.toString() + "] of {";
        int lsize = typeList.size();
        for (int i = 0; i < lsize; i++){
            retStr = retStr + typeList.get(i).toString();
            if (i<lsize-1) retStr = retStr + ", ";
        }
        retStr = retStr + "}";
        
        return retStr;
    }
}
