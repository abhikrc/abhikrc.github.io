package pmlADT;

import java.util.HashSet;

/**
 * Node representing a unary operation "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_Unarop extends AST_Expr_AnyExpr {
    private AST_Expr_AnyExpr operand;
    private String operation;
    
    public AST_AnyExpr_Unarop() {}
    
    public void setOperand(AST_Expr_AnyExpr para){ operand = para; }    
    public void setOperation(String para){ operation = para; }
    public AST_Expr_AnyExpr getOperand(){ return operand; }
    public String getOperation(){ return operation; }
    
    @Override
    public String toString(){
        return operation + operand.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
        retStr = retStr + operation + operand.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(operand.getUses());
        return retObj;
    }
    
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    @Override
    public boolean willSpawnNewProcess() {
        return operand.willSpawnNewProcess();
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return operand.extractRun();
    }
}
