package pmlADT;

import java.util.HashSet;

/**
 * Abstract base class for steps.
 * @author Choo Wei Chern
 */
public abstract class AST_Step extends AST_Node {

    
    ///Section below ADDED TO SUPPORT CFG GENERATION + LIVENESS CHECKING
    private AST_Step followsFrom;
    private AST_Step followsBy;
    private boolean isGuard = false;


    /**
     * @author lss
     */
    public void setFollowsFrom(AST_Step followsFrom){
        this.followsFrom = followsFrom;
    }

    /**
     * @author lss
     */
    public void setFollowsBy(AST_Step followsBy){
        this.followsBy = followsBy;
    }


    public boolean isIsGuard() {
        return isGuard;
    }

    public void setIsGuard(boolean isGuard) {
        this.isGuard = isGuard;
    }
   
    /**
     * Constructs the follows relation for a pair of steps.
     * a=1; b=1; a=1 will be the step, b=1 will be the followingStep
     * @param step the earlier step. can be null (for start of sequence)
     * @param followingStep the later step. can be null (for end of sequence)
     */
    public static void linkFollows(AST_Step step, AST_Step followingStep){
        // Contruct forward relation
        if (step != null){
            step.followsBy = followingStep;
        }
        
        // Construct backwards relation
        if (followingStep !=null){
            followingStep.followsFrom = step;
        }
    }
    
    /** Get the step "above" this.
     * e.g a=1; b=1;
     * (b=1).followsFrom() will return (a=1)
     *@return the step of which this step is following, if any. otherwise return null
     */
    public AST_Step followsFrom(){
        return followsFrom;
    }

    /** Get the step "above" this.
     * e.g a=1; b=1;
     * (a=1).followsFrom() will return (b=1)
     *@return the step of which follows this step, if any. otherwise return null
     */
    public AST_Step followsBy(){
        return followsBy;
    }
    
    public static int TYPE_OTHERS = 0;
    public static int TYPE_GOTO = 1;
    public static int TYPE_BREAK = 2;
    public static int TYPE_IF = 3;
    public static int TYPE_DO = 4;
    public static int TYPE_LABEL = 5;
    public static int TYPE_Expr = 6;
    public static int TYPE_ATOMIC = 7;
    //public static int TYPE_UNLESS = 5;//to be considered in future
    
    /** Returns the type of step, represented by an integer.
     * @return the int representation of the type of step.
     */
    public abstract int typeOfStep();
    
    /**
     * Get the variables used by this step, if any
     * @return a hashset of var index (referenced in VarTable) of the variables used
     */
    public abstract HashSet<Integer> getUses();
    /**
     * Get the variables used by this step, if any
     * @return a hashset of var index (referenced in VarTable) of the variables used
     */
    public abstract HashSet<Integer> getMods();
    
    /**
     * Get the trace step number, for reconciliation with the trace list
     * @return the trace number, if any. returns null if this step can NEVER appear in any trace (for example the do stmt construct, declList etc)
     */
    public abstract Integer getTraceStepNo();
}
