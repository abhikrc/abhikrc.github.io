package pmlADT;

import java.util.HashSet;

/**
 *  Node representing a bracketted expression.
 * @author Choo Wei Chern
 */
public class AST_Expr_Bracket extends AST_Expr {
    private AST_Expr content;
    public AST_Expr_Bracket() {}
    
    public void setContentExpr(AST_Expr para){ content = para ;}
    public AST_Expr getContentExpr(){ return content; } 
    
    @Override
    public String toString(){
        return "(" + content.toString() + ")" ;
    } 
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr + "(" + content.toString_Debug(c, l) + ")" ;
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(content.getUses());
        return retObj;
    }
    
    @Override
    public boolean isAlwaysTrue(){
        return content.isAlwaysTrue();
    }

    @Override
    public boolean willSpawnNewProcess() {
        return content.willSpawnNewProcess();
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return content.extractRun();
    }
}
