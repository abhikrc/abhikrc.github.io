package pmlADT;

/**
 * Node representing a proctype.
 * @author Choo Wei Chern
 */
public class AST_Process_ProcType extends AST_Module_Process {
    private int initialActive;
    private String procName;
    private AST_DeclList declList;
    private int priority;
    private AST_Expr enablingExpr;
    private AST_Sequence sequence;

    public AST_Process_ProcType() {
        initialActive = 0;
        priority = 1;
    }

    public AST_DeclList getDeclList() { return declList; }
    public void setDeclList(AST_DeclList declList) { this.declList = declList; }
    public AST_Expr getEnablingExpr() { return enablingExpr; }
    public void setEnablingExpr(AST_Expr enablingExpr) { this.enablingExpr = enablingExpr; }
    public int getInitialActive() { return initialActive; }
    public void setInitialActive(int initalActive) { this.initialActive = initalActive; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public String getProcName() { return procName; }
    public void setProcName(String procName) { this.procName = procName; }
    public AST_Sequence getSequence() { return sequence; }
    public void setSequence(AST_Sequence sequence) { this.sequence = sequence; }
    
    @Override
    public String toString(){
        String retStr;
        if (initialActive==0) retStr = "";
        else retStr = "active[" + initialActive + "] "; 
        retStr = retStr + procName + "(";
        if (declList!=null) retStr = retStr + declList.toString();
        retStr = retStr + ") ";
        retStr = retStr + "priority " + priority + " ";
        if (enablingExpr!=null) retStr = retStr + "provided (" + enablingExpr.toString() + ")";
        retStr = retStr + "{\n" + sequence.toString() + "}";
            
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
        if (initialActive==0) retStr = retStr + "";
        else retStr = "active[" + initialActive + "] "; 
        retStr = retStr + procName + "(";
        if (declList!=null) retStr = retStr + declList.toString_Debug(c, l);
        retStr = retStr + ") ";
        retStr = retStr + "priority " + priority + " ";
        if (enablingExpr!=null) retStr = retStr + "provided (" + enablingExpr.toString_Debug(c, l) + ")";
        retStr = retStr + "{\n" + sequence.toString_Debug(c, l) + "}";
        
        return retStr;
    }
}
