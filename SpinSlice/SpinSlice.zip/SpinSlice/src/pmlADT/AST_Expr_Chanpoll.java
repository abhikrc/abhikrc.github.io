package pmlADT;

import java.util.HashSet;

/**
 * Node representing a channel poll expression.
 * @author Choo Wei Chern
 */
public class AST_Expr_Chanpoll extends AST_Expr {
    private String pollType;
    private AST_VarRef chan;
    public AST_Expr_Chanpoll() {}
    
    public String getPollType() { return pollType; }
    public void setPollType(String pollType) { this.pollType = pollType; }
    public void setChannel(AST_VarRef para){ chan = para; }
    public AST_VarRef getChannel(){ return chan; }
    
    @Override
    public String toString(){
        return pollType + " " + chan.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
       
	retStr = retStr + pollType + " " + chan.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(chan.getUses());
        retObj.add(chan.getVarInd());
        return retObj;
    }
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    @Override
    public boolean willSpawnNewProcess() {
        return false;
    }

    @Override
    public AST_AnyExpr_Run extractRun() {
        return null;
    }
    
    
}
