package pmlADT;

import java.util.HashSet;

/**
 * Node representing an expression of the forms: expr1 && expr2, or expr1 || expr2
 * @author Choo Wei Chern
 */
public class AST_Expr_AndOr extends AST_Expr {
    private String type;
    private AST_Expr lExpr;
    private AST_Expr rExpr;
    
    public AST_Expr_AndOr() {}
    
    public void setAndOrType(String para){ type = para; }
    public void setLeftExpr(AST_Expr para){ lExpr = para; }
    public void setRighttExpr(AST_Expr para){ rExpr = para; }
    public String getAndOrType(){ return type; }
    public AST_Expr getLeftExpr(){ return lExpr; }
    public AST_Expr getRightExpr(){ return rExpr; }
    
    @Override
    public String toString(){
        return lExpr.toString() + " " + type + " " + rExpr.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
          
	retStr = retStr + lExpr.toString_Debug(c, l) + " " + type + " " + rExpr.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(lExpr.getUses());
        retObj.addAll(rExpr.getUses());
        return retObj;
    }
    
  @Override
    public boolean isAlwaysTrue(){
        if (type.compareTo("&&")==0){
            return (lExpr.isAlwaysTrue() && rExpr.isAlwaysTrue());
        }
        return (lExpr.isAlwaysTrue() || rExpr.isAlwaysTrue());
    }

    @Override
    public boolean willSpawnNewProcess() {
        return (lExpr.willSpawnNewProcess() || rExpr.willSpawnNewProcess());
    }

    @Override
    public AST_AnyExpr_Run extractRun() {
        AST_AnyExpr_Run left = lExpr.extractRun();
        AST_AnyExpr_Run right = rExpr.extractRun();
        
        if (left == null){
            return right;
        }
        else {
            if (right == null){
                return left;
            }   
        }
        throw new RuntimeException("Multiple run expressions in a single statement unsupported");
    }    
}
