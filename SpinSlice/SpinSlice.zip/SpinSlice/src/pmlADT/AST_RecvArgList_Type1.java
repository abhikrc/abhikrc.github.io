package pmlADT;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing a series of receive arguments in the form:
 * recv_arg [ ',' recv_arg ] * 
 * @author Choo Wei Chern
 */
public class AST_RecvArgList_Type1 extends AST_RecvArgList{
    private ArrayList<AST_RecvArg> ral;
    public AST_RecvArgList_Type1() { 
        ral = new ArrayList<AST_RecvArg>();
    }
    
    public void addRecvArg(AST_RecvArg para){
        ral.add(para);
    }
    
    public ArrayList<AST_RecvArg> getRecvArgList(){ return ral; }
    
    @Override
    public String toString(){
        String retStr = "";
        int size = ral.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + ral.get(i).toString();
            if (i<size-1) retStr = retStr + ", ";
        }
        return retStr;
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
         
	retStr = retStr + "";
        int size = ral.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + ral.get(i).toString_Debug(c, l);
            if (i<size-1) retStr = retStr + ", ";
        }
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        for (int i = 0; i < ral.size(); i++) {
            AST_RecvArg tmp = ral.get(i);
            retObj.addAll(tmp.getUses());
        }
        return retObj;
    }

    @Override
    public HashSet<Integer> getMods() {
        HashSet<Integer> retObj = new HashSet<Integer>();
        for (int i = 0; i < ral.size(); i++) {
            AST_RecvArg tmp = ral.get(i);
            retObj.addAll(tmp.getMods());
        }
        return retObj;
    }
    
}
