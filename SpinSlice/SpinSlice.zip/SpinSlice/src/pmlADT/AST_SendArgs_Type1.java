package pmlADT;

import java.util.HashSet;

/**
 * Node representing a series of send arguments in the argument list form.
 * @author Choo Wei Chern
 */
public class AST_SendArgs_Type1 extends AST_SendArgs {
    private AST_ArgList argList;

    public AST_SendArgs_Type1() {}

    public AST_ArgList getArgList() { return argList; }
    public void setArgList(AST_ArgList para) { argList = para; }
    
    @Override
    public String toString(){
        return argList.toString();
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
      
	retStr = retStr + argList.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(argList.getUses());
        return retObj;
    }

    @Override
    public boolean willSpawnNewProcess() {
        return argList.willSpawnNewProcess();
    }
    
    
}
