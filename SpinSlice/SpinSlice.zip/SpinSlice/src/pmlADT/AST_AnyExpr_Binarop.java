package pmlADT;

import java.util.HashSet;

/**
 * Node representing a binary operation of 2 "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_Binarop extends AST_Expr_AnyExpr {
    private AST_Expr_AnyExpr lOperand;
    private AST_Expr_AnyExpr rOperand;
    private String operation;
    
    public AST_AnyExpr_Binarop() {}
    
    public void setLeftOperand(AST_Expr_AnyExpr para){ lOperand = para; }
    public void setRightOperand(AST_Expr_AnyExpr para){ rOperand = para; }
    public void setOperation(String para){ operation = para; }
    public AST_Expr_AnyExpr getLeftOperand(){ return lOperand; }
    public AST_Expr_AnyExpr getRightOperand(){ return rOperand; }
    public String getOperation(){ return operation; }
    
    
    @Override
    public String toString(){
        return lOperand.toString() + operation + rOperand.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
        
        retStr = retStr + lOperand.toString_Debug(c,l) + operation + rOperand.toString_Debug(c,l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(lOperand.getUses());
        retObj.addAll(rOperand.getUses());
        return retObj;
    }
   
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    
    @Override
    public boolean willSpawnNewProcess() {
        return (lOperand.willSpawnNewProcess() || rOperand.willSpawnNewProcess());
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        AST_AnyExpr_Run left = lOperand.extractRun();
        AST_AnyExpr_Run right = rOperand.extractRun();
        
        if (left == null){
            return right;
        }
        else {
            if (right == null){
                return left;
            }   
        }
        throw new RuntimeException("Multiple run expressions in a single statement unsupported");
    
    }
}
