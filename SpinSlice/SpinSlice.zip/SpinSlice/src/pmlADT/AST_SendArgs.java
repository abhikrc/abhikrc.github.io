package pmlADT;

import java.util.HashSet;

/**
 * Abstract base class for send arguments.
 * @author Choo Wei Chern
 */
public abstract class AST_SendArgs extends AST_Node {
    public abstract HashSet<Integer> getUses();
    public abstract boolean willSpawnNewProcess();
}
