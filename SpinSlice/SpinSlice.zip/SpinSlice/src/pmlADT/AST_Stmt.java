package pmlADT;

import java.util.HashSet;

/**
 * Abstract base class representing a statement.
 * @author Choo Wei Chern
 */
public abstract class AST_Stmt extends AST_Node {
    /**
     * Some statements (not in the form of tracesteps, like if/do) can still appear in the end of the trace.
     * These statements usually indicate the next-to-be executed lines of a process.
     * As this statements can be crucial in the slice (for instance it is a deadlock), there is a need to convert extract from these statements the possible tracesteps that can be used as a criterion.
     * @return a hashset of traceStep nodes representing the possible criterion.
     */
    public abstract HashSet<INF_TraceStep> getTraceStepsForCriterion();
    /**
     * To facilitate visibility in output, enclosing structures like if/do should also be displayed as relevant if they have a child in the relevant slice.
     * This method helps returns the enclosing structure for a given statement.
     * @return the AST_Node representing this statement's parent.
     */
    public abstract AST_Node getEnclosingParent();
}
