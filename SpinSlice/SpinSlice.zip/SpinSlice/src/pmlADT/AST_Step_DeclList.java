package pmlADT;

import java.util.HashSet;

/**
 * Node representing a step in the form of declarations.
 * @author Choo Wei Chern
 */
public class AST_Step_DeclList extends AST_Step {
    private AST_DeclList declList;
    public AST_Step_DeclList() {    }
 
    public void setDeclList(AST_DeclList para){ declList = para; }
    public AST_DeclList getDeclList(){ return declList; }
    
    @Override
    public String toString(){
        return declList.toString();
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
         
	retStr = retStr + declList.toString_Debug(c, l);
        
        return retStr;
    }

    @Override
    public HashSet<Integer> getMods() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public HashSet<Integer> getUses() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int typeOfStep() {
        return TYPE_OTHERS;
    }

    @Override
    public Integer getTraceStepNo() {
        return null;
    }
    
}
