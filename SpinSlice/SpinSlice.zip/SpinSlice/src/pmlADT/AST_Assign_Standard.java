package pmlADT;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing a standard assignment statement.
 * @author Choo Wei Chern
 */
public class AST_Assign_Standard extends AST_Stmt_Assign{
    private AST_VarRef lhs;
    private AST_Expr_AnyExpr rhs;

    private int traceStepNo;
    
    private AST_Node encParent;
    
    public AST_Assign_Standard(TraceStepNodesTable st, StmtTable stmtT, int line, AST_Node enc) {
        st.InsertNode(this, line);
        stmtT.InsertStmt(this, line);
        encParent = enc;
    }
    public AST_VarRef getLhs() { return lhs; }
    public void setLhs(AST_VarRef lhs) { this.lhs = lhs; }
    public AST_Expr_AnyExpr getRhs() { return rhs; }
    public void setRhs(AST_Expr_AnyExpr rhs) { this.rhs = rhs; }    
    
    @Override
    public String toString(){
        return lhs.toString() + "=" + rhs.toString();
    }    
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
        retStr = retStr + lhs.toString_Debug(c, l) + "=" + rhs.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public int getPhyStartLineNo() { return getPhyStartLine(); }
    @Override
    public int getPhyEndLineNo() { return getPhyEndLine(); }
    @Override
    public void setTraceStepNo(int no) { traceStepNo = no; }
    @Override
    public int getTraceStepNo() { return traceStepNo; }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(rhs.getUses());
        retObj.addAll(lhs.getUses());
        return retObj;
    }
    
    @Override
    public HashSet<Integer> getMods(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.add(lhs.getVarInd());
        return retObj;
    }
    @Override
    public boolean hasAlwaysTrueExecute(){
        return true;
    }
    
    @Override
    public boolean willSpawnNewProcess() {
        return rhs.willSpawnNewProcess();
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return rhs.extractRun();
    }
    
    @Override
    public HashSet<INF_TraceStep> getTraceStepsForCriterion() {
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        retObj.add(this);
        return retObj;
    }
    
    @Override
    public AST_Node getEnclosingParent() {
        return encParent;
    }
    
    @Override
    public ArrayList<INF_TraceStep> getAllControlDependent() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public INF_TraceStep getDirectControlDependent() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
