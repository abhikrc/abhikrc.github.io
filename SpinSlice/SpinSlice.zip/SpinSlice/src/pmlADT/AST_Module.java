package pmlADT;

/**
 * Abstract base for modules.
 * @author Choo Wei Chern
 */
public abstract class AST_Module extends AST_Node {
}
