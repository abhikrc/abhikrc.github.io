package pmlADT;

import java.util.HashSet;

/**
 * Node representing a step in the form of statement.
 * @author Choo Wei Chern
 */
public class AST_Step_Stmt extends AST_Step {
    private AST_Stmt mainStmt;
    private AST_Stmt unlessStmt; // Optional
    
    public AST_Step_Stmt() {}
    
    public void setMainStmt(AST_Stmt para){ mainStmt = para; }
    public void setUnlessStmt(AST_Stmt para){ unlessStmt = para; }
    public AST_Stmt getMainStmt(){ return mainStmt; }
    public AST_Stmt getUnlessStmt(){ return unlessStmt; }
    
    @Override
    public String toString(){
        String retStr = mainStmt.toString();
        if (unlessStmt!=null) retStr = retStr + " unless " + unlessStmt.toString();
        return retStr;
    }
    
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
          
	retStr = retStr + mainStmt.toString_Debug(c, l);
        if (unlessStmt!=null) retStr = retStr + " unless " + unlessStmt.toString_Debug(c, l);
        
        return retStr;
    }

    @Override
    public HashSet<Integer> getMods() {
        if (mainStmt instanceof INF_TraceStep){
            return ((INF_TraceStep)mainStmt).getMods();
        }
        else return null;
    }

    @Override
    public HashSet<Integer> getUses() {
        if (mainStmt instanceof INF_TraceStep){
            return ((INF_TraceStep)mainStmt).getUses();
        }
        else return null;
    }

    @Override
    public int typeOfStep() {
        if (mainStmt instanceof AST_Stmt_Break) return TYPE_BREAK;
        else if (mainStmt instanceof AST_Stmt_If) return TYPE_IF;
        else if (mainStmt instanceof AST_Stmt_Do) return TYPE_DO;
        else if (mainStmt instanceof AST_Stmt_Goto) return TYPE_GOTO;
        else if (mainStmt instanceof AST_Stmt_LabeledStmt) return TYPE_LABEL;
        else if (mainStmt instanceof AST_Stmt_Expr) return TYPE_Expr;
        else if (mainStmt instanceof AST_Stmt_Atomic) return TYPE_ATOMIC;
        else return TYPE_OTHERS;
    }
    
    @Override
    public Integer getTraceStepNo() {
         if (mainStmt instanceof INF_TraceStep){
            return ((INF_TraceStep)mainStmt).getTraceStepNo();
        }
        else return null;
    }
}
