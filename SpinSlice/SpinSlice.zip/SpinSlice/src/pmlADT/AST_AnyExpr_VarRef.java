package pmlADT;

import java.util.HashSet;

/**
 * Node representing a var reference "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_VarRef extends AST_Expr_AnyExpr{
    private AST_VarRef ref;
    public AST_AnyExpr_VarRef(){}
    
    public void setReference(AST_VarRef para){ ref = para; }
    public AST_VarRef getReference(){ return ref; }
    
    @Override
    public String toString(){
        return ref.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
          
	retStr = retStr + ref.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.add(ref.getVarInd());
        retObj.addAll(ref.getUses());
        return retObj;
    }
    
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    @Override
    public boolean willSpawnNewProcess() {
        return false;
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return null;
    }
}
