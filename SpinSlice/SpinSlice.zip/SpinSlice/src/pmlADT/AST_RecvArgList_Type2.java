package pmlADT;

import java.util.HashSet;

/**
 * Node representing a series of receive arguments in the form:
 * recv_arg '(' recv_argList ')'
 * @author Choo Wei Chern
 */
public class AST_RecvArgList_Type2 extends AST_RecvArgList{
    private AST_RecvArg mainRecvArg;
    private AST_RecvArgList subRecvArgList;

    public AST_RecvArgList_Type2() {}

    public AST_RecvArg getMainRecvArg() { return mainRecvArg; }
    public void setMainRecvArg(AST_RecvArg para) { mainRecvArg = para; }
    public AST_RecvArgList getSubRecvArgList() { return subRecvArgList; }
    public void setSubRecvArgList(AST_RecvArgList para) { subRecvArgList = para; }
    
    @Override
    public String toString(){
        return mainRecvArg + "(" + subRecvArgList.toString() + ")";
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr + mainRecvArg + "(" + subRecvArgList.toString_Debug(c, l) + ")";
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(mainRecvArg.getUses());
        retObj.addAll(subRecvArgList.getUses());
        return retObj;
    }
    
    @Override
    public HashSet<Integer> getMods(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(mainRecvArg.getMods());
        retObj.addAll(subRecvArgList.getMods());
        return retObj;
    }
}
