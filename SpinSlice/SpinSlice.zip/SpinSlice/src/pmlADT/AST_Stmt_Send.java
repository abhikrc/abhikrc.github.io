package pmlADT;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing a send statement.
 * @author Choo Wei Chern
 */
public class AST_Stmt_Send extends AST_Stmt implements INF_TraceStep{
    public static final int FIFO_SEND = 1;
    public static final int SORTED_SEND = 2;
    
    private int sendType;
    private AST_VarRef channel;
    private AST_SendArgs sendArgs;

    private int traceStepNo;
    private AST_Node encParent;
    
    public AST_Stmt_Send(TraceStepNodesTable st, StmtTable stmtT, int line, AST_Node enc) {
        st.InsertNode(this, line);
        stmtT.InsertStmt(this, line);
        encParent = enc;
    }
    
    public AST_VarRef getChannel() { return channel; }
    public void setChannel(AST_VarRef para) { channel = para; }

    public AST_SendArgs getSendArgs() { return sendArgs; }
    public void setSendArgs(AST_SendArgs para) { sendArgs = para; }

    public int getSendType() { return sendType; }
    public void setSendType(int para) { sendType = para; }
    
    @Override
    public String toString(){
        String retStr = channel.toString();
        switch(sendType){
            case FIFO_SEND: retStr = retStr + "!"; break;
            case SORTED_SEND: retStr = retStr + "!!"; break;
        }
        retStr = retStr + sendArgs.toString();
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
	retStr = retStr + channel.toString_Debug(c, l);
        switch(sendType){
            case FIFO_SEND: retStr = retStr + "!"; break;
            case SORTED_SEND: retStr = retStr + "!!"; break;
        }
        retStr = retStr + sendArgs.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public int getPhyStartLineNo() { return getPhyStartLine(); }
    @Override
    public int getPhyEndLineNo() { return getPhyEndLine(); }
    @Override
    public void setTraceStepNo(int no) { traceStepNo = no; }
    @Override
    public int getTraceStepNo() { return traceStepNo; }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(sendArgs.getUses());
        retObj.addAll(channel.getUses()); 
        // NOTE: channel.getUses() will return the variables used as array elements
        // for e.g  "ch[i]!x", the uses variables are only i and x. (ch is not being used)
        return retObj;
    }
    
    @Override
    public HashSet<Integer> getMods(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.add(channel.getVarInd());
        return retObj;
    }
    @Override
    public boolean hasAlwaysTrueExecute(){
        return false;
    }
    
    @Override
    public boolean willSpawnNewProcess() {
        return sendArgs.willSpawnNewProcess();
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        throw new RuntimeException("Run expressions within a send statement not supported");
    }
    
    @Override
    public HashSet<INF_TraceStep> getTraceStepsForCriterion() {
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        retObj.add(this);
        return retObj;
    }
    
    @Override
    public AST_Node getEnclosingParent() {
        return encParent;
    }
    
    @Override
    public ArrayList<INF_TraceStep> getAllControlDependent() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public INF_TraceStep getDirectControlDependent() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
