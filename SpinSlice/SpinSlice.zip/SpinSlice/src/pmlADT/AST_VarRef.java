package pmlADT;

import java.util.HashSet;

/**
 *  Node representing a variable.
 * @author Choo Wei Chern
 */
public class AST_VarRef extends AST_Node {
    // varref	: name [ '[' any_expr ']' ] [ '.' varref ]
    
    private String varName;
    private Integer varInd;
    
    private AST_Expr_AnyExpr arrayExpr;
    private AST_VarRef typedefChild; // 
    
    /** Creates a new instance of AST_VarRef */
    public AST_VarRef() {}
    
    public void setArrayExpr(AST_Expr_AnyExpr para){ arrayExpr = para; }
    public void setTypeDefChild(AST_VarRef para){ typedefChild = para; }
    public void setVarName(String para) { varName = para; }

    public Integer getVarInd() { return varInd; }
    public void setVarInd(Integer varInd) { this.varInd = varInd; }
    
    public AST_Expr_AnyExpr getArrayExpr() { return arrayExpr; }
    public AST_VarRef getTypedefChild() { return typedefChild; }
    public String getVarName() { return varName; }
    
    @Override
    public String toString(){
        String retStr = varName;
        if (arrayExpr!=null) retStr = retStr + "[" +arrayExpr.toString() + "]";
        if (typedefChild!=null) retStr = retStr + "." + typedefChild.toString();
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
       
	retStr = retStr + varName;
        if (arrayExpr!=null) retStr = retStr + "[" +arrayExpr.toString_Debug(c, l) + "]";
        if (typedefChild!=null) retStr = retStr + "." + typedefChild.toString_Debug(c, l);
        
        return retStr;
    }
    
    /** Return the uselist of variables in the arrayElements/typedefChild expressions */
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        if (arrayExpr != null) retObj.addAll(arrayExpr.getUses());
        if (typedefChild != null) retObj.addAll(typedefChild.getUses());
        return retObj;
    }
}
