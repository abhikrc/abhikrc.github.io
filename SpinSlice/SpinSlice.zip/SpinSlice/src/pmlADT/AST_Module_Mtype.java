package pmlADT;

import java.util.ArrayList;
/**
 * Node representing a series of Mtype declarations.
 * @author Choo Wei Chern
 */
public class AST_Module_Mtype extends AST_Module {
    private ArrayList<String> symbolicNameList;

    public AST_Module_Mtype() {
        this.symbolicNameList = new ArrayList<String>();
    }

    public ArrayList<String> getSymbolicNameList() { return symbolicNameList; }
    public void addSymbolicName(String para) {
        symbolicNameList.add(para);
    }    
    
    @Override
    public String toString(){
        String retStr = "mtype = ";
        int size = symbolicNameList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + symbolicNameList.get(i).toString();
            if (i<size-1) retStr = retStr + ", ";
        }
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
        int size = symbolicNameList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + symbolicNameList.get(i);
            if (i<size-1) retStr = retStr + ", ";
        } 
        
        return retStr;
    }
}
