package pmlADT;

/**
 * Node representing a constant.
 * @author Choo Wei Chern
 */
public class AST_Const extends AST_Node  {
    private String stringValue;
    
    /** Creates a new instance of AST_Const */
    public AST_Const(String para) {
        stringValue = para;
    }
    
    public String getString(){ return stringValue; }
    public int getIntValue(){
        if (stringValue.compareTo("true")==0){
            return 1;
        }
        if (stringValue.compareTo("false")==0){
            return 0;
        }
        if (stringValue.compareTo("skip")==0){
            return 1;
        }
        return Integer.parseInt(stringValue);
    }
    
    
    @Override
    public String toString(){
        return stringValue;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr + stringValue;
        
        return retStr;
    }
    
    public boolean isTrue(){
        return (getIntValue()!=0);
    }
}
