package pmlADT;

import java.util.Hashtable;
import java.util.ArrayList;
import pmlException.PmlNodeDeterminationException;

/**
 * Stores the collection of nodes that can represent a step in the dynamic trace as well as the mapping to an integer.
 * @author Choo Wei Chern
 */
public class TraceStepNodesTable { 
    ArrayList<INF_TraceStep> nodeList;
    Hashtable<Integer, ArrayList<INF_TraceStep>> lineToNodeHash;

    public TraceStepNodesTable() {
        nodeList = new ArrayList<INF_TraceStep>();
        lineToNodeHash = new Hashtable<Integer, ArrayList<INF_TraceStep>>();
    }

    public void InsertNode(INF_TraceStep para, int line){
        nodeList.add(para);
        
        ArrayList<INF_TraceStep> tmpList = lineToNodeHash.get(line);
        if (tmpList == null){
            ArrayList<INF_TraceStep> newList = new ArrayList<INF_TraceStep>();
            newList.add(para);
            lineToNodeHash.put(line, newList);
        }else{
            tmpList.add(para);
        }
        int nodeNo = nodeList.indexOf(para);
        para.setTraceStepNo(nodeNo);
    }
    public int getNodeNumber(AST_Stmt paraStmt, int line) throws PmlNodeDeterminationException {
        ArrayList<INF_TraceStep> possibleList = lineToNodeHash.get(line);
       
        int matchCount = 0;
        int retVal = -1;
        
        for (int i = 0; i < possibleList.size(); i++) {
            INF_TraceStep possible = possibleList.get(i);
            if (possible.getClass() == paraStmt.getClass()){
                matchCount++;
                retVal = possible.getTraceStepNo();
            }else if(paraStmt instanceof pmlADT.AST_Assign_Standard){
                // Exceptions: i++ in Pml will be converted to i=(i+1) in the trace
                // Thus special case checking is done for decrements/increments
                if (possible instanceof pmlADT.AST_Assign_Decr ||
                    possible instanceof pmlADT.AST_Assign_Incr)
                {
                    matchCount++;
                    retVal = possible.getTraceStepNo();                    
                }
            }
        }
        
        if (matchCount == 0){
            throw new PmlNodeDeterminationException("No steps found at line "+line);
        }
        else if (matchCount > 1){
            throw new PmlNodeDeterminationException("Multiple ambiguous steps found at line "+line+". Separation into multiple lines is needed.");
        }
        
        return retVal;
    }
    public INF_TraceStep getStmt(int no){
        return nodeList.get(no);
    }
    
    public int getSize(){
        return nodeList.size();
    }
    
        
    
}
