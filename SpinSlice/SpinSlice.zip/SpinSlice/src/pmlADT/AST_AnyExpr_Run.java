package pmlADT;

import java.util.HashSet;

/**
 * Node representing a run "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_Run extends AST_Expr_AnyExpr{
    private String procName;
    private AST_ArgList runArgs;
    private AST_Const runPriority;

    public AST_AnyExpr_Run() {}

    public String getProcName() { return procName; }
    public void setProcName(String procName) { this.procName = procName; }
    public AST_ArgList getRunArgs() { return runArgs; }
    public void setRunArgs(AST_ArgList runArgs) { this.runArgs = runArgs; }
    public AST_Const getRunPriority() { return runPriority; }
    public void setRunPriority(AST_Const runPriority) { this.runPriority = runPriority; }
 
    @Override
    public String toString(){
        String retStr =  "run " + procName+"(" ;
        if(runArgs!=null) retStr = retStr  + runArgs.toString() ;
        retStr = retStr + ")";
        if (runPriority!=null) retStr = retStr + " priority " + runPriority.toString();
           
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
        retStr =  "run " + procName+"(" ;
        if(runArgs!=null) retStr = retStr  + runArgs.toString() ;
        retStr = retStr + ")";
        
        if (runPriority!=null) retStr = retStr + " priority " + runPriority.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    /*
     * While a run expr will "use" other variables, the actual value return from this expression
     * is almost unrelated to what has been "used".
     * The return value of a run will be a process ID or a zero if this run cannot be executed due to limits in processes.
     * Thus it is decided that this run will return an empty set of "used" variables
     */
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        return retObj;
    }
    
    @Override
    public boolean isAlwaysTrue(){
        return true;
    }
    @Override
    public boolean willSpawnNewProcess() {
        return true;
    }

    @Override
    public AST_AnyExpr_Run extractRun() {
        return this;
    }
}
