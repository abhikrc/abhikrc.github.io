package pmlADT;

import java.util.ArrayList;
/**
 * Node representing the program. This also serves as the head of the entire syntax tree.
 * @author Choo Wei Chern
 */
public class AST_Program extends AST_Node {
    private ArrayList<AST_Module> modList;

    public AST_Program() {
        modList = new ArrayList<AST_Module>();
    }

    public ArrayList<AST_Module> getModList() { return modList; }
    public void addModule(AST_Module para){ modList.add(para); }
    
    @Override
    public String toString(){
        String retStr = "";
        int size = modList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + modList.get(i).toString();
            retStr = retStr + "\n";
        }
        return retStr;
    }    
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
     
        int size = modList.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + modList.get(i).toString_Debug(c, l);
            retStr = retStr + "\n";
        }
        
        return retStr;
    }
}
