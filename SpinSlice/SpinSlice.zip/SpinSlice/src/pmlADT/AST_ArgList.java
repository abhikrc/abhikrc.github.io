package pmlADT;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing an argument list.
 * @author Choo Wei Chern
 */
public class AST_ArgList extends AST_Node {
    private ArrayList<AST_Expr_AnyExpr> listOfAnyExpr;

    public AST_ArgList() {
        listOfAnyExpr = new ArrayList<AST_Expr_AnyExpr>();
    }
    
    public void addAnyExpr(AST_Expr_AnyExpr para){
        listOfAnyExpr.add(para);
    }

    public ArrayList<AST_Expr_AnyExpr> getListOfAnyExpr() {
        return listOfAnyExpr;
    }
    
    @Override
    public String toString(){
        String retStr = "";
        int size = listOfAnyExpr.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + listOfAnyExpr.get(i).toString();
            if (i<size-1) retStr = retStr + ", ";
        }
        return retStr;
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
           
	int size = listOfAnyExpr.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + listOfAnyExpr.get(i).toString_Debug(c, l);
            if (i<size-1) retStr = retStr + ", ";
        } 
        
        return retStr;
    }
    
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        for (int i = 0; i < listOfAnyExpr.size(); i++) {
            AST_Expr_AnyExpr tmp = listOfAnyExpr.get(i);
            retObj.addAll(tmp.getUses());
        }
        return retObj;
    }
    
    public boolean willSpawnNewProcess(){
        for (int i = 0; i < listOfAnyExpr.size(); i++) {
            AST_Expr_AnyExpr tmp = listOfAnyExpr.get(i);
            if (tmp.willSpawnNewProcess()) return true;
        }
        return false;
    }
    
    public AST_AnyExpr_Run extractRun(){
        boolean alreadyHasRun = false;
        AST_AnyExpr_Run retObj = null;
        for (int i = 0; i < listOfAnyExpr.size(); i++) {
            AST_Expr_AnyExpr tmp = listOfAnyExpr.get(i);
            retObj = tmp.extractRun();
            if (retObj != null){
                if (alreadyHasRun){
                    throw new RuntimeException("Multiple run expressions in a single statement unsupported");
                }
                alreadyHasRun = true;
            }
        }
        return retObj;
    }
}

