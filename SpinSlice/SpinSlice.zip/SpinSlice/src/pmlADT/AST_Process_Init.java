package pmlADT;

/**
 * Node representing the init proctype.
 * @author Choo Wei Chern
 */
public class AST_Process_Init extends AST_Module_Process {
    private int priority;
    private AST_Sequence sequence;

    public AST_Process_Init() { priority = 1 ; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public AST_Sequence getSequence() { return sequence; }
    public void setSequence(AST_Sequence sequence) { this.sequence = sequence; }

    @Override
    public String getProcName() {
        return "::init::";
    }
    
    @Override
    public String toString(){
        return "init priority " + priority + " {\n" + sequence.toString() + "}"; 
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
	retStr = retStr + "init priority " + priority + " {\n" + sequence.toString_Debug(c, l) + "}"; 
        
        return retStr;
    }
}
