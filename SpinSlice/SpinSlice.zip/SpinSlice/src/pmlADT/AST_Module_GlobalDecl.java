package pmlADT;

/**
 * Node representing a series of global declarations.
 * @author Choo Wei Chern
 */
public class AST_Module_GlobalDecl extends AST_Module {
    private AST_DeclList globalDeclList;

    public AST_Module_GlobalDecl() {
        globalDeclList = new AST_DeclList();
    }

    public AST_DeclList getGlobalDeclList() { return globalDeclList; }
    public void setGlobalDeclList(AST_DeclList globalDeclList) { this.globalDeclList = globalDeclList; }
    
    @Override
    public String toString(){
        return globalDeclList.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
        retStr = retStr + globalDeclList.toString_Debug(c, l);
        
        return retStr;
    }
}
