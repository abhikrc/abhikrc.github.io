package pmlADT;

import java.util.HashSet;

/**
 * Abstract base class representing a series of receive arguments.
 * @author Choo Wei Chern
 */
public abstract class AST_RecvArgList extends AST_Node{
    public abstract HashSet<Integer> getUses();
    public abstract HashSet<Integer> getMods(); //added
}
