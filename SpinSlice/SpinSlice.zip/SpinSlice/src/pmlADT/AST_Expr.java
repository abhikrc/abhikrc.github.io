package pmlADT;

import java.util.HashSet;

/**
 * Abstract base class for expressions.
 * @author Choo Wei Chern
 */
public abstract class AST_Expr extends AST_Node {
    public abstract HashSet<Integer> getUses();
    public abstract boolean isAlwaysTrue();
    public abstract boolean willSpawnNewProcess();
    
    public abstract AST_AnyExpr_Run extractRun();
}
