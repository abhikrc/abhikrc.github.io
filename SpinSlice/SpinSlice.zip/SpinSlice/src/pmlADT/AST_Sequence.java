package pmlADT;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing a series of steps.
 * @author Choo Wei Chern
 */
public class AST_Sequence extends AST_Node {
    private ArrayList<AST_Step> steps;
    
    public AST_Sequence() {
        steps = new ArrayList<AST_Step>();
    }
    
    public void addStep(AST_Step para){ steps.add(para); }
    public ArrayList<AST_Step> getSteps() { return steps; }
    
    /*
     * added by lss 
     */
    public AST_Step getStep(int index) {
        if(index<0 ||index>steps.size())
            return null;
        return steps.get(index);
    }
    
    @Override
    public String toString(){
        String retStr = "";
        int size = steps.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + steps.get(i).toString();
            retStr = retStr + ";\n";
        }
        return retStr;
    }  
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
          
	retStr = retStr + "";
        int size = steps.size();
        for (int i = 0; i < size; i++){
            retStr = retStr + steps.get(i).toString_Debug(c, l);
            retStr = retStr + ";\n";
        }
        
        return retStr;
    }
    
    public HashSet<INF_TraceStep> getTraceStepsForCriterion(){
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        
        // Look for the first AST_Stmt
        for (int i = 0; i < steps.size(); i++) {
            AST_Step step = steps.get(i);
            if (step instanceof AST_Step_Stmt){
                HashSet<INF_TraceStep> crit = ((AST_Step_Stmt)step).getMainStmt().getTraceStepsForCriterion();
                retObj.addAll(crit);
                break;
            }
        }
        return retObj;
    }
}
 