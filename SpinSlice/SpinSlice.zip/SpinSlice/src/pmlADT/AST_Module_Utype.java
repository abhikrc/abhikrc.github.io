package pmlADT;

/**
 * Node representing a series of user-defined variables.
 * @author Choo Wei Chern
 */
public class AST_Module_Utype extends AST_Module {
    private String typeName;
    private AST_DeclList memberDeclList;

    public AST_Module_Utype() {}

    public AST_DeclList getMemberDeclList() { return memberDeclList; }
    public void setMemberDeclList(AST_DeclList memberDeclList) { this.memberDeclList = memberDeclList; }

    public String getTypeName() { return typeName; }
    public void setTypeName(String typeName) { this.typeName = typeName; }
    
    @Override
    public String toString(){
        return "typedef " + typeName + "{\n" + memberDeclList.toString() + "}\n";
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
   
        retStr = retStr + "typedef " + typeName + "{\n" + memberDeclList.toString_Debug(c,l) + "}\n";
        
        return retStr;
    }
    
}
