package pmlADT;

import java.util.Hashtable;
/**
 * Translate a Mtype symbolic name into a constant number.
 * @author Choo Wei Chern
 */
public class MtypeSymbolsTable {
    Hashtable<String, Integer> symHash;
    int mCount;
    
    public MtypeSymbolsTable() {
        mCount = 1;
        symHash = new Hashtable<String, Integer>();
    }
    
    public Integer nameToInt(String name){
        return symHash.get(name);
    }
    
    public boolean isMtypeSymbol(String name){
        boolean retVal = symHash.containsKey(name);
        return retVal;
    }
    
    public void insertMtypeSymbol(String name){
        symHash.put(name, mCount);
        mCount++; 
    }
}
