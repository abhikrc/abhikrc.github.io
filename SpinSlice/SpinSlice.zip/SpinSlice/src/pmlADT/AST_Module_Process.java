package pmlADT;

/**
 * Node representing a module of process type declaration.
 * @author Choo Wei Chern
 */
public abstract class AST_Module_Process extends AST_Module {
    public abstract String getProcName();
}
