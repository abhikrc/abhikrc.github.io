package pmlADT;

import java.util.HashSet;

/**
 * Node representing a conditional "any_expressions".
 * @author Choo Wei Chern
 */
public class AST_AnyExpr_CondExpr extends AST_Expr_AnyExpr{
    private AST_Expr_AnyExpr condition;
    private AST_Expr_AnyExpr trueOption;
    private AST_Expr_AnyExpr falseOption;
    
    public AST_AnyExpr_CondExpr() {}

    public void setCondition(AST_Expr_AnyExpr para){ condition = para; }
    public void setTrueOption(AST_Expr_AnyExpr para){ trueOption = para; }
    public void setFalseOption(AST_Expr_AnyExpr para){ falseOption = para; }
    public AST_Expr_AnyExpr getCondition(){ return condition; }
    public AST_Expr_AnyExpr getTrueOption(){ return trueOption; }
    public AST_Expr_AnyExpr getFalseOption(){ return falseOption; }
    
    @Override
    public String toString(){
        return "(" + condition.toString() + "->" + trueOption.toString() + 
            ":" + falseOption.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
         
	retStr = retStr + "(" + condition.toString_Debug(c,l) + "->" + trueOption.toString_Debug(c, l) + 
            ":" + falseOption.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(condition.getUses());
        retObj.addAll(trueOption.getUses());
        retObj.addAll(falseOption.getUses());
        return retObj;
    }
   
    @Override
    public boolean isAlwaysTrue(){
        return false;
    }
    
    @Override
    public boolean willSpawnNewProcess() {
        return (condition.willSpawnNewProcess() || trueOption.willSpawnNewProcess() || falseOption.willSpawnNewProcess());
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        AST_AnyExpr_Run cond = condition.extractRun();
        AST_AnyExpr_Run trueOpt = trueOption.extractRun();
        AST_AnyExpr_Run falseOpt = falseOption.extractRun();
        
        if (cond == null){
            if (trueOpt == null){
                return falseOpt;
            }
            else {
                if (falseOpt == null){
                    return trueOpt;
                } // else error
            }
        } else{
            if (trueOpt == null){
                if (falseOpt == null){
                    return cond;
                } // else err
            } // else err  
        }
        throw new RuntimeException("Multiple run expressions in a single statement unsupported");
    }
}
