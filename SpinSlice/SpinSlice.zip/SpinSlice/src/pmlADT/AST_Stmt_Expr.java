package pmlADT;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Node representing a statement of expression.
 * @author Choo Wei Chern
 */
public class AST_Stmt_Expr extends AST_Stmt implements INF_TraceStep{
    private AST_Expr expr;
    private int traceStepNo;
    private AST_Node encParent;

    public AST_Stmt_Expr(TraceStepNodesTable st, StmtTable stmtT, int line, AST_Node enc) {
        st.InsertNode(this, line);
        stmtT.InsertStmt(this, line);
        encParent = enc;
    }

    public AST_Expr getExpr() { return expr; }
    public void setExpr(AST_Expr expr) { this.expr = expr; }
    
    @Override
    public String toString(){
        return expr.toString();
    }
    @Override
    public String toString_Debug(boolean c, boolean l){
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
       
	retStr = retStr + expr.toString_Debug(c, l);
        
        return retStr;
    }
    
    @Override
    public int getPhyStartLineNo() { return getPhyStartLine(); }
    @Override
    public int getPhyEndLineNo() { return getPhyEndLine(); }
    @Override
    public void setTraceStepNo(int no) { traceStepNo = no; }
    @Override
    public int getTraceStepNo() { return traceStepNo; }
    
    @Override
    public HashSet<Integer> getUses(){
        HashSet<Integer> retObj = new HashSet<Integer>();
        retObj.addAll(expr.getUses());
        return retObj;
    }
    
    @Override
    public HashSet<Integer> getMods(){
        return new HashSet<Integer>();
    }
    
    @Override
    public boolean hasAlwaysTrueExecute(){
        return expr.isAlwaysTrue();
    }
    
    @Override
    public boolean willSpawnNewProcess() {
        return expr.willSpawnNewProcess();
    }
    
    @Override
    public AST_AnyExpr_Run extractRun() {
        return expr.extractRun();
    }
    
    @Override
    public HashSet<INF_TraceStep> getTraceStepsForCriterion() {
        HashSet<INF_TraceStep> retObj = new HashSet<INF_TraceStep>();
        retObj.add(this);
        return retObj;
    }
    
    @Override
    public AST_Node getEnclosingParent() {
        return encParent;
    }
    
    @Override
    public ArrayList<INF_TraceStep> getAllControlDependent() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public INF_TraceStep getDirectControlDependent() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
