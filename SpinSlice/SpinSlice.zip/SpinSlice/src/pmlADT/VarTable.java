package pmlADT;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Set;

/** 
 * Stores a information of declared variables.
 * Maps (scope, String of variable name) <--> (Unique Integer representing the var)
 * @author Choo Wei Chern
 */
public class VarTable implements Cloneable {
    public final static int GLOBAL = -1;
    
    int currIndex; // Running number for the varIndex
    
    Hashtable<String, Integer> varHash; // Stores from <varname,scope> to <varindex>
    ArrayList<String> varList;          // Stores from <varindex> to <varname,scope>
    
    /** Creates a new instance of VarTable */
    public VarTable() {
        currIndex = 0;
        varHash = new Hashtable<String, Integer>(50);
        varList = new ArrayList<String>();
    }
    
    /**
     * Method to get the index of a variable.
     * @param varName Variable name.	
     * @param scope Integer value representing the scope.
     * @return its current index, if varName in the scope is found.
     * @return OTHERWISE return null
     */
    public Integer getIndex(String varName, int scope){
        String combined = convToStr(varName, scope);
        return varHash.get(combined);
    }
    
    /**
     * Method to get the scope of a variable from its varIndex.
     * @param varIndex Index of the variable.	
     * @return scope value of the variable if found. 
     * @return OTHERWISE return null
     */
    public Integer getScope(int varIndex){
        if (varIndex < 0 || varIndex >= varList.size()){
            return null;
        }
        String combined = varList.get(varIndex);
        return scopeFromStr(combined);
    }
    
    /**
     * Method to determing if a variable is global.
     * @param varIndex Index of the variable.	
     * @return true if global
     */
    public boolean isGlobalVar(int varIndex){
        if (varIndex < 0 || varIndex >= varList.size()){
            return false;
        }
        String combined = varList.get(varIndex);
        return (GLOBAL==scopeFromStr(combined));
    }
    
    /**
     * Method to get the name of a variable from its varIndex.
     * @param varIndex Index of the variable.	
     * @return name of the variable if found.
     * @return OTHERWISE return null
     */    
    public String getName(int varIndex){
        if (varIndex < 0 || varIndex >= varList.size()){
            return null;
        }
        String combined = varList.get(varIndex);
        return nameFromStr(combined);
    }
    
    /**
     * Method to insert a variable.
     * @param varName Variable name.	
     * @param scope Integer value representing the scope.
     * @return the varIndex assigned to the added variable, or the existing varIndex if it already exists
     */
    public Integer insertVar(String varName, int scope){
        if (getIndex(varName,scope) == null){
            String combined = convToStr(varName,scope);
            
            varList.add(currIndex,combined);
            varHash.put(combined,currIndex);
            
            currIndex++;
            return currIndex-1;
        }
        else {
            // Already exists
            return getIndex(varName,scope);
        }
    }
    /**
     * Method to determine if variable exists
     * @param varName Variable name.	
     * @return true if exist, otherwise false.
     */
    public boolean varExists(String varName){
        for (int i = 0; i < varList.size(); i++){
            String tmp = nameFromStr(varList.get(i));
            if (varName.compareTo(tmp) == 0 ) return true;
        }
        return false;
    }
    
    private String convToStr(String varName, int scope){
        String scopeStr = ((Integer)scope).toString() + ":";
        return scopeStr + varName;
    }
    private Integer scopeFromStr(String combined){
        int pos = combined.indexOf(':');
        String scopeStr = combined.substring(0,pos);
        return Integer.parseInt(scopeStr);
    }
    private String nameFromStr(String combined){
        int pos = combined.indexOf(':');
        String name = combined.substring(pos+1);
        return name;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        VarTable retVal = new VarTable();
        retVal.currIndex = 0;
        
        Hashtable<String, Integer> retVarHash = new Hashtable<String, Integer>(50);
        ArrayList<String> retVarList = new ArrayList<String>();
        
        // Deep copy hash
        Set<String> keys = varHash.keySet();
        Iterator<String> keyIt = keys.iterator();
        while(keyIt.hasNext()){
            String tmpKey = keyIt.next();
            Integer tmpVal = varHash.get(tmpKey);
            retVarHash.put(tmpKey, tmpVal);
        }
        
        // Deep copy arraylist
        ListIterator<String> listIt = varList.listIterator();
        while (listIt.hasNext()){
            String tmpVal = listIt.next();
            retVarList.add(tmpVal);
        }
        
        retVal.varHash = retVarHash;
        retVal.varList = retVarList;
        
        return retVal;
    }
    
    
    //////////// For Debugging purposes /////////////
    public void debug_displayVarTable(){
        System.out.println(varHash.toString());
        System.out.println(varList.toString());
    }
}
