package pmlADT;

/**
 * For unparsed Never/Trace modules
 * @author Choo Wei Chern
 */
public class AST_Module_Dummy extends AST_Module{

    @Override
    public String toString() {
        return "Unsupported Never/Trace module";
    }

    @Override
    public String toString_Debug(boolean c, boolean l) {
        String retStr = "";
        if (c) retStr = retStr + getClass().getSimpleName().substring(4);
        if (l) retStr = retStr + "(" + phy_startline + "-" + phy_endline + ")";
        retStr = retStr + "~";
        
        return "Unsupported Never/Trace module";
    }
}
