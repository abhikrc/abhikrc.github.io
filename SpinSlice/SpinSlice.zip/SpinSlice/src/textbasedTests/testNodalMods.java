package textbasedTests;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;
import pmlADT.TraceStepNodesTable;
import pmlADT.VarTable;
import pmlADT.INF_TraceStep;
import pmlParser.SourceParser;

/**
 *
 * @author Choo Wei Chern
 */
public class testNodalMods {
public static void main(String[] args) {
        SourceParser test;
        System.out.print("Starting parse\n");
        try{
            test = new SourceParser(new FileInputStream("most2.pml"));
           // VarTable tb = test.getVarTable();
            TraceStepNodesTable snT = test.getSnTable();
            VarTable vt = test.getVarTable();
            
            for (int i = 0; i < snT.getSize(); i ++){
                INF_TraceStep tmp = snT.getStmt(i);
                Iterator<Integer> it = tmp.getMods().iterator();
                
                System.out.print(tmp + " modifies : ");
                while (it.hasNext()){
                    int ind = it.next();
                    System.out.print(vt.getName(ind));
                    if (vt.isGlobalVar(ind)){
                        System.out.print("(G) ");
                    }else{
                        System.out.print("(L) ");
                    }
                    
                }
                System.out.println();
            }
            
            
        }catch(FileNotFoundException e){
         
            System.out.println(e);
            
        }
        System.out.print("Ending parse");

    }
}
