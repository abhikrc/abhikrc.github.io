package textbasedTests;

import pmlParser.*;
import pmlADT.*;
import pmlException.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 *
 * @author Choo Wei Chern
 */
public class testTraceParser {
    public static void main(String[] args) {
        SourceParser srcP;
        System.out.println("Starting parse");
       
        try{
            srcP = new SourceParser(new FileInputStream("leak.pml"));
            // AST_Program tmp =  srcP.getAST();
            VarTable vt = srcP.getVarTable();
            VarTable vt2 = (VarTable) vt.clone();
        //    System.out.print(tmp.toString());
            
      //      StepParser test = new StepParser(vt2, srcP.getMtypeTable(),);
            
            String testString = "want = i";
  //          AST_Stmt tmpRes = test.parseStmt(testString);
            
    //        System.out.println(tmpRes.toString());
            
        }catch(FileNotFoundException e){
            System.out.println(e);
   //     } catch (PmlParseException e){
     //       System.out.println("Trace parsing error: " + e.getMessage());
        }catch (CloneNotSupportedException e){
            System.out.println(e);
        }       
        
        System.out.println("Ending parse");

    }
}
