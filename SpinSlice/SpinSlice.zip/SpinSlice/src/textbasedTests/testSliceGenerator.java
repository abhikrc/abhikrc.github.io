package textbasedTests;

import infiniteCheck.InfiniteCheckHelper;
import infiniteCheck.InfiniteSliceGenerator;
import pmlException.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import CFGBuilder.CFG_Builder;
import CFGBuilder.CFG_Node;

import pmlADT.AST_Module;
import pmlADT.AST_Process_Init;
import pmlADT.AST_Process_ProcType;
import pmlADT.AST_Program;
import pmlADT.AST_Sequence;
import pmlADT.AST_Step;
import pmlADT.AST_Step_Stmt;
import pmlADT.INF_TraceStep;
import pmlADT.VarTable;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.SliceGenerator;
import pmlAnalyser.adt.AllProcVarsState;
import pmlAnalyser.adt.CriterionTuple;
import pmlAnalyser.adt.Reason;
import pmlAnalyser.adt.SliceAndReasons_List;
import pmlAnalyser.adt.TraceListTuple;
import pmlAnalyser.adt.Trace_List;

/**
 * 
 * @author Choo Wei Chern
 */
public class testSliceGenerator {
	public static void testMetalock() {
		try {
			InfiniteSliceGenerator isg = new InfiniteSliceGenerator(
					new FileInputStream(
							"D:\\workspace\\ss\\forSlicing\\metalock\\metalock_noArray.txt"));
			Trace_List trace = new Trace_List();
			ArrayList<CriterionTuple> crit = new ArrayList<CriterionTuple>();
			ArrayList<AllProcVarsState> apvsList = new ArrayList<AllProcVarsState>();

			SliceGenerator sG = isg.getSG();
			boolean isAssertFailure = sG
					.generateTraceAndCriterionList(
							new FileInputStream(
									"D:\\workspace\\ss\\forSlicing\\metalock\\metalock_noArray_fair.trail"),
							trace, crit, apvsList, "");
			// System.out.println("\n\nPrinting full listing from trace");
			// System.out.println("Linear trace : ");
			// System.out.print( sG.debug_TraceList(trace.getLinear()));
			// System.out.println("\n\nCyclic trace : ");
			// System.out.print( sG.debug_TraceList(trace.getCycle()));

			/* lss */
			VarTable vt = sG.getVarTable();
			Integer vIndex = vt.getIndex("acc0", -1);

			HashSet<ProcStepPair> sliceList = new HashSet<ProcStepPair>();
			HashSet<AST_Step> relevantList = new HashSet<AST_Step>();
            HashSet<CriterionTuple> critList = new HashSet<CriterionTuple>();

			isg.checkWithStatic(vIndex, trace.getAll(), sliceList,
							relevantList, critList);

			System.out.println("\n\nprinting slice list: <procId, stepId>");

			INF_TraceStep its;
			for (ProcStepPair psp : sliceList) {
				its = sG.getSnTable().getStmt(psp.getStepInd());
				System.out.println("<" + psp.getProcId() + ", "
						+ psp.getStepInd() + "> " + its.toString()
						+ ", startline=" + its.getPhyStartLineNo()
						+ ", endline=" + its.getPhyEndLineNo());
			}

			System.out.println("\n\nprinting relevant list:");
			for (AST_Step asp : relevantList) {
				System.out.println(((AST_Step_Stmt) asp).toString());
			}
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (PmlNodeDeterminationException e) {
			System.out.println(e);
		} catch (PmlParseException e) {
			System.out.println(e);
		}
	}
	public static void testMost() {
		try {
            SliceGenerator sG = new SliceGenerator(new FileInputStream(
                    "D:\\workspace\\ss\\forSlicing\\most\\most_noEventNonFair.txt"));
            Trace_List trace = new Trace_List();
			ArrayList<CriterionTuple> crit = new ArrayList<CriterionTuple>();
			ArrayList<AllProcVarsState> apvsList = new ArrayList<AllProcVarsState>();

            boolean isAssertFailure = sG
					.generateTraceAndCriterionList(
							new FileInputStream(
//									"D:\\workspace\\ss\\forSlicing\\most\\MOST_v4_wc_fair2.trail"),
							"D:\\workspace\\ss\\forSlicing\\most\\most_noEventNonFair_fair.trail"),
							trace, crit, apvsList, "configSuccess");

			/* lss */
			VarTable vt = sG.getVarTable();
			Integer vIndex = vt.getIndex("configSuccess", -1);

			HashSet<ProcStepPair> sliceList = new HashSet<ProcStepPair>();
			HashSet<AST_Step> relevantList = new HashSet<AST_Step>();
            HashSet<CriterionTuple> critList = new HashSet<CriterionTuple>();

			InfiniteSliceGenerator isg = new InfiniteSliceGenerator(sG);
			isg.checkWithStatic(vIndex, trace.getAll(), sliceList,
							relevantList, critList);

            crit.clear();
            crit.addAll(critList);
			System.out.println("\n\nprinting slice list: <procId, stepId>");

			INF_TraceStep its;
			for (ProcStepPair psp : sliceList) {
				its = sG.getSnTable().getStmt(psp.getStepInd());
				System.out.println("<" + psp.getProcId() + ", "
						+ psp.getStepInd() + "> " + its.toString()
						+ ", startline=" + its.getPhyStartLineNo()
						+ ", endline=" + its.getPhyEndLineNo());
			}

			System.out.println("\n\nprinting relevant list:");

			for (AST_Step asp : relevantList) {
				int line = -1;
				try{
					line = ((AST_Step_Stmt) asp).getMainStmt().getPhyStartLine();
				}catch(Exception e){}
				System.out.println(((AST_Step_Stmt) asp).toString() + "@" + line);
			}

			System.out.println("\n\nCriterion list:");
			for(CriterionTuple ctp : crit){
				System.out.println("<" + ctp.getSourcePID() + ", " + ctp.getNodeID() + ", "
						+ ctp.getLineNoOfTrace() + ">");
			}

			SliceAndReasons_List srl = sG.generateSliceAndReasonLists(isAssertFailure, true, true,
					trace, crit);

			 System.out.println("\n\nPrinting dynamic sliced listing");
			 System.out.println(sG.debug_BackwardSlice(srl.getSliceList()));
			 System.out.println(sG.debug_BackwardSlice_Ind(srl.getSliceList()));

		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (PmlNodeDeterminationException e) {
			System.out.println(e);
		} catch (PmlParseException e) {
			System.out.println(e);
		}
	}
//	public static void testMost() {
//		try {
//			InfiniteSliceGenerator isg = new InfiniteSliceGenerator(
//					new FileInputStream(
////							"D:\\workspace\\ss\\forSlicing\\most\\MOST_v4_wc.txt"));
//					"D:\\workspace\\ss\\forSlicing\\most\\most_noEventNonFair.txt"));
//			Trace_List trace = new Trace_List();
//			ArrayList<CriterionTuple> crit = new ArrayList<CriterionTuple>();
//			ArrayList<AllProcVarsState> apvsList = new ArrayList<AllProcVarsState>();
//
//			SliceGenerator sG = isg.getSG();
//			boolean isAssertFailure = sG
//					.generateTraceAndCriterionList(
//							new FileInputStream(
////									"D:\\workspace\\ss\\forSlicing\\most\\MOST_v4_wc_fair2.trail"),
//							"D:\\workspace\\ss\\forSlicing\\most\\most_noEventNonFair_fair.trail"),
//							trace, crit, apvsList, "");
//			// System.out.println("\n\nPrinting full listing from trace");
//			// System.out.println("Linear trace : ");
//			// System.out.print( sG.debug_TraceList(trace.getLinear()));
//			// System.out.println("\n\nCyclic trace : ");
//			// System.out.print( sG.debug_TraceList(trace.getCycle()));
//
//			/* lss */
//			VarTable vt = sG.getVarTable();
//			Integer vIndex = vt.getIndex("configSuccess", -1);
//
//			HashSet<ProcStepPair> sliceList = new HashSet<ProcStepPair>();
//			HashSet<AST_Step> relevantList = new HashSet<AST_Step>();
//
//			crit.clear();
//			isg.checkWithStatic(vIndex, trace.getAll(), sliceList,
//							relevantList, crit);
//
//			System.out.println("\n\nprinting slice list: <procId, stepId>");
//
//			INF_TraceStep its;
//			for (ProcStepPair psp : sliceList) {
//				its = sG.getSnTable().getStmt(psp.getStepInd());
//				System.out.println("<" + psp.getProcId() + ", "
//						+ psp.getStepInd() + "> " + its.toString()
//						+ ", startline=" + its.getPhyStartLineNo()
//						+ ", endline=" + its.getPhyEndLineNo());
//			}
//
//			System.out.println("\n\nprinting relevant list:");
//
//			for (AST_Step asp : relevantList) {
//				int line = -1;
//				try{
//					line = ((AST_Step_Stmt) asp).getMainStmt().getPhyStartLine();
//				}catch(Exception e){}
//				System.out.println(((AST_Step_Stmt) asp).toString() + "@" + line);
//			}
//
//
//			System.out.println("\n\nCriterion list:");
//			for(CriterionTuple ctp : crit){
//				System.out.println("<" + ctp.getSourcePID() + ", " + ctp.getNodeID() + ", "
//						+ ctp.getLineNoOfTrace() + ">");
//			}
//
//			SliceAndReasons_List srl = sG.generateSliceAndReasonLists(isAssertFailure, true, true,
//					trace, crit);
//
//			 System.out.println("\n\nPrinting dynamic sliced listing");
//			 System.out.println(sG.debug_BackwardSlice(srl.getSliceList()));
//			 System.out.println(sG.debug_BackwardSlice_Ind(srl.getSliceList()));
//
//		} catch (FileNotFoundException e) {
//			System.out.println(e);
//		} catch (PmlNodeDeterminationException e) {
//			System.out.println(e);
//		} catch (PmlParseException e) {
//			System.out.println(e);
//		}
//	}

	public static void testSliceGenerator() {
		try {
			SliceGenerator sG = new SliceGenerator(new FileInputStream(
					"D:\\workspace\\ss\\forSlicing\\test_CFG\\trace.pml"));
			Trace_List trace = new Trace_List();
			ArrayList<CriterionTuple> crit = new ArrayList<CriterionTuple>();
			ArrayList<AllProcVarsState> apvsList = new ArrayList<AllProcVarsState>();
			boolean isAssertFailure = sG
					.generateTraceAndCriterionList(
							new FileInputStream(
									"D:\\workspace\\ss\\forSlicing\\test_CFG\\trace.trail"),
							trace, crit, apvsList, "");
			// System.out.println("\n\nPrinting full listing from trace");
			// System.out.print( sG.debug_TraceList(trace));

			/* lss */
			AST_Program tmp = sG.getAST();
			CFG_Builder.buildFullCFG(tmp);
			CFG_Node forSearchNode = null;
			// System.out.print(CFG_Builder.toStringCFG());
			ArrayList<CFG_Node> allNodes = CFG_Builder.allNodesCol;
			VarTable vt = sG.getVarTable();
			Integer bIndex = vt.getIndex("b", -1);
			for (int i = 0; i < allNodes.size(); i++) {
				AST_Step startStep = allNodes.get(i).getStartStep();
				// System.out.println(startStep.toString());
				HashSet<Integer> uses = startStep.getUses();
				if (uses != null && uses.contains(bIndex)) {
					forSearchNode = allNodes.get(i);
				}
			}
			try {
				HashSet<TraceListTuple> pre_tlps = new HashSet<TraceListTuple>();
				HashSet<AST_Step> bSteps = new HashSet<AST_Step>();
				CFG_Builder.searchFirstBlockedSteps(
					forSearchNode, trace.getLinear(), pre_tlps, bSteps);
				for(AST_Step step : bSteps){
					System.out.println("result = " + step.toString());
					System.out.println("pre_tlps = ");
				}
				for (TraceListTuple tlp : pre_tlps) {
					System.out.print("nodeID:" + tlp.getNodeID());
					System.out.println(" sourcePID:" + tlp.getSourcePID());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			// ArrayList<ProcStepPair> sliceList = new
			// ArrayList<ProcStepPair>();
			// ArrayList<ArrayList<Reason>> reasonsList = new
			// ArrayList<ArrayList<Reason>>();
			//            
			// // sG.generateSliceAndReasonLists(isAssertFailure, true, true,
			// trace, crit, sliceList, reasonsList);
			//           
			// System.out.println("\n\nPrinting sliced listing");
			// System.out.println(sG.debug_BackwardSlice(sliceList));
			// System.out.println(sG.debug_BackwardSlice_Ind(sliceList));

			int a = 1;
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (PmlNodeDeterminationException e) {
			System.out.println(e);
		} catch (PmlParseException e) {
			System.out.println(e);
		}

	}

	public static void printSG() {
		try {
			SliceGenerator sG = new SliceGenerator(new FileInputStream(
					"D:\\workspace\\ss\\forSlicing\\most\\most2.pml"));
			AST_Program astp = sG.getAST();
			for (AST_Module module : astp.getModList()) {
				if (module instanceof AST_Process_Init) {
					AST_Sequence seq = ((AST_Process_Init) module)
							.getSequence();
					ArrayList<AST_Step> asts = seq.getSteps();
					System.out
							.println("**************************AST_Module start");
					for (int i = 0; i < asts.size(); i++) {
						System.out.println("Step " + i + ": "
								+ asts.get(i).toString());
					}
					System.out
							.println("**************************AST_Module end");
				} else if (module instanceof AST_Process_ProcType) {
					AST_Sequence seq = ((AST_Process_ProcType) module)
							.getSequence();
					ArrayList<AST_Step> asts = seq.getSteps();
					System.out
							.println("**************************AST_Module start");
					for (int i = 0; i < asts.size(); i++) {
						System.out.println("Step " + i + ": "
								+ asts.get(i).toString());
					}
					System.out
							.println("**************************AST_Module end");
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
		// testSliceGenerator.testSliceGenerator();
		// testSliceGenerator.printSG();
		// testSliceGenerator.testMetalock();
		testSliceGenerator.testMost();
	}
}
