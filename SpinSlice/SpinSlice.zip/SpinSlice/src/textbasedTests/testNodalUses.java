package textbasedTests;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;
import pmlADT.TraceStepNodesTable;
import pmlADT.VarTable;
import pmlADT.INF_TraceStep;
import pmlParser.SourceParser;

/**
 *
 * @author Choo Wei Chern
 */
public class testNodalUses {
    public static void main(String[] args) {
        SourceParser test;
        System.out.print("Starting parse\n");
        try{
            test = new SourceParser(new FileInputStream("most2.pml"));
           // VarTable tb = test.getVarTable();
            TraceStepNodesTable snT = test.getSnTable();
            VarTable vt = test.getVarTable();
            
            for (int i = 0; i < snT.getSize(); i ++){
                INF_TraceStep tmp = snT.getStmt(i);
                Iterator<Integer> it = tmp.getUses().iterator();
                
                System.out.print(tmp + " uses : ");
                while (it.hasNext()){
                    Integer ind = it.next();
                    if (ind==null) continue;
                    System.out.print(vt.getName(ind));
                     if (vt.isGlobalVar(ind)){
                        System.out.print("(G) ");
                    }else{
                        System.out.print("(L) ");
                    }
                }
                System.out.println();
            }
            
            
        }catch(FileNotFoundException e){
         
            System.out.println(e);
            
        }
        System.out.print("Ending parse");

    }
}
