package textbasedTests;

import pmlParser.*;
import pmlADT.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;

import CFGBuilder.*;
/**
 *
 * @author Choo Wei Chern
 */
public class testSourceParser {
    
    /** Creates a new instance of Main */
    public testSourceParser() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SourceParser test;
        System.out.print("Starting parse");
        try{
            test = new SourceParser(new FileInputStream("D:\\workspace\\ss\\forSlicing\\most\\MOST_v4_wc.txt"));
            AST_Program tmp =  test.getAST();
           CFG_Builder.buildFullCFG(tmp);
           CFG_Node forSearchNode = null;
           //System.out.print(CFG_Builder.toStringCFG());
//           ArrayList<CFG_Node> allNodes = CFG_Builder.allNodesCol;
//           VarTable vt = test.getVarTable();
//           Integer bIndex = vt.getIndex("", -1);
//           for(int i = 0; i<allNodes.size(); i++) {
//        	   AST_Step startStep = allNodes.get(i).getStartStep();
//        	   HashSet<Integer> mods = startStep.getMods();
//        	   if(mods.contains(bIndex)){
//        		   forSearchNode = allNodes.get(i);
//        	   }        	   
//           }
           
            
           //System.out.print(tmp.toString());
            //System.out.print(tmp.toString_Debug(true,true));
            //int tmp;
            //tb.debug_displayVarTable();
            TraceStepNodesTable st = test.getSnTable();
            
            int i = 1;
        }catch(FileNotFoundException e){         
            System.out.println(e);
        }
        System.out.print("Ending parse");
    }
    
}
