package pmlAnalyser.dependenceTool;

import java.util.ArrayList;
import java.util.HashSet;
import pmlADT.TraceStepNodesTable;
import pmlADT.INF_TraceStep;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.ProcVarPair;
import pmlAnalyser.adt.TraceListTuple;

/**
 * Checker class for ready dependence.
 * @author Choo Wei Chern
 */
public class ReadyDepChecker{
    private TraceStepNodesTable snTable;

    public ReadyDepChecker(TraceStepNodesTable snTable) {
        this.snTable = snTable;
    }
    
    public boolean consider(ArrayList<ProcStepPair> sliceList, TraceListTuple tlTup, HashSet<ProcVarPair> useList) {
        // Check if there exists a statement of the same process which is in the slice
        int sPid = tlTup.getSourcePID();
        boolean exists = false;
        for (int i = 0; i < sliceList.size(); i++) {
            ProcStepPair procStepPair = sliceList.get(i);
            if (sPid == procStepPair.getProcId()){
                exists = true;
                break;
            }
        }
        if (exists == false){
            return false;
        }
        
        return !hasTrueExecutability(tlTup.getNodeID());
    }
    
    private boolean hasTrueExecutability(int nodeNo){
        INF_TraceStep tmp = snTable.getStmt(nodeNo);
        
        boolean retVal = tmp.hasAlwaysTrueExecute();
        
        return retVal;
        // Possible improvements.
        // a) Check expressions type for always true expression based on dynamic values
        // b) If (all var used in expr are local && there exist a step of the same procID in later trace) then true
    }
}
