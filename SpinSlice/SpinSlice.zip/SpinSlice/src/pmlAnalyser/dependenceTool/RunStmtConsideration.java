package pmlAnalyser.dependenceTool;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import pmlADT.ProcTypeTable;
import pmlADT.TraceStepNodesTable;
import pmlADT.VarTable;
import pmlADT.AST_AnyExpr_Run;
import pmlADT.AST_Decl;
import pmlADT.AST_Expr_AnyExpr;
import pmlADT.AST_IVar;
import pmlADT.AST_Process_ProcType;
import pmlADT.INF_TraceStep;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.ProcVarPair;
import pmlAnalyser.adt.TraceListTuple;

/**
 * Checker class for data/interference dependence in run statements.
 * Run stmts will produce another thread. The issue we need to is the passing of parameters from one process to another
 * If the target's variable is in the uselist when this run stmt is executed, the target variable must be alias with the caller's parameter
 * 
 * Current limitation: Does not work for statements with multiple RUN.
 * @author Choo Wei Chern
 */
public class RunStmtConsideration {
    private TraceStepNodesTable snTable;
    private ProcTypeTable pTable;
    private VarTable vTable;
        
    
    public RunStmtConsideration(TraceStepNodesTable snTable, ProcTypeTable pTable, VarTable vTable) {
        this.snTable = snTable;
        this.pTable = pTable;
        this.vTable = vTable;        
    }
    
    public boolean process(TraceListTuple tlTup, HashSet<ProcVarPair> useList, Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo){
        int nodeId = tlTup.getNodeID();
        INF_TraceStep node = snTable.getStmt(nodeId);
        // Return if stmt does not contains a run stmt
        if (!node.willSpawnNewProcess()) return false;
        
        int sourcePid = tlTup.getSourcePID();
        int targetPid = tlTup.getTargetPID();
        
        AST_AnyExpr_Run runStmt = node.extractRun();
        
        if (runStmt.getRunArgs()==null){
            // No parameters, so no need to check further;
            return false;
        }
        
        String procTypeName = runStmt.getProcName();
        AST_Process_ProcType proc = (AST_Process_ProcType)pTable.getProcType(pTable.getProcNo(procTypeName));
        int procId = pTable.getProcNo(procTypeName);
        
        
        ArrayList<AST_Expr_AnyExpr> sourceArgs = runStmt.getRunArgs().getListOfAnyExpr();
        ArrayList<AST_Decl> destArgs = proc.getDeclList().getDeclList();
        
        if (doCheckAndMatchUp(sourceArgs,destArgs,useList,useInfo,procId,sourcePid,targetPid, nodeId)){
            return true;
        }
        return false;
    }
    
    private boolean doCheckAndMatchUp(ArrayList<AST_Expr_AnyExpr> sourceArgs, ArrayList<AST_Decl> destArgs, HashSet<ProcVarPair> useList, Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo, int procId, int sourcePid, int targetPid, int nodeId){
        ArrayList<Integer> destList = new ArrayList<Integer>();
        // Converting to standardise list format for destination args
        for (int i = 0; i < destArgs.size(); i++) {
            AST_Decl similarTypeGroup = destArgs.get(i);
            ArrayList<AST_IVar> varList = similarTypeGroup.getIvList();
            for (int j = 0; j < varList.size(); j++) {
                AST_IVar var = varList.get(j);
                int varInd = vTable.getIndex(var.getVarName(), procId);
                destList.add(varInd);
            }
        }
        
        // Check arrays are of same length
        if (destList.size()!=sourceArgs.size()){
            throw new RuntimeException("Error occur while matching length of parameter list of a run statement with the proctype's declaration");
        }
        
        boolean hasUpdatedUseList = false;
        // Check if target list has a declaration of a variable in uselist
        for (int i = 0; i < destList.size(); i++) {
            int varInd = destList.get(i);
            if (useList.contains(new ProcVarPair(varInd, targetPid))){
                // Target parameter is in useList.
                // Add the respective source variables that can affect the target parameter into useList
                HashSet<ProcVarPair> sourceVars = convertToPair(sourceArgs.get(i).getUses(),sourcePid);
                if (sourceVars.size()!=0){
                    hasUpdatedUseList = true;
                }
                // Update useList
                useList.addAll(sourceVars);
               
                Iterator itUsedPvars = sourceVars.iterator();
                while (itUsedPvars.hasNext()){
                    ProcVarPair pv = (ProcVarPair)itUsedPvars.next();
                    HashSet<ProcStepPair> linesUsingVar = useInfo.get(pv);
                    if (linesUsingVar==null){
                        linesUsingVar = new HashSet<ProcStepPair>();
                        linesUsingVar.add(new ProcStepPair(nodeId, sourcePid));
                        useInfo.put(pv, linesUsingVar);
                    }else{
                        linesUsingVar.add(new ProcStepPair(nodeId, sourcePid));
                    }
                }
            }
        }
        return hasUpdatedUseList;
    }
    private HashSet<ProcVarPair> convertToPair(HashSet<Integer> oriSet, int pid){
        Iterator<Integer> it = oriSet.iterator();
        HashSet<ProcVarPair> retObj = new HashSet<ProcVarPair>();
        
        while (it.hasNext()){
            int varId = it.next();
            if (vTable.isGlobalVar(varId)){
                retObj.add(new ProcVarPair(varId, -1));
            }else {
                retObj.add(new ProcVarPair(varId, pid));
            }
        }
        return retObj;
    }
    
}
