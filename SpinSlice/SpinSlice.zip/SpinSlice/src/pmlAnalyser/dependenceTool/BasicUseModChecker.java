package pmlAnalyser.dependenceTool;

import java.util.HashSet;
import java.util.Iterator;
import pmlADT.TraceStepNodesTable;
import pmlADT.VarTable;
import pmlADT.INF_TraceStep;
import pmlAnalyser.adt.ProcVarPair;
import pmlAnalyser.adt.TraceListTuple;

/**
 * Checker class for data/interference dependence.
 * @author Choo Wei Chern
 */
public class BasicUseModChecker{
    private TraceStepNodesTable snTable;
    private VarTable vTable;

    public BasicUseModChecker(TraceStepNodesTable snTable, VarTable vTable) {
        this.snTable = snTable;
        this.vTable = vTable;
    }    
    
    public HashSet<ProcVarPair> getVarsModifiedAndInUseList(TraceListTuple tlTup, HashSet<ProcVarPair> useList) {
        int sourcePid = tlTup.getSourcePID();
        int nodeId = tlTup.getNodeID();
        INF_TraceStep step = snTable.getStmt(nodeId);
        HashSet<ProcVarPair> modSet = convertToPair(step.getMods(), sourcePid);
        return common(modSet, useList);
    }
    
    private HashSet<ProcVarPair> common(HashSet<ProcVarPair> set1, HashSet<ProcVarPair> set2){
        HashSet<ProcVarPair> commonList = new HashSet<ProcVarPair>();
        Iterator<ProcVarPair> it1 = set1.iterator();
        while(it1.hasNext()){
            ProcVarPair tmp = it1.next();
            if (set2.contains(tmp)) {
                commonList.add(tmp);
            }
        }
        return commonList;
    }
    private HashSet<ProcVarPair> convertToPair(HashSet<Integer> oriSet, int pid){
        Iterator<Integer> it = oriSet.iterator();
        HashSet<ProcVarPair> retObj = new HashSet<ProcVarPair>();
        
        while (it.hasNext()){
            int varId = it.next();
            if (vTable.isGlobalVar(varId)){
                retObj.add(new ProcVarPair(varId, -1));
            }else {
                retObj.add(new ProcVarPair(varId, pid));
            }
        }
        return retObj;
    }
}
