package pmlAnalyser;

import pmlADT.AST_Program;
import pmlAnalyser.adt.ProcVarPair;
import pmlAnalyser.adt.ProcStepPair;
import pmlAnalyser.adt.TraceListTuple;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;

import pmlADT.ProcTypeTable;
import pmlADT.StmtTable;
import pmlADT.TraceStepNodesTable;
import pmlADT.VarTable;

import pmlADT.INF_TraceStep;

import pmlAnalyser.adt.AllProcVarsState;
import pmlAnalyser.adt.CriterionTuple;
import pmlAnalyser.adt.ProcIdTable;
import pmlAnalyser.adt.Reason;
import pmlAnalyser.adt.Reason_DataDep;
import pmlAnalyser.adt.Reason_Simple;
import pmlAnalyser.adt.Reason_RdyDep;
import pmlAnalyser.adt.SliceAndReasons_List;
import pmlAnalyser.adt.Trace_List;
import pmlAnalyser.dependenceTool.BasicUseModChecker;
import pmlAnalyser.dependenceTool.ReadyDepChecker;
import pmlAnalyser.dependenceTool.RunStmtConsideration;
import pmlException.PmlNodeDeterminationException;
import pmlParser.StepParser;
import pmlParser.SourceParser;
import pmlException.PmlParseException;

/**
 * The main class of the entire tool.
 * Accepts traces as input, parse and produce a slice.
 * @author Choo Wei Chern
 */
public class SliceGenerator {    
    private SourceParser sParser;
    private StepParser stParser;
    private TraceStepNodesTable snTable;
    private VarTable vTable;
    private ProcTypeTable pTable;
    private StmtTable stmtTable;
    
    private RunStmtConsideration runConsider;
    
    private ProcIdTable pIdTable;
    
    private boolean toCheckUseMod = true;
    private BasicUseModChecker useModCheck;
    
    private boolean toCheckRdyDep = true;
    private ReadyDepChecker rdyCheck;
    
    
    /**
     * Constructor.
     * @param codeStream The promela source code.
     */
    public SliceGenerator(InputStream codeStream){
        sParser = new SourceParser(codeStream);
        snTable = sParser.getSnTable();
        vTable = sParser.getVarTable();
        pTable = sParser.getProcTypeTable();
        stmtTable = sParser.getStmtTable();
        pIdTable = new ProcIdTable();
                
        stParser = new StepParser(sParser.getVarTable(),sParser.getMtypeTable(),pIdTable,snTable,stmtTable);
        
        useModCheck = new BasicUseModChecker(snTable, vTable);
        rdyCheck = new ReadyDepChecker(snTable);
        runConsider = new RunStmtConsideration(snTable, pTable, vTable);
        
    }

    /* ss */
    public VarTable getVarTable(){
    	return sParser.getVarTable();
    }

    /* ss */
    public AST_Program getAST(){
        return sParser.getAST();
    }
    
    /** 
     * Takes in a dynamic trace and generates: tracelist, reasonlist, criterionlist, variableInfolist and returns the type of error trace.
     * @param traceStream the stream of trace
     * @param returnTraceList the list of trace which will be populated by this method
     * @param returnCriterionList the list of criterion which will be populated by this method
     * @param returnVarInfoList the list of variable information at each step.
     * @param ltlVars string of variables involved in the violated ltl/buchi automata property. Variables are space separated.
     * @return  true if trace is due to assertion failure, false otherwise
     **/   
    public boolean generateTraceAndCriterionList(InputStream traceStream, Trace_List returnTraceList, ArrayList<CriterionTuple> returnCriterionList, ArrayList<AllProcVarsState> returnVarInfoList, String ltlVars) throws PmlParseException,PmlNodeDeterminationException {
        return stParser.generateTraceAndCriterionList(traceStream, returnTraceList, returnCriterionList, returnVarInfoList,ltlVars);
    }
 
    
    /**
     * Accepts the tracelist and criterion as well as boolean inputs related to which dependences to check for, and return the relevant slice and reasons for including it in the slice.
     * @param isAssertFailure boolean input indicating if the trace is due to assertion failure
     * @param ckUseMod boolean input to indicate checking of data/interference dependence
     * @param ckRdy boolean input to indicate checking of ready dependence.
     * @param traceList input list of trace.
     * @param criterionList input list of criterion.
     * @return list of slice its respective reasons. 
     */
    public SliceAndReasons_List generateSliceAndReasonLists(boolean isAssertFailure, boolean ckUseMod, boolean ckRdy, Trace_List traceList, ArrayList<CriterionTuple> criterionList){
        SliceAndReasons_List retList = new SliceAndReasons_List(new ArrayList<HashSet<Reason>>(), new ArrayList<ProcStepPair>(), new HashSet<Integer>());
        
        toCheckUseMod = ckUseMod;
        toCheckRdyDep = ckRdy;
        
        // Check if any criteria selected
        if (criterionList == null || criterionList.size() == 0) {
            return retList;
        }
        

        for (int i = 0; i < criterionList.size(); i++){
            retList.mergeWith(generateSliceAndReasonLists_SingleCrit(isAssertFailure, traceList, criterionList.get(i)));
        }
        
        return retList;
    }

    // Generate the slice and reason list for 1 criteria
    private SliceAndReasons_List generateSliceAndReasonLists_SingleCrit(boolean isAssertFailure, Trace_List traceList, CriterionTuple criterion){
        // ReasonsLists is paired with sliceList. The reasons for sliceList(x) is in reasonsList(x)
        ArrayList<ProcStepPair> sliceList = new ArrayList<ProcStepPair>();
        ArrayList<HashSet<Reason>> reasonsList = new ArrayList<HashSet<Reason>>();
        HashSet<Integer> traceListNo_Set = new HashSet<Integer>();
        SliceAndReasons_List srList = new SliceAndReasons_List(reasonsList, sliceList, traceListNo_Set);
        HashSet<ProcVarPair> useList = new HashSet<ProcVarPair>();
        Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo = new Hashtable<ProcVarPair, HashSet<ProcStepPair>>();
        
        // Criterion is always added to sliceList
        initialiseSlice(isAssertFailure, srList, useInfo, useList, criterion);
    
            
        // Do backward scan from criterion   

        int startIndex; // used to be called lastIndex. represent the index of the starting point
        int critLine = criterion.getLineNoOfTrace();
        if (critLine == -1){
            // Start trace from last line of the trace
            startIndex = traceList.totalSize()-1;
        }else{
            // Start trace 1 line above the criterion line. (-1)
            // -1 again for offset of criterion line to actual index.
            startIndex = critLine - 1 - 1 ;
            
            // -1 for conversion from 1-based to 0-based
            traceListNo_Set.add(critLine-1); //added
        }
        
        int sizeOfLinear = traceList.linearSize();
        
        // ADDED FOR CYCLE
        if (startIndex >= sizeOfLinear){
            // Cyclic trace involved. Do unroll cycle twice, after which do the linear trace
            int endIndex = sizeOfLinear;
            doScan(startIndex, endIndex, traceList, sliceList, reasonsList, useList, useInfo, traceListNo_Set);         
            doScan(startIndex, endIndex, traceList, sliceList, reasonsList, useList, useInfo, traceListNo_Set);             
        }else{
            // Normal trace, do just linear trace
            int endIndex = 0;
            // scan from criterion until first item in trace (index 0)
            doScan(startIndex, endIndex, traceList, sliceList, reasonsList, useList, useInfo, traceListNo_Set);
        }
        
/* previous version
        int lastIndex;
        int critLine = criterion.getLineNoOfTrace();
        if (critLine == -1){
            // Start trace from last line of the trace
            lastIndex = traceList.size()-1;
        }else{
            // Start trace 1 line above the criterion line. (-1)
            // -1 again for offset of criterion line to actual index.
            lastIndex = critLine - 1 - 1 ;
        }
        
        for (int i = lastIndex; i >=0 ; i--){
            TraceListTuple tlTup = traceList.get(i);
            toAdd = false;
            // Start off with empty list of reasons. IE, no reason to add it to slice
            reasonsForASlice = new HashSet<Reason>();
            
            // Ready dependence check
            if(toCheckRdyDep && rdyCheck.consider(sliceList, tlTup, useList)){
                toAdd = true;
                reasonsForASlice.add(new Reason_RdyDep());
            }
            
            // Data dependence check
            if (toCheckUseMod){
                HashSet<ProcVarPair> commonList = useModCheck.getVarsModifiedAndInUseList(tlTup, useList);
                if (commonList.size() != 0) {
                    toAdd = true;
                    
                    ///// Section for: Generate reasons
                    INF_TraceStep step = snTable.getStmt(tlTup.getNodeID());
                    HashSet<Integer> modList = step.getMods();
                    Iterator<Integer> iterModVars = modList.iterator();
                    // Generarate varnames for variables modified by this line
                    String varNames = "";
                    varNames = varNames + vTable.getName(iterModVars.next()); 
                    while (iterModVars.hasNext()){
                        varNames = varNames + ", ";
                        varNames = varNames + vTable.getName(iterModVars.next());
                    }
                    HashSet<ProcStepPair> dependees = new HashSet<ProcStepPair>();
                    Iterator<ProcVarPair> itModPvars = commonList.iterator(); // Reset iterator
                    // For each modified var, get list of dependees
                    while (itModPvars.hasNext()){
                        HashSet<ProcStepPair> linesUsingVar = useInfo.get(itModPvars.next());
                        if (linesUsingVar != null) dependees.addAll(linesUsingVar);
                    }
                    reasonsForASlice.add(new Reason_DataDep(dependees, varNames));
                    ////// End of section for generate reasons
                }
            }
            
            // Special considerations for run stmts
            if (toCheckUseMod && specialConsiderationForRunStmts(tlTup, useList, useInfo)){
                toAdd = true;
                reasonsForASlice.add(new Reason_Simple("This line calls a new process whose initialised parameter(s) are relevant to the slice."));
                // Note, runStmtconsiderations will manually update useInfo and useList, since not all parameters "used" might be relevant to the slice.
            }   
            
            if (toAdd){
                addToSlice(sliceList, useInfo, useList, tlTup);
                reasonsList.add(reasonsForASlice);
            }
        } */
        
        Collections.reverse(sliceList);
        Collections.reverse(reasonsList);
        
        return srList;

    }
    
    // Initialise the slice by considering what criterion is to be set.
    private void initialiseSlice(boolean isAssertFailure, SliceAndReasons_List srList, Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo, HashSet<ProcVarPair> useList, CriterionTuple cTup){
        ArrayList<ProcStepPair> sliceList = srList.getSliceList();
        ArrayList<HashSet<Reason>> reasonsList = srList.getReasonsList();
        
        if (isAssertFailure){
            HashSet<Reason> tmp = new HashSet<Reason>();
            tmp.add(new Reason_Simple("This line is added as it fails an assertion"));
            reasonsList.add(tmp);
        }else{
            HashSet<Reason> tmp = new HashSet<Reason>();
            tmp.add(new Reason_Simple("This line as it is choosen as a criteria point."));
            reasonsList.add(tmp);
            
        }
        addToSlice_Criteria(sliceList, useInfo, useList, cTup);
    }
    
    private boolean specialConsiderationForRunStmts(TraceListTuple tlTup, HashSet<ProcVarPair> useList, Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo){
        return runConsider.process(tlTup, useList, useInfo);
    }
    
    private void updateUseInfo(Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo
        , TraceListTuple tlTup, HashSet<ProcVarPair> commonList){
        ////// Section for updating useInfo
        // Since this line is goin to be added to slice, useInfo should reflect variables used by this line
        // In addition, modified vars should be cleared of their respective lines.
        INF_TraceStep step = snTable.getStmt(tlTup.getNodeID());
        Iterator<ProcVarPair> itModPvars = commonList.iterator(); // Reset iterator
        
        while (itModPvars.hasNext()){
            useInfo.remove(itModPvars.next());
            // Clear modified var's info
        } 
        HashSet<ProcVarPair> usedByThisLine = convertToPair(step.getUses(), tlTup.getSourcePID());
        Iterator itUsedPvars = usedByThisLine.iterator();
        while (itUsedPvars.hasNext()){
            ProcVarPair pv = (ProcVarPair)itUsedPvars.next();
            HashSet<ProcStepPair> linesUsingVar = useInfo.get(pv);
            if (linesUsingVar==null){
                linesUsingVar = new HashSet<ProcStepPair>();
                linesUsingVar.add(new ProcStepPair(tlTup.getNodeID(), tlTup.getSourcePID()));
                useInfo.put(pv, linesUsingVar);
            }else{
                linesUsingVar.add(new ProcStepPair(tlTup.getNodeID(), tlTup.getSourcePID()));
            }
        }
    }
    
    
    /*
        ArrayList<ProcStepPair> sliceList = new ArrayList<ProcStepPair>();
        ArrayList<HashSet<Reason>> reasonsList = new ArrayList<HashSet<Reason>>();
        SliceAndReasons_List srList = new SliceAndReasons_List(reasonsList, sliceList);
        HashSet<ProcVarPair> useList = new HashSet<ProcVarPair>();
        Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo = new Hashtable<ProcVarPair, HashSet<ProcStepPair>>();
*/
    private void doScan(int startIndex, int endIndex, Trace_List traceList, ArrayList<ProcStepPair> sliceList, ArrayList<HashSet<Reason>> reasonsList, HashSet<ProcVarPair> useList, Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo, HashSet<Integer> traceListNo_Set){
        // Create tmp list for storing multiple reasons for a single line of slice
        HashSet<Reason> reasonsForASlice = new HashSet<Reason>(); //added
        
        boolean toAdd;
        for (int i = startIndex; i >=endIndex ; i--){
            TraceListTuple tlTup = traceList.getEither(i);
            toAdd = false;
            // Start off with empty list of reasons. IE, no reason to add it to slice
            reasonsForASlice = new HashSet<Reason>();
            
            // Ready dependence check
            if(toCheckRdyDep && rdyCheck.consider(sliceList, tlTup, useList)){
                toAdd = true;
                reasonsForASlice.add(new Reason_RdyDep());
            }
            
            // Data dependence check
            if (toCheckUseMod){
                HashSet<ProcVarPair> commonList = useModCheck.getVarsModifiedAndInUseList(tlTup, useList);
                if (commonList.size() != 0) {
                    toAdd = true;
                    
                    ///// Section for: Generate reasons
                    INF_TraceStep step = snTable.getStmt(tlTup.getNodeID());
                    HashSet<Integer> modList = step.getMods();
                    Iterator<Integer> iterModVars = modList.iterator();
                    // Generarate varnames for variables modified by this line
                    String varNames = "";
                    varNames = varNames + vTable.getName(iterModVars.next()); 
                    while (iterModVars.hasNext()){
                        varNames = varNames + ", ";
                        varNames = varNames + vTable.getName(iterModVars.next());
                    }
                    HashSet<ProcStepPair> dependees = new HashSet<ProcStepPair>();
                    Iterator<ProcVarPair> itModPvars = commonList.iterator(); // Reset iterator
                    // For each modified var, get list of dependees
                    while (itModPvars.hasNext()){
                        HashSet<ProcStepPair> linesUsingVar = useInfo.get(itModPvars.next());
                        if (linesUsingVar != null) dependees.addAll(linesUsingVar);
                    }
                    reasonsForASlice.add(new Reason_DataDep(dependees, varNames));
                    ////// End of section for generate reasons
                }
            }
            
            // Special considerations for run stmts
            if (toCheckUseMod && specialConsiderationForRunStmts(tlTup, useList, useInfo)){
                toAdd = true;
                reasonsForASlice.add(new Reason_Simple("This line calls a new process whose initialised parameter(s) are relevant to the slice."));
                // Note, runStmtconsiderations will manually update useInfo and useList, since not all parameters "used" might be relevant to the slice.
            }   
            
            if (toAdd){
                addToSlice(sliceList, useInfo, useList, tlTup);
                reasonsList.add(reasonsForASlice);
                
                traceListNo_Set.add(i); //added
            }
        }
    }
    
    private void updateUseInfo_Critieria(Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo
        , CriterionTuple cTup){
        
        // Special version of updateUseInfo(), meant for criteria initialising.
        // Does not remove modified variables from info
        
        ////// Section for updating useInfo
        // Since this line is goin to be added to slice, useInfo should reflect variables used by this line
        INF_TraceStep step = snTable.getStmt(cTup.getNodeID());
        
        HashSet<ProcVarPair> usedByThisLine = convertToPair(step.getUses(), cTup.getSourcePID());
        Iterator itUsedPvars = usedByThisLine.iterator();
        while (itUsedPvars.hasNext()){
            ProcVarPair pv = (ProcVarPair)itUsedPvars.next();
            HashSet<ProcStepPair> linesUsingVar = useInfo.get(pv);
            if (linesUsingVar==null){
                linesUsingVar = new HashSet<ProcStepPair>();
                linesUsingVar.add(new ProcStepPair(cTup.getNodeID(), cTup.getSourcePID()));
                useInfo.put(pv, linesUsingVar);
            }else{
                linesUsingVar.add(new ProcStepPair(cTup.getNodeID(), cTup.getSourcePID()));
            }
        }
    }

    private void addToSlice(ArrayList<ProcStepPair> sliceList, Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo, HashSet<ProcVarPair> useList, TraceListTuple tlTup ){
        int sourcePid = tlTup.getSourcePID();
        int nodeId = tlTup.getNodeID();
        INF_TraceStep step = snTable.getStmt(nodeId);

        HashSet<ProcVarPair> modSet = convertToPair(step.getMods(), sourcePid);
        HashSet<ProcVarPair> useSet = convertToPair(step.getUses(), sourcePid);
        
        // Update useInfo
        HashSet<ProcVarPair> commonList = new HashSet<ProcVarPair>();
        commonList.addAll(modSet);
        commonList.retainAll(useList);
        // Commonlist is the list of variables modified by this line, and is in the useList
        updateUseInfo(useInfo, tlTup, commonList);
        
        // Update useList
        useList.removeAll(modSet);
        useList.addAll(useSet);
        
        // Add to slice
        sliceList.add(new ProcStepPair(nodeId, sourcePid));
    }
    private void addToSlice_Criteria(ArrayList<ProcStepPair> sliceList, Hashtable<ProcVarPair, HashSet<ProcStepPair>> useInfo, HashSet<ProcVarPair> useList, CriterionTuple cTup ){
        // Special version of addToSlice for adding criteria
        // Does not remove modified variables from useList and useInfo
        int sourcePid = cTup.getSourcePID();
        int nodeId = cTup.getNodeID();
        INF_TraceStep step = snTable.getStmt(nodeId);
        HashSet<ProcVarPair> useSet = convertToPair(step.getUses(), sourcePid);
        
        // Update useInfo
       updateUseInfo_Critieria(useInfo, cTup);
        
        // Update useList
        useList.addAll(useSet);
        
        // Add to slice
        sliceList.add(new ProcStepPair(nodeId, sourcePid));
    }
 
    private HashSet<ProcVarPair> convertToPair(HashSet<Integer> oriSet, int pid){
        Iterator<Integer> it = oriSet.iterator();
        HashSet<ProcVarPair> retObj = new HashSet<ProcVarPair>();
        
        while (it.hasNext()){
            Integer varId = it.next();
            if (vTable.isGlobalVar(varId)){
                retObj.add(new ProcVarPair(varId, -1));
            }else {
                retObj.add(new ProcVarPair(varId, pid));
            }
        }
        return retObj;
    }
    
    //// For debug purposes ////
    public String debug_TraceList(ArrayList<TraceListTuple> list){
        String retStr = "";
        for (int i = 0; i < list.size(); i++) {
            TraceListTuple traceListTuple = list.get(i);
            retStr = retStr + (traceListTuple.getSourcePID()+
                "->"+traceListTuple.getTargetPID()+ ": " +
                snTable.getStmt(traceListTuple.getNodeID()).toString()) + "\n";
        }
        return retStr;
    }
    public String debug_BackwardSlice(ArrayList<ProcStepPair> list){
        String retStr = "";
        for (int i = list.size()-1; i>=0; i--) {
            ProcStepPair procStepPair = list.get(i);
            retStr = retStr + (procStepPair.getProcId() +": " +
                    snTable.getStmt(procStepPair.getStepInd()).toString()) + "\n";
          
        }
        return retStr;
    }
    public String debug_BackwardSlice_Ind(ArrayList<ProcStepPair> list){
        String retStr = "";
        ArrayList<ArrayList<ProcStepPair>> indlist = new ArrayList<ArrayList<ProcStepPair>>();
            
        int maxPid = 0;
        for (int i = list.size()-1; i>=0; i--) {
            ProcStepPair procStepPair = list.get(i);
            int pId = procStepPair.getProcId();
            if (pId> maxPid) maxPid = pId;             
        }
        for (int i =0 ; i <= maxPid; i++){
            indlist.add(new ArrayList<ProcStepPair>());
        }
        for (int i = list.size()-1; i>=0; i--) {
            ProcStepPair procStepPair = list.get(i);
            int pId = procStepPair.getProcId();
            indlist.get(pId).add(procStepPair);          
        }
        
        for (int i =0 ; i <= maxPid; i++){
            retStr = retStr + ("Steps for pid " + i) + "\n";
            for (int j = 0; j<indlist.get(i).size();j++) {
                ProcStepPair procStepPair = indlist.get(i).get(j);
                retStr = retStr + (procStepPair.getProcId()  +": "  +
                snTable.getStmt(procStepPair.getStepInd()).toString()) + "\n";
            }
            retStr = retStr + "\n";
        }
        return retStr;
    }

    /**
     * Accessor
     * @return a ProcId table storing the collections of spawned processes and their process ID
     */
    public ProcIdTable getPIdTable() {
        return pIdTable;
    }
    
    /**
     * Accessor
     * @return a procType table storing the collections of processType declarations.
     */
    public ProcTypeTable getPTable() {
        return pTable;
    }
    
    
    /**
     * Accessor
     * @return a table of potential nodes that can appear in a trace.
     */
    public TraceStepNodesTable getSnTable() {
        return snTable;
    }
    
  
}
