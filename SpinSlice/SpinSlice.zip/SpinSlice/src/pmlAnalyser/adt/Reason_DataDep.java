package pmlAnalyser.adt;

import java.util.HashSet;

/**
 * The type of Reason used if a slice is added due to data/interference dependence
 * @author Choo Wei Chern
 */
public class Reason_DataDep extends Reason {
    HashSet<ProcStepPair> depNodes;
    String varNames;

    public Reason_DataDep(HashSet<ProcStepPair> para, String varNames) {
        this.depNodes = para;
        this.varNames = varNames;
    }       
    
    public HashSet<ProcStepPair> getDependentNodes() {
        return depNodes;
    } 
    
    public String getAffectVarNames(){
        return varNames;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;       
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;      
        
        final Reason_DataDep otherReason = (Reason_DataDep)obj;
        HashSet<ProcStepPair> d = otherReason.getDependentNodes();
        String v = otherReason.getAffectVarNames();
        return (v.equals(varNames) && d.equals(depNodes));
    }
    @Override
    public int hashCode() {
        return depNodes.hashCode() * varNames.hashCode();
    }
}
