package pmlAnalyser.adt;

/**
 * A tuple of tracestepnode, processId, and the step no on the trace list..
 * @author Choo Wei Chern
 */
public class CriterionTuple {
    private int sourcePID;
    private int lineNo; // represents the line no of the trace (starting from 1. -1 is used for statements blocked (for instance deadlocks criterion)
    private int nodeID;

    public CriterionTuple(int sourcePID, int lineNo, int nodeID) {
        this.sourcePID = sourcePID;
        this.lineNo = lineNo;
        this.nodeID = nodeID;
    }

    public int getLineNoOfTrace() { return lineNo; }
    public void setLineNoOfTrace(int lineNo) { this.lineNo = lineNo;}

    public int getNodeID() {return nodeID;}
    public void setNodeID(int nodeID) {this.nodeID = nodeID;}

    public int getSourcePID() {return sourcePID;}
    public void setSourcePID(int sourcePID) {this.sourcePID = sourcePID;}
}
