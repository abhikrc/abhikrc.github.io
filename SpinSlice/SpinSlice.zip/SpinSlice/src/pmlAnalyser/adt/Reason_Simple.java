package pmlAnalyser.adt;

/**
 * The generic type of Reason used where the coder manually indicates the reason.
 * @author Choo Wei Chern
 */
public class Reason_Simple extends Reason {
    String reason;

    public Reason_Simple(String reason) {
        this.reason = reason;
    }
    
    public String getReasonString(){
        return reason;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;       
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;      
        final String str = ((Reason_Simple)obj).getReasonString();  
        return reason.equals(str);
    }
    @Override
    public int hashCode() {
        return reason.hashCode();
    }
}
