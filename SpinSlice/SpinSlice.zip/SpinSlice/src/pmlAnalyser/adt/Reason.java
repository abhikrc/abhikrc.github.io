package pmlAnalyser.adt;


/**
 * Abstract base class for storing a reason for including a line in the slice.
 * @author Choo Wei Chern
 */
public abstract class Reason {
}
