package pmlAnalyser.adt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;

/**
 * Data structure to store the value of all variables at a given point of time.
 * @author Choo Wei Chern
 */
public class AllProcVarsState {
    Hashtable<Integer, SingleProc_VarsState> procIdToVarsStateHash;
    
    /**
     * Constructor.
     */
    public AllProcVarsState() {
       procIdToVarsStateHash = new Hashtable<Integer, SingleProc_VarsState>();
    }
    private AllProcVarsState(Hashtable<Integer, SingleProc_VarsState> para) {
       procIdToVarsStateHash = para;
    }
    
    /**
     * Method to update a particular variable's value
     * @param procId process Id of which the local variable belongs to. If this is a global var, use procId as -1
     * @param varString String of the variable to store.
     * @param value New value of the variable.
     */
    public void updateVarState(int procId, String varString, int value){
        SingleProc_VarsState spvs = procIdToVarsStateHash.get(procId);
        if (spvs == null){
            spvs = new SingleProc_VarsState();
        }
        spvs.updateVar(varString, value);
        procIdToVarsStateHash.put(procId, spvs);
    }
    
    /**
     * Returns a formatted string that displays the variables' and their values for a given process
     * @param procId process Id of the process.
     * @return formatted string of the variables and their values.
     */
    public String getDisplayString(int procId){
        SingleProc_VarsState spvs = procIdToVarsStateHash.get(procId);
        if (spvs == null) return ""; // No variable states yet.
        
        ArrayList<String> displayStrList = new ArrayList();
        Hashtable<String, Integer> varToValueHash = spvs.getVariablesHash();
        Iterator<String> itVars = varToValueHash.keySet().iterator();
        while(itVars.hasNext()){
            String varStr = itVars.next();
            Integer varVal = varToValueHash.get(varStr);
            
            String displayStr = varStr+ " = " + varVal.toString();
            displayStrList.add(displayStr);
        }
        
        Collections.sort(displayStrList);
        String retVal = "";
        for (int i = 0; i < displayStrList.size(); i++) {
            String string = displayStrList.get(i);
            retVal = retVal + string + "\n";
        }
        
        return retVal;
    }
    
    public AllProcVarsState duplicate(){
         Hashtable<Integer, SingleProc_VarsState> copyHash = new Hashtable<Integer, SingleProc_VarsState>();
         Iterator<Integer> itKeys = procIdToVarsStateHash.keySet().iterator();
         
         while (itKeys.hasNext()){
             Integer key = itKeys.next();
             SingleProc_VarsState spvs = procIdToVarsStateHash.get(key);
             copyHash.put(key, spvs.duplicate());
         }
         
         return new AllProcVarsState(copyHash);
    }
    
    
    
    /////////////////////////////////////////////////////////////
    private class SingleProc_VarsState{
        // Stores the variable states for a single process
        Hashtable<String, Integer> varNameToInt;
        // Default constructor
        public SingleProc_VarsState() { varNameToInt = new Hashtable<String, Integer>(); }
        // Constructor with initialised hash.
        public SingleProc_VarsState(Hashtable<String, Integer> varNameToInt) { this.varNameToInt = varNameToInt; }
        
        void updateVar(String name, Integer value){ varNameToInt.put(name, value); }
        public Hashtable<String, Integer> getVariablesHash() {
            return varNameToInt;
        }
        
        public SingleProc_VarsState duplicate(){
            Hashtable<String, Integer> copyHash = new Hashtable<String, Integer>();
            Iterator<String> itKeys = varNameToInt.keySet().iterator();
            
            while (itKeys.hasNext()){
                String key = itKeys.next();
                Integer value = varNameToInt.get(key);
                
                copyHash.put(key, value);
            }
            
            return new SingleProc_VarsState(copyHash);
        }
    }
}
