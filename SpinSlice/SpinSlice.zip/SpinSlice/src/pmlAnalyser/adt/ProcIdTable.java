package pmlAnalyser.adt;

import java.util.ArrayList;

/**
 * Associates a spawned process's ID in a trace to the proctype name.
 * @author Choo Wei Chern
 */
public class ProcIdTable {
    ArrayList<String> procNameList;

    public ProcIdTable() {
        procNameList = new ArrayList<String>();
    }
    
    public void addProcName(String name){
        // Assumes Pid is assigned sequentially in trace
        procNameList.add(name);
    }
    
    public String getProcName_ViaTraceProcID(int no){
        return procNameList.get(no);
    }
    
    public int getSize(){
        return procNameList.size();
    }
    
}
