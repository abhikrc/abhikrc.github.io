package pmlAnalyser.adt;

import java.util.ArrayList;

/**
 * ADT to represent the error trace
 * @author Choo Wei Chern
 */
public class Trace_List {
  
    
    // For the non-cyclic part
    ArrayList<TraceListTuple> linearTrace;
    
    // For the cyclic part
    ArrayList<TraceListTuple> cyclicTrace;

    public Trace_List() {
        linearTrace = new ArrayList<TraceListTuple>();
        cyclicTrace = new ArrayList<TraceListTuple>();
    }

    public void addLinear(TraceListTuple para){
        linearTrace.add(para);
    }
    
    public void addCyclic(TraceListTuple para){
        cyclicTrace.add(para);
    }

    public boolean isCyclic(){
        return (!cyclicTrace.isEmpty());
    }
    /* ss */
    public ArrayList<TraceListTuple> getLinear() {
    	return linearTrace;
    }
    public ArrayList<TraceListTuple> getCycle(){
    	return cyclicTrace;
    }
    
    public int linearSize(){
        return linearTrace.size();
    }
    public TraceListTuple getLinear(int i){
        return linearTrace.get(i);
    } 
    public int totalSize(){
        return linearTrace.size() + cyclicTrace.size();
    }
    
    public ArrayList<TraceListTuple> getAll(){
    	ArrayList<TraceListTuple> ret = new ArrayList<TraceListTuple>();
    	ret.addAll(linearTrace);
    	ret.addAll(cyclicTrace);
    	return ret;
    }
    
    public String toString(){
    	String msg = "Linear trace : \n";
    	for(TraceListTuple tlp : linearTrace){
    		msg += tlp.toString() + "\n";
    	}
    	msg += "Cyclic trace : \n";
    	for(TraceListTuple tlp : cyclicTrace){
    		msg += tlp.toString() + "\n";
    	}
    	return msg;
    }
    /**
     * Returns a trace from either the linear part or cyclic part
     * @param index if index is less than linearSize, then index correspond to linear index. else (index-linearSize) correspond to cyclic index
     * @return a trace from either the linear part or cyclic part
     */
    public TraceListTuple getEither(int index){
        if (index < linearSize()){
            return linearTrace.get(index);
        }else
        {
            return cyclicTrace.get(index-linearSize());
        }
    }

}
