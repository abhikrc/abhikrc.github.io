package pmlAnalyser.adt;

/**
 * The type of Reason used if a slice is added due to ready dependence
 * @author Choo Wei Chern
 */
public class Reason_RdyDep extends Reason {
    public String getReasonString() {
        return "This statement's executability can vary between true and false at points of time.\nThus this line can control when the statements following it can be executed.";
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;       
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;      
        
        return true;
    }
    
    @Override
    public int hashCode() {
        return 7;
    }
}
