package pmlAnalyser.adt;

/**
 * A tuple of tracestepnode, processId of the source, processId of the target.
 * The tuple represents a single line of the dynamic trace, where sourceId indicates the calling process.
 * TargetId is usually the same as the sourceId except in the case of Run statements, where the targetID is that of the spawned process's Id.
 * @author Choo Wei Chern
 */
public class TraceListTuple {
    private int sourcePID;
    private int targetPID;
	//= Inf_TraceStep.getTraceStepNo()
    private int nodeID; 

    public TraceListTuple(){
        this.sourcePID = -1;
        this.targetPID = -1;
        this.nodeID = -1;
    }

    public TraceListTuple(int sourcePID, int targetPID, int nodeID) {
        this.sourcePID = sourcePID;
        this.targetPID = targetPID;
        this.nodeID = nodeID;
    }

    public int getNodeID() { return nodeID; }
    public void setNodeID(int nodeID) { this.nodeID = nodeID; }
    public int getSourcePID() { return sourcePID; }
    public void setSourcePID(int sourcePID) { this.sourcePID = sourcePID; }

    public int getTargetPID() { return targetPID; }
    public void setTargetPID(int targetPID) { this.targetPID = targetPID; }
    /**
     * @author lss
     */
    public String toString(){
    	if(nodeID == -1){
    		return null;
    	}
    	return "<sourcePID=" + sourcePID + ", targetPID=" + targetPID + ", nodeID=" + nodeID +">";
    }
}
