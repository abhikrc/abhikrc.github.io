package pmlAnalyser.adt;

/**
 * Datatype storing a pair of process ID and traceStepNode id.
 * The pairing is a reference to a statement with its process in the dynamic trace.
 * @author Choo Wei Chern
 */
public class ProcStepPair {
        int stepInd;
        int procId;
        public ProcStepPair(int stepInd, int procId) {
            this.stepInd = stepInd;
            this.procId = procId;
        }
        public int getProcId() { return procId; }
        public int getStepInd() { return stepInd; }
       @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;       
            if (obj == null) return false;
            if (getClass() != obj.getClass()) return false;      
            final ProcStepPair other = (ProcStepPair) obj;  
            return ( stepInd == other.stepInd && procId == other.procId );
        }
        @Override
        public int hashCode() {
            int hash = 7;
            hash = 31 * hash + stepInd;
            hash = 31 * hash + procId;
            return hash;
        }
}
