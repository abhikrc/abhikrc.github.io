package pmlAnalyser.adt;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Contains a slice as well as their corresponding reasons for being in the list.
 * @author Choo Wei Chern
 */
public class SliceAndReasons_List {
    ArrayList<HashSet<Reason>> reasonsList;
    ArrayList<ProcStepPair> sliceList;
    
    HashSet<Integer> traceListNo_Set; // Stores the index of relevant steps in the trace

    public SliceAndReasons_List(ArrayList<HashSet<Reason>> reasonsList, ArrayList<ProcStepPair> sliceList, HashSet<Integer> traceListNo_Set) {
        this.reasonsList = reasonsList;
        this.sliceList = sliceList;
        
        this.traceListNo_Set = traceListNo_Set; //added
    }

    /**
     * Check whether a certain line in the trace is in the slice
     * @param index the 0-based index of the line in the tracelist 
     * @return true if the line if the line is in the slice, false otherwise
     */
    public boolean traceStepIsInSlice(int index) {
        return traceListNo_Set.contains(index);
    }
    
    public ProcStepPair getSliceStep(int i){
        return sliceList.get(i);
    }
    
    public HashSet<Reason> getReasons(int i){
        return reasonsList.get(i);
    }
    
    public int size(){
        return sliceList.size();
    }

    public ArrayList<HashSet<Reason>> getReasonsList() {
        return reasonsList;
    }

    public ArrayList<ProcStepPair> getSliceList() {
        return sliceList;
    }
    
    /* Merge this slice/reasons list with another
     */
    public void mergeWith(SliceAndReasons_List anotherList){
        if (anotherList == null) return;
             
        ArrayList<HashSet<Reason>> rList = anotherList.getReasonsList();
        ArrayList<ProcStepPair> sList = anotherList.getSliceList();
        
        for (int i = 0; i < sList.size(); i ++){
            int index = sliceList.indexOf(sList.get(i));
            if (index == -1){
                // Not found
                reasonsList.add(rList.get(i));
                sliceList.add(sList.get(i));
            }else{
                // Found, merge reasons
                reasonsList.get(index).addAll(rList.get(i));
            }
        }
        
        
        /// Added
        traceListNo_Set.addAll(anotherList.traceListNo_Set);
    }
    
}
