package pmlAnalyser.adt;

/**
 * Datatype storing a pair of process ID and variable id.
 * The pairing is a reference to a variable with its (process) scope in the dynamic trace.
 * @author Choo Wei Chern
 */
public class ProcVarPair{
        int varInd;
        int procId;
        public ProcVarPair(int varInd, int procId) {
            this.varInd = varInd;
            this.procId = procId;
        }
        public int getProcId() { return procId; }
        public int getVarInd() { return varInd; }
        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;       
            if (obj == null) return false;
            if (getClass() != obj.getClass()) return false;      
            final ProcVarPair other = (ProcVarPair) obj;  
            return ( varInd == other.varInd && procId == other.procId );
        }
        @Override
        public int hashCode() {
            int hash = 7;
            hash = 31 * hash + varInd;
            hash = 31 * hash + procId;
            return hash;
        }
    } 
