
public class TutEx1 extends Thread {
	
	public synchronized static void staticPrint() {
		System.out.println("In staticPrint");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public synchronized void instancePrint()  {
		System.out.println("In instancePrint");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public void run() {
		instancePrint();
	}


	public static void main(String arg[]){
		for(int i = 0; i<10; i++){
			TutEx1 tutex = new TutEx1();
			tutex.start();
		}
	}
}
