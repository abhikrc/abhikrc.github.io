
public class Test extends Thread{
	public void setOther(Test other){
		this.other = other;
	}
	private Test other;
	public synchronized void foo(){
		try {
			Thread.sleep(1000);
			other.foo();
			System.out.println("at the end of foo");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public void run() {
		foo();
	}

	
	public static void main(String arg[]){
		Test A = new Test();
		Test B = new Test();
		A.setOther(B);
		B.setOther(A);
		A.start();
		B.start();
	}
}
