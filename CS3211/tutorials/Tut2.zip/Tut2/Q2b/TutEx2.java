
public class TutEx2 extends Thread {
	
	public synchronized static void staticPrint() {
		System.out.println("In staticPrint");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public synchronized void instancePrint()  {
		System.out.println("In instancePrint");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public void run() {
		staticPrint();
	}


	public static void main(String arg[]){
		for(int i = 0; i<10; i++){
			TutEx2 tutex = new TutEx2();
			tutex.start();
		}
	}
}
